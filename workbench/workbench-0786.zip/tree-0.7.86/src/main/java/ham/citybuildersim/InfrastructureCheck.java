package ham.citybuildersim;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * The road network, from the curve up to a city that actually jams.
 *
 * Three things have to hold and none of them is obvious from the code:
 *
 *   1. The response curve is right - flat until it isn't, and floored.
 *   2. A NEW city is never congested. The base network exists precisely so
 *      that the opening hour is not a wall, which is the mistake the land pass
 *      made when the starting allocation could not fit a power plant.
 *   3. Building a road actually fixes it, and the fix survives a save.
 *
 * The last one is the point of the whole feature. A mechanic the player cannot
 * see themselves solve is just a tax.
 */
public class InfrastructureCheck {

    static int fails = 0;

    static void assertTrue(String label, boolean ok) {
        if (!ok) fails++;
        System.out.printf("%-58s %s%n", label, ok ? "OK" : "FAIL");
    }

    /** Finite, and inside the range the screen's own label claims for it. */
    static boolean sane(double value, double low, double high) {
        return Double.isFinite(value) && value >= low - 1e-9 && value <= high + 1e-9;
    }

    static void close(String label, double actual, double expected) {
        boolean ok = Math.abs(actual - expected) < 1e-9;
        if (!ok) {
            fails++;
            System.out.printf("%-58s FAIL  %.6f != %.6f%n", label, actual, expected);
        } else {
            System.out.printf("%-58s OK%n", label);
        }
    }

    /**
     * True once the month in progress reads the same as the month last struck.
     *
     * A growing city's shops sell more this month than the statement says
     * they sold last month; while that is still moving, a save that rebuilt
     * the statement rather than carrying it would drift, for reasons that
     * have nothing to do with roads. Since the sector template the statement
     * and the ledger are both carried, and this is the test of that.
     */
    static boolean steady(ham.citybuildersim.sectors.Retail shops) {
        return Math.abs(shops.statement().revenue - shops.pending().revenue()) < 1e-9;
    }

    /** How many convenience stores give this much coverage - the fixture's shape, not a count. */
    static int shopsFor(Game g, double coverage) {
        BuildingsTemplate shop = template(g, "Convenience Store");
        return (int) Math.max(1, Math.ceil(coverage / shop.getCoverage()));
    }

    static BuildingsTemplate template(Game game, String name) {
        for (BuildingsTemplate t : game.getBuildingManager().getTemplates()) {
            if (t.getName().equals(name)) return t;
        }
        throw new IllegalStateException("no template named " + name);
    }

    public static void main(String[] args) throws Exception {

        /* ================= 1. the curve, on its own ================= */
        System.out.println("--- the response curve ---");

        InfrastructureManager road = new InfrastructureManager();

        assertTrue("an empty network is not congested", !road.isCongested());
        close("...and carries everything", road.getThroughputRatio(), 1);
        close("a new city starts with a network at all",
                road.getCapacity(), InfrastructureManager.BASE_CAPACITY);

        road.setLoad(InfrastructureManager.BASE_CAPACITY * .5);
        close("half full, still free-flowing", road.getThroughputRatio(), 1);
        assertTrue("...and says so", "Clear".equals(road.getStatus()));

        // Exactly at free flow is the last moment nothing is lost. One unit
        // more and it starts to cost, which is the whole shape of the mechanic.
        road.setLoad(InfrastructureManager.BASE_CAPACITY * InfrastructureManager.FREE_FLOW);
        close("exactly at free flow, still nothing lost", road.getThroughputRatio(), 1);
        assertTrue("...but there is no headroom left", road.getHeadroom() < 1e-9);

        road.setLoad(InfrastructureManager.BASE_CAPACITY * .95);
        assertTrue("just past it, throughput starts falling",
                road.getThroughputRatio() < 1);
        assertTrue("...but only just", road.getThroughputRatio() > .9);
        assertTrue("...and it is congested, not merely busy",
                road.isCongested() && !road.isStrained());

        road.setLoad(InfrastructureManager.BASE_CAPACITY * 100);
        close("hopelessly overloaded, throughput hits the floor",
                road.getThroughputRatio(), InfrastructureManager.MIN_THROUGHPUT);
        assertTrue("...a gridlocked city still moves",
                road.getThroughputRatio() > 0);

        // The floor is what stops congestion being a death spiral: construction
        // is throttled by this same ratio, so a network that could reach zero
        // would leave a city unable to build its way out. See SimulationEngine.
        assertTrue("the floor is well clear of zero",
                InfrastructureManager.MIN_THROUGHPUT > .2);

        /* ================= 2. monotonic, with no cliff ================= */
        System.out.println("\n--- and it degrades smoothly ---");

        boolean monotonic = true;
        boolean smooth = true;
        double previous = 1;
        for (int i = 1; i <= 400; i++) {
            road.setLoad(InfrastructureManager.BASE_CAPACITY * i / 100.0);
            double now = road.getThroughputRatio();
            if (now > previous + 1e-12) monotonic = false;
            if (previous - now > .05) smooth = false;   // no single step off a cliff
            previous = now;
        }
        assertTrue("more traffic never means more throughput", monotonic);
        assertTrue("no cliff edge - one building never costs 5%", smooth);

        /* ================= 3. capacity is what you paid for ================= */
        System.out.println("\n--- what a road buys ---");

        road.setBuiltCapacity(600);
        close("built capacity adds to the base",
                road.getCapacity(), InfrastructureManager.BASE_CAPACITY + 600);
        close("...and the player's share is reported separately",
                road.getBuiltCapacity(), 600);

        road.setLoad(InfrastructureManager.BASE_CAPACITY + 600);
        assertTrue("a network at exactly capacity is congested", road.isCongested());

        road.reset();
        close("reset puts the base network back",
                road.getCapacity(), InfrastructureManager.BASE_CAPACITY);
        close("...with nothing on it", road.getLoad(), 0);

        /* ================= 4. a real city ================= */
        System.out.println("\n--- and now a city that has to live with it ---");

        Path root = Files.createTempDirectory("roads");
        GameFiles files = new GameFiles(root.resolve("data"), root.resolve("no-legacy"));

        Game city = new Game(files);
        city.run();
        // THE TREASURY THIS FIXTURE WAS WRITTEN AGAINST (0.7.10): its build list
        // is bought out of cash, and a city founds on D$100M since 0.7.10, not the
        // D$2.5B it assumed - so it is given that, the Wealthy preset's, explicitly.
        city.setCashForTest(Founding.WEALTHY_CASH);

        assertTrue("a brand new city is not congested",
                !city.getInfrastructureManager().isCongested());
        close("...its roads carry everything", city.getRoadRatio(), 1);

        /*
         * Small enough to stay inside the base network. If this ever starts
         * failing, the opening of the game has become a traffic puzzle, which
         * is not what a first turn should be.
         *
         * SIX MONTHS, NOT TWELVE, since 2026-09-09. What is under test is
         * whether the buildings ON THIS LIST fit inside the base roads, and
         * they do comfortably - 170 of 400 by month five. What broke the
         * twelve-month version is that the works department was quadrupled at
         * the same time, so a year of private investment now adds ninety-five
         * homes of its own on top and the network fills at month eleven. That
         * is the city outgrowing its roads, which is the mechanic working, and
         * it belongs to section 5 below rather than here.
         */
        city.buildStack(template(city, "House"), 40, false);
        /*
         * SIZED FROM THE TEMPLATE. This fixture's whole second half is a city
         * whose shops are the bottleneck the roads have to feed, and it opened
         * with "3 stores" when a store covered 120 people. The retail
         * rebalance of 2026-09-10 made a store cover 480, so three of them fed
         * the grown city with or without roads and the delivered-share
         * assertion below compared 93% against 84% instead of 89% against 35%.
         * The number that matters is 360 of coverage for a thousand people;
         * the count is derived from it.
         */
        city.buildStack(template(city, "Convenience Store"), shopsFor(city, 360), false);
        city.simulateMonths(6);

        System.out.printf("   a starter city: %.0f of %.0f used%n",
                city.getInfrastructureManager().getLoad(),
                city.getInfrastructureManager().getCapacity());
        assertTrue("a starter city still has road to spare",
                city.getInfrastructureManager().getHeadroom() > 0);
        close("...and loses nothing to traffic", city.getRoadRatio(), 1);

        /* ================= 5. growth jams it ================= */
        System.out.println("\n--- growth is what breaks it ---");

        /*
         * GROWN UNTIL IT JAMS. "260 houses" jammed the network two and a half
         * times over when a food plant loaded the roads by 200 and the advisor
         * built several; at a fifth of the size (2026-09-10) the same 260
         * houses loaded it 491 against 400, throughput 73%, and every
         * assertion below about a congested city was being made of one that
         * was merely busy. The fixture's premise is the load, so the lorries
         * the plants used to put on the road come from six builders' yards at
         * 90 apiece instead - a building whose load did not move.
         */
        city.buildStack(template(city, "House"), 260, false);
        city.buildStack(template(city, "Construction Depot"), 6, false);
        city.simulateMonths(30);

        InfrastructureManager net = city.getInfrastructureManager();
        System.out.printf("   grown: %.0f of %.0f used, throughput %.1f%%%n",
                net.getLoad(), net.getCapacity(), city.getRoadRatio() * 100);

        assertTrue("a grown city outruns the network it was given",
                net.isCongested());
        assertTrue("...and the load really is above free flow",
                net.getUtilisation() > InfrastructureManager.FREE_FLOW);
        assertTrue("...it says Congested", "Congested".equals(net.getStatus()));

        // The reason a player notices at all. If congestion did not reach the
        // income statement it would be a number on a screen.
        // The regression guard for a bug the road pass very nearly shipped: the
        // throttle went into simulateMonth() alone, so the build rate the screen
        // quoted - and, worse, the figure construction was PAID for - stayed at
        // the uncongested number while the sites crawled. One definition now,
        // in Game.getConstructionOutput(); this is what proves it is still the
        // one being used.
        /*
         * SICKNESS IS IN HERE TOO, and it was not when this was written.
         *
         * This assertion restates Game.getConstructionOutput()'s formula, which
         * is the duplication trap in miniature: the day a fourth multiplier
         * arrived - workers off ill - the copy was wrong and the original was
         * fine, and this line failed at 285 against 352. That is the harness
         * working as intended, and the fix is to ask the city what its work
         * ratio is rather than to assume it is 1.
         */
        /*
         * ...AND THE CREWS KEPT ON (0.7.17), for the same reason. The builders
         * lay off the crews their work does not need (sectors.Construction,
         * THE CREWS THE WORK NEEDS), and this city's six depots, built for
         * their lorries, have little to build: they keep a share of their
         * posts, and their capacity works at that share - the city's own
         * works department, which has no posts, whole. The copy missed it and
         * read 191 against 383: the crews laid off counted as working.
         */
        double depots = city.getBuildingManager().getTotalConstructionCapacity() - BuildingManager.BASE_CONSTRUCTION;
        double undiscounted = (city.getBuildingManager().getTotalConstructionCapacity()
                        - depots * (1 - city.getSectors().construction().getPostsOfferedShare()))
                * city.getSectors().construction().getAverageFill()
                * city.getHealth().getWorkRatio();
        assertTrue("the builders are slowed by it too",
                city.getConstructionOutput() < undiscounted);
        close("...by exactly the throughput ratio",
                city.getConstructionOutput(),
                Math.round(undiscounted * city.getRoadRatio()));

        assertTrue("the shops feel it",
                city.getSectors().retail().getRoadRatio() < 1);

        /* ================= 6. building a road fixes it ================= */
        System.out.println("\n--- and building a road fixes it ---");

        BuildingsTemplate roadNetwork = template(city, "Paved Road");

        assertTrue("roads are a building the city can order",
                roadNetwork.getCategory() == BuildingType.INFRASTRUCTURE);
        assertTrue("...that costs materials, so construction earns from it",
                roadNetwork.getConstructionMaterials() > 0);
        assertTrue("...and takes months, so it cannot be a panic button",
                roadNetwork.getConstructionPoints() > 0);
        assertTrue("...and adds capacity when it is done",
                roadNetwork.getCapacity() > 0);
        assertTrue("a road generates no traffic of its own",
                roadNetwork.getRoadLoad() == 0);
        assertTrue("...and employs nobody to run it",
                roadNetwork.getTotalJobs() == 0);

        /*
         * Run as a controlled pair, not as a before-and-after.
         *
         * Sixty months change a great deal besides the roads - the congested
         * city sheds shops, the investors reprice, the population moves - so
         * "income went up after I built a road" proves nothing on its own. Two
         * copies of the SAME saved city, one that builds and one that does not,
         * isolates the only variable anyone cares about.
         */
        assertTrue("the congested city saved", city.saveGame(2, "gridlock").ok);

        Game withRoads = new Game(files);
        withRoads.loadGameSave(2);

        Game without = new Game(files);
        without.loadGameSave(2);

        double capacityBefore = withRoads.getInfrastructureManager().getCapacity();

        /*
         * Funded, and given somewhere to put it. A road is a big lot, and this
         * check is about traffic rather than about whether a jammed city can
         * still raise the money - which it can, by borrowing, elsewhere.
         *
         * BOTH CITIES GET THE MONEY AND THE LAND since 2026-09-07, and only one
         * of them spends it on roads. Before, the subsidy and the acreage went
         * to withRoads alone, so the two cities differed in three ways at once
         * and the fixture called the sum of them "roads". The consumption
         * assertion below was the one that noticed: it passed by 2% on a
         * four-person population gap, which is not a margin, it is a coin
         * landing the right way up. Rent becoming a market tipped the coin -
         * roads eat construction materials, dearer materials mean a dearer
         * rent floor, and the road city's households had less left for the
         * shops - and a 2% pass became a 3% fail without anything about roads
         * changing at all.
         *
         * Controlled, the question is the one the section actually asks: same
         * money, same ground, one city builds roads. The GDP claim never needed
         * this - it wins by 50% - but the consumption claim did.
         */
        withRoads.getGovernmentInvestor().spend(-500000);
        without.getGovernmentInvestor().spend(-500000);
        withRoads.getLandManager().setOwnedSqFt(
                withRoads.getLandManager().getOwnedSqFt() + roadNetwork.getLandSqFt() * 3);
        without.getLandManager().setOwnedSqFt(
                without.getLandManager().getOwnedSqFt() + roadNetwork.getLandSqFt() * 3);

        Game.BuildResult ordered = withRoads.buildStack(roadNetwork, 2, false);
        assertTrue("the order goes through", ordered == Game.BuildResult.SUCCESS);

        // Ordering is not finishing. This is the half of the mechanic that
        // makes waiting until you are already jammed a bad idea.
        close("ordering one changes nothing yet",
                withRoads.getInfrastructureManager().getCapacity(), capacityBefore);

        withRoads.simulateMonths(60);
        without.simulateMonths(60);

        InfrastructureManager built = withRoads.getInfrastructureManager();
        System.out.printf("   with roads:    %.0f of %.0f used, throughput %.1f%%, income %.1f%n",
                built.getLoad(), built.getCapacity(),
                withRoads.getRoadRatio() * 100, withRoads.getIncome());
        System.out.printf("   without:       %.0f of %.0f used, throughput %.1f%%, income %.1f%n",
                without.getInfrastructureManager().getLoad(),
                without.getInfrastructureManager().getCapacity(),
                without.getRoadRatio() * 100, without.getIncome());

        assertTrue("the finished roads added capacity",
                built.getCapacity() > capacityBefore);
        assertTrue("...and cleared the jam", withRoads.getRoadRatio() > without.getRoadRatio());
        assertTrue("...while the city that built nothing is still stuck",
                without.getInfrastructureManager().isCongested());
        /*
         * BETTER OFF IN OUTPUT, not in the treasury's monthly line.
         *
         * This compared getIncome(), which is what the CITY collects - and the
         * city that built roads is also paying to keep them. At this scale the
         * upkeep is the same order as the extra tax, so the comparison came
         * down to a couple of dollars either way and flipped on 2026-09-07 when
         * the House grew to six and both cities got bigger. The benefit of a
         * road was never the treasury's; it is that the economy on it runs at
         * all, which is what GDP measures and what the throughput ratio above
         * is a direct input to.
         */
        /*
         * AVERAGED, NOT SNAPSHOT - and that correction matters more than it
         * sounds. One month's GDP contains one month's CAPITAL SPENDING, which
         * is lumpy in a way nothing else here is: measured on a single month,
         * the jammed city read $9,012 of investment against the healthy city's
         * $273, because somebody happened to order a power plant that month.
         * GDP came out sixteen times higher in the city that could not move its
         * goods, and the fixture duly reported that roads make you poorer.
         *
         * A year, on both, and the lump is one twelfth of what it was. This is
         * the same mistake as reading whichever month a loop stopped on, which
         * HouseholdCheck was carrying on the same day.
         */
        double gdpWith = 0, gdpWithout = 0;
        for (int m = 0; m < 12; m++) {
            withRoads.simulateMonths(1);
            without.simulateMonths(1);
            gdpWith += withRoads.getEconomyManager().getMonthGdp();
            gdpWithout += without.getEconomyManager().getMonthGdp();
        }
        gdpWith /= 12;
        gdpWithout /= 12;
        System.out.printf("   GDP over a year: with roads %.1f/mo, without %.1f/mo%n",
                gdpWith, gdpWithout);
        System.out.printf("   and the shops: %.1f/mo against %.1f/mo, for %d people against %d%n",
                withRoads.getEconomyManager().getNationalAccounts().getConsumption(),
                without.getEconomyManager().getNationalAccounts().getConsumption(),
                withRoads.getPopulationManager().getPopulation(),
                without.getPopulationManager().getPopulation());

        /* -------------------------------------------------------------------
           AND THE CLEANER SIGNAL UNDERNEATH IT, WHICH IS NOT CONSUMPTION.

           This used to assert that the road city's shops SELL MORE, on the
           reasoning that consumption is people earning and spending and has no
           capital lump in it. That was true when it was written and stopped
           being true when the shelf price learned to ration.

           Look at what the two cities actually do:

               delivered share   0.889 with roads   0.347 without
               units sold          143                164
               consumption       390.6/mo           403.4/mo

           The CONGESTED city spends more money at the shops. Its lorries cannot
           get through, its shelves are bare, the scarcity mark-up on what does
           arrive is enormous, and its households hand over more cash for fewer
           goods. Consumption measured in money now RISES with congestion, so
           asserting it falls is asserting the opposite of the mechanic.

           (The old assertion passed anyway, by 2% on a four-person population
           gap - a coin landing the right way up rather than a margin. Rent
           becoming a market tipped it: roads eat construction materials, dearer
           materials mean a dearer rent floor, and 2% the right way became 3%
           the wrong way without anything about roads changing.)

           What roads actually do is MOVE GOODS, and the delivered share says so
           by a factor of two and a half. That is the clean signal, it is the
           one this section is about, and unlike consumption it cannot be
           satisfied by charging more for less. (Until 0.7.43: since then the
           shops' planner builds to what its shops can hand over, the delivered
           share no longer separates the two cities, and the signal is the
           share of their reach the shops can work - the rate, below.)
           ------------------------------------------------------------------- */
        double deliveredWith = withRoads.getSectors().retail().getDeliveredShare();
        double deliveredWithout = without.getSectors().retail().getDeliveredShare();
        for (Game g : new Game[] { withRoads, without }) {
            ham.citybuildersim.sectors.Retail r = g.getSectors().retail();
            System.out.printf("   shops %s: coverage %d at a rate of %.3f (roads %.3f), hand over %.0f, %.0f wanted at %.4f (floor %.4f)%n",
                    g == withRoads ? "with roads" : "without   ", r.getStoreCoverage(), r.getOperatingRate(),
                    r.getRoadRatio(), r.getSupplyBaskets(), r.getDemandAtPrice(), r.getStoreSellPrice(), r.getFloorPrice());
        }
        System.out.printf("   and the shelves: %.0f%% of what customers came for"
                + " against %.0f%%%n", deliveredWith * 100, deliveredWithout * 100);
        /*
         * REWRITTEN FOR 0.7.43 (spec-inflation.md 4.3, a premise the design
         * changes): the shops' planner forecasts baskets against what its
         * shops can HAND OVER - coverage times the operating rate - so a city
         * whose roads hold its shops to a third of their reach builds three
         * times the shops (above: 4,640 of coverage against 1,600), and the
         * delivered share no longer tells the two cities apart. What roads do
         * to the shops is the share of their reach they can work, and that
         * is what is asserted: the road city's shops at more than half again
         * the rate of the jammed city's. Until 0.7.43 the planner counted
         * people against coverage, and the delivered share said the same.
         */
        assertTrue("...and its shops can actually be supplied: each hands over more of its reach",
                withRoads.getSectors().retail().getOperatingRate()
                        > without.getSectors().retail().getOperatingRate() * 1.5);
        /* -------------------------------------------------------------------
           AND THERE IS NO SECOND OUTCOME ASSERTION HERE, ON PURPOSE.

           This slot has now held two of them and both were wrong, in the same
           way, three days apart.

           It first asserted that the road city PRODUCES more, in money. The
           paragraph above had already worked out why that cannot be trusted -
           a congested city has bare shelves, an enormous scarcity mark-up, and
           hands over more cash for fewer goods - and the assertion had simply
           been surviving on luck. Rebalance stage two took the luck away.

           So it was rewritten to assert POPULATION, on the reasoning that a
           real quantity cannot be faked by a mark-up. That lasted until the
           bank started paying savers a share of its interest income, whereupon
           the road city held FEWER people at every setting of that dial. Which
           is not absurd: deposit interest changes household savings, savings
           change what a household can afford, and affordability is a term in
           the migration target. The two cities differ in one input and then
           differ in everything.

           THE TELL IS IN THE PRINTOUT. Across three settings of a bank
           constant, the roadless city's annual GDP came out at 2,322.9, 1,232.2
           and 1,235.8 while the road city sat at 1,590.1, 1,590.5 and 1,590.8.
           The congested city's figures are noise; the well-supplied one's are
           stable. That is what a money quantity looks like when scarcity is
           setting the price.

           What roads do is MOVE GOODS, and this section already asserts it
           where it can be measured cleanly: deliveredShare is
           deliveredUnits/plannedUnits, a ratio of two REAL quantities that no
           price can touch, and it comes out at 74% against 22% - a factor of
           three and a half, stable across every one of those runs.

           GDP and population are printed above as context. They are the
           weather. The delivered share is the claim.
           ------------------------------------------------------------------- */

        /* ================= 7. across a save ================= */
        System.out.println("\n--- across a save ---");

        // Deliberately saved while congested. The ratio a month was traded at
        // is carried in the save now, and a city whose ratios are all 1 cannot
        // prove that carrying works - the same reason a city with no industry
        // cannot catch an industrial bug.
        Game jammed = new Game(files);
        jammed.run();
        // THE TREASURY THIS FIXTURE WAS WRITTEN AGAINST (0.7.10): its build list
        // is bought out of cash, and a city founds on D$100M since 0.7.10, not the
        // D$2.5B it assumed - so it is given that, the Wealthy preset's, explicitly.
        jammed.setCashForTest(Founding.WEALTHY_CASH);
        jammed.buildStack(template(jammed, "House"), 300, false);
        jammed.buildStack(template(jammed, "Convenience Store"), shopsFor(jammed, 720), false);
        jammed.simulateMonths(40);

        /*
         * Deliberately saved MID-GROWTH, and that is the point of the fixture.
         *
         * This section used to run the city on until it stopped growing before
         * saving, because a month's statement is written at the start of the
         * month against what the previous month left behind - so in a growing
         * city the report describes a smaller place than the one the save is
         * taken from, and the load rebuilt it from the larger one. Waiting for
         * a steady city took that lag out of the measurement.
         *
         * The statements are carried whole now, so there is nothing left to
         * take out. A city still moving is the harder case and therefore the
         * one worth testing: if any figure below is rebuilt rather than
         * restored, a growing city is where it shows.
         */
        ham.citybuildersim.sectors.Retail shops = jammed.getSectors().retail();

        assertTrue("the test city is still growing, which is the hard case",
                !steady(shops));
        assertTrue("the test city is genuinely congested",
                jammed.getInfrastructureManager().isCongested());

        double incomeBefore = jammed.getIncome();
        double ratioBefore = jammed.getRoadRatio();
        double basisBefore = shops.getRoadRatio();
        double grossBefore = shops.statement().revenue;
        double pendingBefore = shops.pending().revenue();

        assertTrue("saved", jammed.saveGame(1, "gridlock").ok);

        Game reloaded = new Game(files);
        reloaded.loadGameSave(1);

        assertTrue("it loaded", reloaded.getLoadFailure() == null);
        close("the network came back", reloaded.getInfrastructureManager().getLoad(),
                jammed.getInfrastructureManager().getLoad());
        close("...at the same capacity",
                reloaded.getInfrastructureManager().getCapacity(),
                jammed.getInfrastructureManager().getCapacity());
        close("...and the same throughput", reloaded.getRoadRatio(), ratioBefore);

        // The one that caught a real bug: the ratio the month was TRADED at is
        // not the ratio the city ends the month showing, and recomputing the
        // report from the latter reports revenue nobody earned. Since the
        // sector template the statement is CARRIED, and so is the ledger of
        // the month in progress - so both come back as they were.
        close("the ratio the sectors were handed came back",
                reloaded.getSectors().retail().getRoadRatio(), basisBefore);
        close("...so retail revenue is unchanged",
                reloaded.getSectors().retail().statement().revenue,
                grossBefore);
        close("...and so is the month in progress",
                reloaded.getSectors().retail().pending().revenue(),
                pendingBefore);
        /*
         * Exact, on a growing city, with the roads jammed.
         *
         * This was a bounded assertion for about an hour, with a note saying
         * the residual was one month of lag in the food price the industrial
         * statement was written against - true, and the fourth input in a row
         * to be found underneath the last one. The month's statements are
         * carried whole now rather than rebuilt from their ingredients, so
         * there is no fifth.
         */
        System.out.printf("   income %.6f -> %.6f%n", incomeBefore, reloaded.getIncome());
        close("...and so is next month's income", reloaded.getIncome(), incomeBefore);

        close("...and the industrial statement, which was the last to drift",
                reloaded.getSectors().industry().statement().revenue,
                jammed.getSectors().industry().statement().revenue);

        assertTrue("the basis is NOT just the current ratio, or this proved nothing",
                Math.abs(basisBefore - 1) > 1e-9);

        /* ================= 7b. THREE ROADS, AND ALL THREE USEFUL =================

           A building that loses to something else at EVERY price is not a
           choice, it is a mistake the player is allowed to make. Studio
           Apartments are that today - houses beat them below $38.81 a square
           foot and low-rises from $32.55, so there is no land price at which a
           studio is the right answer, and nothing in the game says so.

           The three roads were costed to avoid exactly that, and costing is not
           a promise. This is the promise: each of them is the cheapest road per
           trip carried somewhere in the range of land prices the game actually
           reaches, and every one of those bands is non-empty.

           The comparison has to be PER TRIP. A gravel road is cheaper than an
           elevated highway in every column and carries 40% of the traffic, so
           comparing sticker prices would "prove" the gravel road dominates when
           it does nothing of the kind.
           ================================================================= */
        System.out.println("\n--- three roads, and each of them wins somewhere ---");

        BuildingsTemplate gravel   = template(reloaded, "Gravel Road");
        BuildingsTemplate paved    = template(reloaded, "Paved Road");
        BuildingsTemplate elevated = template(reloaded, "Elevated Highway");
        BuildingsTemplate[] roads  = { gravel, paved, elevated };

        for (BuildingsTemplate r : roads) {
            assertTrue(r.getName() + " carries traffic",     r.getCapacity() > 0);
            assertTrue(r.getName() + " generates none",      r.getRoadLoad() == 0);
            assertTrue(r.getName() + " employs nobody",      r.getTotalJobs() == 0);
            assertTrue(r.getName() + " takes months",        r.getConstructionPoints() > 0);
            assertTrue(r.getName() + " occupies ground",     r.getLandSqFt() > 0);
        }

        /*
         * THE TRADE ITSELF, asserted rather than described.
         *
         * Jerus asked for one that is cheap in construction and hungry for land
         * and one that is the reverse. If a rebalance ever quietly undid that,
         * the three would still all be "useful" by the band test below while no
         * longer being the three things they were asked to be.
         */
        double gravelPoints   = gravel.getConstructionPoints()   / (double) gravel.getCapacity();
        double pavedPoints    = paved.getConstructionPoints()    / (double) paved.getCapacity();
        double elevatedPoints = elevated.getConstructionPoints() / (double) elevated.getCapacity();

        double gravelLand   = gravel.getLandSqFt()   / (double) gravel.getCapacity();
        double pavedLand    = paved.getLandSqFt()    / (double) paved.getCapacity();
        double elevatedLand = elevated.getLandSqFt() / (double) elevated.getCapacity();

        System.out.printf("  per 1,000 trips:  %-18s %8s %12s %10s%n",
                "", "points", "land sqft", "power");
        for (BuildingsTemplate r : roads) {
            System.out.printf("                    %-18s %8.0f %12.0f %10.1f%n", r.getName(),
                    r.getConstructionPoints() * 1000.0 / r.getCapacity(),
                    r.getLandSqFt() * 1000.0 / r.getCapacity(),
                    r.getElectricityConsumption() * 1000.0 / r.getCapacity());
        }

        assertTrue("the gravel road is the cheapest to build per trip",
                gravelPoints < pavedPoints && pavedPoints < elevatedPoints);
        assertTrue("...and the hungriest for ground per trip",
                gravelLand > pavedLand && pavedLand > elevatedLand);
        assertTrue("the elevated highway draws the most power per trip",
                elevated.getElectricityConsumption() / (double) elevated.getCapacity()
                > paved.getElectricityConsumption() / (double) paved.getCapacity());
        assertTrue("...and the gravel road the least",
                gravel.getElectricityConsumption() / (double) gravel.getCapacity()
                < paved.getElectricityConsumption() / (double) paved.getCapacity());

        /*
         * AND NOW THE BANDS.
         *
         * Money for one trip of capacity = (cash + materials x price + land x
         * ground price) / capacity. Only the last term moves with the land
         * price, so each road is a straight line in it and the cheapest of three
         * lines is a step function with at most three steps. Walking the price
         * upward and recording who is cheapest finds them without solving
         * anything.
         *
         * The range walked is the range the game reaches: ground starts at
         * $0.70 a square foot and is multiplied by blocks owned and population,
         * and the housing analysis found live crossovers in the thirties.
         */
        double matPrice = reloaded.getBuildingManager().getConstructionMaterialPrice();
        java.util.Set<String> everCheapest = new java.util.LinkedHashSet<>();
        String cheapestSoFar = null;

        System.out.println("\n  cheapest road per trip, walking the ground price:");
        for (int tenthsOfCent = 0; tenthsOfCent <= 600; tenthsOfCent++) {

            double landPrice = tenthsOfCent / 10.0 * .001;   // $/sq ft, in thousands

            BuildingsTemplate best = null;
            double bestCost = Double.MAX_VALUE;
            for (BuildingsTemplate r : roads) {
                double cost = (r.getCashCost()
                        + r.getConstructionMaterials() * matPrice
                        + r.getLandSqFt() * landPrice) / r.getCapacity();
                if (cost < bestCost) { bestCost = cost; best = r; }
            }

            everCheapest.add(best.getName());
            if (!best.getName().equals(cheapestSoFar)) {
                System.out.printf("    from $%5.2f / sq ft:  %s%n",
                        landPrice * 1000, best.getName());
                cheapestSoFar = best.getName();
            }
        }

        for (BuildingsTemplate r : roads) {
            assertTrue(r.getName() + " is the right answer at SOME land price",
                    everCheapest.contains(r.getName()));
        }
        assertTrue("all three roads win a band, not two of them",
                everCheapest.size() == 3);

        /* ================= 8. a new game forgets the traffic ================= */
        System.out.println("\n--- and a new game starts clear ---");

        reloaded.newGame();
        close("capacity is back to the base",
                reloaded.getInfrastructureManager().getCapacity(),
                InfrastructureManager.BASE_CAPACITY);
        close("nothing is on the roads", reloaded.getInfrastructureManager().getLoad(), 0);
        close("...and throughput is whole again", reloaded.getRoadRatio(), 1);

        /* ============ 9. EVERY FIGURE THE INFRASTRUCTURE TAB READS ============

           WHY THIS SECTION EXISTS, and it is an honest admission rather than a
           design. The Infrastructure tab (2026-09-17) is the first screen in
           this game that was written and shipped WITHOUT ANYONE LOOKING AT IT:
           JavaFX needs its platform natives to render, the only ones on hand
           are the Windows build, and the machine this was written on is Linux.
           The compiler proves the screen assembles. Nothing proved the numbers
           on it were numbers.

           So this walks every accessor those four pages call, in the four city
           states that break screens - empty, congested, motorised, railed - and
           asks the only two questions a renderer cannot survive the wrong
           answer to: is it finite, and is it inside the range the screen's own
           label claims for it. A NaN reaches a Label as "NaN%" and an infinity
           reaches a meter as a bar of unbounded width.

           It is not a substitute for looking at it. It is what can be checked
           from here, and it is the half that would actually crash.
           ==================================================================== */
        System.out.println("\n--- every figure the Infrastructure tab reads is a number ---");

        InfrastructureManager[] states = new InfrastructureManager[4];
        String[] named = {"an empty city", "a congested one", "a motorised one", "a railed one"};
        for (int i = 0; i < states.length; i++) states[i] = new InfrastructureManager();

        states[1].setBuiltCapacity(1000);
        states[1].setLoad(9000);
        states[1].setBreakdown(new double[] {7000, 400, 1600});

        states[2].setBuiltCapacity(10_000);
        states[2].setLoad(12_000);
        states[2].setBreakdown(new double[] {8600, 400, 3000});
        states[2].setModes(4000, 20_000);
        states[2].setFare(TaxPolicy.MAX_TRANSIT_FARE);
        states[2].setCarOwnership(1);
        // ...every commuter with a car of their own (0.7.49): with nobody car-less, the most fare there is puts nobody on a bus.
        states[2].setCommute(0, Motoring.CAR_FUEL_PER_JOURNEY);
        for (int i = 0; i < 40; i++) states[2].noteCongestion(InfrastructureManager.MIN_THROUGHPUT);

        states[3].setBuiltCapacity(10_000);
        states[3].setLoad(12_000);
        states[3].setBreakdown(new double[] {8600, 400, 3000});
        states[3].setRailShare(new double[] {0, 1, 1});

        for (int i = 0; i < states.length; i++) {
            InfrastructureManager n = states[i];
            boolean ok = true;
            ok &= sane(n.getCapacity(), 0, Double.MAX_VALUE);
            ok &= sane(n.getBuiltCapacity(), 0, Double.MAX_VALUE);
            ok &= sane(n.getEffectiveLoad(), 0, Double.MAX_VALUE);
            ok &= sane(n.getUtilisation(), 0, Double.MAX_VALUE);
            ok &= sane(n.getHeadroom(), 0, Double.MAX_VALUE);
            ok &= sane(n.getThroughputRatio(), InfrastructureManager.MIN_THROUGHPUT, 1);
            ok &= sane(n.getHighwayShare(), 0, 1);
            ok &= sane(n.getCarOwnership(), 0, 1);
            ok &= sane(n.carRoadFactor(), 1, InfrastructureManager.CAR_LOAD_AT_SATURATION);
            ok &= sane(n.getJam(), 0, 1);
            ok &= sane(n.willingToRide(), 0, 1);
            ok &= sane(n.getRememberedThroughput(), InfrastructureManager.MIN_THROUGHPUT, 1);
            ok &= sane(n.getTransitCover(), 0, 1);
            ok &= sane(n.getTransitCapacity(), 0, Double.MAX_VALUE);
            ok &= sane(n.getUsableTransit(), 0, Double.MAX_VALUE);
            ok &= sane(n.getTransitRiders(), 0, Double.MAX_VALUE);
            ok &= sane(n.getFareShare(), 0, 1);
            ok &= sane(n.cityThroughput(), InfrastructureManager.MIN_THROUGHPUT, 1);
            ok &= n.getStatus() != null && !n.getStatus().isEmpty();
            for (Traffic t : Traffic.values()) {
                ok &= sane(n.getLoad(t), 0, Double.MAX_VALUE);
                ok &= sane(n.getShareOf(t), 0, 1);
                ok &= sane(n.roadCostOf(t), 0, 1);
                ok &= sane(n.throughputOf(t), InfrastructureManager.MIN_THROUGHPUT, 1);
                ok &= sane(n.getRailShare(t), 0, 1);
            }
            /*
             * AND THE PREVIEW THE FARE DIAL DRAWS - riders at a fare the
             * player has not applied yet, which the SCREEN worked out rather
             * than read off the model until 0.7.29 (InfrastructureManager.
             * ridersAt() since). It divides by nothing, but it is the line
             * most likely to be handed a zero.
             */
            for (double fare : new double[] {0, TaxPolicy.DEFAULT_TRANSIT_FARE,
                                             TaxPolicy.MAX_TRANSIT_FARE}) {
                double share = InfrastructureManager.ridershipAt(fare);
                double ceiling = n.getLoad(Traffic.COMMUTERS)
                        * InfrastructureManager.TRANSIT_MAX_SHARE;
                ok &= sane(share, 0, 1);
                ok &= sane(Math.min(n.getUsableTransit(), ceiling) * share * n.willingToRide(),
                        0, Double.MAX_VALUE);
            }
            assertTrue("...in " + named[i], ok);
        }

        /*
         * ...AND THE FREIGHT PAGE'S TWO GRIDS, which read the goods and the
         * sectors rather than the network. The band grid divides by the import
         * price and the fleet grid by the tonnage, and both are guarded on the
         * screen - this is the guard's other half.
         */
        boolean goodsOk = true;
        Markets bandMarkets = new Markets();
        bandMarkets.setExchangeRate(1);
        for (Good g : Good.values()) {
            GoodsMarket m = bandMarkets.get(g);
            if (!g.traded() || !g.exportable() || !g.importable()) continue;
            if (!(m.importPrice() > 0)) continue;
            goodsOk &= sane((m.importPrice() - m.exportPrice()) / m.importPrice(), 0, 1);
            goodsOk &= sane((m.netImportPrice() - m.netExportPrice()) / m.importPrice(), 0, 1);
        }
        assertTrue("every good's wedge is a share of its own price", goodsOk);

        boolean fleetOk = true;
        for (Sector s : reloaded.getSectors().all()) {
            fleetOk &= sane(s.tonnesMoved(), 0, Double.MAX_VALUE);
            fleetOk &= sane(s.vansNeeded(), 0, Double.MAX_VALUE);
            fleetOk &= sane(s.vanFleet(), 0, Double.MAX_VALUE);
            fleetOk &= sane(s.getVanRatio(), Sector.MIN_VAN_RATE, 1);
            fleetOk &= sane(s.getOperatingRate(), 0, 1);
        }
        assertTrue("every sector's fleet reading is a number", fleetOk);

        /* ======= 10. THE CURVE, THE WALK AND THE WEDGE, AS THE SCREEN DRAWS THEM (0.7.29) =======

           The Roads page draws the curve with throughputAt() and puts the
           city's dot on it at getUtilisation(); it draws the load as a walk
           from the trips the city makes to what is on its road
           (roadBreakdown()); the Freight page splits each good's wedge into
           the world's margin, the freight still paid abroad and the
           railway's charge (GoodsMarket's four reads). None of them may be a
           second copy of what the model already sums, so each is held to the
           figure it takes apart - in the four states above, and in the two
           played cities this harness grew.
           ==================================================================== */
        System.out.println("\n--- the curve, the walk and the wedge, as the Infrastructure screen draws them ---");

        /*
         * ...AND ONE WITH EVERY STEP OF THE WALK LIVE, which none of the four
         * is: the motorised one charges the most fare there is, so nobody
         * rides. Commuters on a tram at the default fare, six households in
         * ten with a car and a commute that has been jammed, nearly two fifths of the
         * road built for lorries, and the railway carrying half the goods and
         * all the bulk.
         */
        InfrastructureManager ridden = new InfrastructureManager();
        ridden.setBuiltCapacity(10_000);
        ridden.setLoad(12_000);
        ridden.setBreakdown(new double[] {8600, 400, 3000});
        ridden.setModes(4000, 20_000);
        ridden.setFare(TaxPolicy.DEFAULT_TRANSIT_FARE);
        ridden.setCarOwnership(.6);
        // ...four commuters in ten with no car of their own, and a journey's fuel at the founding price (0.7.49).
        ridden.setCommute(.4, Motoring.CAR_FUEL_PER_JOURNEY);
        ridden.setRailShare(new double[] {0, .5, 1});
        for (int i = 0; i < 40; i++) ridden.noteCongestion(InfrastructureManager.MIN_THROUGHPUT);

        InfrastructureManager[] walked = {states[0], states[1], states[2], states[3], ridden,
                city.getInfrastructureManager(), jammed.getInfrastructureManager()};
        boolean onCurve = true, sumsOnRoad = true, sumsWalk = true, sameLoad = true;
        for (InfrastructureManager n : walked) {
            onCurve &= Double.compare(InfrastructureManager.throughputAt(n.getUtilisation()),
                    n.getThroughputRatio()) == 0;
            InfrastructureManager.RoadBreakdown w = n.roadBreakdown();
            double tol = 1e-9 * Math.max(1, n.getEffectiveLoad());
            double onRoad = 0;
            for (double v : w.onRoad()) onRoad += v;
            sumsOnRoad &= Math.abs(onRoad - n.getEffectiveLoad()) <= tol;
            sumsWalk &= Math.abs(w.rawTotal() - w.transitOff() + w.carsAdd() - w.freightOffTotal()
                    - n.getEffectiveLoad()) <= tol;
            sameLoad &= Double.compare(w.effective(), n.getEffectiveLoad()) == 0;
        }
        assertTrue("the dot sits on the curve: throughputAt(use) is the ratio, to the bit", onCurve);
        assertTrue("the streams on the road add to the load the curve reads", sumsOnRoad);
        assertTrue("...and trips, less transit, plus cars, less rail and highways, is that load",
                sumsWalk);
        assertTrue("...which the walk carries as getEffectiveLoad() itself", sameLoad);

        InfrastructureManager.RoadBreakdown motorised = ridden.roadBreakdown();
        InfrastructureManager.RoadBreakdown railed = states[3].roadBreakdown();
        assertTrue("a motorised city with riders, highways and rail has every step of the walk",
                motorised.transitOff() > 0 && motorised.carsAdd() > 0 && motorised.freightOffTotal() > 0);
        assertTrue("...and a railed one with no cars adds nothing for them and takes freight off",
                railed.carsAdd() == 0 && railed.transitOff() == 0 && railed.freightOffTotal() > 0);
        InfrastructureManager.RoadBreakdown plain = states[1].roadBreakdown();
        boolean untouched = plain.transitOff() == 0 && plain.carsAdd() == 0 && plain.freightOffTotal() == 0;
        for (Traffic t : Traffic.values()) untouched &= plain.onRoad()[t.ordinal()] == plain.raw()[t.ordinal()];
        assertTrue("a city with no modes walks its trips straight onto the road", untouched);
        close("without cars, the motorised road is its streams at a trip each, less the relief",
                motorised.withoutCars(),
                motorised.rawTotal() - motorised.transitOff() - motorised.freightOffTotal());

        boolean floorOk = InfrastructureManager.throughputAt(InfrastructureManager.FREE_FLOW) == 1
                && InfrastructureManager.throughputAt(
                        InfrastructureManager.FREE_FLOW / InfrastructureManager.MIN_THROUGHPUT * 1.01)
                   == InfrastructureManager.MIN_THROUGHPUT
                && InfrastructureManager.throughputAt(
                        InfrastructureManager.FREE_FLOW / InfrastructureManager.MIN_THROUGHPUT * .99)
                   > InfrastructureManager.MIN_THROUGHPUT;
        assertTrue("the curve is flat to free flow and floors where FREE_FLOW / MIN_THROUGHPUT says",
                floorOk);

        /*
         * THE RIDERS BY REASON (0.7.49): the car-less in reach and the owners
         * who chose the bus are the riders, to the bit - and at the ceiling
         * fare, where no owner chooses the bus on cost and the jam's curve is
         * at nothing, the car-less alone (with a journey's fuel under half
         * the ceiling fare, as every fixture here has it).
         */
        boolean funnelOk = true;
        for (InfrastructureManager n : walked) {
            funnelOk &= Double.compare(n.getCaptiveRiders() + n.getChoiceRiders(), n.getTransitRiders()) == 0
                    && (!(n.getFuelPerJourney() < TaxPolicy.MAX_TRANSIT_FARE / 2)
                        || Double.compare(n.ridersAt(TaxPolicy.MAX_TRANSIT_FARE), n.getCaptiveRiders()) == 0)
                    && n.getTransitCeiling() <= n.getTransitCapacity() + 1e-9
                    && n.getTransitCeiling() <= n.getTransitRoadCeiling() + 1e-9
                    && n.getTransitCeiling() <= n.getTransitShareCeiling() + 1e-9;
        }
        assertTrue("the funnel's last step is the riders: the car-less in reach and the owners who chose the bus, under all three ceilings",
                ridden.getTransitRiders() > 0 && ridden.getChoiceRiders() > 0 && funnelOk);

        /*
         * THE FARE DIAL CARD'S ROWS (0.7.38): what a fare would do, each the
         * model's read at that fare. At the network's own fare they are what
         * it carries and what the month books (its riders at
         * TaxPolicy.monthlyFare()), and nothing goes back onto the road; at
         * a dearer one the riders are what the same network carries at that
         * fare and the trips back onto the road its load then, less this
         * one's, which a second network set to it says.
         */
        TaxPolicy fareDial = new TaxPolicy();
        double ownFare = fareDial.getTransitFare(), dearFare = TaxPolicy.MAX_TRANSIT_FARE / 2;
        InfrastructureManager dear = new InfrastructureManager();
        dear.setBuiltCapacity(10_000);
        dear.setLoad(12_000);
        dear.setBreakdown(new double[] {8600, 400, 3000});
        dear.setModes(4000, 20_000);
        dear.setFare(dearFare);
        dear.setCarOwnership(.6);
        dear.setCommute(.4, Motoring.CAR_FUEL_PER_JOURNEY);
        dear.setRailShare(new double[] {0, .5, 1});
        for (int i = 0; i < 40; i++) dear.noteCongestion(InfrastructureManager.MIN_THROUGHPUT);
        assertTrue("fixture: the ridden network is at the city's own fare, and the dear one rides fewer",
                ownFare == TaxPolicy.DEFAULT_TRANSIT_FARE && dear.getTransitRiders() < ridden.getTransitRiders());
        assertTrue("the fare card at its own fare: the riders, the month's fares, none back on the road",
                Double.compare(ridden.ridersAt(ownFare), ridden.getTransitRiders()) == 0
                        && Double.compare(ridden.faresAt(ownFare), ridden.getTransitRiders() * fareDial.monthlyFare()) == 0
                        && ridden.backOnTheRoadAt(ownFare) == 0);
        close("...at a dearer fare, the riders the network set to it carries",
                ridden.ridersAt(dearFare), dear.getTransitRiders());
        close("...and the trips back onto the road, its load less this one's",
                ridden.backOnTheRoadAt(dearFare), dear.getEffectiveLoad() - ridden.getEffectiveLoad());
        /*
         * ...AND IN TODAY'S MONEY (0.7.45; the UI spec's B7): the month
         * charges a ride the dial at the expected price level the money
         * constants are struck at, and the card's fares did not - at any level
         * but 1 its "Fares collected" at rest was not the month's.
         */
        TaxPolicy struckDial = new TaxPolicy();
        struckDial.setExpectedLevel(1.2);
        ridden.setFareLevel(1.2);
        assertTrue("fixture: the fare struck at a level of 1.2, the dial unmoved",
                struckDial.getTransitFare() == ownFare && struckDial.chargedFare() > ownFare);
        assertTrue("...where the card's fares at its own fare are what the month books, the riders at the charged fare",
                Double.compare(ridden.faresAt(ownFare), ridden.getTransitRiders() * struckDial.monthlyFare()) == 0);
        close("...and its riders are the dial's, which reads the fare in founding money",
                ridden.ridersAt(ownFare), ridden.getTransitRiders());
        ridden.setFareLevel(1);

        boolean roomOk = true;
        for (InfrastructureManager n : walked) {
            roomOk &= Math.abs(n.getHeadroom()
                    - Math.max(0, n.getCapacity() * InfrastructureManager.FREE_FLOW - n.getEffectiveLoad())) < 1e-9;
        }
        assertTrue("the room before it slows is read against the load the curve reads", roomOk);
        /*
         * THE CASE THE RAW LOAD GOT WRONG (the 600-month city read 585 trips
         * of room on a road 161% full): trips made under the line, and cars
         * that put the road well over it.
         */
        InfrastructureManager driven = new InfrastructureManager();
        driven.setBuiltCapacity(13_000);
        driven.setLoad(12_000);
        driven.setBreakdown(new double[] {8600, 400, 3000});
        driven.setCarOwnership(.5);
        assertTrue("a road whose trips are under its line and whose cars put it over",
                driven.getLoad() < driven.getCapacity() * InfrastructureManager.FREE_FLOW
                        && driven.getUtilisation() > 1);
        assertTrue("...has no room before it slows, and none spare",
                driven.getHeadroom() == 0 && driven.getSpareCapacity() == 0);

        /*
         * THE WEDGE, TAKEN APART. A fixture railway carries 60% of every good
         * at a quote of 25% of the lorry rate, at an exchange rate that is not
         * one, so every term is live; the untouched markets of section 9 are
         * the city with no railway.
         */
        Markets railedMarkets = new Markets();
        railedMarkets.setExchangeRate(1.3);
        boolean bandOk = true, deliveredOk = true, lorryOk = true, marginOk = true;
        int twoSided = 0;
        for (Good g : Good.values()) {
            if (!g.traded() || !g.exportable() || !g.importable()) continue;
            GoodsMarket m = railedMarkets.get(g);
            m.setFreightFactor(.4);
            m.setRailCharge(.6 * .25);
            if (!(m.importPrice() > 0)) continue;
            twoSided++;
            double tol = 1e-9 * Math.max(1, m.importPrice());
            bandOk &= Math.abs(m.worldMargin() + m.freightInBand()
                    - (m.importPrice() - m.exportPrice())) <= tol;
            deliveredOk &= m.railInWedge() > 0 && Math.abs(m.worldMargin() + m.freightInBand() + m.railInWedge()
                    - (m.netImportPrice() - m.netExportPrice())) <= tol;
            marginOk &= m.worldMargin() >= 0;
            GoodsMarket bare = bandMarkets.get(g);
            double bareTol = 1e-9 * Math.max(1, bare.importPrice());
            lorryOk &= Math.abs(bare.bandByLorry() - (bare.importPrice() - bare.exportPrice())) <= bareTol
                    && bare.railInWedge() == 0;
        }
        assertTrue("the world's margin and the freight paid abroad are the band",
                twoSided > 0 && bandOk);
        assertTrue("...and with the railway's charge, the delivered wedge", deliveredOk);
        assertTrue("with no railway the band is the band by lorry, and nothing is billed at home",
                lorryOk);
        assertTrue("no good's world margin is below zero, so a bar of it can be drawn", marginOk);

        /*
         * ...AND WITH A PORT (0.7.86, batch O9; spec-oil 4's "the band with a
         * port"). A fixture berth takes half of every good that has a kind of
         * cargo before a railway carrying 30% of the rest at a quote of 25%:
         * the ships' freight is paid abroad inside the band at the kind's
         * SEA_FREIGHT_SHARE, so the band is still the world's margin and the
         * freight paid abroad - the lorries' part and the ships' - and the
         * railway's charge is still its own share at its quote.
         */
        Markets portMarkets = new Markets();
        portMarkets.setExchangeRate(1.3);
        boolean portBand = true, portDelivered = true, portFreight = true;
        int shipped = 0;
        for (Good g : Good.values()) {
            if (!g.traded() || !g.exportable() || !g.importable() || g.cargo() == null) continue;
            GoodsMarket m = portMarkets.get(g);
            double sea = .5, rail = .3 * (1 - sea), x = g.cargo().seaFreightShare();
            m.setFreightFactor(Ports.factor(rail, sea, x));
            m.setRailCharge(rail * .25);
            if (!(m.importPrice() > 0)) continue;
            shipped++;
            double tol = 1e-9 * Math.max(1, m.importPrice());
            portBand &= Math.abs(m.worldMargin() + m.freightInBand() - (m.importPrice() - m.exportPrice())) <= tol;
            portDelivered &= Math.abs(m.worldMargin() + m.freightInBand() + m.railInWedge()
                    - (m.netImportPrice() - m.netExportPrice())) <= tol;
            portFreight &= Math.abs(m.freightInBand() - 2 * g.baseFreight() * ((1 - rail - sea) + sea * x) * 1.3) <= tol
                    && m.getFreightFactor() < 1 - rail;
        }
        assertTrue("WITH A PORT the world's margin and the freight paid abroad - the lorries' and the ships' - are the band",
                shipped > 0 && portBand);
        assertTrue("...and with the railway's charge, the delivered wedge", portDelivered);
        assertTrue("...the freight in the band the lorries' part and the ships' at their kind's sea freight, under the"
                + " railway's alone", portFreight);

        /* ======= 11. WHO RIDES, BY WHAT THEY PAY (0.7.49) =======

           Jerus: "if one household category has 3k workers and 2k cars, then
           well, 1k has to take transit cause they have no choice ... but if
           they already have car they look at oil costs". The commuters with
           no car of their own ride at any fare if a line reaches them and
           there is a seat, and walk if not; the owners weigh a ride against a
           journey's fuel and split rather than flip; and the riders never
           pass the share a city's lines reach. Every figure against the
           model's own constants.
           ==================================================================== */
        System.out.println("\n--- who rides, by what they pay ---");

        InfrastructureManager mixed = new InfrastructureManager();
        mixed.setBuiltCapacity(10_000);
        mixed.setLoad(12_000);
        mixed.setBreakdown(new double[] {8600, 400, 3000});
        mixed.setModes(0, 1_000_000);
        mixed.setCarOwnership(.5);
        mixed.setCommute(.6, Motoring.CAR_FUEL_PER_JOURNEY);
        double[] dials = {0, TaxPolicy.DEFAULT_TRANSIT_FARE, TaxPolicy.MAX_TRANSIT_FARE / 2, TaxPolicy.MAX_TRANSIT_FARE};
        mixed.setFare(dials[0]);
        double carless = mixed.getCaptiveRiders();
        assertTrue("fixture: six commuters in ten with no car, seats for all, every one in reach riding",
                carless > 0 && Double.compare(carless, mixed.getCaptiveDemand()) == 0
                        && Double.compare(mixed.getCaptiveDemand(),
                                mixed.getLoad(Traffic.COMMUTERS) * .6 * InfrastructureManager.TRANSIT_MAX_SHARE) == 0);
        boolean anyFare = true, ownersFall = true;
        double ownersBefore = Double.POSITIVE_INFINITY;
        for (double dial : dials) {
            mixed.setFare(dial);
            anyFare &= Double.compare(mixed.getCaptiveRiders(), carless) == 0 && mixed.ridersAt(dial) >= carless;
            ownersFall &= mixed.getChoiceRiders() <= ownersBefore;
            ownersBefore = mixed.getChoiceRiders();
        }
        assertTrue("the car-less in reach ride at any fare the dial allows", anyFare);
        assertTrue("...while the owners on the bus fall as the fare rises", ownersFall);

        double f = TaxPolicy.DEFAULT_TRANSIT_FARE;
        boolean monotone = true;
        double lastShare = -1;
        for (int k = 0; k <= 30; k++) {
            double s = InfrastructureManager.transitChosen(f * k / 10.0, f);
            monotone &= s >= lastShare;
            lastShare = s;
        }
        assertTrue("an owner switches when the fuel costs more than the fare",
                InfrastructureManager.transitChosen(2 * f, f) == 1 && InfrastructureManager.transitChosen(f, 2 * f) == 0
                        && InfrastructureManager.transitChosen(f, f) == .5 && monotone);
        double near = InfrastructureManager.transitChosen(.9 * f, f), nearOther = InfrastructureManager.transitChosen(f, .9 * f);
        assertTrue("...and a cell splits rather than flips",
                near > 0 && near < .5 && nearOther > .5 && nearOther < 1);

        InfrastructureManager short_ = new InfrastructureManager();
        short_.setBuiltCapacity(10_000);
        short_.setLoad(12_000);
        short_.setBreakdown(new double[] {8600, 400, 3000});
        short_.setModes(0, 2_000);
        short_.setFare(TaxPolicy.DEFAULT_TRANSIT_FARE);
        short_.setCommute(.6, Motoring.CAR_FUEL_PER_JOURNEY);
        assertTrue("a commuter out of reach or without a seat walks",
                Double.compare(short_.getWalking(), short_.getCaptiveCommuters() - short_.getCaptiveRiders()) == 0
                        && short_.getWalking() > short_.getCaptiveCommuters() * (1 - InfrastructureManager.TRANSIT_MAX_SHARE)
                        && Double.compare(mixed.getWalking(),
                                mixed.getCaptiveCommuters() - mixed.getCaptiveDemand()) == 0);

        boolean reach = true;
        for (double captive : new double[] {0, .3, .6, 1}) {
            for (double dial : dials) {
                for (double remembered : new double[] {1, InfrastructureManager.MIN_THROUGHPUT}) {
                    InfrastructureManager n = new InfrastructureManager();
                    n.setBuiltCapacity(10_000);
                    n.setLoad(12_000);
                    n.setBreakdown(new double[] {8600, 400, 3000});
                    n.setModes(0, 1_000_000);
                    n.setCarOwnership(.5);
                    n.setCommute(captive, Motoring.CAR_FUEL_PER_JOURNEY);
                    n.setFare(dial);
                    for (int i = 0; i < 40; i++) n.noteCongestion(remembered);
                    reach &= n.getTransitRiders() <= n.getLoad(Traffic.COMMUTERS) * InfrastructureManager.TRANSIT_MAX_SHARE + 1e-9;
                }
            }
        }
        assertTrue("the riders never pass the share any city's lines reach", reach);

        cleanUp(root);

        System.out.println(fails == 0
                ? "\nAll checks passed."
                : "\n" + fails + " FAILED");
        System.exit(fails == 0 ? 0 : 1);
    }

    static void cleanUp(Path root) {
        try (var walk = Files.walk(root)) {
            walk.sorted(java.util.Comparator.reverseOrder()).forEach(p -> {
                try { Files.deleteIfExists(p); } catch (java.io.IOException ignored) { }
            });
        } catch (java.io.IOException ignored) { }
    }
}
