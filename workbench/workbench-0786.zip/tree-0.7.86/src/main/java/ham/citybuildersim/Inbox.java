package ham.citybuildersim;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Everything the city has had to say for itself, newest first.
 *
 * WHAT THIS REPLACED
 *
 * Four red boxes that appeared in the middle of the main screen and had to be
 * dismissed before you could get on with anything. They worked - the shedding
 * banner is the reason a 4,000-month playtest stopped freezing at 660 people -
 * but they had two faults a banner cannot fix. A dismissed banner was gone: no
 * record it had ever appeared, and nothing to go back to when the player
 * changed their mind three months later. And a banner only exists on the screen
 * it was written for, so a warning raised during a fifty-month skip was
 * announced to an empty room.
 *
 * A notice does neither. It is raised by the CITY, once a month, whether
 * anybody is watching; it stays in the list after it is read; and it stays
 * after it is resolved, greyed, for two years, so "what went wrong in the
 * forties" has an answer.
 *
 * WHY THE TEXT IS BUILT HERE AND NOT ON THE SCREEN
 *
 * Because the screen is not always there. These sentences used to be built
 * inside UserInterface, which meant they could only be built while somebody was
 * looking at the main menu - so a condition that arose and passed inside a skip
 * produced no words at all. Built here, they are written the month the
 * condition is true, and the screen's only job is to draw them.
 *
 * @author Jerus
 */
public class Inbox {

    /** How long a resolved notice stays readable. Jerus asked for two years. */
    public static final int KEEP_MONTHS = 24;

    /*
     * Newest LAST, because that is the order they happened in and appending is
     * the honest way to record a sequence. The screen reverses it.
     */
    private List<Notice> notices = new ArrayList<>();

    /* ==================================================================
       THE MONTH
       ================================================================== */

    /**
     * Raise what is newly true, refresh what still is, resolve what is not.
     *
     * Called from Game.recordMonth, beside the graph history, and for the same
     * reason: both are records of a month that has finished, and both have to
     * happen whether or not a window is open.
     */
    public void takeMonth(Game game) {

        int month = game.getMonth();

        take(game, month, "shedding",
                game.isConstructionShedding(),
                "Your builders are being laid off",
                sheddingBody(game));

        take(game, month, "landlock",
                game.isPrivateInvestmentLandLocked(),
                "Your businesses have nowhere to build",
                landLockBody(game));

        take(game, month, "bank",
                game.getBank().isInsolvent(),
                "The bank has failed",
                bankBody(game));

        // The city resolved it this month (0.7.14): what happened, in the
        // log's words, read once and kept two years like any settled notice.
        TreasuryFund.Resolution resolved = game.getLastResolution();
        take(game, month, "resolved",
                resolved != null && resolved.month() == month,
                "The bank failed, and the city took it over",
                resolvedBody(game, resolved));

        // ...and a standing bank under its minimum asks for preferred: the
        // popup Jerus asked for, answered on the Bank tab.
        take(game, month, "preferred",
                game.isPreferredOfferPending(),
                "The bank asks the city to buy its preferred shares",
                preferredBody(game));

        List<String> defaults = defaultsBody(game);
        take(game, month, "defaults",
                !defaults.isEmpty(),
                "Businesses are going bust",
                defaults);

        List<String> health = healthcareBody(game);
        take(game, month, "healthcare",
                !health.isEmpty(),
                "The city is not looking after its people",
                health);

        List<String> crime = crimeBody(game);
        take(game, month, "crime",
                !crime.isEmpty(),
                "Crime is running above Canada's",
                crime);

        // The player's hand on the queue (0.7.22): a rushed site going into
        // its third month on overtime, when a month on it starts to do LESS
        // than a normal month for more pay - said the month before, while it
        // can still be stopped - and a demolition done.
        List<String> overtime = overtimeBody(game);
        take(game, month, "overtime",
                !overtime.isEmpty(),
                "Overtime now costs more than it gains",
                overtime);

        List<String> demolished = demolishedBody(game);
        take(game, month, "demolished",
                !demolished.isEmpty(),
                "A demolition is done",
                demolished);

        // Automatic building (0.7.73): a service below its spare margin that
        // this month's pass could not order for - the builders, the ground,
        // the budget or the player's debt limit, or nothing it could build -
        // a paragraph each, in its own words.
        List<String> autoBuild = new ArrayList<>();
        for (String held : game.getAutoBuilder().held()) {
            if (!autoBuild.isEmpty()) autoBuild.add("");
            autoBuild.addAll(wrapped(held, BODY_COLUMNS));
        }
        take(game, month, "autobuild",
                game.getAutoBuilder().isOn() && !autoBuild.isEmpty(),
                "Automatic building is held back",
                autoBuild);

        // ...and the ground it bought for its orders this month (0.7.77): which
        // offers, for what, and why those - a paragraph a purchase.
        List<String> autoLand = new ArrayList<>();
        for (String line : game.getAutoBuilder().bought()) {
            if (!autoLand.isEmpty()) autoLand.add("");
            autoLand.addAll(wrapped(line, BODY_COLUMNS));
        }
        take(game, month, "autobuild-land",
                game.getAutoBuilder().isOn() && !autoLand.isEmpty(),
                "Automatic building bought land",
                autoLand);

        cull(month);
    }

    /**
     * Every city's site on overtime whose next month is its third or later
     * (ConstructionControl, B. RUSH): from the third month on a 50-hour week
     * does less than a 40-hour one and still costs 1.375 times the wages.
     */
    private static List<String> overtimeBody(Game game) {
        List<String> lines = new ArrayList<>();
        BuildingManager b = game.getBuildingManager();
        for (ConstructionControl.Rush r : b.getControl().rushes()) {
            if (!r.on || r.months < 2) continue;
            int next = r.months + 1;
            lines.add(String.format("%s: month %d on overtime next - %.2fx a normal month's work for %.3fx the wages.",
                    b.nameOfSite(r.key), next, ConstructionControl.overtimeOutput(next),
                    ConstructionControl.OVERTIME_WAGE_BILL));
        }
        if (!lines.isEmpty()) {
            lines.add("");
            lines.add("Stop the rush on the construction page to go back to a normal week.");
        }
        return lines;
    }

    /** The demolitions that finished this month: the material sold to the builders, the ground freed. */
    private static List<String> demolishedBody(Game game) {
        List<String> lines = new ArrayList<>();
        // Each site's own sale, off its event (Game.settleConstructionControl()),
        // not looked up by its building and count: two demolitions of one
        // building and count finishing in one month are two sales.
        for (ConstructionControl.Completed c : game.getControlThisMonth().completed) {
            ConstructionControl.Demolition d = c.site();
            lines.add(String.format("%,d %s gone: %,.0f units of material to the builders for %s, %s back to the city.",
                    d.buildings, d.building, c.unitsSold(), money(c.paid()), LandManager.areaWords(d.landSqFt)));
        }
        return lines;
    }

    /**
     * One condition, this month.
     *
     * The live/not-live distinction is the whole method. A condition that is
     * true and has no live notice raises one; a condition that is true and
     * already has one refreshes its wording, because the numbers in it have
     * moved; a condition that has gone away resolves whatever was standing.
     */
    private void take(Game game, int month, String key, boolean nowTrue,
                      String title, List<String> body) {

        Notice live = live(key);

        if (nowTrue) {
            if (live == null) {
                notices.add(new Notice(key, title, body, month));
            } else {
                live.refresh(title, body);
            }
        } else if (live != null) {
            live.markResolved(month);
        }
    }

    /** A body line's most characters (0.7.73): the measure the bodies written by hand keep, inside the list's width in its mono face. */
    static final int BODY_COLUMNS = 62;

    /** A sentence broken at spaces into lines of at most `columns` characters (a longer word on a line of its own). */
    static List<String> wrapped(String text, int columns) {
        List<String> lines = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            if (line.length() > 0 && line.length() + 1 + word.length() > columns) {
                lines.add(line.toString());
                line.setLength(0);
            }
            if (line.length() > 0) line.append(' ');
            line.append(word);
        }
        if (line.length() > 0) lines.add(line.toString());
        return lines;
    }

    /** Drop what has been settled longer than anybody needs to remember. */
    private void cull(int month) {
        notices.removeIf(n -> n.isResolved()
                && n.monthsSinceResolved(month) > KEEP_MONTHS);
    }

    /* ==================================================================
       READING
       ================================================================== */

    /** Newest first, which is the order the screen wants and nothing else does. */
    public List<Notice> newestFirst() {
        List<Notice> out = new ArrayList<>(notices);
        Collections.reverse(out);
        return out;
    }

    /** In the order they happened. The harnesses read this one. */
    public List<Notice> all() { return notices; }

    public int size() { return notices.size(); }

    /**
     * The one that interrupts: newest unread notice whose condition still holds.
     * Until 0.7.20 its title was the line under the envelope; since then the
     * window toasts every urgent notice once (Notice.isUrgent(); the
     * interface's TOASTS), and this one turns the envelope red and is what
     * the clock stops for when the player has asked it to.
     *
     * Null most of the time, which is the point - an inbox that always has
     * something shouting in it is an inbox nobody opens.
     */
    public Notice urgent() {
        for (int i = notices.size() - 1; i >= 0; i--) {
            if (notices.get(i).isUrgent()) return notices.get(i);
        }
        return null;
    }

    /** What goes on the envelope. Counts unread, resolved or not. */
    public int unread() {
        int n = 0;
        for (Notice notice : notices) if (!notice.isRead()) n++;
        return n;
    }

    /** The live notice for a condition, or null if there is not one. */
    public Notice live(String key) {
        for (int i = notices.size() - 1; i >= 0; i--) {
            Notice notice = notices.get(i);
            if (notice.getKey().equals(key) && !notice.isResolved()) return notice;
        }
        return null;
    }

    public void markRead(Notice notice, int month) {
        if (notice != null) notice.markRead(month);
    }

    /* ==================================================================
       SAVE AND LOAD
       ================================================================== */

    /**
     * Takes over a loaded inbox wholesale.
     *
     * The same shape as HistorySave.restoreFrom and for the same reason: Gson
     * leaves a field alone when the JSON has no key for it, so a save written
     * before the inbox existed arrives here as null and has to come out as an
     * empty list rather than a crash. A city that loads with no notices is
     * correct - it is a city nothing had been said to yet, and next month the
     * conditions that are still true will say it again.
     */
    public void restoreFrom(List<Notice> loaded) {
        notices = loaded == null ? new ArrayList<>() : new ArrayList<>(loaded);
        notices.removeIf(java.util.Objects::isNull);
    }

    public void reset() { notices = new ArrayList<>(); }

    /* ==================================================================
       WHAT EACH ONE SAYS

       Lifted from the four banners in UserInterface, unchanged in wording,
       because the wording was the part that worked. What changed is where they
       are built: here, from the city, every month - rather than on a screen,
       from the city, whenever somebody happened to be looking at it.
       ================================================================== */

    private static List<String> sheddingBody(Game game) {

        List<String> lines = new ArrayList<>();
        if (!game.isConstructionShedding()) return lines;

        double capacity = game.getBuildingManager().getTotalConstructionCapacity();
        boolean covered = game.isAutoSubsidised(game.getSectors().construction());
        double lost = game.getConstructionShedPoints();

        lines.add(String.format("Construction sold %,.0f points of capacity - it has no", lost));
        lines.add("orders, so it is losing money and shrinking to fit.");
        lines.add("");
        lines.add(String.format("Capacity left:      %,.0f pts", capacity));
        lines.add(covered
                ? "Standing policy:    ON - the city covers its losses"
                : "Standing policy:    off - nothing is protecting them");
        lines.add("");
        lines.add("Everything you build runs through these crews. Once they are");
        lines.add("gone, rebuilding them is the slowest thing in the game.");
        return lines;
    }

    private static List<String> landLockBody(Game game) {

        List<String> lines = new ArrayList<>();
        if (!game.isPrivateInvestmentLandLocked()) return lines;

        java.util.Set<String> blocked = game.getLandBlockedSectors();
        double free = game.getLandManager().getAvailableSqFt();
        double used = game.getLandManager().getUtilisation() * 100;

        lines.add(blocked.size() == 1
                ? String.format("%s wants to expand and cannot -", blocked.iterator().next())
                : String.format("%d sectors want to expand and cannot -", blocked.size()));
        lines.add("there is no land left to build on.");
        lines.add("");
        lines.add(String.format("Waiting:            %s", String.join(", ", blocked)));
        lines.add("Land free:          " + LandManager.areaWords(free));
        lines.add(String.format("Land in use:        %.0f%%", used));
        lines.add("");
        lines.add("They will keep asking every month and keep being refused.");
        lines.add("Nothing else is wrong, and nothing will fix itself.");
        return lines;
    }

    private static List<String> bankBody(Game game) {

        List<String> lines = new ArrayList<>();
        Bank bank = game.getBank();
        if (!bank.isInsolvent()) return lines;

        // Since 0.7.14 nobody absorbs the hole: the bank carries it at the
        // central bank's window and waits for the city - this notice is only
        // ever live on the button, since automatic resolves it the same month.
        lines.add("It lost more than it owned, and it is frozen: no business can");
        lines.add("borrow to build or to cover a loss, the families can draw on");
        lines.add("their credit only for its interest, and the private sector");
        lines.add("has stopped building. It carries its hole at the central");
        lines.add("bank's window meanwhile, at the window's rate.");
        lines.add("");
        // TIMES A THOUSAND: the model counts in thousands and this was the one
        // place in the inbox that printed the raw figure with a dollar sign.
        lines.add(String.format("To resolve it:      $%,.0f",
                bank.recapitalisationNeeded() * 1000));
        lines.add(String.format("The treasury holds: $%,.0f", game.getCash() * 1000));
        lines.add("");
        lines.add("Resolving it pays the hole and the capital to reopen, from");
        lines.add("the treasury's cash and the rest advanced by the central");
        lines.add("bank. The city takes every share; the old owners lose");
        lines.add("everything.");
        return lines;
    }

    /** The month the city resolved the bank (0.7.14): the log's sentence, with its figures. */
    private static List<String> resolvedBody(Game game, TreasuryFund.Resolution r) {
        List<String> lines = new ArrayList<>();
        if (r == null || r.month() != game.getMonth()) return lines;
        lines.add("The bank failed. The city took all its shares; the old owners");
        lines.add(String.format("lost everything (%s at the last price).", money(r.ownersLost())));
        lines.add("");
        lines.add(String.format("The city put in:    %s", money(r.paid())));
        lines.add(String.format("  from its cash     %s", money(r.fromCash())));
        lines.add(String.format("  advanced by the   %s", money(r.advanced())));
        lines.add("  central bank");
        lines.add(String.format("The hole:           %s", money(r.shortfall())));
        lines.add(String.format("Capital to reopen:  %s", money(r.exitCapital())));
        if (r.preferredCancelled() > 0) {
            lines.add(String.format("The city's preferred, %s, went with the hole.", money(r.preferredCancelled())));
        }
        lines.add("");
        lines.add("It reopened the same month. Its new shares go to others, so");
        lines.add("the city's stake falls as it rebuilds.");
        return lines;
    }

    /** The bank's offer (0.7.14): the popup's sentence, TARP's terms. */
    private static List<String> preferredBody(Game game) {
        List<String> lines = new ArrayList<>();
        if (!game.isPreferredOfferPending()) return lines;
        Bank bank = game.getBank();
        lines.add("The bank is under its minimum capital and asks the city to");
        lines.add(String.format("buy %s of preferred shares: %.0f%% a year for five", money(game.preferredOfferSize()),
                Bank.PREFERRED_RATE * 100));
        lines.add(String.format("years, then %.0f%%, repayable at par after three years;",
                Bank.PREFERRED_STEP_RATE * 100));
        lines.add(String.format("with warrants on %s of its shares at %s.",
                money(game.preferredOfferWarrantValue()), money(game.preferredOfferStrike())));
        if (bank.preferredOfferCapped()) {
            lines.add("");
            lines.add("That is 3% of its risk-weighted assets, the most it may ask;");
            lines.add(String.format("the other %s it leaves to its own share issues.",
                    money(bank.preferredOfferShortOfTarget())));
        }
        lines.add("");
        lines.add("Accept or decline it on the Bank tab. Declined, it asks again");
        lines.add("in three months if it is still under its minimum.");
        return lines;
    }

    /**
     * FIRMS GOING BUST (0.7.8). A sector defaults a slice at a time now - a
     * small flow most months wherever anybody owes much - so the notice is
     * raised only on what a player should hear about
     * (BusinessDebtManager.defaultsAreNews()): the backstop, where a whole
     * sector went under, or a sector past the default point, where half its
     * firms fail within a year. Empty otherwise, which is the common case.
     */
    private static List<String> defaultsBody(Game game) {
        BusinessDebtManager credit = game.getEconomyManager().getBusinessDebtManager();
        List<String> lines = new ArrayList<>();
        List<String> news = new ArrayList<>();
        for (String s : credit.sectors()) if (credit.defaultsAreNews(s)) news.add(s);
        if (news.isEmpty()) return lines;

        lines.add(news.size() == 1
                ? "Firms in one sector went bust this month, and the bank"
                : String.format("Firms in %d sectors went bust this month, and the bank", news.size()));
        lines.add("wrote their loans off:");
        lines.add("");
        for (String s : news) {
            if (credit.wasRestructuredThisMonth(s)) {
                lines.add(String.format("%-16s went under whole - %s written off,", s,
                        money(credit.getWrittenOffThisMonth(s))));
                double forgiven = game.getEconomyManager().getOverdraftForgivenThisMonth(s);
                lines.add(String.format("%-16s %s of unpaid bills forgiven, shut out", "", money(forgiven)));
                lines.add(String.format("%-16s for %d months", "", credit.getBlockedMonths(s)));
            } else {
                lines.add(String.format("%-16s %.1f%% of its debt defaulted, %s written off", s,
                        credit.getDefaultShareThisMonth(s) * 100, money(credit.getWrittenOffThisMonth(s))));
                lines.add(String.format("%-16s (%.2fx its assets now: %.0f%% of its firms fail a year)", "",
                        credit.getLeverage(s), credit.getDefaultRate(s) * 100));
            }
        }
        lines.add("");
        Bank bank = game.getBank();
        if (bank.getBranches() > 0) {
            lines.add(String.format("Of all it wrote off this month, the bank had %s", money(bank.getAllowanceUsed())));
            lines.add("set aside already; the rest came out of its profit.");
            lines.add("");
        }
        lines.add("A sector keeps losing firms while it owes more than its plant");
        lines.add("can carry. It stops when it earns its way back or sheds debt.");
        return lines;
    }

    /** Thousands - the unit the model counts in - as a player reads money: $1.3M, $450k. */
    private static String money(double thousands) {
        double d = thousands * 1000, a = Math.abs(d);
        String sign = d < 0 ? "-" : "";
        if (a >= 1e9) return String.format("%s$%.1fB", sign, a / 1e9);
        if (a >= 1e6) return String.format("%s$%.1fM", sign, a / 1e6);
        if (a >= 1e4) return String.format("%s$%.0fk", sign, a / 1e3);
        return String.format("%s$%,.0f", sign, a);
    }

    /**
     * Crime at one and a half times Canada's rate or worse, or people the
     * police caught with no cell to hold them (2026-09-11). The reasons come
     * first, because they are the only thing that removes it - the police
     * second, and the cells third.
     */
    private static List<String> crimeBody(Game game) {
        Crime crime = game.getCrime();
        List<String> lines = new ArrayList<>();
        boolean high = crime.getRateVsCanada() >= 1.5;
        boolean unheld = crime.getNotHeld() >= 1;
        if (!high && !unheld) return lines;

        if (high) {
            lines.add(String.format("%,.0f crimes a year per 100,000 people - %.1f times Canada's.",
                    crime.getRatePer100k(), crime.getRateVsCanada()));
            Crime.Cause top = null;
            for (Crime.Cause c : Crime.Cause.values()) {
                if (c == Crime.Cause.NO_CAUSE) continue;
                if (top == null || crime.getCrimes(c) > crime.getCrimes(top)) top = c;
            }
            if (top != null && crime.getPressure() > 0) {
                lines.add(String.format("The biggest reason is %s: %.0f%% of it.",
                        top.label().toLowerCase(), 100 * crime.getCrimes(top) / Math.max(1e-9, crime.getCrimes())));
            }
            lines.add(String.format("Police cover %.0f%% of the city. Full coverage would take 90%% off",
                    crime.getCoverage() * 100));
            lines.add("the rest - never all of it. Only work, homes and money remove the reasons.");
            lines.add(String.format("%.1f people were killed last month; %s was stolen.",
                    crime.getKilled(), String.format("$%,.0f", crime.getStolen() * 1000)));
            lines.add("");
        }
        if (unheld) {
            lines.add(String.format("%,.0f people the police caught had no cell to go to, so they are",
                    crime.getNotHeld()));
            lines.add("still on the street. A jail or a penitentiary holds them.");
        }
        return lines;
    }

    /**
     * The three things healthcare is silently costing the city, when they apply.
     *
     * ONE NOTICE, UP TO FOUR PARAGRAPHS, rather than four notices - they are one
     * subject and one answer, and an inbox with four red lines in it teaches a
     * player to stop reading red lines.
     *
     * Ordered by how expensive each is right now rather than by category, so
     * whatever is actually hurting most is the first thing read. Empty when the
     * city has nothing to answer for, which is the common case in a city that
     * has built its clinics and its cemetery.
     */
    private static List<String> healthcareBody(Game game) {

        Health health = game.getHealth();
        Healthcare service = game.getHealthcare();
        BuildingManager bm = game.getBuildingManager();
        PopulationCohorts cohorts = game.getCohorts();
        double[] staffing = game.getPopulationManager().getJobFillRate();

        List<String> lines = new ArrayList<>();

        /* 1. the dead, because it is the sharpest and the cheapest to fix */
        if (service.getUnburied() > 0) {
            lines.add(String.format("%,.0f people have nowhere to be buried. It is adding %.0f",
                    service.getUnburied(), health.getUnburiedRate() * 100));
            lines.add("points to the sick rate. A cemetery or a crematorium ends it.");
            lines.add("");
        }

        /* 2. general care, which is the largest standing loss */
        double generalCover = Health.coverageOf(
                bm.getStaffedCareCapacity(CareType.GENERAL, staffing), cohorts.total());
        if (generalCover < .9 && cohorts.total() > 0) {
            lines.add(String.format("Only %.0f%% of the city can see a doctor, so %.0f%% of every",
                    generalCover * 100, health.getBaselineRate() * 100));
            lines.add("month's work is not done. Clinics and hospitals fix it.");
            // The long sick (2026-09-11): the same shortfall now kills.
            Sickness sickness = game.getSickness();
            double longSick = sickness.peoplePastTwoMonths(cohorts);
            if (longSick >= 1) {
                lines.add(String.format("%,.0f people have been ill for more than two months, and",
                        longSick));
                lines.add(String.format("%,.0f died of it last month. Only %.0f%% of the sick get",
                        sickness.getLastDeaths(), Sickness.recovery(generalCover) * 100));
                lines.add("better each month here.");
            }
            lines.add("");
        }

        /* 3. the two that kill people rather than slow them down */
        double childCover = Health.coverageOf(
                bm.getStaffedCareCapacity(CareType.CHILDCARE, staffing),
                CareType.CHILDCARE.populationServed(cohorts));
        double seniorCover = Health.coverageOf(
                bm.getStaffedCareCapacity(CareType.SENIOR, staffing),
                CareType.SENIOR.populationServed(cohorts));

        if (childCover < .5) {
            lines.add(String.format("Childcare reaches %.0f%%, so infants die at %.1fx the rate a",
                    childCover * 100,
                    Healthcare.mortalityFactor(AgeBand.BABY, childCover, .5, .5)));
            lines.add(String.format("half-served city loses - %.2f%% a year - and %.0f%% fewer",
                    AgeBand.BABY.getAnnualMortality()
                            * Healthcare.mortalityFactor(AgeBand.BABY, childCover, .5, .5) * 100,
                    (1 - Healthcare.birthFactor(childCover)
                            / Healthcare.birthFactor(1)) * 100));
            lines.add("children are born than in a city that has somewhere to put them.");
            lines.add("");
        }

        if (seniorCover < .5) {
            lines.add(String.format("Senior care reaches %.0f%%. Covering them would cut senior",
                    seniorCover * 100));
            lines.add(String.format("deaths to %.0f%% of today's and draw %.0f%% more people here.",
                    Healthcare.mortalityFactor(AgeBand.SENIOR, .5, .5, 1) * 100,
                    (Migration.seniorCarePull(1) - Migration.seniorCarePull(seniorCover)) * 100));
            lines.add("");
        }

        // Drop the trailing blank so the notice does not end in whitespace.
        if (!lines.isEmpty()) lines.remove(lines.size() - 1);
        return lines;
    }
}
