package ham.citybuildersim;

import ham.citybuildersim.sectors.Oil;
import ham.citybuildersim.sectors.Oil.Vintage;
import ham.citybuildersim.sectors.Oil.WellKind;

import java.io.OutputStream;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * The oil wells' lives (0.7.84, batch O7; runs/spec-oil.md 2.6 and 4's
 * WellCheck, the land half - the sea's platforms are batch O10's).
 *
 * WHAT THIS HAS TO PROVE:
 *
 *   1. THE PROFILES, TO THE BIT: a land well lifts LAND_KEEPS_A_YEAR (nine
 *      tenths) of its nameplate to the power of its years - 10% less a year -
 *      and a platform well all of it through PLATFORM_PLATEAU_MONTHS, then
 *      PLATFORM_KEEPS_A_YEAR to the power of its years past them.
 *
 *   2. RETIRED AT 263 MONTHS ON LAND AND 348 ON A PLATFORM: the first age at
 *      which a well lifts under ten barrels a day, 41.5 t of its 415.
 *
 *   3. A TOWN'S LIFT IS ITS VINTAGES': each batch of wells, from the month it
 *      opened, at its profile, summed oldest first - the nameplate the month
 *      is struck on, to the bit; a new well lifts its whole nameplate the
 *      month it opens; a read moves nothing; and the world's oil is
 *      conserved to the tonne.
 *
 *   4. A WORN-OUT WELL IS RETIRED, OLDEST FIRST, AND ITS SITE REFILLED: at 263
 *      months, by the month's retirements, and the sector's one-well-a-month
 *      rule drills its site again.
 *
 *   5. DRY AND SEA SITES ARE KEPT APART: a land well stands only on a dry site
 *      - the order, the card and the investors all refuse a sea one - and
 *      wells already standing past the dry sites, as a save from before 0.7.84
 *      carries them on the sea's, are kept.
 *
 *   6. THE VINTAGES CROSS A SAVE, to the bit, as the Oil sector's extras; and a
 *      save from before them reads every well new, opened the first month the
 *      city plays.
 *
 *   7. A WELL HAS ONE POST, a diploma's (the research's Q13: 0.2-0.4 workers a
 *      well [W12]; three until 0.7.84).
 *
 * Every fixture CAUSES its condition: the town is handed its oil by fiat
 * (LandManager.restoreSites(), as MiningCheck hands a city its ore), its
 * wells' ages by their vintages (Oil.setVintagesForTest()), and section 5's
 * sea field is bought.
 */
public class WellCheck {

    static int fails = 0;
    static PrintStream out;
    static PrintStream quiet;

    static void assertTrue(String label, boolean ok) {
        if (!ok) fails++;
        out.printf("%-100s %s%n", label, ok ? "OK" : "FAIL");
    }

    static void report(String label, boolean ok, String detail) {
        if (!ok) fails++;
        out.printf("%-100s %s  %s%n", label, ok ? "OK" : "FAIL", detail);
    }

    static void quietly(Runnable r) {
        PrintStream real = System.out;
        System.setOut(quiet);
        try { r.run(); } finally { System.setOut(real); }
    }

    static <T> T quietlyGet(java.util.function.Supplier<T> s) {
        Object[] r = new Object[1];
        quietly(() -> r[0] = s.get());
        @SuppressWarnings("unchecked") T t = (T) r[0];
        return t;
    }

    static BuildingsTemplate template(Game g, String name) {
        BuildingsTemplate t = g.getBuildingManager().getTemplateByName(name);
        if (t == null) throw new IllegalStateException("no template named " + name);
        return t;
    }

    /** Each fixture town's save folder (section 6). */
    static final java.util.Map<Game, GameFiles> FILES = new java.util.IdentityHashMap<>();

    /** A well's nameplate a month, the template's: 415 t, a hundred barrels a day. */
    static final double WELL_TONNES = 415;

    /** The oil a town is handed: far more than its wells lift in the months a section runs, so the ground never limits them. */
    static final double PLENTY = 50_000_000;

    /**
     * OilCheck's town: houses, shops, bakeries to work in, power, water, roads
     * and builders, standing, on ground a quarter more than they take and
     * `spare` square feet more, on the world `seed` (0 the default).
     */
    static Game town(String label, int houses, double spare, long seed) {
        GameFiles files = GameFiles.scratch(label);
        Game g = new Game(files);
        FILES.put(g, files);
        quietly(() -> {
            if (seed == 0) g.newGame(); else g.newGame(Founding.defaults().withWorldSeed(seed));
            g.setCashForTest(Founding.WEALTHY_CASH);
            BuildingManager b = g.getBuildingManager();
            String[] names = { "House", "Convenience Store", "Small Grocery Store", "Industrial Bakery", "Paved Road",
                    "Coal Power Plant", "Water Treatment Plant", "Construction Depot" };
            int[] counts = { houses, Math.max(1, houses / 45), Math.max(1, houses / 150), Math.max(1, houses / 150),
                    Math.max(4, houses / 15), 2, 1, 4 };
            double ground = 0;
            for (int i = 0; i < names.length; i++) ground += b.getTemplateByName(names[i]).getLandSqFt() * counts[i];
            g.getLandManager().setOwnedSqFt(LandManager.STARTING_SQ_FT + ground * 1.25 + spare);
            for (int i = 0; i < names.length; i++) g.buildStack(b.getTemplateByName(names[i]), counts[i], true);
        });
        return g;
    }

    /** The lift the vintages say, as the spec writes it: each vintage's wells x a well's nameplate x its profile at its age, oldest first. */
    static double liftOf(List<Vintage> vintages, double each, int month) {
        double lift = 0;
        for (Vintage v : vintages) lift += v.count() * each * Oil.profile(v.kind(), month - v.month());
        return lift;
    }

    /** Whether the world's oil is the town's unowned + remaining + extracted, to the tonne. */
    static boolean conserved(LandManager land, double world) {
        return Math.abs(land.getUnowned(Resource.OIL) + land.getRemaining(Resource.OIL) + land.getExtracted(Resource.OIL) - world) <= 1;
    }

    public static void main(String[] args) throws Exception {
        out = System.out;
        quiet = new PrintStream(new OutputStream() { @Override public void write(int b) { } });

        theProfiles();
        theirLife();
        Game lifted = aTownsLift();
        Game worn = wornOutWellsRetire();
        drySitesAndSea();
        acrossASave(worn);
        onePost();

        for (GameFiles f : FILES.values()) LongPlaytest.cleanUp(f.getDirectory().getParent());
        out.println();
        if (fails == 0) {
            out.println("All checks passed.");
        } else {
            out.println(fails + " FAILED");
            System.exit(fails);
        }
    }

    /* ============================ 1. THE PROFILES ============================ */

    static void theProfiles() {
        out.println("--- 1. the profiles, to the bit ---");
        assertTrue("a land well loses 10% of its lift a year, a platform well 8.5% after a plateau of three years (the research's"
                        + " 3.1 [W6][W16], est.)",
                Oil.LAND_KEEPS_A_YEAR == 1 - .10 && Oil.PLATFORM_KEEPS_A_YEAR == 1 - .085 && Oil.PLATFORM_PLATEAU_MONTHS == 36);
        boolean land = true, platform = true, yearly = true;
        for (int age = 0; age <= 600; age++) {
            land &= Oil.profile(WellKind.LAND, age) == StrictMath.pow(Oil.LAND_KEEPS_A_YEAR, age / 12.0);
            platform &= Oil.profile(WellKind.PLATFORM, age) == (age < Oil.PLATFORM_PLATEAU_MONTHS ? 1
                    : StrictMath.pow(Oil.PLATFORM_KEEPS_A_YEAR, (age - Oil.PLATFORM_PLATEAU_MONTHS) / 12.0));
            yearly &= Math.abs(Oil.profile(WellKind.LAND, age + 12) / Oil.profile(WellKind.LAND, age) - Oil.LAND_KEEPS_A_YEAR) < 1e-12;
        }
        assertTrue("a land well's profile is LAND_KEEPS_A_YEAR to the power of its age in years, every month of fifty years, to"
                + " the bit", land);
        assertTrue("...all of its nameplate the month it opens, nine tenths a year on, and nine tenths of the year before every year",
                Oil.profile(WellKind.LAND, 0) == 1 && Oil.profile(WellKind.LAND, 12) == Oil.LAND_KEEPS_A_YEAR && yearly);
        assertTrue("a platform well's is 1 through PLATFORM_PLATEAU_MONTHS, then PLATFORM_KEEPS_A_YEAR to the power of its years"
                + " past them, to the bit", platform && Oil.profile(WellKind.PLATFORM, 35) == 1
                && Oil.profile(WellKind.PLATFORM, 36) == 1 && Oil.profile(WellKind.PLATFORM, 48) == Oil.PLATFORM_KEEPS_A_YEAR);
        assertTrue("...and an age under nothing reads as nothing", Oil.profile(WellKind.LAND, -5) == 1
                && Oil.profile(WellKind.PLATFORM, -5) == 1);
    }

    /* ============================ 2. THEIR LIFE ============================ */

    static void theirLife() {
        out.println("\n--- 2. a well is worn out under ten barrels a day: at 263 months on land, 348 on a platform ---");
        double floor = WELL_TONNES * Oil.WORN_OUT_SHARE;
        assertTrue("worn out is WORN_OUT_BARRELS_A_DAY of a well's NAMEPLATE_BARRELS_A_DAY, ten of a hundred: 41.5 t of 415",
                Oil.WORN_OUT_SHARE == Oil.WORN_OUT_BARRELS_A_DAY / Oil.NAMEPLATE_BARRELS_A_DAY && Oil.WORN_OUT_BARRELS_A_DAY == 10
                        && Oil.NAMEPLATE_BARRELS_A_DAY == 100 && floor == 41.5);
        int land = Oil.lifeMonths(WellKind.LAND), platform = Oil.lifeMonths(WellKind.PLATFORM);
        report("a land well's life is 263 months: at 262 it lifts ten barrels a day or more, at 263 less",
                land == 263 && WELL_TONNES * Oil.profile(WellKind.LAND, 262) >= floor
                        && WELL_TONNES * Oil.profile(WellKind.LAND, 263) < floor,
                String.format("%,.2f t at 262, %,.2f t at 263", WELL_TONNES * Oil.profile(WellKind.LAND, 262),
                        WELL_TONNES * Oil.profile(WellKind.LAND, 263)));
        report("...a platform well's 348: its plateau and 26 years past it",
                platform == 348 && WELL_TONNES * Oil.profile(WellKind.PLATFORM, 347) >= floor
                        && WELL_TONNES * Oil.profile(WellKind.PLATFORM, 348) < floor,
                String.format("%,.2f t at 347, %,.2f t at 348", WELL_TONNES * Oil.profile(WellKind.PLATFORM, 347),
                        WELL_TONNES * Oil.profile(WellKind.PLATFORM, 348)));
    }

    /* ============================ 3. A TOWN'S LIFT ============================ */

    static Game aTownsLift() {
        out.println("\n--- 3. a town's lift is its vintages', to the bit ---");
        Game g = town("wellcheck-lift", 300, 8 * 87_120, 0);
        BuildingsTemplate well = template(g, "Oil Well");
        LandManager land = g.getLandManager();
        Oil wells = g.getSectors().oil();
        int[] stood = new int[2];
        quietly(() -> {
            // The wells' own orders held: this section's wells are the ones it stands.
            g.getBusinessInvestment().holdSector(Sectors.OIL);
            land.restoreSites(Resource.OIL, 6, PLENTY);
            stood[0] = g.getMonth();
            g.buildStack(well, 2, true);
        });
        double world = land.getWorldTotal(Resource.OIL);
        report("fixture: the town is handed six dry oil sites and plenty of oil, and stands two wells",
                land.getSites(Resource.OIL, true) == 6 && wells.landWellsStanding() == 2, String.format("%,.0f t", land.getOilReserveTonnes()));
        List<Vintage> unstruck = wells.vintagesNow();
        assertTrue("...read before a month is played: two wells new this month, the vintages struck holding none (a read moves"
                        + " nothing)",
                unstruck.equals(List.of(new Vintage(stood[0], 2, WellKind.LAND))) && wells.vintages().isEmpty()
                        && wells.getCapacity(Good.CRUDE) == 2 * WELL_TONNES);
        boolean struck = true, kept = true;
        for (int m = 0; m < 12; m++) {
            quietly(() -> g.simulateMonths(1));
            Sector.Output o = wells.output(Good.CRUDE);
            struck &= o.capacity == liftOf(wells.vintages(), WELL_TONNES, g.getMonth());
            kept &= conserved(land, world);
        }
        int firstOpened = stood[0] + 1;
        report("wells stood between two months open the first month played, and are struck so once a month",
                wells.vintages().equals(List.of(new Vintage(firstOpened, 2, WellKind.LAND))), wells.vintages().toString());
        quietly(() -> {
            stood[1] = g.getMonth();
            g.buildStack(well, 2, true);
        });
        double before = liftOf(wells.vintages(), WELL_TONNES, g.getMonth());
        report("a new well lifts all of its nameplate the month it opens: two more add 830 t to the lift, to the bit",
                wells.getCapacity(Good.CRUDE) == before + 2 * WELL_TONNES, String.format("%,.4f t on %,.4f", wells.getCapacity(Good.CRUDE), before));
        for (int m = 0; m < 6; m++) {
            quietly(() -> g.simulateMonths(1));
            Sector.Output o = wells.output(Good.CRUDE);
            struck &= o.capacity == liftOf(wells.vintages(), WELL_TONNES, g.getMonth());
            kept &= conserved(land, world);
        }
        List<Vintage> two = List.of(new Vintage(firstOpened, 2, WellKind.LAND), new Vintage(stood[1] + 1, 2, WellKind.LAND));
        report("two batches, two vintages, oldest first", wells.vintages().equals(two), wells.vintages().toString());
        double expected = liftOf(two, WELL_TONNES, g.getMonth());
        report("the nameplate is each vintage's wells x 415 t x its profile at its age, summed oldest first, to the bit",
                wells.getCapacity(Good.CRUDE) == expected && expected < 4 * WELL_TONNES,
                String.format("%,.6f t at ages %d and %d (new: %,.0f)", expected, g.getMonth() - firstOpened,
                        g.getMonth() - stood[1] - 1, wells.newWellsCapacity()));
        assertTrue("...the nameplate each month was struck on, every month of the eighteen", struck);
        double lifted = wells.output(Good.CRUDE).produced;
        report("...and the wells lift it at their operating rate, the ground permitting",
                lifted > 0 && Math.abs(lifted - wells.output(Good.CRUDE).capacity * wells.getOperatingRate()) <= 1e-9 * lifted,
                String.format("%,.3f t at %.4f", lifted, wells.getOperatingRate()));
        double first = wells.getCapacity(Good.CRUDE);
        assertTrue("the lift is cached on the month: read twice, the same, and the vintages unmoved",
                wells.getCapacity(Good.CRUDE) == first && wells.vintages().equals(two));
        assertTrue("...a well's part of the shrinking rules' measure is the average well's lift",
                Math.abs(wells.unitsOf(well) * 4 - first) <= 1e-9 * first);
        assertTrue("the world's oil is unowned + the town's remaining + its extracted, to the tonne, every month", kept);
        return g;
    }

    /* ============================ 4. WORN OUT, RETIRED, REFILLED ============================ */

    static Game wornOutWellsRetire() {
        out.println("\n--- 4. a worn-out well is retired, oldest first, and its site refilled ---");
        // Three hundred houses more than its jobs, and a year for their people to come, so the town has the hands to staff
        // a new well.
        Game g = town("wellcheck-worn", 600, 12 * 87_120 + 300 * 10_000, 0);
        BuildingsTemplate well = template(g, "Oil Well");
        LandManager land = g.getLandManager();
        Oil wells = g.getSectors().oil();
        int[] at = new int[1];
        quietly(() -> {
            g.buildStack(template(g, "House"), 300, true);
            land.restoreSites(Resource.OIL, 4, PLENTY);
            g.buildStack(well, 4, true);
            g.simulateMonths(12);
            at[0] = g.getMonth();
            // Two wells a month short of their life, two a hundred months old.
            wells.setVintagesForTest(List.of(new Vintage(at[0] - (Oil.lifeMonths(WellKind.LAND) - 1), 2, WellKind.LAND),
                    new Vintage(at[0] - 100, 2, WellKind.LAND)));
        });
        int month = at[0];
        report("fixture: four wells on four dry sites, two of them 262 months old: none worn out yet - and hands to staff another",
                wells.landWellsStanding() == 4 && wells.wornOut() == 0 && land.getSites(Resource.OIL, true) == 4
                        && wells.staffing(well).passes(),
                wells.vintages().toString());
        double world = land.getWorldTotal(Resource.OIL);
        int retiredBefore = g.getWellsWornOut();
        quietly(() -> g.simulateMonths(1));
        List<Vintage> after = wells.vintages();
        boolean younger = !after.isEmpty() && after.get(0).equals(new Vintage(month - 100, 2, WellKind.LAND));
        for (int i = 1; i < after.size(); i++) younger &= after.get(i).month() == month + 1;
        report("a month on, the two at 263 months are retired by the month's retirements, oldest first: the two younger stand",
                g.getWellsWornOut() - retiredBefore == 2 && younger
                        && wells.landWellsStanding() == 2 + (after.size() - 1 == 0 ? 0 : after.get(after.size() - 1).count()),
                String.format("%d retired; %s", g.getWellsWornOut() - retiredBefore, after));
        int[] committed = new int[8];
        boolean oneAMonth = true, kept = true;
        committed[0] = g.wellsCommitted();
        for (int m = 1; m < committed.length; m++) {
            quietly(() -> g.simulateMonths(1));
            committed[m] = g.wellsCommitted();
            oneAMonth &= committed[m] - committed[m - 1] <= 1 && committed[m] <= land.getSites(Resource.OIL, true);
            kept &= conserved(land, world);
        }
        report("the sector's one-well-a-month rule drills the freed sites again, one at a time",
                wells.landWellsStanding() == 4 && oneAMonth, java.util.Arrays.toString(committed) + " wells committed by month");
        List<Vintage> now = wells.vintages();
        boolean refilled = now.size() >= 2 && now.get(0).equals(new Vintage(month - 100, 2, WellKind.LAND));
        int fresh = 0;
        for (int i = 1; i < now.size(); i++) {
            refilled &= now.get(i).month() > month;
            fresh += now.get(i).count();
        }
        report("...each new well a vintage of its own month, lifting its whole nameplate when it opened",
                refilled && fresh == 2, now.toString());
        assertTrue("...and the world's oil is conserved, to the tonne", kept);
        return g;
    }

    /* ============================ 5. DRY AND SEA SITES ============================ */

    static void drySitesAndSea() {
        out.println("\n--- 5. dry and sea sites are kept apart: a land well stands only on a dry one ---");
        World w = World.of(OilCheck.SEA_OIL_SEED);
        Deposit sea = OilCheck.nearestSeaOil(w);
        report("fixture: the world's nearest oil field to its site is in the sea", sea != null,
                sea == null ? "none" : String.format("%d sites, %,.0f t, %.0f m deep", sea.sites(), sea.amount(), w.depthAt(sea.x(), sea.y())));
        if (sea == null) return;
        Game g = town("wellcheck-sea", 300, 4 * 87_120, OilCheck.SEA_OIL_SEED);
        BuildingsTemplate well = template(g, "Oil Well"), mine = template(g, "Iron Mine");
        LandManager land = g.getLandManager();
        Oil wells = g.getSectors().oil();
        int pushes = 0;
        while (!g.getCityLand().ownsPlot(sea.x(), sea.y()) && pushes < 200) {
            LandParcel p = MiningCheck.nearestOffer(land.getMarket(), sea.x(), sea.y());
            if (p == null) break;
            g.setCashForTest(g.getCash() + p.localPrice(g.getForeignAccounts().getRate()));
            if (!quietlyGet(() -> g.buyLandParcel(p.getId()))) break;
            pushes++;
        }
        int all = land.getOilSites(), seaSites = land.getSites(Resource.OIL, false), dry = land.getSites(Resource.OIL, true);
        report("fixture: the town buys the ground over it, and all its oil sites are the sea's",
                g.getCityLand().ownsPlot(sea.x(), sea.y()) && all > 0 && seaSites == all && dry == 0,
                String.format("%d purchase(s): %d site(s), %d at sea", pushes, all, seaSites));
        assertTrue("a land well's sites are the dry ones (Game.sitesFor()); an Iron Mine's all its iron's",
                g.sitesFor(well) == dry && g.sitesFor(mine) == land.getSites(Resource.IRON) && g.sitesFor(template(g, "House")) == 0);
        Game.BuildResult refused = quietlyGet(() -> g.buildStack(well, 1, false));
        BuildCard.Verdict v = BuildCard.verdict(g, well, 1);
        report("an Oil Well on a sea site is refused for its deposit, on the card as at the order",
                refused == Game.BuildResult.NO_DEPOSIT && v.kind() == BuildCard.VerdictKind.NO_DEPOSIT, refused + ", " + v.kind());
        BusinessInvestment.Decision d = wells.plan(g.getBusinessInvestment(), g);
        report("...and the investors drill none: the word names the deposit and the dry ground", !d.build
                && d.reason.contains("deposit") && d.reason.contains("dry ground"), "\"" + d.reason + "\"");

        // Two dry sites handed to the centre, with none of the oil: the wells lift the town's pool, the sea field's.
        double owned = land.getOwnedAmount(Resource.OIL);
        quietly(() -> land.restoreSites(Resource.OIL, seaSites + 2, owned));
        Game.BuildResult two = quietlyGet(() -> g.buildStack(well, 2, true));
        Game.BuildResult third = quietlyGet(() -> g.buildStack(well, 1, false));
        report("with two dry sites beside the sea's, two wells stand and a third is refused",
                land.getSites(Resource.OIL, true) == 2 && land.getSites(Resource.OIL, false) == seaSites
                        && two == Game.BuildResult.SUCCESS && third == Game.BuildResult.NO_DEPOSIT && g.wellsCommitted() == 2,
                two + ", " + third);

        // ...and those two dry sites taken away again: the wells now stand past the dry sites, as a save from before 0.7.84
        // carries wells on the sea's.
        quietly(() -> land.restoreSites(Resource.OIL, seaSites, owned));
        double world = land.getWorldTotal(Resource.OIL);
        boolean kept = true, standing = true;
        for (int m = 0; m < 6; m++) {
            quietly(() -> g.simulateMonths(1));
            standing &= wells.landWellsStanding() == 2 && g.wellsCommitted() == 2;
            kept &= conserved(land, world);
        }
        report("wells standing past the dry sites, on the sea's, are kept: six months on, both stand and lift, and none is added",
                standing && land.getSites(Resource.OIL, true) == 0 && wells.output(Good.CRUDE).produced > 0,
                String.format("%,.0f t lifted the last month", wells.output(Good.CRUDE).produced));
        Game.BuildResult again = quietlyGet(() -> g.buildStack(well, 1, false));
        assertTrue("...an order is still refused for its deposit", again == Game.BuildResult.NO_DEPOSIT);
        assertTrue("...and the world's oil is conserved, to the tonne", kept);
    }

    /* ============================ 6. ACROSS A SAVE ============================ */

    static void acrossASave(Game g) throws Exception {
        out.println("\n--- 6. the vintages cross a save, and a save from before them reads every well new ---");
        Oil wells = g.getSectors().oil();
        List<Vintage> before = wells.vintages();
        double lift = wells.getCapacity(Good.CRUDE);
        GameFiles files = FILES.get(g);
        quietly(() -> g.saveGame(10, "wells"));
        Game twin = new Game(files);
        quietly(() -> twin.loadGameSave(10));
        Oil back = twin.getSectors().oil();
        report("the vintages and the lift cross a save, to the bit",
                twin.getLoadFailure() == null && back.vintages().equals(before) && back.getCapacity(Good.CRUDE) == lift
                        && before.size() >= 2,
                before.toString());
        quietly(() -> {
            g.simulateMonths(1);
            twin.simulateMonths(1);
        });
        assertTrue("...and a month on, the city and its reload strike the same vintages and lift the same crude, to the bit",
                back.vintages().equals(wells.vintages()) && back.getCapacity(Good.CRUDE) == wells.getCapacity(Good.CRUDE)
                        && back.output(Good.CRUDE).produced == wells.output(Good.CRUDE).produced);

        // The keys, and a save without them.
        quietly(() -> twin.saveGame(10, "wells"));
        Path file = files.saveFile(10);
        com.google.gson.JsonObject o = com.google.gson.JsonParser.parseString(Files.readString(file)).getAsJsonObject();
        com.google.gson.JsonObject oilState = OilCheck.sectorOf(o, Sectors.OIL);
        com.google.gson.JsonObject extras = oilState == null ? null : oilState.getAsJsonObject("extras");
        java.util.List<String> keys = new java.util.ArrayList<>();
        if (extras != null) for (String k : extras.keySet()) if (k.startsWith(Oil.VINTAGE_KEY)) keys.add(k);
        Vintage oldest = back.vintages().isEmpty() ? null : back.vintages().get(0);
        assertTrue("...saved as the Oil sector's extras, vintages.<month opened>.<kind>, the count the value",
                oldest != null && keys.size() == back.vintages().size()
                        && extras.get(Oil.VINTAGE_KEY + oldest.month() + "." + oldest.kind().name()).getAsDouble() == oldest.count());
        for (String k : keys) extras.remove(k);
        Files.writeString(file, new com.google.gson.GsonBuilder().serializeSpecialFloatingPointValues().create().toJson(o));
        Game old = new Game(files);
        quietly(() -> old.loadGameSave(10));
        Oil oldWells = old.getSectors().oil();
        int standing = oldWells.landWellsStanding();
        report("a save from before 0.7.84 has none: every well it stands is read new, its whole nameplate",
                old.getLoadFailure() == null && oldWells.vintages().isEmpty() && standing > 0
                        && oldWells.getCapacity(Good.CRUDE) == standing * WELL_TONNES && oldWells.wornOut() == 0,
                String.format("%d well(s), %,.0f t", standing, oldWells.getCapacity(Good.CRUDE)));
        int loaded = old.getMonth();
        quietly(() -> old.simulateMonths(1));
        report("...and struck as opened the first month the city plays",
                oldWells.vintages().equals(List.of(new Vintage(loaded + 1, oldWells.landWellsStanding(), WellKind.LAND))),
                oldWells.vintages().toString());
        assertTrue("...the audit closing", old.getLastMoneyAudit().relative() < 1e-10);
    }

    /* ============================ 7. ONE POST ============================ */

    static void onePost() {
        out.println("\n--- 7. a well has one post ---");
        BuildingManager bm = new BuildingManager();
        bm.initializeBuiltInTemplates();
        BuildingsTemplate twin = bm.getTemplateByName("Oil Well");
        BuildingsTemplate data = null;
        List<BuildingsTemplate> file = new BuildingCatalog().load();
        if (file != null) for (BuildingsTemplate t : file) if (t.getId() == 74) data = t;
        boolean one = true;
        for (BuildingsTemplate t : new BuildingsTemplate[] { twin, data }) {
            one &= t != null && t.getTotalJobs() == 1 && t.getJobs(JobType.DIPLOMA) == 1;
        }
        assertTrue("the Oil Well has one post, a diploma's, in buildings.json and its built-in twin (the research's Q13; three"
                + " until 0.7.84)", one);
    }
}
