package ham.citybuildersim.sectors;

import ham.citybuildersim.BuildingType;
import ham.citybuildersim.BuildingsTemplate;
import ham.citybuildersim.BusinessInvestment;
import ham.citybuildersim.Formats;
import ham.citybuildersim.Game;
import ham.citybuildersim.Good;
import ham.citybuildersim.LandManager;
import ham.citybuildersim.Resource;
import ham.citybuildersim.Sector;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Oil wells. THE SIXTEENTH SECTOR (0.7.62, batch K; the project's
 * spec-land.md 2.7).
 *
 * MINING'S SHAPE, ON THE OTHER RESOURCE. The world laid oil in fields from
 * the start (Resource.OIL, batch J1a) and the land office has sold the
 * ground over it since J1b; this is what lifts it. A well stands on an
 * unworked oil site the city owns (Game.hasDepositFor(), by its good), lifts
 * 415 t of crude a month - a hundred barrels a day - and ships what it
 * lifts: CRUDE is a flow good, so what the refiners do not take at the
 * local price leaves at the export price the same month, which is why a
 * well is worth drilling before there is a refinery. The ground limits it
 * through the template's hook (groundLimit()), and the wells retire when
 * the oil runs out, as the mines do when the ore does.
 *
 * SINCE 0.7.84 (batch O7; runs/spec-oil.md 2.6) A WELL DECLINES: it lifts
 * its 415 t the month it opens and 10% less each year after, and is retired
 * below ten barrels a day, after 263 months (THE WELLS DECLINE, below); a
 * land well stands only on a dry site - a field whose centre is on land -
 * and has one post, not three.
 *
 * Everything else - the books, the credit, the market, the payroll, the
 * export - is the template's.
 */
public final class Oil extends Sector {

    public Oil() {
        super("Oil", "Oil", BuildingType.MINING);
        makes(Good.CRUDE);
        blurb("Lifts crude from the city's oil fields and sells it to the refinery, or ships "
                + "it abroad when the refinery does not want it. The oil the city owns is the "
                + "limit, and the city has to buy the ground it is under.");
    }

    /** The ground, not the well, decides what comes up. */
    @Override
    protected double groundLimit(Good g, double asked) {
        if (game == null || g != Good.CRUDE) return asked;
        LandManager land = game.getLandManager();
        return land == null ? asked : land.extractOil(asked);
    }

    /** What the wells could lift this month if the ground allowed it. */
    public double getPotentialOutput() {
        return getCapacity(Good.CRUDE) * getOperatingRate();
    }

    /* =====================================================================
       THE WELLS DECLINE (0.7.84, batch O7; runs/spec-oil.md 2.6, the
       project's oil-and-ports-research.md 3)

       A well lifted its 415 t a month - a hundred barrels a day - for as
       long as its field had oil. A real one does not: an onshore well loses
       10-25% in its first year and a field 4.2% a year [W6]; a well on a
       shallow-water platform holds a plateau of two or three years and then
       loses 8.5% a year [W6][W16]. The research's proposal (3.2): each land
       well loses 10% a year (est.) and retires below ten barrels a day, and
       the sector's one-well-a-month rule refills its site.

       VINTAGES. The wells are kept as vintages - the month a batch of them
       opened, how many, and their kind (LAND; PLATFORM is batch O10's) -
       saved in the sector's extras as vintages.<month>.<KIND>. A well lifts
       its template's nameplate times its kind's profile at its age in
       months (profile()), so the sector's nameplate is the sum over its
       vintages (getCapacity()), struck once a month and cached on it.

       ONE COUNT, MANY WAYS TO MOVE IT. Wells open (the month's completions,
       a fixture's stand, a load) and close (worn out, the shrinking rules, a
       demolition, a buy-out) by paths that know nothing of vintages. So the
       vintages are read against the wells standing (view()): wells they do
       not hold are new this month, and wells they hold that no longer stand
       were the oldest - the retirements below take the oldest first, and
       every other rule that sells a well is taken to sell its least
       productive one. The vintages are struck to that reading once a month,
       at its end (endOfMonth()), after the month's completions have lifted:
       a well lifts its whole nameplate the month it opens, and the month's
       retirements, at its top (Game.runRetirement()), read its age then.
       A read never moves them, so nothing a screen reads changes the month.

       A save from before 0.7.84 has no vintages: every well it stands is
       read as new, and struck as opened the first month the city plays.
       ===================================================================== */

    /** A well's kind: on land, on a dry site; or on an offshore platform's slot (batch O10). Saved by name. */
    public enum WellKind { LAND, PLATFORM }

    /** A batch of wells: the month they opened, how many, and their kind. */
    public record Vintage(int month, int count, WellKind kind) { }

    /** A land well keeps nine tenths of its lift a year: it loses 10% a year (the research's 3.2, est.; [W6]). */
    public static final double LAND_KEEPS_A_YEAR = .9;

    /** A platform well holds its lift for a plateau of three years (the research's 3.1: two or three [W6][W16]; spec-oil 2.6)... */
    public static final int PLATFORM_PLATEAU_MONTHS = 36;

    /** ...and then keeps 91.5% of it a year: it loses 8.5% a year, the IEA's shallow-offshore rate [W6][W16]. */
    public static final double PLATFORM_KEEPS_A_YEAR = .915;

    /** A well's nameplate is a hundred barrels a day (BuildingManager, FUEL: 415 t a month at 7.33 barrels a tonne). */
    public static final double NAMEPLATE_BARRELS_A_DAY = 100;

    /** A well lifting under ten barrels a day is worn out and retired (the research's 3.2): 41.5 t a month of a 415 t well's. */
    public static final double WORN_OUT_BARRELS_A_DAY = 10;

    /** ...the share of its nameplate a well is retired under: WORN_OUT_BARRELS_A_DAY over NAMEPLATE_BARRELS_A_DAY, a tenth. */
    public static final double WORN_OUT_SHARE = WORN_OUT_BARRELS_A_DAY / NAMEPLATE_BARRELS_A_DAY;

    /** The extras' key a vintage is saved under: vintages.<month opened>.<kind>, its count the value. */
    public static final String VINTAGE_KEY = "vintages.";

    /**
     * The share of its nameplate a well of `kind` lifts at `age` months (pure):
     * a land well LAND_KEEPS_A_YEAR to the power of its years; a platform well
     * 1 through its plateau and PLATFORM_KEEPS_A_YEAR to the power of its
     * years past it. StrictMath, as World's arithmetic, so a well declines the
     * same on every machine. An age under nothing is read as nothing.
     */
    public static double profile(WellKind kind, int age) {
        int a = Math.max(0, age);
        if (kind == WellKind.PLATFORM) {
            return a < PLATFORM_PLATEAU_MONTHS ? 1
                    : StrictMath.pow(PLATFORM_KEEPS_A_YEAR, (a - PLATFORM_PLATEAU_MONTHS) / 12.0);
        }
        return StrictMath.pow(LAND_KEEPS_A_YEAR, a / 12.0);
    }

    /** The age, in months, from which a well of `kind` lifts under WORN_OUT_SHARE of its nameplate: 263 on land, 348 on a platform. */
    public static int lifeMonths(WellKind kind) {
        return kind == WellKind.PLATFORM ? PLATFORM_LIFE : LAND_LIFE;
    }

    private static final int LAND_LIFE = firstWornOut(WellKind.LAND), PLATFORM_LIFE = firstWornOut(WellKind.PLATFORM);

    private static int firstWornOut(WellKind kind) {
        int age = 0;
        while (!(profile(kind, age) < WORN_OUT_SHARE)) age++;
        return age;
    }

    /** The vintages as struck, oldest first (the month's reading is vintagesNow()). */
    private final List<Vintage> vintages = new ArrayList<>();

    /** Moves with every change to `vintages`, for the lift's cache. */
    private long vintagesStamp;

    /** The vintages as struck last, oldest first: what the save carries. */
    public List<Vintage> vintages() {
        return List.copyOf(vintages);
    }

    /** Whether a building is a land well: one of this sector's MINING templates that lifts crude. */
    public static boolean isLandWell(BuildingsTemplate t) {
        return t != null && t.getCategory() == BuildingType.MINING && t.makes(Good.CRUDE) > 0;
    }

    /** The land wells standing, finished. */
    public int landWellsStanding() {
        if (buildings == null) return 0;
        int n = 0;
        for (BuildingsTemplate t : buildings.getTemplatesBySector(key())) {
            if (isLandWell(t)) n += buildings.getQuantity(t.getId());
        }
        return n;
    }

    /** A land well's nameplate a month: the template's crude (415 t); 0 with no such template. */
    public double wellNameplate() {
        if (buildings == null) return 0;
        for (BuildingsTemplate t : buildings.getTemplatesBySector(key())) {
            if (isLandWell(t)) return t.makes(Good.CRUDE);
        }
        return 0;
    }

    /** The month the vintages are read at: the game's. */
    private int monthNow() {
        return game == null ? 0 : game.getMonth();
    }

    /**
     * Vintages read against the wells standing (pure): of `kind`, those it
     * holds past the wells standing are dropped oldest first, and wells
     * standing past those it holds are a new vintage opened in `month`;
     * vintages of the other kind are left as they are.
     */
    public static List<Vintage> view(List<Vintage> kept, WellKind kind, int standing, int month) {
        int held = 0;
        for (Vintage v : kept) if (v.kind() == kind) held += v.count();
        List<Vintage> out = new ArrayList<>(kept.size() + 1);
        int drop = Math.max(0, held - Math.max(0, standing));
        for (Vintage v : kept) {
            if (v.kind() != kind || drop == 0) {
                out.add(v);
                continue;
            }
            int gone = Math.min(drop, v.count());
            drop -= gone;
            if (v.count() > gone) out.add(new Vintage(v.month(), v.count() - gone, kind));
        }
        int added = Math.max(0, standing - held);
        if (added > 0) {
            Vintage last = out.isEmpty() ? null : out.get(out.size() - 1);
            if (last != null && last.month() == month && last.kind() == kind) {
                out.set(out.size() - 1, new Vintage(month, last.count() + added, kind));
            } else {
                out.add(new Vintage(month, added, kind));
            }
        }
        return out;
    }

    /** The vintages this month, read against the wells standing (view()): what the lift and the retirements read. */
    public List<Vintage> vintagesNow() {
        return view(vintages, WellKind.LAND, landWellsStanding(), monthNow());
    }

    /** Strikes the vintages to this month's reading (endOfMonth(): once a month, after it has lifted). */
    public void strikeVintages() {
        List<Vintage> now = vintagesNow();
        if (now.equals(vintages)) return;
        vintages.clear();
        vintages.addAll(now);
        vintagesStamp++;
    }

    /** A fixture's vintages, struck as given, oldest first (WellCheck, SaveFileCheck). */
    public void setVintagesForTest(List<Vintage> given) {
        vintages.clear();
        vintages.addAll(given);
        vintagesStamp++;
    }

    /** The lift's cache: the month, the wells standing and the vintages' stamp it was summed for. */
    private int liftMonth = Integer.MIN_VALUE, liftStanding = -1;
    private long liftStamp = -1;
    private double liftCached;

    /**
     * The crude the wells can lift a month (0.7.84): over this month's
     * vintages, each vintage's wells times a well's nameplate times its kind's
     * profile at its age, oldest first - cached on the month, the wells
     * standing and the vintages. Every other good, and a sector with no city,
     * the template's nameplate.
     */
    @Override
    public double getCapacity(Good g) {
        if (g != Good.CRUDE || game == null || buildings == null) return super.getCapacity(g);
        int month = monthNow(), standing = landWellsStanding();
        if (month == liftMonth && standing == liftStanding && vintagesStamp == liftStamp) return liftCached;
        double each = wellNameplate(), lift = 0;
        for (Vintage v : view(vintages, WellKind.LAND, standing, month)) {
            lift += v.count() * each * profile(v.kind(), month - v.month());
        }
        liftMonth = month;
        liftStanding = standing;
        liftStamp = vintagesStamp;
        liftCached = lift;
        return lift;
    }

    /** The wells' nameplate at the template's figure, as if every one were new: what the decline is measured against. */
    public double newWellsCapacity() {
        return super.getCapacity(Good.CRUDE);
    }

    /** The wells standing that are worn out this month: past their kind's life (lifeMonths()), under ten barrels a day. */
    public int wornOut() {
        int n = 0, month = monthNow();
        for (Vintage v : vintagesNow()) {
            if (month - v.month() >= lifeMonths(v.kind())) n += v.count();
        }
        return n;
    }

    /** The land well the sector drills, its own template: what a worn-out well's retirement sells. */
    public BuildingsTemplate landWell() {
        if (buildings == null) return null;
        for (BuildingsTemplate t : buildings.getTemplatesBySector(key())) if (isLandWell(t)) return t;
        return null;
    }

    /** The month's loose ends (Markets.clearMonth()'s last step): the vintages struck to the wells that stood this month. */
    @Override
    public void endOfMonth(Game game) {
        if (game != null) strikeVintages();
    }

    @Override
    protected void saveExtras(Map<String, Double> extras) {
        for (Vintage v : vintages) extras.put(VINTAGE_KEY + v.month() + "." + v.kind().name(), (double) v.count());
    }

    /** A save from before 0.7.84 has none: its wells are read as new (view()). A key or count that does not read is skipped. */
    @Override
    protected void restoreExtras(Map<String, Double> extras) {
        vintages.clear();
        for (Map.Entry<String, Double> e : extras.entrySet()) {
            String k = e.getKey();
            Double c = e.getValue();
            if (k == null || !k.startsWith(VINTAGE_KEY) || c == null || !(c >= 1) || !Double.isFinite(c)) continue;
            String[] parts = k.substring(VINTAGE_KEY.length()).split("\\.");
            if (parts.length != 2) continue;
            try {
                vintages.add(new Vintage(Integer.parseInt(parts[0]), (int) Math.min(Integer.MAX_VALUE, Math.floor(c)),
                        WellKind.valueOf(parts[1])));
            } catch (IllegalArgumentException bad) {
                // not a vintage this build reads
            }
        }
        vintages.sort(java.util.Comparator.comparingInt(Vintage::month).thenComparing(Vintage::kind));
        vintagesStamp++;
    }

    @Override
    protected void resetExtras() {
        vintages.clear();
        vintagesStamp++;
    }

    /**
     * Whether to drill another well: one a month while an owned oil site is
     * unworked and oil is left in the ground - Mining's rule, on oil
     * (spec-land 2.7). The deposit word says "deposit", which the Sectors
     * screen reads as ORE (BuildCard.wordKind()). Since 0.7.84 a land well's
     * site is a dry one (Game.sitesFor()): the sea's sites wait for a
     * platform (batch O10), and the wells already on them are kept.
     */
    @Override
    public BusinessInvestment.Decision plan(BusinessInvestment plans, Game game) {

        String sector = key();
        if (buildings.getUnderConstructionBySector(sector) >= BusinessInvestment.MAX_CONCURRENT_ORDERS) {
            return BusinessInvestment.Decision.no(sector, "already building");
        }

        LandManager land = game.getLandManager();
        int dry = land.getSites(Resource.OIL, true);
        int unworked = dry - game.wellsCommitted();
        double reserve = land.getOilReserveTonnes();

        if (land.getOilSites() <= 0) return BusinessInvestment.Decision.no(sector, "no oil deposit to drill");
        if (unworked <= 0) {
            return BusinessInvestment.Decision.no(sector, dry < land.getOilSites()
                    ? "no oil deposit on dry ground to drill" : "no oil deposit to drill");
        }
        if (reserve <= 0)  return BusinessInvestment.Decision.no(sector, "every oil deposit is worked out");

        BuildingsTemplate best = null;
        double bestScore = 0;
        Staffing staffingHold = null;
        String staffingHoldName = null;
        for (BuildingsTemplate t : buildings.getTemplatesBySector(sector)) {
            if (t.makes(Good.CRUDE) <= 0) continue;
            // ...and one the city could staff (0.7.18; see Sector.staffing()).
            Staffing staffing = staffing(t);
            if (!staffing.passes()) {
                if (staffingHold == null || staffing.share > staffingHold.share) {
                    staffingHold = staffing;
                    staffingHoldName = t.getName();
                }
                continue;
            }
            double cost = plans.getCostOf(t, 1);
            if (cost <= 0) continue;
            double score = estimatedMonthlyProfit(t, plans) / cost;
            if (score > bestScore) {
                bestScore = score;
                best = t;
            }
        }

        if (best == null) {
            return BusinessInvestment.Decision.no(sector, staffingHold != null
                    ? staffingHold.why(staffingHoldName) : "nothing worth sinking");
        }
        if (plans.plotsAvailableFor(best) < 1) {
            return BusinessInvestment.Decision.noLand(sector, plans.landReason(best));
        }
        return new BusinessInvestment.Decision(sector, best, 1,
                String.format("%d oil deposit site(s) undrilled, %,.0fk tonnes in the ground",
                        unworked, reserve / 1000), true);
    }

    /**
     * A price-taking exporter sells what it lifts and shrinks on distress -
     * while there is oil. A well over a worked-out field lifts nothing, and is
     * spare by any measure: Mining's rule, for Mining's reason.
     */
    @Override
    public double[] retirementDemandAndCapacity(Game game) {
        if (game == null) return null;
        double capacity = getCapacity(Good.CRUDE);
        if (capacity <= 0) return null;
        return game.getLandManager().getOilReserveTonnes() > 0
                ? null
                : new double[] { 0, capacity };
    }

    /**
     * A well's part of the measure above (0.7.84): the average well's lift -
     * the template's nameplate times the wells' lift over what they would lift
     * new - so a field worked out sheds wells by the count, as it did before
     * the wells declined, not by their lift in new wells.
     */
    @Override
    public double unitsOf(BuildingsTemplate t) {
        double each = super.unitsOf(t), asNew = newWellsCapacity();
        if (!isLandWell(t) || game == null || !(asNew > 0)) return each;
        return each * (getCapacity(Good.CRUDE) / asNew);
    }

    @Override
    public List<Line> ownLines(Game game) {
        List<Line> lines = new java.util.ArrayList<>();
        if (game == null) return lines;
        Formats f = Formats.INSTANCE;
        LandManager land = game.getLandManager();
        int dry = land.getSites(Resource.OIL, true);
        lines.add(Line.head("What is under the ground"));
        lines.add(Line.of("Oil sites owned", f.count(land.getOilSites())));
        lines.add(Line.of("On dry ground", f.count(dry)));
        lines.add(Line.of("Being worked", f.count(game.wellsCommitted()),
                game.wellsCommitted() < dry ? Line.Tone.WARN : Line.Tone.GOOD));
        lines.add(Line.of("Crude in the ground", f.count(land.getOilReserveTonnes()) + " t"));
        double asNew = newWellsCapacity();
        if (asNew > 0) {
            lines.add(Line.of("Lifting a month", f.count(getCapacity(Good.CRUDE)) + " t, "
                    + Math.round(getCapacity(Good.CRUDE) / asNew * 100) + "% of new"));
        }
        if (game.wellsCommitted() < dry && land.getOilReserveTonnes() > 0) {
            lines.add(Line.note("There is oil under this city that no well is lifting."));
        }
        if (dry < land.getOilSites()) {
            lines.add(Line.note("A land well stands only on dry ground, not on the sites at sea."));
        }
        return lines;
    }
}
