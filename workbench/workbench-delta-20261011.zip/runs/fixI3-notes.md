# fixI3 notes (0.7.116): iron's prices and the split of scrap from ore
Worktree /home/claude/git/wt-I3, branch batch/I3 from 04d505c; scratch /home/claude/scratch-i3. Opus, 2026-10-11.

## 0. Progress
- PROBE A (goods + rows 11/12/14 + iron 1/212.5; HeavyIndustry's old plan on SCRAP): moves from m4; the player built Electric Arc
  Furnaces 5 times on the maker's estimate, shed, Heavy Industry a shell from m1032 (402 default months); end 433,661 (566,444).
  PROBE B (Heavy Industry on ProcessingSector, Mining's money gate): end 577,610, no furnace ever. pt07116 = ptB byte for byte.
- SLIPS: one sed's output sent to /dev/null (`>/dev/null 2>&1`), owned; a WellCheck edit anchored on a line found four
  times cut 600 lines - rebuilt from `git show HEAD:` in scratch, both edits re-applied (diff 17+/19-).

## 1. What I built
- **Good**: IRON "Iron ore" .115/.085 (freight .01125); SCRAP new (.41/.30, .04125, flow, BULK, DRY_BULK; appended); STEEL
  .650/.470 (.0675); FABRICATED_STEEL -/1.545 (.3398); MACHINERY 13.4/8.1 (1.98); CARS 41.3125/33.3125; VANS 68.135;
  ROLLING_STOCK 2,302.2. Comments: each figure's reason; the old tables kept as the dated history.
- **Rows** (json + twin): id 11 "Electric Arc Furnace" uses SCRAP 1,320, consumables 24.13; id 12 SCRAP 6,600, 119.7; id 14
  20,000 t IRON, 60,000 L DIESEL, 600 kW, water 20, cash 33,749 / points 7,411 / material 625 (x4.632, D$44,999k all in),
  roadLoad 3,360, consumables 199.8 (469 - 226.2 wages - 6 power - 1 water - 36 diesel at D$0.60). Readme lines.
- **Sectors**: labels "Iron Mining", "Iron & Steel" (keys kept). HeavyIndustry extends ProcessingSector (makes STEEL, uses
  SCRAP; its spare-ore plan, getOreDemand/getScrapPricePerTonne/getConversionMargin gone - nothing else read them).
  ExtractionSector: planner() (SpreadPlanner, money gate ON_ITS_WHOLE_COST) asked in plan() before the order, refusal in its
  words; estimatedMonthlyProfit() = the maker's less ownCosts(). Mining uses DIESEL. Mining.IRON_MINE 14,
  HeavyIndustry.ARC_FURNACE 11, MINI_MILL 12.
- **Resource.IRON** in-ground share 1/212.5 (US$0.40 a tonne at .085). **GameVersion** 0.7.116, SAVE_FORMAT 37, floor 37.
- **By id**: LongPlaytest (nameOf(), byId() and "#id" in template(); the mine and foundry rules, the report), BuildAdvice
  .fieldEarnings(), 25 harnesses. BuildCard groups "Iron & Steel", "Iron Mining". TradeScreen drops "(scrap in)".

## 2. Departures, with reasons
No IronSplit (the rule). ExtractionSector's estimate takes consumables off (★3; not in the spec, else the mine's D$199.8k a
month is invisible). Fixtures that stood furnaces up hold Iron & Steel (★4). New Car/Van/RailCheck sections (★1).

## 3. Premises changed (before -> after) and the new assertions
- **By the decisions** (Q4/Q5/Q6/Q6b/C/D):
  - MiningCheck: ore band labels "scrap ceiling" -> "landed ore"; 3: foundry 20-36% (imported scrap) / 48-62% (local ore), two
    cities x36 months -> each furnace walked by hand, steel sold at home at the landed price: EAF 8.0% / 26.6%, Mini-Mill
    13.8% / 32.4% in the spec's 5-15% / 20-35%, and the gap = the scrap band x tonnes; 4: mine at the floor now with diesel
    + consumables at PayTier wages (were .8/1.5/4.0), net over 2% of its all-in cost (2.74%: $23.36 a tonne, D$1,232.7k
    a month on D$44,999k); "a mill next door is worth more to a mine" -> "nothing in the catalogue uses ore until I4".
    New: SCRAP its own good; the Iron Mine's rows.
  - ManufacturingCheck: steel ceiling 1.284 -> .650; "a year of its billings" at the prices it was costed on (STEEL_WAS
    etc. written down); NEW margin over steel held but for the rows' rounding (★1); "steel > 2 x wages" -> "steel its
    biggest bill, past wages" (44% vs 29%; 61% vs 20% before); "half again on steel: dearShop < 0" -> "< a tenth of
    what it clears" ($6.5k of $368.7k).
  - TradeCostCheck DELIVERED: the seven rows moved, SCRAP added. BuildingDataCheck: "no building buys consumables" -> the
    three iron rows do (11, 12, 14), no power. BuildCardCheck: groups renamed. LandCheck: label 1/350 -> US$0.40; NEW the
    founding field's ore at US$0.40 a tonne (1/212.5 of .085, to 1e-15).
  - MaterialsCheck 2/3/5/6/7 on SCRAP and ids; 2: ownCosts(furnace) 0 -> its consumables x factor; 5: fixture zeroes the
    furnace's consumables for "a works with none"; 6 reads the real Iron & Steel (and plans.estimatedMonthlyProfit).
    NEW 9 (four cases, years abroad, consumables' arithmetic, founding tariffs) and 10 (format 36 refused, file untouched;
    this build's save loads with SCRAP). NEW CarCheck/VanCheck/RailCheck: price and plants' margin to the cent.
- **FOUR CASES** (A/B/C/D, % of cost a month at parity; the study's in brackets): Iron Mine 2.72/2.74/4.07/4.06 (2.7/2.7/
  4.1/4.1); EAF -0.55/-0.06/0.66/0.17 (-0.5/-0.1/0.7/0.2; A at the edge of its rounding); Mini-Mill -0.50/0.11/1.01/0.41
  (-0.5/0.1/1.0/0.4); years abroad 2.206/4.427/3.541 (2.2/4.4/3.5). Differs: diesel a feed at the case's price (D$41.3k
  landed, D$35.2k at export; the study's D$36k at D$0.60 in running cost) and standing 0, as the study's cases.
- **By the rule (old saves refused at the floor; SaveFileCheck.refusedAtTheFloor(): P7's words, month 1, file to the byte)**:
  ConversionCheck 6 "format-31 save loads, converted ..." -> refused; LandCheck 13's format-30 save (quote at the loading
  rate) -> refused; LandCheck 21 four format-30 saves "converted once" -> refused; WaterCheck 12 format-30 rights -> refused;
  ConstructionControlCheck / ChartCheck "format 27/28 loads with none" -> the key absent at this format loads with none, and
  27/28 refused; SectorStatementCheck 6b "format-32 loads, paid-in derived ..." -> refused, nothing derived; OilCheck 10
  "format-33 FUEL split ..." -> refused (the town itself handed to 11); WellCheck "format-34 one pool charged ..." ->
  refused. SaveFileCheck P7 now tests format 36 itself. Pure conversions (GridConversion, FuelSplit, ...) stand.
- **Fixtures re-caused, premises unchanged**: VanCheck, RailCheck, ManufacturingCheck 6, SaveFileCheck (hauls, college,
  their twins - a hold is not saved) hold Iron & Steel; RailCheck + 8 held Fabrication Works (steel's freight alone paid 63%
  of two spurs' allowed); MapCheck hands the city the mine's price; ReadPathCheck: the world sells the fund a bond when none
  has by m87; SaveFileCheck's fund share: the first company whose sale fills; ScaleCheck 635; PolicyPreviewCheck's duty in
  the model's association (litres x charged duty).

## 4. Trace movement (pt07113 -> pt07116; the probe in 0)
- Every trace moves from m4: the first car is 6% cheaper (CARS 44 -> 41.3125); ore at founding $0.10 a tonne (was $0.28).
- Iron & Steel never builds: credit "HI $0k" at all 16 checkpoints (pt07113: $28.8M by m266, $56.5B by m2026). The
  advisor's jobs throttle built "Steel Foundry" 19 times before; its wouldPay() now fails for the furnace (case A -0.55%
  of its cost) and the throttle goes to "Industrial Bakery: BUILT 27". The first bond the city borrows on: m138 "1 x Steel
  Foundry" before, m1090 "cheap money" now. No mine in either (nothing uses ore until I4); steel is imported at .650 x fx.
- End (m4000 / m4002): people 577,610 (566,444); posts 321,670 (345,198); unemployment 15.6% (9.3%); GDP $3.1T a month
  ($6.2T) at a price level 906 (1,456) - real GDP about -20%; exports $2.61T a month ($5.71T), imports $1.03T
  ($2.81T), NX $1.58T ($2.89T), real about -12%; the rate 563.6 per US$ (916.7). Crime 0.44x Canada's (2.18x). The fund
  wrote down 14,882 bond lots (0), traded 5,435 lot-months (17). Both: "Nothing. Every month passed the audit and every
  reload matched." No furnace is the decisions' intent (on imported scrap 5-15% of sales); exports halve.
- ENSEMBLE 07116 against 07113 (runs/ensemble/out/07116/score.md): 20/25 (1 vacuous), was 24/26. AUTO2: T1 16/16 reach
  40,000 at m1,458 [1,436-1,693] (m1,208); T2 197,342 [113,525-228,368], 86% of 230,198, PASS; M1 0 and F1 0/16 in every
  policy; pairing 64/64. Red before and still: A2 (14 months, was 20), S1 (a 17-month spell). NEWLY RED: H1 (ZERO_HOT's 2nd
  minus 1st half +1.83 points, was +0.51; each half still >= +1), H2 vacuous, R3 (3 HIGH seeds > +1 point, 2 allowed),
  HIGH T2 4,148 [1,591-7,201] under 4,805 (75% of 6,406); HIGH's unemployment at m720 31.6% (18.4%).
- WHY HIGH, traced on seeds 6, 2, 12 (scratch-i3/diag: -Densemble.extra, each sector's posts and exports, both builds, m720
  cut): at m600 the old city's steel chain (Heavy Industry 330-440 posts, Manufacturing ~400, Automotive 0-500) kept its
  posts through 15%; the new one has none (no furnace pays; Manufacturing 133, no assembly yet) and leans on Industrial
  Bakeries (750-1,060 posts, shed to 170-235) and Business Services (1,190-1,490, closed under 15% in both builds). Seed
  6: unemployment 60% at m690. Not tuned and no premise moved: the four stand red for the orchestrator.

## 5. Gate and final commit
Gate on 3a41526 (scratch-i3/gate.log): both builds silent (0 bytes each); the suite 96 harnesses in 754 s, 96 passed, 0
failed (HealthCheck green too); BuildMenuCheck PASS, 101 of 101 described; tools.Stale 0 firm, 436 soft (317 maps behind
the sources, 18 fuzzy counts - the docs pass's); playtest 8 of 8 traces identical to pt07116; 0 w/crlf outside .bat.
Then a58b4ca, labels only (★9): both builds silent, TradeCostCheck green, traces identical, Stale 0 firm. FINAL a58b4ca
(after d1fea23 model, 37d4e8c harnesses, 1b2a03b vehicles + CLAUDE.md, 3a41526 comments). Maps left to the docs pass.

## 6. Star calls
None in place of Jerus's asks: decisions Q4-Q6b, C and D are applied as written (D: iron US$0.40 a tonne in the ground).
- ★1 The goods' rows are the study's rounded figures (FABRICATED_STEEL 1.545, MACHINERY 13.4/8.1); ManufacturingCheck holds
  the works' old margin over steel to the rows' rounding (<.3%), the vehicles' plants (CarCheck/VanCheck/RailCheck) to the cent.
- ★2 Old saves: SAVE_FORMAT 36 -> 37 and OLDEST_LOADABLE_FORMAT -> 37, no IronSplit (the standing rule): IRON in a format-36
  save holds scrap and ore as one and would load wrongly. JERUS'S SAVES STOP LOADING on 0.7.116 - every save at format 36
  or below, his slots 1-9 among them, is refused (the old-format sections in 3 assert it): nothing applied, the file
  untouched, the screen naming the build that saved it (0.7.115 or older), which still opens it.
- ★3 ExtractionSector: estimate less consumables (SpreadPlanner.ownCosts); the planner's money gate before an order.
- ★4 Fixtures that stood furnaces up hold Iron & Steel (holdSector; twins too); RailCheck's town + 8 Fabrication Works.
- ★5 MiningCheck 3 walks each furnace's month by hand, not two cities x36 months: no furnace is built at these prices.
- ★6 MaterialsCheck 9 runs the four cases at founding wages (PayTier) and the default tariffs, standing 0 (the study's), and
  says where caseEarns() reads the rows otherwise (the mine's diesel a feed at the case's price).
- ★7 Old-format harness sections are asserted refused through SaveFileCheck.refusedAtTheFloor() (P7's words, month 1, file
  to the byte); where they tested a key's absence, that is now tested at this format, and the old format refused beside it.
- ★8 BuildCard's groups follow the labels; LongPlaytest names rows by id ("#11", nameOf()); HeavyIndustry's old helpers
  deleted (no reader); ScaleCheck FREE_FIXTURE_MONTHS 595 -> 635 (scanned 490-700 for the house shape, probe/scale-*.txt).
- ★9 Labels: LongPlaytest's NX line "scrap" -> "the rest" (all other imports); TradeCostCheck "mostly ore" -> "bulk".

## 7. For the next batch (I4)
- Nothing in the catalogue uses IRON: the mine's case B/C (2.7%/4.1%) is all it has; the blast furnace / DRI rows plug into
  HeavyIndustry with uses(Good.IRON) (it is a ProcessingSector now; SpreadPlanner orders its works by the best spread).
- SCRAP has no local supply: "own scrap" in MiningCheck is the export price, by hand. A local scrap source is I4's or later.
- Take-off later (T1 m1,458, was m1,208), HIGH harder with no steel chain (4); Business Services closes under 15% in both.
- NationalAccounts' importsRawMaterial javadoc still tells the scrap story (still true of the EAF); the docs pass's.

## 8. For Jerus to check on the PC
1. Load screen: his slots marked no longer readable, naming the build that saved each (0.7.115 still opens them).
2. Build tab: "Electric Arc Furnace", "Steel Mini-Mill", "Iron Mine" cards under "Iron & Steel" / "Iron Mining", the
   investors' word on a furnace (it should not pay on imported scrap) and the mine's (the money gate's words).
3. Sectors, Iron & Steel's Operations page (scrap in, steel out) and the Trade tab's "Iron ore" and "Scrap" - by eye.
4. A city under a steep rate sheds harder now (4): worth a look on the PC.

## 9. Outside my files
Nothing written outside the worktree, scratch-i3, these two files and runs/ensemble/out/07116. One /dev/null redirect (0).
