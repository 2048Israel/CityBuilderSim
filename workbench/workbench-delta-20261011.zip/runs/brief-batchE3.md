# Brief: E3, deposits on the Earth's geology. 0.7.117. 2026-10-11

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## What this is
The third batch of "the world as planet Earth". Read the spec, `/home/claude/runs/spec-earth.md`: §4 whole, §8's E3 row, and §1's geology line. Jerus answered the study's questions "all rec" (2026-10-10); the one that bears on E3 is **Q5, no guaranteed iron field within 2 km of a site** (the founding card shows the nearest iron instead, at E4).

E1 (0.7.111) built the reader, and E2 (0.7.115) built the Earth's ground:
- **`World.Key`** names a world.
- **On an Earth world,** deposits use today's densities on the cells pass's land (`World.landKm2()` / `totalOf()` branch on Earth), and fields are redrawn off the sea with `EarthTerrain.seaAt()`.

Read `/home/claude/runs/fixE2-notes.md` whole: its §7 says where w × Z goes, `EarthTerrain.cellLand()` and `cellForest()`.

**E3 makes an Earth world's deposits follow real geology. Generated worlds must stay byte-identical** (on them w = 1 and Z = 1).

Build:
- **`Geology`** (new):
  - the province classes (ocean, shield, fold belt, rift, shelf, basin, other) read from the data's `geology` and `provinces` layers (`EarthData`);
  - **the hand-checked table** for the 219 provinces the name rules leave "other" (spec §4: "about an afternoon"). Class each by its USGS name with your own geological knowledge, mark every hand call in the table (a column or a comment), and say in your notes how many moved and to what. A province you cannot place stays "other".
  - The rule list itself is in `/home/claude/scratch-earth/e0/tools/earth/geology.py` (also in the repo under `tools/earth/`).
- **The field density on Earth:** λ_r(cell) = today's density × the cell's land km² × w_r(class) × Z_r.
  - The weights w are spec §4's table.
  - Z_r = Σ land / Σ land·w_r, so the Earth's expected count stays today's. The spec measured Z as iron 0.888, oil 0.701, coal 0.959, copper 0.846, uranium 1.049 and stone 0.751.
  - Oil is also multiplied by 1 + log10(1 + known petroleum ÷ 1,000 MMBOE), and its area includes sea in shelf, basin and rift provinces.
  - **Keep the weights and Z in `Geology`, not in `Resource`:** I3 (beside you) edits `Resource`.
- **Field types lean on geology on Earth** (`/home/claude/runs/spec-materials.md` §2.4, "On Earth (E3)"):
  - coking coal ×3 in fold belts and ×0.5 on shields;
  - limestone ×2 in basins and on shelves, ×0.5 in fold belts and ×0.25 on shields;
  - iron and copper flat.

  These are odds ratios on I1's `Deposit.type()` draw (`TYPE_SHARES`), with one constant a resource keeping the Earth-wide share at the generated share. The study measured limestone at .886 in basins and .493 on shields, 70.00% in all. Generated worlds draw flat, byte-identical.
- **Totals and depletion work as now:** a cell's total is drawn without its fields, the fields share it exactly, and depletion runs in acquisition order.

**Checks** (spec §8 E3, in `EarthTerrainCheck` or WorldCheck's Earth section, ★):
- totals exact;
- on Earth, iron fields per land km² on shields against basins by the weight ratio, within sampling error;
- the spec's spots, as far as the fixture's tiles reach:
  - Rotterdam: oil ×2.99, coal ×1.92, iron ×0.44;
  - Perth and Paris: oil ×1.40, iron ×0.44;
  - 150 km east of Perth, on the Yilgarn shield: iron ×3.55, oil ×0.04 (may need the full file);
- Z matches the spec's to its rounding, on the full file;
- the type odds' Earth-wide share;
- **generated fields byte-identical**, which WorldCheck's existing sections already hold.

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| E3 | 0.7.117 | named in the launch prompt | `/home/claude/scratch-e3` | **byte-identical** to the reference the launch prompt names |

**Your files:**
- `Geology` (new);
- `World` (the Earth branch of the counts and totals);
- `Deposit` (the Earth branch of `type()`);
- `EarthTerrain` if a read is needed there;
- the harness sections above;
- `GameVersion`;
- `CLAUDE.md`/`README.md` rows and counts.

**Beside you:** I3 (0.7.116, iron's prices and the split) works in `Good`, `buildings.json` and its twin, `Resource`, `sectors/Mining`, `sectors/HeavyIndustry`, `Sectors`, the harnesses that name buildings, and `LongPlaytest`. Keep out of those.

**Building:**
- Copy `src/main/resources/earth/` into your classes folder as well as the json.
- Set `JDK_JAVA_OPTIONS="-Djava.io.tmpdir=<scratch>/tmp -Dcbs.earth=/home/claude/scratch-earth/e0/out/earth-1.bin"` for the suite.
- Read that file only; never write into `/home/claude/scratch-earth/`.

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** The full suite green (the count at your base, more if you add one); BuildMenuCheck 101.

Reply with:
- a short summary;
- the hand table: how many provinces moved, and to what;
- the spots' multipliers and Z against the spec's;
- the type odds' shares;
- the gate and your final commit;
- your ★ calls.
