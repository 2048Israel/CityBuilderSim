# Brief: I4, the integrated route and old steel. 0.7.121. 2026-10-11

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## What this is
The fourth batch of the materials chains (★, it moves the playtest). Read:
- the spec, `/home/claude/runs/spec-materials.md`: §2.1–§2.3, §2.6a, §2.7, §2.8, §2.9, §4 and §5's I4 row;
- the study, `/home/claude/runs/materials-chains-research.md`: §1.2, §1.6, §2.2–§2.8 and §10.

Jerus decided (2026-10-08):
- Q4: scrap splits from ore.
- Q6: steel at the world's price.
- Q7: the processing sector builds whatever earns most, held by freight in the bands.
- Q8: Scrap Yards pay the sellers 70% of scrap's export price.
- Q19: two sizes where real plants are big.
- Q20: the coke ovens, blast furnace and oxygen shop make their own power now, and sell what they do not use.
- A: every order on its whole cost.

**Build (the spec's I4 row):**
- **The seven Iron & Steel rows:** Scrap Yard, Pelletising Plant, Coke Ovens, Mini Blast Furnace, Blast Furnace, Oxygen Steel Shop and Large Mini-Mill. Take the study's §2.4 figures and the spec's §2.2 conventions (money, posts, power, water, land, roadLoad, stock, fuel, consumables). Ids come from `buildings.json`'s `nextId`. `gen` goes on three: the Coke Ovens 8,000 kW, the Blast Furnace 60,000, the Oxygen Steel Shop 25,000 (study §1.6).
- **The goods they need:** PELLETS, PIG_IRON, MET_COKE, THERMAL_COAL, COKING_COAL, LIMESTONE and LIME. They are imported until their own sectors come (coal I6, stone I7). Use the study's prices (§2.3, §3.2, §6.3, with §1.2's widened LIME band) and Good's freight rule. Stockable: MET_COKE and both coals. Each new stockable good joins `NationalAccounts.HELD` at the end (GdpCheck HELD). Append, never reorder.
- **`OldMetal`** (steel, spec §2.9): steel arising each month at 85% recovery, from:
  - scrapped cars × 0.9 t (`Motoring` keeps the cars it scraps; today they are dropped);
  - demolitions × 0.3 t a materials unit;
  - Manufacturing's offcuts, 0.05 t a tonne made;
  - retired rolling stock, 300 t a set.

  The Scrap Yard buys it at 70% of SCRAP's export price (Q8), paying the sellers pro rata. What is left goes to landfill. Copper waits for I8.

  Save it as `DataSave.oldMetal`. An older save lacks it and reads none, which is right, not wrong: no bump. The audit gets "+ households OldMetalSold", "+ sectors OldMetalSold" and "− sectors OldMetalBought".
- **Iron & Steel on `ProcessingSector`** (I3) orders these works by the best earnings on cost (SpreadPlanner, the whole-cost gate). Captive coke, pig iron and scrap go to its own need first (§2.7). The works make and sell their own power (I2's `gen`).

**Rows as data (★, Jerus has not answered the research study's Q3):**
- The study (`claude/research-design.md` §2.1) asks the materials batches to write each building's inputs, outputs and posts as a `recipes` list, with `since` on anything after the start year (1900, decided).
- The orchestrator's recommendation to him, unanswered: keep today's row shape and add `since` to each new row.
- **Do that:** a `since` year on each of your seven rows, the year it first existed, sourced from the study or the research doc's catalogue (§4, e.g. the Pelletising Plant 1955, E4). A new template field, read by nothing yet; hold it json = twin in BuildingDataCheck.
- **Do not build the recipes list.**

**Harnesses:**
- **MaterialsCheck:** new sections after I3's (I3 added 9 and 10):
  - the study's four cases for each new row, at parity, through `SpreadPlanner.caseEarns()`, to the study's rounding (§2.5's table);
  - OldMetal's pool and the 70% rule;
  - captive coke and pig iron;
  - the works' power sold.
- **Also:** GdpCheck HELD; BuildingDataCheck (json = twin, `gen`, `since`); BuildMenuCheck's count (101 + 7 = 108); MoneyCheck's OldMetal lines; SaveFileCheck/ReadPathCheck for `oldMetal`.

## The playtest (★)
**Probe first.** Add the rows and goods and run one playtest against the reference the launch prompt names (I3's `pt07116`, in which Iron & Steel never builds and unemployment ends at 15.6%). The spec expects new candidates. Watch:
- pelletising on the city's own ore (.59–1.15%);
- the scrap pool against one yard (spec §6, "measure first" 4).

Then:
- re-baseline in your scratch (named in the launch prompt), each move explained;
- run the ensemble against `/home/claude/runs/ensemble/out/07116/summary.json`;
- say plainly whether the steel chain's jobs come back (I3 left HIGH T2, H1 and R3 newly red because the old steel chain held jobs under 15% rates);
- **guardrails:** the money audit closes every month; the city does not stall or collapse.

## What changed since the spec
Read §1 and §7 of `runs/fixI1-notes.md`, `fixI2-notes.md`, `fixI2b-notes.md` and `fixI3-notes.md`. Notably, from I3:
- **Nothing in the catalogue uses IRON yet;** the blast furnace and pelletising rows are its first buyers.
- **SCRAP has no local supply** until your OldMetal.
- **`SAVE_FORMAT` is 37,** with the floor at 37 (I3).
- **ExtractionSector subtracts consumables** and asks the money gate.

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| I4 | 0.7.121 (the orchestrator renumbers at the merge if another batch ships first) | named in the launch prompt | `/home/claude/scratch-i4` | moves: re-baseline |

**Your files:**
- `Good`, `NationalAccounts.HELD`;
- `buildings.json` and the twin (`BuildingManager`), the template (`since`);
- `sectors/HeavyIndustry`, `OldMetal` (new), `Motoring` (keeping the cars scrapped);
- `Game`'s demolition hook and `Manufacturing`'s offcut hook (one line each);
- `DataSave.oldMetal` and its load line;
- `MoneyAudit`'s lines;
- the harnesses above;
- `GameVersion`;
- `CLAUDE.md`/`README.md` counts and rows.

**Beside you:** E4 (founding on Earth) works in `Founding`, `ui/FoundingScreen`, `DataSave`'s Earth fields and the load path's world key, `World`/`EarthTerrain`, `.gitignore` and the save harnesses' Earth sections. Keep your `DataSave` field apart from its fields. E4 bumps `SAVE_FORMAT` and you do not.

**Building:**
- Copy `src/main/resources/earth/` into your classes folder as well as the json.
- For the suite, set `JDK_JAVA_OPTIONS="-Djava.io.tmpdir=<scratch>/tmp -Dcbs.earth=/home/claude/scratch-earth/e0/out/earth-1.bin"`.

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** The full suite green (the count at your base, more if you add one); BuildMenuCheck 108.

Reply with:
- a short summary;
- the probe and the playtest's moves, explained;
- whether the steel chain's jobs come back;
- the ensemble;
- the four cases against the study's;
- the scrap pool's figures;
- the gate and your final commit;
- your ★ calls.
