# Brief: the docs pass for 0.7.107 to 0.7.115. 2026-10-11

You are a docs pass, on Opus with a fresh context. Your job is prose: comments, javadoc, banners, `docs/*.md` (not `docs/manual.*`), `CLAUDE.md`, `README.md`, and the strings the player sees. They must say what the code **now** does (the tree is 0.7.115). **Change no behaviour,** constant, assertion or tolerance; a bug is a finding for your notes.

Read first, in this order:
1. `/home/claude/runs/brief-shared-git.md`: the rules for every implementer.
   - The Git paragraph.
   - Your worktree as the tree.
   - The standing rules: no `rm`; never `/dev` in any form; **every `java` run under `flock /home/claude/jvm.lock`**.
   - The gate and the notes.

   Where this brief differs, this brief wins.
2. `docs/docs-pass.md` in your worktree: the house brief for a docs pass. **Skip its steps 4 and 6** (the project's records and the manual's line); the orchestrator runs the records. Put what they need in your notes §7.
3. `CLAUDE.md` in your worktree.
4. `/home/claude/runs/docs-07106.md`: the last docs pass (0.7.100–0.7.106): how it worked and what it left.

## One part (a docs pass runs alone)
| branch | versions | range (`git diff <a> <b> -- src docs CLAUDE.md README.md`) | batches |
|---|---|---|---|
| `batch/docs-07115` | 0.7.107–0.7.115 | `8e90ab7 01bf29c` | Z1, P7, Z2, I1, E1, I2, I2b, E2 |

- **Each batch's notes:** `runs/fix<batch>-notes.md`; read §7 first. **Its files:** `runs/fix<batch>-changed.txt`.
- **The range says where to look; the truth is today's code.** A sentence your range made false, and a later version changed again, must be true of the code as it is now.

**What the batches left for you (their notes §7 and §9, read them all):**
- maps (`tools.Maps`) for the new classes: `Zoning`, `ZoningView`, `ui/ZoningScreen`, `EarthProj`, `EarthData`, `ProcessingSector`, `ExtractionSector`, `EarthTerrain`, and whatever I2b and E2 added;
- dials without a sentence;
- harness sections and labels, and `docs/harnesses.md` (E1 spliced EarthCheck's entry by hand; regenerate it);
- `docs/month-order.md` (I2's consumables and the works' power in the month; Z1's zoning in `refreshLand`);
- `CLAUDE.md`'s rows and counts.

**Things the orchestrator already knows:**
- **The versions merged out of order:** E2 (0.7.115) landed before I2b (0.7.113), and 0.7.114 was never used (I3 will be 0.7.116). `GameVersion`'s entries are in version order. E2's entry may say the playtest is 0.7.112's or 0.7.106's byte for byte. Since I2b, generated worlds are unchanged by E2 and the playtest is 0.7.113's. Make each entry's trace sentence true of the order they shipped in.
- **Harness counts disagree.** `README.md` says "ninety-five harnesses plus the playtest, which it reports as ninety-six", while the suite prints "95 harnesses run". Make the sentence say what `AllChecks` counts.
- **`.gitignore`** needs `__pycache__/`, because running `tools/earth/*.py` writes one (E1 §7).
- **`docs/notes/`** carries copies of the project's todo, changelog and index from 2026-10-07. `CLAUDE.md` says so. Leave them, and leave the sentence.
- **`BuildAdvice.suggestFor()`'s javadoc** still says "for one its budget cannot run one of" (P2b §7). Check whether it is still false and fix it if so.
- **The saves section** of any doc that still says "a bump alone refuses nothing" is false since 0.7.108 (P7).

## Do
1. **Read your batches' notes §7 and your range's diff,** file by file (`docs/map/<File>.md` for where a member is; `tools.Where` for what moved). Fix every comment, javadoc, banner, header and player string that is now false, in the file's own voice. Your versions' `GameVersion` entries must agree with each other and with the code.
2. **Dials:** every `static final` your batches added has one sentence above it.
3. **Harnesses:** every section your batches added prints `--- title ---` and labels its assertions. Fix labels only where they are false; never an assertion.
4. **Player strings** your versions added must fit at 1,389 × 868. Change only false words.
5. **`tools.Stale`:** firm stays 0. Work its soft list for your files, and say how many you closed.
6. **`CLAUDE.md` and `README.md`:** `grep -c` the counts and the tree's shape (harnesses, buildings, sectors, ui files), and check the rows for the classes 0.7.107–0.7.115 added.
7. **Regenerate the indexes last** with `tools.Maps`, from your worktree's root against your built classes, under the lock. Commit them with your prose. If Maps rewrites a file only for its date line, put the old one back with `git -C <path> show HEAD:<file> > <file>`.

## The gate (your tree, your scripts, under the lock)
Copy `/home/claude/scratch-gate/{build,suite,pt,bmc}.sh` into your scratch. In each copy, change every `/home/claude/scratch-gate` to your scratch and every `/home/claude/git/CityBuilderSim` to your worktree. They already copy `resources/earth` and name the Earth file for the suite. Run each under `flock /home/claude/jvm.lock`.
- Both builds silent.
- The suite: every harness green (HealthCheck included, as it has been).
- BuildMenuCheck PASS, 101 of 101.
- `tools.Stale`: 0 firm.
- The playtest **byte-identical** to `/home/claude/scratch-ui1/orch-gate/pt07113/`. A docs pass moves no trace.
- `git -C <wt> ls-files --eol`: no `w/crlf` but the `.bat` files.

Then commit your final state, the message starting "0.7.115 docs-07115:".

## Notes: `/home/claude/runs/docs-07115.md`, at most 100 lines
- §0 progress: a line per step, as you go.
- §1 files changed, a line each.
- §2 player strings changed.
- §3 flags: a comment you couldn't settle (the code is right for now). Leave a `TODO(docs):` and say why.
- §4 Stale firm/soft before and after.
- §5 the gate and your final commit's hash.
- §7 for the records and the manual (17 is next): the numbers the manual shows that moved (save format, oldest loadable format, buildings, harnesses, new dials and notices), and the new player-facing things the manual must cover (zoning's three boards, the old-save refusal, anything I2b and E2 made visible).
- §9 outside your files, if any.

Reply with a short summary: files changed, flags, Stale before and after, the gate and the commit hash.
