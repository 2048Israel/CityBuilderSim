# Brief: I2b, every order on its whole cost. 0.7.113. 2026-10-10

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## Why
Jerus's decision A (2026-10-08, the materials build plan): **"test every order on its whole cost, whoever pays."** Today a works paid from a sector's own cash is not asked to earn anything over its interest, so loss-making or thin plants get built. With zoning, the ground in that cost is at its zone's price.

His decision A13 (2026-10-10, "all rec", `claude/decisions-2026-10-10.md` row 13) extends it:

| # | Question | Answer | Batch |
|---|---|---|---|
| 13 | The whole-cost test (A) to decide the `Game.Slices` orders and the sea's orders (moves the playtest) | Yes | I2 (I2b) |

I2 (0.7.112, running beside you or just before you) makes `SpreadPlanner`'s default money gate `ON_ITS_WHOLE_COST` for the processing sectors. **This batch does the same for every other order.**

## Do
1. **`Game.Slices` (THE LARGEST SLICE, WITHOUT COUNTING TO IT, about `Game.java` line 4660; `docs/map/Game.md`).** `passes(n)` asks `businessInvestment.servicesItsOwnDebt(perUnitProfit * n, borrowed, tested)` with `borrowed = max(cost - cash, 0)`, so a slice the till pays for needs only to earn more than nothing.
   - Ask it of the whole cost instead, whoever pays: the interest at the rate the slice would be judged at, × `PROFIT_OVER_INTEREST`, on `cost`.
   - The financing stays as it is: the bond desk is still asked for what is borrowed, and the ban still stops a borrowed slice.
   - ★ The rate for the part the till pays: the slice's own `projectRate`, or the blended rate where a bond is cheaper. Say why.
   - `askPrime`/`carriesAtPrime` and the refusal's words follow the same cost.
   - `OrderSearchCheck`'s premise (the search equals the countdown) must still hold. Monotonicity may change, so re-read its banner's argument and say whether it still stands.
2. **The sea's orders:** find every other place an order is decided on "earns > 0" or on borrowing alone, and bring each to the whole cost. Start with the oil at sea, O10's platforms and platform wells (`runs/fixO10-notes.md`, `fixO10b-notes.md`), the ports' terminals (O9, `fixO9-notes.md`) and `BusinessInvestment`'s other paths. List each one in your notes, with whether you changed it.
   - **Leave alone:**
     - the player's own orders;
     - automatic building (P2/P2b, its own long-run rule);
     - `SpreadPlanner` (I2's).
3. **Harnesses:**
   - **InvestCheck** (or the harness that owns the rule): a cash-rich sector's order that earns less than its interest on the whole cost is refused, and the same order on a loan is refused alike.
   - **`RefineryCheck` 11b** is I2's.
   - **Premises that change:** only where decision A changes the rule they assert. List each, before and after.

## Moves the playtest (★)
**Probe first** (shared rules, rule 1): switch `Slices.passes()` to the whole cost and run the playtest before anything else. Expect fewer orders where sectors hold cash.

Then:
- explain each trace's move by its orders (which sectors, which buildings, when);
- re-baseline (`pt07113` in your scratch);
- run the 16-seed ensemble against `runs/ensemble/out/07106/summary.json`:

  ```
  BASELINE=/home/claude/runs/ensemble/out/07106/summary.json bash /home/claude/runs/ensemble/run.sh <a copy of your tree> 07113
  ```

  The script lives in the workbench, not in git. Run it under the JVM lock; it takes about 21 minutes.

**Guardrails:**
- the playtest city does not stall or collapse (people, jobs, the money audit every month);
- the ensemble's greens do not turn red but by the mechanism.

**If the plain switch fails them,** try the variants decision A allows (it fixes the test, not the rate or the margin), build the one closest to his words that passes, and put it first in §6 (rule 2). Never loosen a harness.

## What changed recently (read first)
- `fixP2-notes.md` and `fixP2b-notes.md` §1: automatic building's long-run rule.
- `fixP6-notes.md` §1: the refinery's run and the planner's prices.
- `fixI1-notes.md` §1 and §7: fields by type.
- `fixI2-notes.md`: if it exists when you start, I2's notes. It owns `SpreadPlanner`.

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| I2b | 0.7.113 | named in the launch prompt | `/home/claude/scratch-i2b` | moves: re-baseline `pt07113` |

**Your files:**
- `Game` (THE LARGEST SLICE and `consider()` only);
- `BusinessInvestment`;
- the sea's order paths you find (`sectors/Oil`, `Ports`), only in their order tests;
- `InvestCheck`, `OrderSearchCheck` and the harnesses whose premises A changes;
- `GameVersion`;
- `CLAUDE.md`'s rows for what you change.

**Beside you:** I2 works in `SpreadPlanner`, `ProcessingSector`, `ExtractionSector`, `Mining`, `Sector`, `Output`, `BuildingsTemplate`, `Statement`, `ServicesManager`, `UtilitiesHandler`, `MoneyAudit` and `Refining`'s default gate. Don't touch those.

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** The full suite green (94 harnesses at your base, more if you add one); BuildMenuCheck 101.

Reply with:
- a short summary;
- the probe and what moved;
- every order path found, and what you did with each;
- the ensemble against 07106;
- the gate and your final commit;
- your ★ calls.
