# E4, founding a city on Earth (0.7.121): notes

Worktree /home/claude/git/wt-E4, branch batch/E4, from 676bf69. Scratch /home/claude/scratch-e4 (build.sh, suite.sh,
pt.sh, bmc.sh: scratch-gate's, pointed here; gate.sh without rm; pte.sh the Earth playtest; probe/ E4Probe*, E4Card,
ui/E4Globe (headless renders, renders/*.png), ui/E4Words (the words probe)).

Progress: depth rule probed (search = brute force; W measured) -> 6a43b83 model -> f35c195 EarthFoundingCheck ->
210623f save/new-game/read-path checks -> 7c4eb01 screen, --earth, rows -> gate 1 (07:14-07:35: two premises E4
moves) -> 7ba9270 premises -> pte07121 twice -> 95b7e5a (wheel) -> final gate (5).
RULE SLIPS (harmless, not repeated): one `java -version` without flock at the start; one wait loop with `2>/dev/null`
on a grep, stopped when seen. No rm anywhere.

## 1. What I built
- **EarthSite** (new, model): gameData() (the file EarthData.locate() finds, identity EARTH_1, re-looked when the file
  changes; words saying where it goes when not); available(), loadProblem(), foundingProblem(); search() (accents and
  case folded; whole, begun, word begun, within; data order; SEARCH_HITS 8); randomPlace() (the seed's hash order,
  RANDOM_TRIES 64, first passing the site test: snap finds dry ground, not LC_ICE); measure() -> Card (snap's site and
  distance from the spot, nearest place words, the 5 km disc counted on the plots, nearest fresh/sea, province and
  multipliers, nearest iron within IRON_RINGS 16 cells, ice/desert bits, refusal, warnings); EARTH_FORMAT 38.
- **EarthTerrain**: THE SEA'S DEPTH (depthAt(), coastDistanceM() best-first over 1-degree tiles, measureShelfWidthM(),
  SHELF_WIDTH_M 54,167, SHELF_SAMPLES 2^16, depth cache by plot); siteNear() (the snap without the cells pass; snap()
  uses it, same order and counts). **World.depthAt()** on Earth = EarthTerrain's; shelfTheta() still refuses.
- **Founding**: onEarth(lat, lon) (EARTH_1, seed kept), getWorldKind/isOnEarth/getEarthLat/Lon/Data; problem() on
  Earth = EarthSite.foundingProblem() (so Game.newGame refuses a sea or ice spot).
- **DataSave**: worldKind, earthLat, earthLon, earthData together after worldSeed; written only for an Earth city
  (Gson skips nulls, so a generated save is format 37's but for the number); getFounding() builds the Earth key;
  earthProblem(). **Game** load: refuses an Earth save whose data is not here/another identity, an unknown kind, or no
  spot - before anything is applied, file untouched. **CityMap**: the sidecar header's seed slot holds worldId(key)
  (a generated world's seed, an Earth key folded), read back against the land's key; no sidecar FORMAT change.
- **GameVersion** 0.7.121, SAVE_FORMAT 38 (entry), floor 37 kept. .gitignore `data/`. CLAUDE.md/README rows, counts 97.
- **ui/FoundingScreen**: THE WORLD = chips Earth | Generated (Earth chosen when the data is here, looked for off the
  FX thread on show(); greyed with the data's words otherwise). Earth: the panel widens to 1,200 px, two columns (the
  city's choices 520 px, the world 560 px): search field + Random spot, the globe (560 x 270) with the search hits over
  it and - / + zooms, the card under it (THE SPOT: site line, within 5 km, water, geology + six multipliers, nearest
  iron, warnings in WARN, refusal in BAD_SOFT, the seed line). Globe: orthographic from a 12' picture of the 4' layers
  (grass/forest by land cover, ice light grey, desert sand) from the whole planet to 4 km/px; below, the city's own far
  view (MapTiles.nodeTerrain) to 150 m/px, on the spot's own world while centred on it; drag turns, wheel zooms, click
  picks; workers for the globe and the card. Enter in the search picks its first hit. Generated: as before + chips.
- **LongPlaytest** `--earth <place|lat,lon>` / -Dplaytest.earth; a header line on Earth only.
- **EarthFoundingCheck** (new, 6 sections, see its header); SaveFileCheck (onEarth()); NewGameCheck 14; ReadPathCheck
  (an Earth city read fifty times, readEverything() included).

## 2. Departures, with reasons
- The founding card's iron is "within 983 km" at most (IRON_RINGS), not anywhere on Earth: the search is bounded.
- The coast for the depth is the data's 15" half-contour, not the plots' (★E4-2).

## 3. Premises changed (before -> after) and new assertions
- EarthTerrainCheck 1: "an Earth world refuses the sea's depth" -> refuses shelfTheta() and gives a depth (E4's job).
- MaterialsCheck 10 (outside my files): floor == SAVE_FORMAT and the twin at SAVE_FORMAT-1 -> floor <= SAVE_FORMAT,
  the twin at OLDEST_LOADABLE_FORMAT-1 (still format 36, still refused in P7's words). It encoded "the floor is this
  build's format", which format 38 without a floor raise ends.
- New: EarthFoundingCheck 1-6; SaveFileCheck's Earth section (14 labels); NewGameCheck 14 (12); ReadPathCheck Earth (4).

## 4. Trace movement
- Default playtest: 8 of 8 traces pt07116's byte for byte (both gates). A generated world reaches the code it did.
- Earth playtest baseline **pte07121** = /home/claude/scratch-e4/pte07121/t-*.csv (`LongPlaytest --earth rotterdam`,
  -Dcbs.earth=scratch-earth/e0/out/earth-1.bin): Rotterdam 51.92 N 4.48 E (Natural Earth's, via the search), site 21 m
  away; 4,005 months in 103 s, findings "Nothing" (audit every month, every reload matched); m4005 515,136 people
  (default m4000 577,610), unemployment 14.8%; run twice (pte07121b) 8 of 8 identical, and = the first run (pte1).

## 5. The gate (scratch-e4/gate.sh, gate.log, 07:44-08:05) - final commit 95b7e5a
- Both builds silent (model 0 bytes, ui 0 bytes). AllChecks: 97 run, 97 passed in 799 s (HealthCheck too; MapCheck
  first time, 37.6 s; EarthFoundingCheck 19.1 s with the full file, its width measured again in ~10 s; EarthTerrainCheck
  21.3 s). BuildMenuCheck PASS, 101 of 101. tools.Stale 0 firm (443 soft: map pages behind, the docs pass's). Playtest:
  8 of 8 traces pt07116's. No w/crlf outside .bat. Nothing changed after the gate's builds.
- Gate 1 (07:14) had EarthTerrainCheck 1 and MaterialsCheck 10 red - the premises in 3 - and was otherwise the same.
- Figures: cards (fixture) Rotterdam site 191 m from the window's spot, 91.2% dry / 6.7% rivers and lakes / 2.1% sea
  (study 88 / 9.2 / -), fresh 0.08 km, sea 3.03 km (study 0.6 / 3.0), oil x2.58, iron 24.1 km north; Perth 43.2% sea
  (study 42), fresh 2.33 km (4.5); Paris no sea, the Seine 0.13 km (0.1). A card 0.25-0.9 s (the cells pass). Depth:
  the fixture's line west of Rotterdam 13 sea plots to 69.5 m, each = the brute force; the Earth city's field 21 sites,
  2.1 Mt, 0.7 m deep, 10.1 km out, a platform and 4 wells, "1 m deep · 11 km out". Globe: the 12' picture 0.6 s once,
  a wide frame 26-37 ms; the ground 80-170 ms warm, 480 ms cold at 4 km/px.

## 6. Star calls
- ★0 Nothing Jerus asked is replaced: Earth for new cities and the default when the data is here; sea/ice refused,
  desert/no fresh water within 5 km warned; no iron promised (nearest shown); names for search only, no borders, no
  country shown; today's river-water rule; no elevation.
- ★E4-1 DEPTH: the generated world's rule with the coast's distance for the elevation: depth = SHELF_BREAK_M (140) x
  max(30 m, distance to the coast) / SHELF_WIDTH_M, W the distance within which SHELF_SHARE (8.86%) of the Earth's sea
  lies - measured as the generated world measures its shelf (a quantile of the sea's samples), 54,167 m on earth-1.
  No new figure. Platforms stand within ~58 km of a coast. Rotterdam's North Sea: 16 m at 40 km west, 84 m at 80 km
  (real ~30 m: crude, as the generated rule is). The other candidate (no platforms on Earth) would strand Rotterdam's
  oil x2.58, mostly offshore. Flip: EarthTerrain.depthAt() returning +infinity on a sea plot (no platform anywhere).
- ★E4-2 The coast = centre of the nearest 15" cell with sea share under SEA_LEVEL (the half-contour the plots' coast
  is drawn on, a plot or two off): on the plots a depth moves by under a metre; a sea plot is at least a plot out.
- ★E4-3 FLOOR STAYS 37: a format-37 save has no worldKind = generated, which every pre-E4 city is. SaveFileCheck
  loads one and re-saves the same JSON but saveFormat/gameVersion/savedAt. Saves from 0.7.120 load.
- ★E4-4 Sidecar: the header's seed slot carries worldId(key) (generated: the seed, bytes unchanged); no FORMAT 7.
- ★E4-5 A new harness, EarthFoundingCheck (97), not more sections in EarthTerrainCheck (E2's ★2 reasoning).
- ★E4-6 THE SCREEN (no render survived; built in 0.7.21's style): one panel, widened to two columns on Earth; the
  globe orthographic when wide (a globe), the game's own far view from 4 km/px (where the two projections part by
  under a pixel at the edge) down to 150 m; search hits over the globe; GLOBE_H 270 so the tallest card fits 868.
- ★E4-7 Ice = LC_ICE in the site's 2' land-cover cell (Antarctica's cells carry it too); desert = LC_DESERT there;
  the water warnings over the card's 5 km disc. A refusal blocks Found; a warning does not.
- ★E4-8 Random spot rolls the seed and takes the first of 64 places in the seed's hash order passing the site test.
- ★E4-9 THE DATA (Jerus's call pending): Earth only when EarthData.locate() finds a file whose identity is EARTH_1;
  the chip says where it goes otherwise. A release asset needs GitHub API writes this session cannot make.
- ★E4-10 Earth playtest: `--earth rotterdam` resolved through the screen's own search (not the fixture's window), on
  the full file; without the file it stops, saying so.
- ★E4-11 A save on data a harness registered (EarthTerrain.use()) loads, so the harnesses round-trip fixture cities;
  any other identity, or EARTH_1 with the file absent, is refused in words naming which.
- ★E4-12 The card's place is the nearest of the data's places (E5's placeWords), the site's lat/lon beside it; the
  snap's move shown from 50 m.

## 7. For the next batch
- Docs pass: map pages for EarthSite and EarthFoundingCheck, docs/harnesses.md (EarthFoundingCheck, SaveFileCheck's
  Earth section, NewGameCheck 14, ReadPathCheck's), the stale E2/E5 "until E4" sentences I did not reach.
- The screen is unrendered in the cloud: the headless renders (scratch-e4/renders) are the globe's and ground's
  pixels, not the panel. The Insane tip on Earth prices the bond on the spot's world (builds it on the FX thread if
  the LRU dropped it, ~0.5 s).
- I4 also adds a DataSave field; if it bumps SAVE_FORMAT, EarthSite.EARTH_FORMAT stays 38 (the first with Earth).
- E6: an ICE class (the globe marks ice; the plots do not), the salt lakes, heights (which would replace ★E4-1).

## 8. For Jerus to check on the PC
- New city with data/earth-1.bin beside the game: Earth chosen, the globe turns and zooms to 150 m, search
  "Rotterdam", Random spot, the card; Found. Without the file: Generated chosen, the line saying where it goes.
- The depth rule (★E4-1) and the floor kept at 37 (★E4-3).
- Shipping the data (★E4-9): a release asset `earth-1` (earth-1.bin, its sha256, ATTRIBUTION.txt) is the proposal.

## 9. Outside my files
- AllChecks.java: "EarthFoundingCheck" added to HARNESSES. MaterialsCheck.java: section 10's floor premise (3).
- Comment-only: EarthData.java (header, DATA_FILE, LC_DESERT, LC_ICE), EarthProj.java (header), LandMap.java (one
  javadoc line) - the "until E4" sentences.
