# Brief: C1, the build card asks the investors' interest test. 0.7.122. 2026-10-11

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## Why
The docs pass for 0.7.107–0.7.115 (`/home/claude/runs/docs-07115.md` §3, flag 1) found a card that can say the investors would build when they would not. `BuildCard`'s gates end at LOSS ("pays": the estimate is above nothing), and the Sectors screen's `EVERY_GATE_INFO` says "every gate investors ask ... whether it pays". Neither includes the test `Game.consider()` asks of every order: since 0.7.113 (batch I2b, Jerus's decisions A and A13) that test is the interest on the order's **whole cost**, at the rate the order would be judged at, × `PROFIT_OVER_INTEREST`, whoever pays. So a card can pass every gate while the investors decline the building.

I2b built the door for this: `Game.carriesItsWholeCost()`, `Game.orderGate()` and the refusal's words ("cover its interest"). Read `/home/claude/runs/fixI2b-notes.md` §1 and §7.

## Do
1. **`BuildCard`**: add the interest test as the gate after LOSS (★ its name; e.g. INTEREST), asked through the model's own door (`carriesItsWholeCost()`, or `orderGate()` on the card's order), never recomputed in the card.
   - A card whose building earns over nothing but under its interest on its whole cost fails it.
   - The card's words name what it would earn, what its interest is, and the rate, from the model's figures.
   - `appraise()` (0.7.75: every gate, with what it would earn, cost and take to pay back) reports it.
2. **`ui/SectorScreen`'s `EVERY_GATE_INFO`** and any other player string that lists the investors' gates: add the interest on the whole cost. Every string must fit at 1,389 × 868; run a words probe by the screens' width helpers.
3. **`BuildCardCheck`**: a fixture that pays but not its interest fails the new gate, and the card agrees with `consider()` on the same order, one that passes and one that fails.
4. **No model change:** the playtest stays byte-identical. The card is advice.

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| C1 | 0.7.122 (the orchestrator renumbers at the merge if another batch ships first) | named in the launch prompt | `/home/claude/scratch-c1` | **byte-identical** to `/home/claude/scratch-ui1/orch-gate/pt07116/` |

**Your files:**
- `BuildCard`, `BuildCardCheck`;
- `ui/SectorScreen` and any ui file that prints the gates' list or a card's gate;
- `GameVersion`.

**Beside you:** I4 (the integrated route and old steel) works in:
- `Good`;
- `buildings.json` and its twin;
- `sectors/HeavyIndustry`, `OldMetal`, `Motoring`;
- `DataSave`, `MoneyAudit` and the materials harnesses.

Keep out of those. If you must touch `BuildCard`'s groups for its new rows, don't: I4 owns any group change.

**Building:**
- Copy `src/main/resources/earth/` into your classes folder as well as the json.
- For the suite, set `JDK_JAVA_OPTIONS="-Djava.io.tmpdir=<scratch>/tmp -Dcbs.earth=/home/claude/scratch-earth/e0/out/earth-1.bin"`.
- The scripts in `/home/claude/scratch-gate/` do both; copy them and repoint them.

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** The full suite green (97 at your base); BuildMenuCheck 101.

Reply with:
- a short summary;
- the gate as built and its words;
- the words probe;
- the gate and your final commit;
- your ★ calls.
