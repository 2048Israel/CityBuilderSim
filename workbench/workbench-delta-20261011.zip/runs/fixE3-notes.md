# E3, deposits on the Earth's geology (0.7.117): notes

Worktree /home/claude/git/wt-E3, branch batch/E3, from 04d505c. Scratch /home/claude/scratch-e3 (build.sh, suite.sh,
pt.sh, bmc.sh, gate.sh: copies of scratch-gate's, pointed here; chk.sh runs one harness; py/ the Python cross-checks:
geo5.py measures Z/odds/spots, hand.tsv is the hand table's source, gen.py its Java lines).

Progress (a line per step, for a restart):
- base build silent; EarthTerrainCheck baseline green (cells pass 437 ms).
- py/geo*.py: the study's class shares reproduced on the rules' classes; Z by its definition does not give the
  study's iron/copper/uranium (6, ★E3-2). hand.tsv: 219 + 68 misfires.
- 4e5e233 (WIP) Geology, World, Deposit, EarthTerrain; WorldCheck green. 65fb62f EarthTerrainCheck 10-14, green.
- 074db17 GameVersion 0.7.117, CLAUDE.md's row. Gate 03:33-03:50 green (5). Final commit 49c6072.

## 1. What I built
- **Geology** (new): Kind (ocean, shield, fold belt, rift, shelf, basin, other, the data's names); spec-earth 4's
  weights W_IRON..W_STONE (ocean takes other's); Z_IRON..Z_STONE measured on earth-1 with the hand table;
  OIL_SCALE_MMBOE (pf = 1 + log10(1 + known/1,000)); ANTARCTIC_LAT -60; COKING_/LIMESTONE_RATIO and _ODDS;
  HAND, the hand-checked table (287 rows: row | code | name | rules' class | class | why), parsed into TABLE.
  Geology.of(EarthData): the rules' classes with the table over them - refused if a row's code, name or rules'
  class is not the data's; provinceAt(lat, lon) on the grid in hand; kindOf(), petroleumOf(), multiplier(r, row)
  = w x Z (x pf for oil), seaHoldsOil(); firstShare(r, kind), Deposit.type()'s threshold; measure(): every 4'
  cell's land and sea by province, its sphere area (Measure: zOf(), offshoreOil(), fieldShares(), oddsFor()).
- **EarthTerrain.cellsPass()** also reads each of its 16 points' province: a resource's FIELD LAND share = mean of
  point land x multiplier, oil's land plus the sea where the province is shelf/basin/rift (float a cell a resource,
  3.25 MB an Earth world). cellFieldLand(), geology(), provinceAt(x, y).
- **World**: countOf()/totalOf() take today's density over fieldKm2(cell, r) (generated: landKm2(), the same double);
  the pools, poolTotal/LegacyCount, legacyFieldCount ask holds(c, r) (generated: hasLand's expression); computeTotals
  on Earth per resource (oil at sea too), generated verbatim. Every Deposit drawn carries geologyAt(x, y), the class
  under its centre (null on a generated world). geology(), provinceAt(), geologyAt(), cellFieldShare() (package).
- **Deposit**: an 8th component, Geology.Kind geology; the 7-argument constructor (null) keeps every caller; type()
  on Earth holds the same draw against Geology.firstShare(kind, geology).
- **EarthTerrainCheck 10-14** (its header lists what each proves); GameVersion 0.7.117; CLAUDE.md's Earth row.

## 2. Departures, with reasons
- **Z is not the spec's** (★E3-2). Oil's Z is over the land only, its offshore sea on top (★E3-5).
- The hand table also corrects 68 misfires of the rules (★E3-1), beyond the brief's 219.

## 3. Premises changed and new assertions
No premise moved (WorldCheck, EarthCheck untouched; EarthTerrainCheck 1-9 as they were; section 9 now returns its
reader). New: EarthTerrainCheck 10-14. The study's figures held where they follow from its table: the rules' class
counts (474/151/66/55/38/20/219) exactly; the land by class (Antarctica out) within 0.5 points: basin 35.47 (35.1),
other 22.37 (22.5), fold 18.81 (18.9), shield 17.66 (17.8), shelf 2.75 (2.8), rift 2.23 (2.2), ocean 0.71 (0.7);
limestone .8852 in basins (.886) and .4908 on shields (.493); each spot's province, class and petroleum, and at the
study's Z its multipliers to its rounding (Rotterdam 2.99 / 1.92 / 0.44, Perth and Paris 1.40 / 0.44, Yilgarn
3.55 / 0.04). Ours are printed beside them.

## 4. Trace movement
None: the 8 traces are pt07113's byte for byte. A generated world's field land is its land (the same double),
holds() is hasLand()'s expression, its Deposits carry null and type() takes the old branch.

## 5. The gate (scratch-e3/gate.sh, gate.log, 03:33-03:50) - final commit 49c6072
- Both builds silent (model 0 bytes, ui 0 bytes). AllChecks: 96 run, 96 passed (HealthCheck too; MapCheck OK first
  time, 31.2 s; EarthTerrainCheck 19.2 s with the full file named). BuildMenuCheck PASS, 101 of 101. tools.Stale 0
  firm (438 soft). Playtest: the 8 traces pt07113's byte for byte. No w/crlf outside .bat.
- After the gate: one javadoc sentence above Geology.OF (a dial without one); the model rebuilt silent.
- Earth figures: cells pass 528 ms cold, 499 warm (bound 1 s; 437/424 before E3); Geology.measure() 390 ms.

## 6. Star calls (tagged as in the code)
- ★0 Nothing Jerus asked is replaced (Q5: no guaranteed iron near a site - E3 adds none).
- ★E3-2 Z BY ITS DEFINITION, NOT THE STUDY'S NUMBERS (the brief: "Z matches the spec's to its rounding"). The
  data's class shares match the study's to 0.4 points, yet Z = land / land x w gives, on the rules' classes, iron
  .7611 (study .888), copper .7761 (.846), uranium .8114 (1.049), coal .9498 (.959), stone .7478 (.751), oil .6905
  (.701). With the study's own shares iron's mean weight is 1.31, Z .76; .888 would need a shield weight near 3,
  but its Yilgarn x3.55 is 4 x .888: the study's iron, copper and uranium Z do not follow from its own table.
  Built: Z as defined, measured with the hand table (iron .7219, oil .6033, stone .6915, coal .7884, copper .7322,
  uranium .7518), so the land's expected count is today's. Flip: put the study's numbers in Geology.Z_* and move
  section 13's first assertion.
- ★E3-5 Oil's Z over the land only (pf in), the sea of shelves, basins and rifts on top: the study's .701 reading
  (land-only .6905 on its classes). That sea adds 51.6% to the land's oil count. Flip: Z_OIL 0.3979 (land and
  offshore) keeps the total today's; the spots' oil would fall by a third.
- ★E3-1 The hand table also corrects 68 rule misfires, each row saying why: 23 "OCS" areas and "Foredeep"/"Ridge"/
  "Plain" (ocean to basin 15, shelf 10, fold belt 3 - Mesopotamia's foreland basin, 343,993 MMBOE, was ocean);
  "Uplift"/"Belt"/"Orange" (fold belt to basin 15 - Ghawar's arch - shield 4 - Reguibat, Adirondacks, Aldan,
  Luxi-Jiaoliao - other 1); "Zone"/"Arch" (basin to fold belt 4 - the Lufilian Arc, the Copperbelt, was a basin);
  "platform"/"shelf"/"coastal"/"slope" on land (shelf to basin 13, fold belt 2, shield 1 - the Stuart Shelf's
  Olympic Dam). Deep-sea ridges and rises, deltas and ice shelves stay. Flip: delete the rows whose rules' class
  is not other.
- ★E3-6 The 219: 104 fold belt, 47 basin, 24 ocean, 23 shield, 11 rift, 2 shelf; 8 stay other (the Ethiopian and
  Columbia flood basalts, the Canaries, and five basement highs under the Kara, East Siberian and Okhotsk seas). Calls of note: East Antarctica (Polar, Wilkes, Queen Maud) shield, West
  Antarctica rift; Australia's Proterozoic orogens (Albany-Fraser, Halls Creek, Paterson, Pine Creek) shield like
  the rules' Australian blocks; massifs (Bohemia, Armorica, Deseado, Bureya, Nigerian) shield as the rules class
  "massif"; India's Gondwana grabens rift; the Basin and Range's porphyry-copper arc fold belt.
- ★E3-3 Ocean's land takes other's weights (the spec's table has no ocean column).
- ★E3-4 Z leaves out the ground south of 60 S (the study's "Antarctica excluded"): with the hand table East
  Antarctica is 8.5 M km2 of shield under ice, which would take about a sixth of the reachable world's iron.
- ★E3-7 A cell's field land is its 16 points' land each x its province's multiplier: the spec's formula where a
  cell is one class, a share each where it straddles. A field's type reads the class under its centre point.
- ★E3-8 Deposit carries the class as a record component (null on a generated world): the type stays a pure
  function of the field and the ground under it; no caller changes.
- ★E3-9 The odds' constant weights each class by its expected fields (land x w, Antarctica out): it reproduces
  the study's .886/.493 on the rules' classes. Z and the odds are constants of earth-1 (a re-bake fails 13).
- ★E3-10 The checks are EarthTerrainCheck 10-14 (WorldCheck stays as it was, E2's star 2); sampled figures within
  SIGMAS 3. Fields by class: Perth's world on the fixture 8.005 for 8 (sigma 0.24%); Rotterdam's on the full
  file 8.004 (0.06%); the fields a city sees 8.008 / 8.004.

## 7. For the next batch (E4, E5)
- The founding card's multipliers: World.provinceAt(x, y), World.geology().kindOf(row) / multiplier(r, row) /
  petroleumOf(row), and EarthData.province(row).name(). At the spots (here): Rotterdam oil x2.58, coal x1.58, iron
  x0.36; Perth/Paris oil x1.21, iron x0.36; Yilgarn iron x2.89, oil x0.03.
- The sea's depth: an Earth world now lists oil fields across basin, shelf and rift seas (Rotterdam's fixture world:
  every sea cell near the site); LandManager.atSea()/seaFields(), OilView and Oil's platform rule call depthAt(),
  which throws on Earth (E2's star 7) - E4 must settle it before an Earth city has an oil industry.
- Resource.fieldsPerKm2()'s javadoc ("over its land") is the field land on Earth - I3 owns Resource.
- Docs pass: map pages for Geology; harnesses.md for EarthTerrainCheck 10-14; EarthData.Province's `kind` doc
  could name Geology's table over it.

## 8. For Jerus to check on the PC
- Geology.HAND, 287 rows: a geologist's eye on the calls (★E3-1, ★E3-6) - each row says why.
- The study's numbers versus these (★E3-2, ★E3-5): Rotterdam's oil x2.58 not x2.99, the Yilgarn's iron x2.89 not
  x3.55, because Z is measured as defined. Nothing in play changes until E4 founds a city on Earth.

## 9. Outside my files
None.
