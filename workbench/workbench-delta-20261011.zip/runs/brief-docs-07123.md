# Brief: the docs pass for 0.7.117 to 0.7.123. 2026-10-11

You are a docs pass, on Opus with a fresh context. Your job is prose: comments, javadoc, banners, `docs/*.md` (not `docs/manual.*`), `CLAUDE.md`, `README.md`, and the strings the player sees. They must say what the code **now** does (the tree is 0.7.123). **Change no behaviour,** constant, assertion or tolerance; a bug is a finding for your notes.

Read first, in this order:
1. `/home/claude/runs/brief-shared-git.md`: the rules for every implementer.
   - The Git paragraph.
   - Your worktree as the tree.
   - The standing rules: no `rm`; never `/dev` in any form; **every `java` run under `flock /home/claude/jvm.lock`**.
   - The gate and the notes.

   Where this brief differs, this brief wins.
2. `docs/docs-pass.md` in your worktree: the house brief for a docs pass. **Skip its steps 4 and 6** (the project's records and the manual's line); the orchestrator runs the records. Put what they need in your notes §7.
3. `CLAUDE.md` in your worktree.
4. `/home/claude/runs/docs-07115.md`: the last docs pass (0.7.107–0.7.115): how it worked and what it left.

## One part (a docs pass runs alone)
| branch | versions | range (`git diff <a> <b> -- src docs tools CLAUDE.md README.md *.bat .gitignore`) | batches |
|---|---|---|---|
| `batch/docs-07123` | 0.7.117–0.7.123 | `04d505c 9605b25` | E3 (0.7.117), E5 (0.7.119), I3 (built as 0.7.116, shipped 0.7.120), E4 (0.7.121), C1 (0.7.122), I4 (launched as 0.7.121, shipped 0.7.123), and Jerus's commit f99d62c (the Earth file ships) |

- **Each batch's notes:** `runs/fix<batch>-notes.md`; read §7 first. **Its files:** `runs/fix<batch>-changed.txt`.
- **The range says where to look; the truth is today's code.**
- **f99d62c** came from Jerus's own session: `tools/earth/get-earth.bat`, `Play CityBuilderSim.bat`, `Build EXE.bat`, `.gitignore` and `README.md`. Its commit message says what it does.

**Things the orchestrator already knows** (also in `/home/claude/runs/next-docs-pass-items.md`; read it whole):
- **`EarthData.DATA_FILE`'s comment** (Jerus asked, 2026-10-11): say how the file reaches `data/`. It is the GitHub release `earth-1`, fetched and checked by `tools/earth/get-earth.bat`, which the two .bat files call. A new Earth means changing the names at the top of `get-earth.bat` together with `DATA_FILE`. Also correct any sentence that says E4, or anyone, still settles how the file ships, starting with GameVersion 0.7.111's entry ("how it ships is E4's"). Add "since f99d62c" rather than rewriting the history.
- **Versions out of order:** I3 was built as 0.7.116 and shipped as 0.7.120; I4 was launched as 0.7.121 and shipped as 0.7.123 (E4 took 0.7.121). Their GameVersion entries say so. Harness labels and banners that say "(0.7.116)" or "(0.7.121)" for I3's and I4's work: make them true ("0.7.120", "0.7.123"), ★ once, consistently. Leave E4's 0.7.121 alone.
- **The batches' §7:** C1 (CLAUDE.md's BuildCard row and the INTEREST gate), E4 (EarthSite, EarthFoundingCheck, the remaining "until E4" sentences), E3, E5, I3, I4.

## Do
1. **Read your batches' notes §7 and your range's diff,** file by file (`docs/map/<File>.md` for where a member is; `tools.Where` for what moved). Fix every comment, javadoc, banner, header and player string that is now false, in the file's own voice. Your versions' `GameVersion` entries must agree with each other and with the code.
2. **Dials:** every `static final` your batches added has one sentence above it.
3. **Harnesses:** every section your batches added prints `--- title ---` and labels its assertions. Fix labels only where they are false; never an assertion.
4. **Player strings** your versions added must fit at 1,389 × 868. Change only false words.
5. **`tools.Stale`:** firm stays 0. Work its soft list for your files, and say how many you closed.
6. **`CLAUDE.md` and `README.md`:** `grep -c` the counts and the tree's shape (harnesses, buildings, sectors, ui files), and check the rows for the classes 0.7.117–0.7.123 added (Geology, EarthSite, OldMetal, the new harnesses).
7. **Regenerate the indexes last** with `tools.Maps`, from your worktree's root against your built classes, under the lock. Commit them with your prose. If Maps rewrites a file only for its date line, put the old one back with `git -C <path> show HEAD:<file> > <file>`.

## The gate (your tree, your scripts, under the lock)
Copy `/home/claude/scratch-gate/{build,suite,pt,bmc}.sh` into your scratch. In each copy, change every `/home/claude/scratch-gate` to your scratch and every `/home/claude/git/CityBuilderSim` to your worktree. They already copy `resources/earth` and name the Earth file for the suite. Run each under `flock /home/claude/jvm.lock`.
- Both builds silent.
- The suite: every harness green (HealthCheck included, as it has been).
- BuildMenuCheck PASS, 108 of 108.
- `tools.Stale`: 0 firm.
- The playtest **byte-identical** to `/home/claude/scratch-ui1/orch-gate/pt07123/`. A docs pass moves no trace.
- `git -C <wt> ls-files --eol`: no `w/crlf` but the `.bat` files.

Then commit your final state, the message starting "0.7.123 docs-07123:".

## Notes: `/home/claude/runs/docs-07123.md`, at most 100 lines
- §0 progress: a line per step, as you go.
- §1 files changed, a line each.
- §2 player strings changed.
- §3 flags: a comment you couldn't settle (the code is right for now). Leave a `TODO(docs):` and say why.
- §4 Stale firm/soft before and after.
- §5 the gate and your final commit's hash.
- §7 for the records and the manual (18 is next): the numbers the manual shows that moved (save format, oldest loadable format, buildings, harnesses, new dials and notices), and the new player-facing things the manual must cover (founding on Earth, the globe and the card; the Earth file; the card's INTEREST gate; iron at the world's price and the saves refused; the integrated route and old steel; E5's far view and hover).
- §9 outside your files, if any.

Reply with a short summary: files changed, flags, Stale before and after, the gate and the commit hash.
