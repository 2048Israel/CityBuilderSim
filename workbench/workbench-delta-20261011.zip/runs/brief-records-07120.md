# Brief: the records for 0.7.117 to 0.7.120, the docs pass and manual 17. 2026-10-11

You write the project's records, on **Sonnet**. The orchestrator checks your figures against the notes. Don't ask anything.

## Standing rules
- No command that could raise a permission prompt. No network.
- **Don't use `rm` at all, and never touch `/dev` in any way:** no `2>/dev/null`, no `> /dev/null`, no `/dev/stdout` or `/dev/fd`, no `<(...)` — not in a diff, not in a cmp, not in a wait loop. Use the Write and Edit tools for any text that mentions those strings.
- **Write only in `/home/claude/runs/records/`:**
  - `changelog.md`, `todo.md` and `index.md`; copy each to `<name>.pre07117.md` first;
  - one new write-up, `iron-at-the-worlds-price.md`.

  Edit byte-safely and keep line endings. Don't touch `/home/claude/git` or `/home/claude/cbs*`. Don't grep across `/home/claude/runs` as a whole.
- **No invented numbers.** Every figure comes from a note or from this brief.

## Sources, in `/home/claude/runs/`
- **Notes:**
  - `docs-07115.md`: the docs pass for 0.7.107–0.7.115, merged as 04d505c.
  - `manual-17.md`: manual 17, published as version 17; its tree copies merged as bf61c82.
  - `fixE3-notes.md`: 0.7.117, deposits on the Earth's geology.
  - `fixE5-notes.md`: 0.7.119, the map on Earth.
  - `fixI3-notes.md`: built as 0.7.116, shipped as **0.7.120**, iron's prices and the split.
- **The plans:** `brief-batchE3.md`, `brief-batchE5.md`, `brief-batchI3.md`, and next `brief-batchI4.md` and `brief-batchE4.md`.
- **The house shape:** the changelog's top block and the todo's sections.

## Facts from the orchestrator
**Shipped through GitHub.** Each was merged by the orchestrator, gated on the merged tree and pushed. Tags exist only in the cloud clone.

| merge commit | what | the merged tree's gate |
|---|---|---|
| 04d505c | the docs pass, 0.7.107–0.7.115 | its own branch's (tree identical) |
| bf61c82 | manual 17 into `docs/` | docs only |
| fefc8ae | 0.7.117 E3 (branch 49c6072) | 96 of 96, the playtest identical to `pt07113` |
| b4ba4c2 | 0.7.119 E5 (branch dfbb3f7) | its own branch's (tree identical) |
| 676bf69 | **0.7.120 I3** (branch a58b4ca, built as 0.7.116) | 96 of 96, the playtest identical to I3's re-baseline `pt07116` |

All gates: BuildMenuCheck 101, Stale 0 firm, no `w/crlf`. 0.7.116 and 0.7.118 are unused: versions follow the order of the merges, and I3 shipped after E3 and E5.

**I3 stops Jerus's saves loading:** `SAVE_FORMAT` 37, floor 37. He was told at 23:20 on 2026-10-10 and has not answered. His rule ("old saves do not matter, only once we publish") applied. 0.7.115 or older still opens his cities, and a revert of one merge commit would bring them back.

**Not seen:** the PC was not connected at any check; its last confirmed pull was b327419 (0.7.102), 2026-10-10 11:35.

**The disk:** the session's disk allowance ran down to 1.7 GB free at about 02:55, from harness temp folders and finished batches' scratch. The orchestrator cleared them; the gate now clears its own temp folder.

**Running now:** I4 (0.7.121, the integrated route and old steel; it adds `since` to its seven rows per the orchestrator's unanswered recommendation on the recipes question) and E4 (founding on Earth; it bumps `SAVE_FORMAT`). Whichever merges second takes the next number.

**Open for Jerus (CONFIRM, with recommendations):**
1. **I3's playtest and ensemble** (fixI3 §4–§6):
   - Unemployment ended at 15.6%, against 9.3% before; real GDP about 20% lower; no furnace is ever built.
   - The ensemble: 20 of 25, against 24 of 26. Newly red: H1, R3 and HIGH T2; H2 has nothing to measure.
   - The cause: the old steel chain held jobs under 15% rates.
   - **Recommendation:** judge after I4's integrated route, which the spec expected to bring new candidates.
2. **E3's Z** (fixE3 ★E3-2): built by the spec's definition, not its printed numbers, which its own weights cannot reproduce. So the spots come out about 18% under the spec's figures; Rotterdam's oil is ×2.58, not ×2.99. **Recommendation:** keep it.
3. **E3's 68 corrected province classes** beyond the 219 the spec asked for, and South of 60°S left out of Z. **Recommendation:** keep both.
4. **E5's thinned rivers at far zoom** (★1): the study approved every river at least 1 px wide. Drawing them all at 30 km a pixel made Siberia 45% fresh water against the data's 0.5%. **Recommendation:** keep the thinning (`FAR_RIVER_SHARE`).
5. The earlier lists stay where they are: the landlords' homes, the Earth file, the recipes question and the knowledge limit.

## Do
1. **`changelog.md`:** one block at the top, at most 40 lines, in the house shape, titled `### IRON AT THE WORLD'S PRICE, AND THE EARTH'S GEOLOGY AND MAP — 2026-10-11, 0.7.117 to 0.7.120, shipped through GitHub`. Cover:
   - the docs pass and manual 17 first;
   - then E3, E5 and I3, with figures from the notes: E3's Z table and spots, E5's far-view times, I3's goods, four cases, playtest table, ensemble and the old-save refusal;
   - each batch's ★ calls that Jerus should know.
2. **`todo.md`:**
   - **The opening paragraph** at 0.7.120, at most 4 lines.
   - **NEXT:**
     - strike E3, E5, I3, the docs pass and manual 17, each with a one-line result;
     - mark I4 and E4 as running;
     - fold the notes' §7 into the entries they name (I4, I5, I6, E4).
   - **CONFIRM (from 0.7.117 to 0.7.120):** at most 10 items, the open items above first.
   - **CHECK 0.7.117 TO 0.7.120 ON THE PC:** at most 6 items. Put I3's first: his saves refused, and what the load screen says.
   - **FOUND ON THE WAY.**
   - Keep everything else.
3. **The write-up `iron-at-the-worlds-price.md`:** at most 110 lines, for Jerus, in plain words.
   - What I3 changed and why: his Q4–Q6, C and D. Iron ore, scrap, steel and the vehicles. Why no furnace is built now, and what I4 brings.
   - The saves refused, and how to open an old city (0.7.115 or older).
   - The Earth's geology and map in a few paragraphs.
   - The open calls.
4. **`index.md`:** one line for the write-up.

Reply with what you wrote, the line counts, and anything in the notes that contradicted the brief.
