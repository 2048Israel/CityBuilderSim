# Brief: I2, the shared machinery. 0.7.112. 2026-10-10

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## What this is
The second batch of the materials chains (`/home/claude/runs/spec-materials.md`; read §1, §2.1, §2.5, §2.6, §2.7, §2.8, §4 and §5's I2 row; the study it builds on is `/home/claude/runs/materials-chains-research.md`, §1.2, §1.3 and §1.6). **I2 builds the machinery every chain after it uses, and no chain yet:** no new sector, good or building, so the playtest should stay byte-identical.

1. **`SpreadPlanner`, shared (§2.6):** the default `moneyGate` becomes `ON_ITS_WHOLE_COST`: an order is asked for its interest at `projectRate(cost)` × `PROFIT_OVER_INTEREST` on its whole cost, whatever the sector's cash (Jerus's decision A, 2026-10-08: "test every order on its whole cost, whoever pays"; with zoning, the ground in that cost at its zone's price). `ON_ITS_BORROWING` stays as a named history. Add `outValue(g, u)` and `inValue(g, u)`, the marginal split of `cityValue` (§2.6).
2. **`sectors/ProcessingSector` and `sectors/ExtractionSector`** (abstract, §2.1): Processing's `plan()` = SpreadPlanner, captive use, idle-then-shed (extras `idleMonths.<id>`, `mayRetire()`, O5's rule); Extraction's plan is Mining's rule (§2.6b). **Mining moves onto `ExtractionSector` with today's test, byte-identical** (the MONEY gate comes to extraction at I3). Refining stays as it is unless moving it onto `ProcessingSector` is byte-identical and clearly simpler (★).
3. **Captive use (§2.7):** `Sector.captive(g)`, `Output.captive`; no sector has a captive good today.
4. **The works' own power (§2.8):** the template's `gen`; bought = max(0, draw − gen), sold = max(0, gen − draw); `Statement.powerSold`; `ServicesManager` sets the grid's consumption from the net draws; `UtilitiesHandler.setWorksPower(kW)`; MoneyAudit's two DOMESTIC lines "+ sectors PowerSold", "− utilities PowerBought". No template has `gen` yet.
5. **`consumables` (§2.5):** world k$ a month, paid abroad at the exchange factor through an imported-service line, made general from O10's shuttle freight (`Oil.SHUTTLE_TANKERS` in `otherInputs`, 0.7.91): `otherInputs["Consumables"]`, imports, TRADE scope. No template has it yet.

**Harnesses:**
- **`MaterialsCheck`** (new): the spec's second and third bullets in §4: `outValue`/`inValue` split at the month's imports and exports; the whole-cost gate refuses a cash-rich sector's case A on a fixture; captive books no sale; `gen` is billed net and the city pays the surplus; consumables go to TRADE.
  - The spec's first bullet (the four cases at parity equal the study's) lands with the first building rows at I3, because the study's prototypes did not survive (below). Build the four-case reading as a pure function if it helps I3, and say so in §7.
- **`RefineryCheck` 11b:** premise "cash in the till asks only earns > 0" → "the whole cost is tested whoever pays" (decision A changes the rule it asserts; the only premise this batch moves).
- **`MoneyCheck`:** the PowerSold/PowerBought and Consumables lines.
- **`BuildingDataCheck`:** json = twin on `gen` and `consumables`.

## What changed since the spec was written (read first)
- **0.7.105 (P6), the refinery's run** (`/home/claude/runs/fixP6-notes.md` §1, §2 and §7): `SpreadPlanner.cityValue()` now prices an untraded good at the net export price (R1); `SpreadPlanner.city().rate()` reads `Refining.plantRate()`; Refining weighs an order at the run with it standing (`runWith()`), and its crude units on site don't count against `MAX_CONCURRENT_ORDERS` (R3). Build `outValue`/`inValue` on today's `cityValue`, not the spec's.
- **0.7.101 and 0.7.104 (P2, P2b), automatic building** (`fixP2-notes.md`, `fixP2b-notes.md` §1 and §7): the player's auto-builder chooses by the long run and payback. It is not `SpreadPlanner`; leave it alone.
- **Decision A13 is the next batch, I2b, not this one:** the whole-cost test reaching the orders that go through `Game.Slices` and the sea's orders (it moves the playtest). Leave `Game.Slices` and the sea's orders as they are, and say in §7 what I2b should change.
- **The study's prototypes are gone:** `/home/claude/scratch-materials/` (`balance.py`, `gen_buildings.py`, `out/buildings-materials.json`, `goods-materials.txt`, `gen.txt`) did not survive the workspace's restart on 2026-10-09. The spec's figures and the study's tables (`runs/materials-chains-research.md`) are what is left; I3 onwards regenerate the rows from them. Nothing in I2 needs them.
- **0.7.110 (I1), fields by type** is in: `Deposit.FieldType`, sites by type, `LandManager.fits(...)`, the template's `site`. Read `/home/claude/runs/fixI1-notes.md` §1 and §7. Mining's move onto `ExtractionSector` keeps today's test; `fits()` gates it only from I5.

## The playtest
Expected **byte-identical** to `/home/claude/scratch-ui1/orch-gate/pt07106/` (the spec: refiners never hold cash when they weigh, so the whole-cost default changes nothing for Refining). **Probe that first** (shared rules, rule 1): switch the default and run the playtest before building the rest. If it moves, that is decision A working, not a fault: explain each move by its order, re-baseline (`pt07112` in your scratch), and run the 16-seed ensemble against `runs/ensemble/out/07106/summary.json` (`BASELINE=<that> bash runs/ensemble/run.sh <a copy of your tree> 07112`; it lives in the workbench, not in git; under the JVM lock).

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| I2 | 0.7.112 | named in the launch prompt | `/home/claude/scratch-i2` | byte-identical to `pt07106` (see above) |

Beside you: E1 (0.7.111, Earth's reader, new files only) and, once E1 lands, I2b (0.7.113, the whole-cost test for `Game.Slices` and the sea's orders, in `Game`'s THE LARGEST SLICE, `BusinessInvestment`, and the order tests of `sectors/Oil` and `Ports`). Don't touch those.

Your files: `SpreadPlanner`, `ProcessingSector` and `ExtractionSector` (new), `Mining`, `Sector`, `Output`, `BuildingsTemplate`/`BuildingCatalog` (`gen`, `consumables`), `Statement`, `ServicesManager`, `UtilitiesHandler`, `MoneyAudit`, `Refining` only as far as the default gate, the harnesses above and `AllChecks`, `GameVersion`, the counts in `CLAUDE.md`/`README.md`, `docs/harnesses.md`'s entries for your harnesses.

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** The full suite green (94 harnesses with MaterialsCheck; your base has 93); BuildMenuCheck 101.

Reply with: a short summary; the probe's result (byte-identical or not, and why); the bases as built and what each later batch fills in; the gate and your final commit; your ★ calls.
