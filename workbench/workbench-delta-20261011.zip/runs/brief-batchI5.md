# Brief: I5, Iron Mining by type and size. 0.7.124. 2026-10-11

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## What this is
The fifth batch of the materials chains (★, it may move the playtest). Read:
- the spec, `/home/claude/runs/spec-materials.md`: §1.3, §2.4, §2.6b and §5's I5 row;
- the study, `/home/claude/runs/materials-chains-research.md`: §1.3, §1.4, §2.2, §2.4 (Iron Mining's four rows), §2.5, and §10's Q3, Q5 and Q19.

Jerus decided (2026-10-08):
- Q3: field kinds by real shares.
- Q19: two sizes where real plants are big.
- A: every order on its whole cost.

**Build (the spec's I5 row):**
- **id 14, the Iron Mine, goes onto HEMATITE** (it stood on ANY since I1).
- **The three new mines**, Iron Mining's, from the study's §2.4 and the spec's §2.2 conventions:
  - **Large Open-Pit Mine:** 500,000 t ore, 20 hematite sites.
  - **Magnetite Mine & Concentrator:** 20,000 t concentrate from 60,000 t of rock, 1 magnetite site, dig 3.
  - **Large Magnetite Complex:** 400,000 t from 1.2M t, 20 magnetite sites.

  Ids **108, 109 and 110** (`nextId` after I4's 101–107). A `since` year on each, as I4 did (★, from the study or the research catalogue `/home/claude/runs/research-design.md` §4; e.g. taconite concentrating at Silver Bay, 1955), with no recipes list.
- **`fits()` gates the plan.** `LandManager.fits(r, type, standing, extra)` from I1 packs works onto the held fields of their type. Mining's `ExtractionSector.plan()` asks it before an order. The best earnings on cost among the mines that fit wins (§2.6b), on the whole-cost money gate (I3).
- **I1's notes §7, for I5:**
  - `Game` needs the standing claims by template (site type, sites, quantity + on site + ordered) for `fits()`.
  - The order gate (`hasDepositFor`, `buildRunAhead`'s `before`) counts buildings: multiply by `site.sites()` when a works takes more than one.
  - `remainingFor` by type (`getRemaining(r, type)`).
  - A typed mine digs `extract(r, type, t)`, keeping `ironMinedThisMonth`. The first typed dig makes the save carry `depletionByType`.
- **`groundLimit(IRON)` split by each type's capacity; retirement by type** (a mine retires when its type is worked out).

**Harnesses:**
- **MaterialsCheck, a new section:**
  - a 20-site works fits only on a field of at least 20 sites of its type;
  - a magnetite works never goes on hematite;
  - the four cases for the three new rows at parity, against the study's to its rounding;
  - a typed dig moves only its type's tonnes, with W exact.
- **LandCheck/WorldCheck** where `fits()` or the order gate changes.
- **BuildingDataCheck:** json = twin; BuildMenuCheck **111**.

## The playtest (★)
**Probe first** against the reference the launch prompt names (I4's).
- The playtest city owns almost no mines (I4: "one at the end"). Expect a small move or none; say which and why.
- Run the ensemble against `/home/claude/runs/ensemble/out/07121/summary.json` (I4's, labelled 07121) only if the playtest moves.
- **Guardrails:** the money audit closes every month; the city does not stall or collapse.

## What changed since the spec
Read §1 and §7 of `runs/fixI1-notes.md`, `fixI3-notes.md` and `fixI4-notes.md`.
- **I1's one-type finding:** at 25 sites, 60% of cities hold only hematite and 12% only magnetite. So a magnetite works finds no field in most cities, and the chains lean on imports.
- **I4's works now buy IRON:** the Pelletising Plant, the Mini Blast Furnace and the Blast Furnace. A typed mine's ore is their feed.
- **Every processing works is weighed with its lorries** (I4 ★1). Mining's plan is `ExtractionSector`'s, so say whether a mine's fleet is in its weighing (★) and keep it consistent with I4's.
- **Versions:** each batch keeps the number it was launched with. Yours is 0.7.124.
- **`buildings.json`'s readme lines** (its line 28 and lines 94-104) still say 0.7.116 and 0.7.121 for I3's and I4's rows; they shipped as 0.7.120 and 0.7.123 (the docs pass for 0.7.117-0.7.123 left the file to you, `docs-07123.md` §3). Correct them while you are in the file.

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| I5 | 0.7.124 | named in the launch prompt | `/home/claude/scratch-i5` | probe against the reference named; re-baseline if it moves |

**Your files:**
- `buildings.json` and the twin, for ids 14 and 108–110;
- `sectors/Mining`, `ExtractionSector`;
- `LandManager` (`fits`, `extract` by type, `groundLimit`), `Game` (the claims, the order gate);
- the harnesses above;
- `GameVersion`;
- `CLAUDE.md`/`README.md` counts and rows.

**Beside you:** a manual writer works in `docs/manual.*` only. No other implementer.

**Building:**
- Copy `src/main/resources/earth/` into your classes folder as well as the json.
- For the suite, set `JDK_JAVA_OPTIONS="-Djava.io.tmpdir=<scratch>/tmp -Dcbs.earth=/home/claude/scratch-earth/e0/out/earth-1.bin"`.
- The scripts in `/home/claude/scratch-gate/` do both; copy them and repoint them.

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** The full suite green (the count at your base, more if you add one); BuildMenuCheck 111.

Reply with:
- a short summary;
- the probe and whether the playtest moved;
- the four cases against the study's;
- `fits()` in the plan, with figures;
- the gate and your final commit;
- your ★ calls.
