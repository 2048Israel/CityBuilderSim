# Brief: the records for 0.7.110 to 0.7.115. 2026-10-11

You write the project's records, on **Sonnet**. The orchestrator checks your figures against the notes. Don't ask anything.

## Standing rules
- No command that could raise a permission prompt. No network.
- **Don't use `rm` at all, and never touch `/dev` in any way:** no `2>/dev/null`, no `> /dev/null`, no `/dev/stdout` or `/dev/fd`, no `<(...)`. That includes text inside heredocs and scripts you write; a wait loop or a grep is where agents slip. Use the Write and Edit tools for any text that mentions those strings.
- **Write only in `/home/claude/runs/records/`:**
  - `changelog.md`, `todo.md` and `index.md` (copy each to `<name>.pre07110.md` first);
  - one new write-up, `the-materials-machinery-and-the-earth.md`.

  Edit byte-safely and keep line endings. Don't touch `/home/claude/git` or `/home/claude/cbs*`. Don't grep across `/home/claude/runs` as a whole.
- **No invented numbers.** Every figure comes from a note or from this brief.

## Sources, in `/home/claude/runs/`
- **Notes:**
  - `fixI1-notes.md` (0.7.110, fields by type);
  - `fixE1-notes.md` (0.7.111, the Earth's reader);
  - `fixI2-notes.md` (0.7.112, the shared machinery);
  - `fixI2b-notes.md` (0.7.113, every order on its whole cost);
  - `fixE2-notes.md` (0.7.115, the Earth's ground).
- **The plans:** `brief-batchI1.md`, `brief-batchE1.md`, `brief-batchI2.md`, `brief-batchI2b.md`, `brief-batchE2.md`, `brief-batchI3.md` (next), `spec-materials.md` §5, `spec-earth.md` §8.
- **The house shape:** the changelog's top block (ZONING, AND AN OLD SAVE REFUSED) and the todo's sections.

## Facts from the orchestrator
**Shipped through GitHub** (`main`, each merged by the orchestrator and gated on the merged tree, then pushed; tags only in the cloud clone):

| merge commit | version | the merged tree's gate |
|---|---|---|
| 39eea4e | 0.7.110 I1 (branch afbeecf) | 93 of 93 |
| 9021d3a | 0.7.111 E1 (branch ec7b3aa) | 94 of 94, EarthCheck with the full file named |
| ce5ec19 | 0.7.112 I2 (branch 29906d9) | 95 of 95 |
| 9d70e5d, then 01bf29c | 0.7.115 E2 (branch 32ea094), then 0.7.113 I2b (branch 9ce5f5a) | 96 of 96 on 01bf29c, the playtest identical to I2b's re-baseline `pt07113` |

All gates: BuildMenuCheck 101, Stale 0 firm, no `w/crlf` outside the `.bat` files. 0.7.110–0.7.112 and E2 left the playtest byte-identical to `pt07106`.

**Versions out of order.** E2 (0.7.115) landed before I2b (0.7.113); 0.7.114 was never used; I3 (iron) is 0.7.116. `GameVersion` lists the entries in version order.

**The PC** was not connected at any check tonight; its last confirmed pull was b327419 (0.7.102) at 11:35 on 2026-10-10.

**Also tonight:**
- **The workbench:** the cloud session's notes, briefs, records, the ensemble's premises, the gate's scripts and the 0.7.106 traces were committed to the repo as `workbench/workbench-delta-20261010.zip` (c952c87, 4.3 MB), with `workbench/DELTA-2026-10-10.md`.
- **The docs pass for 0.7.107–0.7.115 is running**, then manual 17.

**Open for Jerus** (put each in CONFIRM, with its recommendation):
1. **The landlords' homes** (fixI2b §6 ★2): left on the lender's test, so a home paid outright is not tested (186 of 648 landlord builds in pt07113). A whole-cost variant left households without a home at months 260–261 and slowed growth (200,000 people at month 2573, against 2315). **Recommendation:** keep it as built; the landlords' hurdle is his "rent at zero profit" rule.
2. **How the 52 MB Earth file ships** (fixE1 §8): **recommendation:** a GitHub release asset, not git.
3. **I3 will stop his current saves loading.** The scrap/ore split makes an older save load wrongly, so by his rule I3 bumps `SAVE_FORMAT` to 37 and raises `OLDEST_LOADABLE_FORMAT` to 37. If he would rather keep playing his cities through the chains, I3 writes the conversion (IronSplit) instead. Asked 2026-10-10 evening.
4. **The recipes question** (the research study's Q3) and **the project's knowledge limit:** already in CONFIRM from 0.7.107–0.7.109. Leave them there.

## Do
1. **`changelog.md`:** one block at the top, at most 40 lines, in the house shape, titled `### THE MATERIALS' MACHINERY AND THE EARTH'S GROUND — 2026-10-11, 0.7.110 to 0.7.115, shipped through GitHub`. For each batch: what ships, its harnesses, its figures (I1's type shares and one-type table; E1's and E2's figures against the spec; I2b's moves and ensemble), and the ★ calls Jerus should know.
2. **`todo.md`:**
   - **The opening paragraph** at 0.7.115, at most 4 lines.
   - **NEXT:** strike I1, I2, I2b, E1 and E2 as done, each with a one-line result. **I3 (0.7.116)** is next, after the docs pass and manual 17. Fold each batch's §7 "for the next batch" into the entries it names (I3, I4, I5, I13, E3, E4).
   - **CONFIRM (from 0.7.110 to 0.7.115):** at most 10 items, the open items above first.
   - **CHECK 0.7.110 TO 0.7.115 ON THE PC:** at most 5 items, from the notes' §8.
   - **FOUND ON THE WAY:** the batches' findings.
   - Keep everything else.
3. **The write-up `the-materials-machinery-and-the-earth.md`:** at most 110 lines, for Jerus, in plain words.
   - What the three materials batches built and why the next ones need it: types; the whole-cost rule and what it changed in the playtest; captive goods; the works' own power; consumables.
   - What the two Earth batches built: the reader, the ground, and what is still missing before he can found a city on Earth.
   - The open calls.
4. **`index.md`:** one line for the write-up.

Reply with what you wrote, the line counts, and anything in the notes that contradicted the brief.
