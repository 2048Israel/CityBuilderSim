# Brief: manual 18, from 0.7.116 to 0.7.123, and its publication. 2026-10-11

You are a manual writer, on Opus with a fresh context. The manual is a published page (the artifact "CityBuilderSim", https://claude.ai/artifact/BkBAN1RDiQTpCj79WPbpCp) that writes the model out in full.
- **Its source:** `/home/claude/runs/manual/index.html`, current to 0.7.115. Its record is `runs/manual-17.md`; read it first.
- **The live page:** version 17.
- **Version 18** brings it to 0.7.123.

Jerus is around but busy; decide, and note your judgement calls in your record. Jerus, 2026-10-10: the manual is published without asking.

## What to write
| versions | the notes in `/home/claude/runs/` (read §1, §2, §6 and §8 of each; §7 for what changed later) |
|---|---|
| 0.7.117–0.7.123 | `fixE3` (deposits on the Earth's geology, 0.7.117), `fixE5` (the map on Earth, 0.7.119), `fixI3` (iron's prices and the split: built as 0.7.116, shipped 0.7.120), `fixE4` (founding on Earth, 0.7.121), `fixC1` (the card's interest gate, 0.7.122), `fixI4` (the integrated route and old steel: launched as 0.7.121, shipped 0.7.123), and the docs pass `docs-07123.md` §7 (the numbers that moved and what the manual must cover) |

- **The Earth file** ships as the GitHub release `earth-1`, fetched by `tools/earth/get-earth.bat`, which `Play CityBuilderSim.bat` and `Build EXE.bat` call (commit f99d62c; its message says the rest).
- **The plain-words write-ups** are in `/home/claude/runs/records/`: `iron-at-the-worlds-price.md`, and `steel-from-the-citys-own-scrap.md` if it exists when you start.
- **The code wins.** Check every figure against the tree, read-only at `/home/claude/git/CityBuilderSim` (`main`, 0.7.123, after its docs pass). Navigate by `docs/map/`, `docs/dials.md` and `docs/harnesses.md`.

**What a player meets:**
- **Founding on the real Earth:** the World chips, the globe, search, Random spot, the card with its refusals and warnings; the Earth file and what happens without it.
- **The Earth's ground, geology and map:** the far view, the hover's place and province, the deposits by province.
- **Iron at the world's price:**
  - ore, scrap and steel, and the vehicles;
  - the renamed sectors and the Electric Arc Furnace;
  - why furnaces don't pay on imported scrap;
  - old saves refused at format 37, and how to open an old city with an older build.
- **The integrated route:** the seven works, the city's old steel and the Scrap Yard, captive use, the works' own power, and a works weighed with its lorries.
- **The build card's interest gate.**

**Then:**
- the harness table and counts;
- the buildings count (108);
- **the masthead's edition line:** "Build 0.7.123 · Save format 38 · 11 October 2026";
- **the "what moved since the last edition" paragraph** (0.7.115 to 0.7.123). It names the unused 0.7.116 and 0.7.118 and why.

Section 18's Earth paragraph from edition 17 ("nothing yet") must be rewritten.

## Standing rules
- No command that could raise a permission prompt. No network, except the Artifact tool's publish and read. You have no Projects tool.
- **Don't use `rm` at all, and never touch `/dev` in any way:**
  - no `2>/dev/null` (write `2> <scratch>/err.txt`);
  - no `/dev/stdout`, `/dev/stdin` or `/dev/stderr`;
  - no `find /`;
  - no `<(...)` (not even a throwaway `diff <(echo) <(echo)`);
  - no `grep ... /dev/null`.
- **Before your first edit,** copy `index.html` to `/home/claude/runs/manual/index.before-07116.html`. Edit byte-safely, with Python on bytes, replacing exact spans. Keep the file's line endings and its HTML conventions. **Keep `&mp;` as it is (it is ∓).**
- **Don't read the big file whole.** Find each `<h2>` with `grep -n`, then read sections with `sed -n`.
- Every `java` run (ManualToMarkdown) goes under `flock /home/claude/jvm.lock`.
- **Write only to:**
  - `runs/manual/index.html` and `runs/manual/manual-publish.html`;
  - `docs/manual.html` and `docs/manual.md` in your worktree (named in the launch prompt), committed there ("0.7.123 manual-18: ...");
  - your scratch (named in the launch prompt);
  - your record `/home/claude/runs/manual-18.md`.

## Publish
1. **Build the publish file:** `manual-publish.html`, with `runs/manual/tools/publish.py`. First check that it rebuilds the current `manual-publish.html` from `index.before-07116.html` byte for byte. Then check that the new one differs only in the manual's new passages.
2. **Read the live page first.** The tool refuses a publish to an artifact this session has not read. So `read` it, then read the saved file it names **in full**, every line, because the tool's rules require the live version to be read before publishing. Check that it is version 17, as `runs/manual/manual-publish.html` was before you began. If it differs, stop and say how.
3. **Publish it as version 18:** the Artifact tool's publish, with `url` https://claude.ai/artifact/BkBAN1RDiQTpCj79WPbpCp and `file_path` your `manual-publish.html`.
4. **The tree's copies:** run `tools.ManualToMarkdown` (`--wrap` into `docs/manual.html`, then `docs/manual.md`), using classes built from your worktree. Commit them on your branch.

## Record: `/home/claude/runs/manual-18.md`, at most 90 lines
- each section you changed and what it says now;
- the figures you checked, and any disagreement between the records and the code;
- the publish (the version it returned);
- anything unsettled.

Reply with a short summary.
