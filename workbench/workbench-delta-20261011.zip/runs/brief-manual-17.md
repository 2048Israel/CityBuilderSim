# Brief: manual 17, from 0.7.107 to 0.7.115, and its publication. 2026-10-11

You are a manual writer, on Opus with a fresh context. The manual is a published page (the artifact "CityBuilderSim", https://claude.ai/artifact/BkBAN1RDiQTpCj79WPbpCp) that writes the model out in full.
- **Its source:** `/home/claude/runs/manual/index.html`, current to 0.7.106. Its records are `runs/manual-16-part1.md` and `manual-16-part2.md`; read both first.
- **The live page:** version 16.
- **Version 17** brings it to 0.7.115.

Jerus is away; decide, and note your judgement calls in your record. Jerus, 2026-10-10: the manual is published without asking ("publish" in his words means releasing the game).

## What to write
| versions | the notes in `/home/claude/runs/` (read §1, §2, §6 and §8 of each; §7 for what changed later) |
|---|---|
| 0.7.107–0.7.115 | `fixZ1` (zoning's model), `fixP7` (an old save refused), `fixZ2` (zoning's screens), `fixI1` (fields by type), `fixE1` (the Earth's reader), `fixI2` (the shared machinery), `fixI2b` (every order on its whole cost), `fixE2` (the Earth's ground), and the docs pass `docs-07115.md` §7 (the numbers that moved and what the manual must cover) |

The project's plain-words write-ups are in `/home/claude/runs/records/`: `zoning-and-the-forest-law.md`, and `the-materials-machinery-and-the-earth.md` if it exists when you start.

**The code wins.** Check every figure against the tree, read-only at `/home/claude/git/CityBuilderSim` (`main`, 0.7.115, after the docs pass). Navigate by `docs/map/`, `docs/dials.md` and `docs/harnesses.md`.

**What a player meets:**
- zoning (Policy's fifth area: the ground, a zone's page, the forest law), and what the investors and the build cards now say;
- an old save refused, and why;
- the whole-cost rule, and what it changes in which plants get built;
- deposit fields now having a type (nothing in play reads a type yet: say so);
- the works' own power and consumables (machinery for the coming chains: say so);
- the Earth: nothing yet; one short paragraph on what is coming, if the manual has a "coming" place.

Then:
- **the harness table and counts** (96);
- **the masthead's edition line:** "Build 0.7.115 · Save format 36 · 11 October 2026";
- **the "what moved since the last edition" paragraph** (0.7.106 to 0.7.115).

## Standing rules
- No command that could raise a permission prompt. No network except the Artifact tool's publish and read. You have no Projects tool.
- **Don't use `rm` at all, and never touch `/dev` in any way.** No `2>/dev/null` (write `2> <scratch>/err.txt`), no `/dev/stdout`, `/dev/stdin` or `/dev/stderr`, no `find /`, no `<(...)` (not even a throwaway `diff <(echo) <(echo)`), and no `grep ... /dev/null`.
- **Before your first edit,** copy `index.html` to `/home/claude/runs/manual/index.before-07107.html`. Edit byte-safely, with Python on bytes, replacing exact spans. Keep the file's line endings and its HTML conventions. **Keep `&mp;` as it is (it is ∓).**
- **Don't read the big file whole.** Find each `<h2>` with `grep -n`, then read sections with `sed -n`.
- Every `java` run (ManualToMarkdown) under `flock /home/claude/jvm.lock`.
- **Write only to:**
  - `runs/manual/index.html` and `runs/manual/manual-publish.html`;
  - `docs/manual.html` and `docs/manual.md` in your worktree (named in the launch prompt), committed there ("0.7.115 manual-17: ...");
  - your scratch (named in the launch prompt);
  - your record `/home/claude/runs/manual-17.md`.

## Publish
1. **The publish file:** build `manual-publish.html` with `runs/manual/tools/publish.py`. First check that it rebuilds the current `manual-publish.html` from `index.before-07107.html` byte for byte. Then check that the new one differs only in the manual's new passages.
2. **Publish it as version 17.** Use the Artifact tool's publish with `url` https://claude.ai/artifact/BkBAN1RDiQTpCj79WPbpCp and `file_path` your `manual-publish.html`.
   - The tool refuses a publish to an artifact this session has not read. So first `read` it, and read the saved file it names **in full**, every line, because the tool's rules require the live version read before publishing.
   - Check that it is version 16 as `runs/manual/manual-publish.html` was before you began.
   - If the live page differs from that, stop and say how.
3. **The tree's copies:** run `tools.ManualToMarkdown` (`--wrap` into `docs/manual.html`, then `docs/manual.md`), using classes built from your worktree. Commit them on your branch.

## Record: `/home/claude/runs/manual-17.md`, at most 90 lines
- each section you changed and what it says now;
- the figures you checked, and any disagreement between the records and the code;
- the publish (the version it returned);
- anything unsettled.

Reply with a short summary.
