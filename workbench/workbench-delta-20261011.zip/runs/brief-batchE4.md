# Brief: E4, founding a city on Earth. 0.7.121. 2026-10-11

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## What this is
The batch that lets a player found a city on the real Earth. Read the spec, `/home/claude/runs/spec-earth.md`: the summary, §2 "Picking a spot", §6 and §8's E4 row.

Jerus answered the study's questions "all rec" (2026-10-10):
- Earth for new cities only, and **the default once E4 ships**; the generated world stays as an option.
- Spots in the sea or on ice are refused; deserts and spots with no fresh water within 5 km get a warning.
- **No guaranteed iron field;** the card shows the nearest iron instead.
- Place names are for search only, with no borders.
- Today's river-water rule.
- No elevation.

What exists:
- **E1** `EarthProj`/`EarthData`.
- **E2** `World.Key`, `EarthTerrain`, the snap (`World` on Earth), `Founding.withWorldKey()` ("the door to found one").
- **E3** `Geology`, `World.provinceAt()`, `geology().multiplier(r, row)`.
- **E5** the far view and the hover's place and province.

Read §1 and §7 of `/home/claude/runs/fixE2-notes.md`, `fixE3-notes.md` and `fixE5-notes.md`.

**Build:**
- **`Founding`:** kind, lat, lon.
- **`ui/FoundingScreen`:**
  - a World chip, Earth | Generated, Earth the default when the data file is present;
  - the globe from the 4′ layer, zoom down to the 150 m view, and search by place name over `EarthData`'s places;
  - **Random spot:** the seed picks among the places that pass the site test.
  - **The card:** the ground within 5 km measured on the game's own plots (dry, river and lake, the distance to fresh water and to the sea), the province and its deposit multipliers (E3), and the nearest iron.
  - The refusals and warnings above.

  The study drew the screen; its renders are gone, so build it in FoundingScreen's own style (0.7.21's one panel) and say what you chose.
- **Saves (spec §6), by the old-saves rule:**
  - `DataSave` gains `worldKind` (absent means generated), `earthLat`, `earthLon` and `earthData` (`"earth-1:<hash>"`).
  - An older build would load an Earth city onto a generated world, so **bump `SAVE_FORMAT` by one.** This is the newer-build refusal's job: an older build refuses a newer format.
  - ★ **Whether `OLDEST_LOADABLE_FORMAT` must rise too.** It must not, if a save of the format before yours loads *rightly* in your build (absent `worldKind` = generated). Say which.
  - A save whose `earthData` differs from the shipped file's identity is refused with a message.
  - The map's sidecar and `CityLand.restore` must carry the key (E2 §7: today an Earth city saved would reload on the generated world).
- **The data file in the game (★, Jerus's call is pending):**
  - The game looks for it at `EarthData.DATA_FILE` (`data/earth-1.bin`) or `-Dcbs.earth`.
  - The recommendation put to him is a GitHub release asset, not git. This session cannot create one: the proxy refuses GitHub API writes.
  - **So the game must run without the file:** Earth is offered only when the file is present and its identity matches. Otherwise the chip says so in plain words and names where the file goes. Add `data/` to `.gitignore`.
- **The sea's depth on Earth (E2 ★7, E3 §7):**
  - `depthAt()` and `shelfTheta()` throw on Earth, and E3 lists offshore oil fields on Earth's shelf, basin and rift seas.
  - An Earth city with an oil industry would throw at the first platform. Decide (★) the least invented rule that keeps the oil chain working, and say it plainly. The study chose no elevation (Q8), so no depth data ships. Two candidates:
    - a depth from distance to the coast on the world's own plots, with its source;
    - platforms simply not offered on Earth until heights ship.

**Checks (spec §8 E4):**
- NewGameCheck, SaveFileCheck and ReadPathCheck cover the fields.
- The format before yours loads generated, byte for byte.
- An Earth city saved and reloaded is identical.
- A save with a different `earthData` is refused.
- An Earth city with oil at sea does not throw.
- A words probe for the founding card at 1,389 × 868.
- **The playtest:**
  - the default trace stays byte-identical;
  - `LongPlaytest --earth rotterdam` (or the fixture's window, ★) gets its own baseline, kept in your scratch and named in your notes.

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| E4 | 0.7.121 (the orchestrator renumbers at the merge if needed) | named in the launch prompt | `/home/claude/scratch-e4` | default: byte-identical to the reference the launch prompt names; Earth: its own baseline |

**Your files:**
- `Founding`, `ui/FoundingScreen`;
- `DataSave` (the four fields), the load path in `Game`, `CityLand`/`CityMap`'s key on load;
- `World`/`EarthTerrain` for the depth rule;
- `GameVersion` (VERSION, SAVE_FORMAT, and the floor if it must move);
- `.gitignore`;
- NewGameCheck, SaveFileCheck, ReadPathCheck and the Earth harnesses;
- `LongPlaytest`'s `--earth` switch;
- `CLAUDE.md`/`README.md` rows.

**Beside you:** I4 (the integrated route and old steel) works in `Good`, `buildings.json` and its twin, `sectors/HeavyIndustry`, `Motoring`, a new `OldMetal`, and `DataSave.oldMetal`. Both of you add a `DataSave` field: keep yours together and apart from its.

**Building:**
- Copy `src/main/resources/earth/` into your classes folder as well as the json.
- For the suite, set `JDK_JAVA_OPTIONS="-Djava.io.tmpdir=<scratch>/tmp -Dcbs.earth=/home/claude/scratch-earth/e0/out/earth-1.bin"`.
- Read that file only.

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** The full suite green (the count at your base, more if you add one); BuildMenuCheck 101.

Reply with:
- a short summary;
- the screen as built;
- the save decision (format, floor, and whether Jerus's saves still load);
- the depth rule;
- the Earth playtest's baseline;
- the gate and your final commit;
- your ★ calls.
