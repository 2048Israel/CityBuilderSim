# E5, the map on Earth (0.7.119): notes

Worktree /home/claude/git/wt-E5, branch batch/E5, from fefc8ae. Scratch /home/claude/scratch-e5 (build.sh, suite.sh,
pt.sh, bmc.sh, gate.sh, chk.sh: copies of scratch-e3's, pointed here; probe.sh + probe/ E5Probe (costs, renders,
medians, blends) and E5Words (the words probe); renders/ the PNGs; ed/ the edit sources).

Progress (a line per step, for a restart):
- base builds silent. 3e10e5a (WIP) farTerrain, nodeTerrain(key), the void, earthWords, MapView/OilView keys.
- probes: every river >= 1.5 px at 30.7 km a pixel drew Siberia 45% fresh and the world view in 9.1 s -> thinning,
  footprint filter, widest-run cache, tile blend from 64, blended pixels from 16: world 1.7-2.3 s, nodes 2-21 ms warm.
- 0c6cad9 MapCheck 10, GameVersion 0.7.119, CLAUDE.md; MapCheck 39 s green; EarthTerrainCheck, OilViewCheck green.
- RULE SLIP: one probe run (javac + java, the longest-segment probe, about a minute) was started without flock while
  debugging the probe script's output path; nothing else ran outside the lock. Nothing touched /dev; no rm.
- gate 05:15-05:31 (scratch-e5/gate.log): green, see 5. After the gate's builds, comments only: EarthTerrain's header
  paragraph THE FAR VIEW.

## 1. What I built
- **EarthTerrain.farTerrain()** (new; section THE FAR VIEW'S NODES), an Earth world's far node, spec-earth 3's "Far
  views": each pixel classed at its centre by the region's rule (classAt(), split out of pointClass(), the reads
  unchanged; 15" shares, the 4' far layers from FAR_STRIDE), its water left to the vectors. Under WATER_STRIDE (16)
  the region's pixels exactly; from it each pixel's lat/lon blended over FAR_BLEND_PX (8) blocks and the forest
  dithered by a hash where it is under the dry ground's forest share (DITHER_STRIDE 16). Then strokeWater(): GRWL runs
  stroked (stroke(): every pixel not sea whose centre lies within max(width/2, FAR_RIVER_HALF_PX x stride) of the
  segment, onRiver()'s rule), a run whole while its median width >= FAR_RIVER_SHARE (30/2500) of a pixel; small lakes
  drawn by blob() (inLake()'s rule, its noise at the stride: a disc from 16 up); from FAR_TILE_BLEND_STRIDE (64) a
  tile's points placed bilinear between its exact corners (tileCorners()/place()); segments with an end within RIM_M
  (LONGEST_SEGMENT_M^2/4R = 12.6 m) of the rim not stroked. nodeTiles(): the node's lat/lon box from 32 points an
  edge, longitudes unwrapped point to point (date line), all longitudes round a pole / past the rim (the antipode's
  latitude then in); each tile with rivers or lakes kept where its padded footprint (footprint()) reaches the node.
  widestRun caches each tile's widest run median, so a wide view skips a tile's decode when none passes.
- **MapTiles.nodeTerrain(key)**: Earth -> farTerrain(), generated -> regionTerrain() as before. nodePixels(): on
  Earth, past the rim (EarthProj.onPlanet()) the void (spec-earth 2).
- **LandMap.earthWords()** (new) and hoverWords(): on Earth, after whose the ground is, "4.1 km south-west of
  Rotterdam" (nearestPlace(): the least angle by unit vectors, cached per reader; placeWords(): EarthProj.distanceM,
  the initial bearing's 8 points, 0.1 km under 10, the name alone under 0.05) and "Geology: Anglo-Dutch Basin, a
  basin" (provinceWords(), KIND_WORDS); OFF_PLANET_WORDS past the rim; nothing on a generated world.
- **ui/MapView**: far nodes by shownMap.worldKey(); the card adds earthWords() after the owner line.
  **OilView.fieldsByPool**: World.of(l.key()).
- **MapCheck 10** (onEarth, farWindow, Water, seam, fullFile; header item 10). GameVersion 0.7.119; CLAUDE.md's row.

## 2. Departures, with reasons
- Rivers are thinned by width as the view widens (★E5-1), beyond the spec's "every river at least 1 px wide".
- The far node reads the 15" shares under FAR_STRIDE and the 4' layers from it (E2's split), not the 4' everywhere:
  at 16 to 128 plots a pixel a 4' cell (7.4 km) would be 2 to 15 pixels, the coast jumping kilometres at the change
  from the tiles.

## 3. Premises changed and new assertions
No premise moved; MapCheck 1-9 untouched (the generated far node is asserted equal to the region at every stride).
New: MapCheck 10 - fixture: generated node = region (1..1,024); each window (Rotterdam, Perth, Paris) under
WATER_STRIDE = region but for river strokes, at 16: every pixel within FAR_RIVER_HALF_PX of a line fresh/sea, every
small lake's sure part fresh/sea, sea and dithered forest the data's within SHARE_POINTS; twice and afresh identical;
the window node <= SCREEN_MS; Fiji's seam (half-overlapping nodes identical, land per side the data's); the corner
node void past the rim exactly; the hover's place (= brute-force nearest, the window's city) and province (E3's 11)
and off-planet words, none on a generated city. Full file: LONGEST_SEGMENT_M; every stride over Rotterdam <=
SCREEN_MS (whole world timed); Finland's small lakes' discs hold their area within LAKE_AREA; Chukotka's seam with
rivers and lakes both sides.

## 4. Trace movement
None: the default playtest's 8 traces are pt07113's byte for byte (findings "Nothing"); a generated world
reaches the code it reached (MapTiles.nodeTerrain() dispatches on the key; the far node is Earth's alone).

## 5. The gate - final commit dfbb3f7
- Both builds silent (model 0 bytes, ui 0 bytes). AllChecks: 96 run, 96 passed in 763 s (HealthCheck too; MapCheck OK
  first time, 38.0 s with section 10; EarthTerrainCheck 21.1 s, the full file named). BuildMenuCheck PASS, 101 of 101.
  tools.Stale 0 firm (438 soft). Playtest: 8 of 8 traces pt07113's. No w/crlf outside .bat. After the gate's builds
  only EarthTerrain's header comment moved (BuildMenuCheck and Stale read it); the model rebuilt silent after.
- Far view against the spec (spec 5: a 128-pixel node 1.4-3.7 ms; generated 13-30 ms before spec-land's rewrite):
  Rotterdam's window at 16 plots a pixel 5.2 ms; Rotterdam's node warm (first time) 2: 7.9 (9), 4: 7.3 (8), 8: 6.8
  (7), 16: 4.7 (6), 32: 5.0 (5), 64: 5.2 (6), 128: 6.4 (10), 256: 5.3 (12), 512: 7.5 (18), 1,024: 20.2 (44) ms - the
  generated region 1-3 ms here; probes: Paris/Perth/Fiji/Finland 2-14 ms to 512, Chukotka 1,024 95 ms (its 147,000
  small lakes). The whole world, 36 nodes at 1,024: 1.6 s (9.1 s before the thinning). Fresh water at 1,024: 9.3% of
  what is not sea. Recognisable (renders/): the Rhine-Meuse delta, IJsselmeer and Zeeland at 480 m a pixel; the
  Thames, Rhine, Meuse and Seine at 1.9 km; the Baltic, Ladoga, Onega at 3.8 km; the Nile, Amazon, Congo, Ob, Lena at
  30.7 km.
- Words probe (scratch-e5/probe E5Words, words.txt; Plex Sans 10 px, the card's line face, against 628.5 px): 59,760
  measured - every place x 8 directions at 20,015 km, every province with its class, the off-planet words - 0 over;
  tightest 54.5%, OFF_PLANET_WORDS 342.8 px; real cards at 7 spots x 3 plots, widest 342.8 px. One name of 7,342
  ("Tarabulus", its T with a dot below) holds a glyph Plex Sans lacks.

## 6. Star calls
- ★E5-1 THINNING (what Jerus approved, the study's "stroke rivers ... at least 1 px wide", built for every river):
  stroked every one at 0.75 px a side, the whole world at 30.7 km a pixel drew Siberia 45% fresh (the data's 0.5%)
  and took 9.1 s. Built: a run is stroked while its median width >= FAR_RIVER_SHARE = 30/2500 of a pixel - GRWL's
  narrowest at the study's own far render (2.5 km a pixel): every river at 2.5 km a pixel and closer, the widest at
  30.7 km (369 m: Nile, Amazon, Ob, Lena, Volga...). Flip: FAR_RIVER_SHARE 0 (and the world view's cost returns).
- ★E5-2 FAR_RIVER_HALF_PX = RIVER_MIN_HALF (0.75 px): a far pixel as a tile's plot; past 1/sqrt2 px, so a 45-degree
  river is 4-connected. 0.5 px would be "exactly 1 px" but 8-connected only.
- ★E5-3 Forest dithered from DITHER_STRIDE (16, no octave wider than a pixel), white noise by a hash of the
  pixel's corner and the stride; closer, the region's ranked noise (E2's rule). Windows: Rotterdam 15.0% vs data 14.9%
  (undithered region 1.5%), Perth 36.5/36.1 (18.7), Paris 39.1/39.0 (29.1).
- ★E5-4 Under WATER_STRIDE the far node is the region exactly but for wider river strokes (exact inverses there);
  from 16, FAR_BLEND_PX 8 blended lat/lon (measured <= 0.15 px off at 1,024, <= 0.014 to 256).
- ★E5-5 FAR_TILE_BLEND_STRIDE 64: a tile's vertices and lakes bilinear between its exact corners (measured <= 0.07 px
  at 64, <= 0.017 from 256; exact past BLEND_MAX_LAT or near the rim). Chukotka 1,024: 147,000 lakes a node.
- ★E5-6 RIM_M from LONGEST_SEGMENT_M (17,915 m measured, held on the full file): a segment can pass the antipode only
  with both ends within L^2/4R = 12.6 m of the rim; what is lost is ground within ~18 km of the antipode.
- ★E5-7 Small lakes drawn at every stride (area-true in expectation: Finland 3 x 3 nodes, discs on 5,729 centres for
  5,781 px of area, -0.9%); none dropped as sub-pixel.
- ★E5-8 The hover: the place by name alone, no country (a country is what a border asserts; Jerus: no borders);
  distance and the 8-point direction from the place; "Geology: <province>, <a basin|a shield|a fold belt|a rift|a
  shelf|oceanic|unclassed>"; no province line where the data has none; OFF_PLANET_WORDS past the rim. The
  multipliers wait for E4's founding card (the land office's map already draws and lists the fields themselves).
- ★E5-9 The void past the rim on the far nodes (spec-earth 2, "drawn as the void"); the model's ground there stays
  sea (terrainAt/regionTerrain unchanged), only nodePixels() paints it VOID.
- ★E5-10 Checks in MapCheck 10 (the brief's first choice): no new harness, AllChecks untouched, counts unchanged.
  The time bound is MapCheck's SCREEN_MS a node (a far node, on the worker, no costlier than a near screen's bound).
- ★E5-11 Words probe slot: the card beside the pointer wherever it is at 1,389 x 868: (1,345 - 2x10 - 2x14)/2 less
  padding and border = 628.5 px.

## 7. For the next batch
- E4: the founding card's multipliers (Geology.multiplier(r, row)); LandMap.placeWords()/nearestPlace() serve the
  search's "near" words; a place name with a glyph Plex Sans lacks (Tarabulus's T-dot-below, 1 of 7,342) falls back
  to JavaFX's face.
- Cost: the far node's pixels are E2's classAt() (bilinear 15" reads, 4-6 ms a node), 2-3 x the study's 1.4-3.7 ms;
  the whole world's first view decodes every river tile once (~1 s of 1.7-2.3 s).
- Docs pass: map pages for EarthTerrain (THE FAR VIEW'S NODES), LandMap, MapTiles; harnesses.md for MapCheck 10;
  EarthTerrain.WATER_STRIDE's sentence ("the far view's rivers are stroked from their vectors (E5)") is now true.

## 8. For Jerus to check on the PC
- Nothing in play changes until E4 founds a city on Earth; MapCheck 10 runs on the fixture (and the full file if at
  data/earth-1.bin). After E4: the land office's map zoomed out on an Earth city, rivers and lakes, and the hover card.

## 9. Outside my files
None.
