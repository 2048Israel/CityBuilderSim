# fixI2b notes (0.7.113): every order on its whole cost (Jerus's A and A13). Implementer (Opus), 2026-10-10/11
Worktree /home/claude/git/wt-I2b, branch batch/I2b from 9021d3a. Scratch /home/claude/scratch-i2b (no rm; build/suite/pt/bmc/gate copied from
scratch-gate; ptp.sh plays a given classes dir; h.sh runs named harnesses; probe/ a copy of src with -Di2b.gate=old, -Di2b.orders=<csv> (every
consider()/mortgage answer), -Di2b.shadow=<csv> (each order the other rule answered otherwise), -Di2b.rate=split, -Di2b.homes=whole; py/ readers).

## 0. Progress (a line per step)
- Read brief, shared rules, P2/O9/O10/O10b/I2 notes; worktree clean at 9021d3a.
- PROBE: Slices.passes() on `cost`: playtest moves from m9, findings "Nothing"; probe's old gate byte-identical to pt07106.
- fcd0e36 Game/Oil/BusinessInvestment/Retail; e2da3de orderGate, harnesses, fixtures; dc719f9 GameVersion. pt07113 = probe, byte for byte.
- suite-1 (fcd0e36): NewGameCheck, ZoningCheck, OrderSearchCheck, RefineryCheck, WellCheck red (3.) - all green after e2da3de (h-2..h-5).
- Probes: -Di2b.rate=split (pt-split), -Di2b.homes=whole (pt-homes) - 6. Ensemble 07113 (5b). Gate on dc719f9; 9ce5f5a (Stale's one
  firm finding, my own: FARM_HANDS between the orders' javadoc and ORDERS) rebuilt, rechecked - 5.
- SLIP: one command read the probe's report with `diff <(echo) <(echo)` (process substitution). Harmless; owned. Nothing else on /dev.

## 1. What I built
- **Game, THE LARGEST SLICE** (banner + ON ITS WHOLE COST paragraph): `Slices.passes(n)` asks servicesItsOwnDebt(profit x n,
  orderGate.testedOn(cost, cash), tested) - the whole cost by default - at the slice's one rate (`judged()`: projectRate(sector, borrowed),
  or the bond's blended rate where a bond is cheaper and covers; the old two comments moved into it). Financing unchanged: till first, the
  desk asked for what is borrowed, a ban stops a slice that borrows. `carriesAtPrime(n, on)` and `askPrime()` on the same amount;
  `askPrimeOfTheRest()` past PRIME_SCAN_SLICES under a ban adds the till's last slice (largestSlice() on cost <= cash) to the four.
  Refusal words: "Declined X - not even one would cover its interest on its whole cost[ at R%, the rate its own risk costs (at the debt it
  would take on | it)]"; trims "(trimmed from N - could not carry the interest on its whole cost)" ("cover its interest" kept for
  LongPlaytest.houseReason()). consider()'s javadoc.
- **Game.orderGate()/setOrderGate()** (SpreadPlanner.MoneyGate; ON_ITS_WHOLE_COST default, ON_ITS_BORROWING a check's counterfactual; not
  saved); **carriesItsWholeCost(sector, earns, cost)** (earns > 0, till + abroad first, ban, judged()'s rate) for planners;
  package-private **sliceFor()** (InvestCheck).
- **sectors/Oil** plan(): EACH KIND ON ITS WHOLE COST - a land well asked carriesItsWholeCost() before it stops the walk (with nothing at sea
  it still goes to consider(), which declines it: the playtest is unchanged by this); planAtSea(): platform well and jacket (package)
  asked it ("a Platform Well would not carry the interest on its whole cost"; "a platform and its wells would not carry ... their whole
  cost" / "would not pay"); THE OIL AT SEA's planner paragraph.
- BusinessInvestment (header's THE BRAKE, servicesItsOwnDebt()'s @param); Retail's P5 comment (outside my files, 9).
- GameVersion 0.7.113. CLAUDE.md/README: no row states the old rule and no count moves (no harness or building added) - unchanged.

## 2. Departures, with reasons
1. **orderGate()** (not in the brief): consider()'s rule is a replaceable piece like I2's planner gate, so a check can ask the rule to
   0.7.112 (RefineryCheck 14, OrderSearchCheck's twin). ON_ITS_BORROWING counts an overdraft as nothing (0.7.112 counted it on top).
2. **The landlords' homes are not changed** (★2): A13 names the Slices orders and the sea's; their test is the mortgage lender's.
3. **Oil's planner asks the test too**, not only consider(): without it a thin land well (or platform well) would stop the walk to the sea.
4. **InvestCheck 6b's at-prime twin** reads a sector that owns nothing (Luxury Retail), the only way a fresh city's loan is priced past prime.

## 3. Premises changed (before -> after) and the new assertions
- **InvestCheck 6** "cash purchase always passes" -> "a test struck on nothing passes (a cash purchase's, until 0.7.113)" (same arithmetic).
- **InvestCheck 6b** (new, 17): a month played (prime struck, the restaurants' books read); a Diner earning half the lower bar is refused
  from a till of twice its cost (the 0.7.112 rule would ask nothing), on a loan, and half and half; at the bar to the bit it is built, a
  hair under not, from the till (the till's rate) and on a loan (the loan's or bond's); the refusal's rate; "at prime" follows the whole
  cost (earnings over prime's bar on half, under it on all: not at prime) and a Boutique of a sector owning nothing, over prime's bar and
  under its own, refused at prime; an order of three, the till paying one: built whole at its bar, none of it at half.
- **OrderSearchCheck**: investedByCount() asks `g.orderGate().testedOn(cost, cash)` (0.7.53's asked the borrowed); section 2's fixture "the
  copy ... trimmed some" -> "decided some below the counted slices" (on the whole cost none is trimmed: 52 orders, 48 refused, 0 trimmed;
  the long run 1,537, 1,418 refused, 0 trimmed); new twin of the copy on ON_ITS_BORROWING causes the deep trims (24, 17 past the slices,
  the deepest 71,823) and every one is the countdown's. Header item 2, COPY_MONTH's note. **The banner's argument stands**: at a fixed
  rate the whole cost makes the test a run from one, but the rate still is not fixed (leverage, a bond's fixed costs, and now a till-paid
  slice at the sector's rate beside a bigger one at a cheaper bond's), so the countdown's slices and the search stay; the at-prime four
  points still decide it (the shortfall is two straight pieces of the whole cost), with the till's last slice under a ban.
- **WellCheck 12**: "ordered while the package earns" -> "...carries the interest on its whole cost" (the town now holds: $1,677.7k a
  month on $320.6M); new: held in the whole cost's words; "a platform well ... while one earns" -> "...while one carries ... whole cost".
- **Fixtures re-caused** (premises unchanged): NewGameCheck's used city founds on USED_HOUSES = 120 (200): without the Diners and Boutiques
  losing $2-37k a month its 756 people fitted in 200 and its landlords never borrowed (old 1,072); RefineryCheck 14's town on
  setOrderGate(ON_ITS_BORROWING) (its lever was the till, I2's ★I2-9 moved its planner the same way); ZoningCheck 8 hands the city its
  unskilled shortfall + FARM_HANDS (100) for the fields' asks, put back after (its unskilled posts outnumbered its hands: "33% of a Mixed
  Farm"); new fixture assertion that the zoned farm is then ordered.

## 4. Trace movement (pt07106 -> pt07113, all 8 traces; scratch-i2b/pt07113 = pt-probe = pt-1 byte for byte)
- **First move m9** (t-bank, t-bonds, t-build, t-month; t-house/t-labour/t-pop m10): Restaurants' Diner, $1,361.8k from a till holding
  exactly that, losing $6,951 a month - built by 0.7.112, refused now (and again m10). t-borrow from m126.
- **What the new rule refused that the old would have built, in the same month's state** (shadow-new.csv, 2,324 orders, all refused whole,
  none trimmed): Retail Filling Stations 1,291 asks from m127 (450 of them losing $14-43k a month); Automotive Assembly Plants 381 from
  m1726; Food Processing Meat Works 204 from m498, Snack & Oils 190 from m1373; Manufacturing Fabrication Works 177 from m830; Business
  Services Contact Centres 52 from m417 (e.g. $177.6k a month on $54.5M); Materials plants 26 from m1439; Diners 2; a Bottling Plant 1.
- **Early city smaller, later bigger**: m262 2,097 people / 1,016 jobs -> m266 1,513 / 603 (a post draws 2.25 people while jobs bind:
  0.7.112's city built the losing Diner m9 and Filling Station m126, then Convenience Stores m128/138/198 and a Fabrication Shop m262).
  People by era 2,026 / 7,966 / 46,251 / 175,436 / 391,331 -> 1,520 / 8,172 / 53,576 / 230,824 / 449,261; 100k m2031 -> m1857, 400k m3618
  -> m3302, 500k never -> m3704; end 492,823 -> 566,444 (m4002). Less credit, fewer defaults: bonds issued 1,985 ($19.6T) -> 1,408 ($12.6T);
  debt defaulted $20.1T -> $12.7T; written off $1.159T -> $1.071T; businesses' debt at the end $1.0T -> $53.2B; money created (backstop)
  $228.4B -> $0.6B. Built units (orders log): homes 6,043 -> 13,793, Convenience Stores 5,698 -> 33,574, Meat Works 61 -> 37.
- Materials (shells): the longest spell holding no plant and owing 257 -> 488 months (from m860); its longest default run 83 -> 298 months
  (264 banned). Findings "Nothing. Every month passed the audit and every reload matched." Guardrails held.

## 5. The gate, and the final commit
- gate.sh on dc719f9 (scratch-i2b/gate.log, 01:37-02:03): model and UI builds silent; **the suite 94 run, 94 passed** (HealthCheck and
  MapCheck green this time, 688 s); **BuildMenuCheck PASS, 101 of 101**; tools.Stale **1 firm** - my own orphaned javadoc (ZoningCheck:
  FARM_HANDS put between ORDERS' javadoc and ORDERS); playtest 8 of 8 identical to pt07113; no w/crlf but .bat files.
- 9ce5f5a moves FARM_HANDS above the javadoc (no code changed): both builds silent again, ZoningCheck and StaleCheck green, tools.Stale
  **0 firm, 429 soft** (I2 reports 429 too), eol 0. **Final commit 9ce5f5a** on batch/I2b (fcd0e36, e2da3de, dc719f9, 9ce5f5a); tree clean.
- Merge with I2 (29906d9): GameVersion (two entries, VERSION 0.7.113), RefineryCheck 14 (I2's planner line and mine, both kept),
  LongPlaytest untouched here. After the merge OrderSearchCheck's twin and RefineryCheck 14 still read ON_ITS_BORROWING, which I2 keeps.

## 5b. The ensemble (label 07113 against 07106; runs/ensemble/out/07113/score.md; 32.5 min; tree copy scratch-i2b/tree-07113)
- **24/26 passed (07106: 22/26)**, none vacuous, no missing or short run, pairing 64/64, M1 0 and F1 0/16 in every policy. No green
  turned red. **Red to green**: HIGH R3 (3 seeds above +1 pt -> 1; median -2.88 -> -3.45 pts) and SHOCK T2 (13,726 -> 15,332, now
  >= 75% of the baseline). **Still red**: A2 (longest yoy > 10% spell from m120: median 14 [0-29] -> 20 [9-24] - longer in the median,
  shorter at the worst) and S1 (1.80% [1.15-3.06], 07106 2.07% [0.79-3.93]; longest spell 15 months, 17).
- T1 16/16 at m1,208 [1,105-2,126] (m1,338 [1,090-1,865]); T2 AUTO2 230,198 [96,402-303,410] (206,974), ZERO_SLACK 161,993 (146,746),
  ZERO_HOT 3,622 (3,324), SHOCK 15,332 (13,726), HIGH 6,406 (6,216). A1 2.34% (2.25%); policy rate from m240 3.95% (3.84%).
- The run's wrapper shell was ended by the tool at ~18 min (exit 144); run.sh itself ran on to the end and scored (times.txt 80 lines).

## 6. ★ calls
- (No choice in place of what Jerus asked: A is in force for every consider() order and the sea's, as asked.)
- ★1 The rate for the till's part: the slice's one rate - the bond's blended rate where a bond is cheaper and covers, else its own
  projectRate - on the whole cost. The till's dollar stands in for the dollar the slice would otherwise raise at the margin, and the
  margin is that rate; one rate keeps the test the brief's sentence and a ratio of earnings to cost; the refusal quotes one rate.
  Measured (-Di2b.rate=split: till part at projectRate, borrowed part at the blended): the playtest identical to m614, then one order
  differs (weather: end 535,686). Flip: judged()'s caller in Slices.passes(), two lines.
- ★2 The landlords' homes keep the mortgage lender's test and an outright purchase stays untested (186 of 648 landlord builds in pt07113
  were paid outright). Not A13's row; the owner's hurdle is his "rent at zero profit" rule with no interest by design. Measured
  (-Di2b.homes=whole: NOI >= 1.25 x interest on the whole cost at the tested insured rate, every slice): households with no home m260-261
  (a finding), 100k at m1959 (m1857), 200k m2573 (m2315). For Jerus (8).
- ★3 Oil's planner asks the whole cost before the walk; with no sea the land well still goes to consider() (its words, the playtest's).
- ★4 orderGate() and carriesItsWholeCost() public; sliceFor() package-private (InvestCheck only).
- ★5 Under a ban past PRIME_SCAN_SLICES the till's last slice is asked at prime too (the line's ends are one and it).
- ★6 The owners are still asked before the test (Equity.raiseFor() in consider()): a refused plan's raise stays in the till, as before.
- ★7 The bank's branches (retail's money, consider()) now carry their whole cost too: the playtest opens none either way.

## 7. For the next batch
- Under the whole cost an order is taken whole or refused: 0 trims in OrderSearchCheck's 1,537-order run. Refused orders re-ask each month
  (Filling Stations 2,214 asks, 13 built). The search still decides refusals in log steps.
- LongPlaytest's -Dplaytest.moneyGate switch (I2's) could set Game.setOrderGate() too for the whole counterfactual (not done: I2's line).
- Materials' long shell and default spells (4.) - look at its orders under the whole cost.
- I2: SpreadPlanner rates the whole cost at projectRate(sector, cost); consider() at the slice's own (★1). For a processing order the
  planner's gate is the stricter; they agree when the till pays nothing and no bond is cheaper.

## 8. For Jerus to check on the PC
1. The Sectors screen's investors' words: "Declined X - not even one would cover its interest on its whole cost".
2. ★2: whether a landlord's home bought outright (or on a mortgage) should also carry the interest on its whole cost.
3. A young city grows slower without its loss-making shops and diners, then faster (4.).

## 9. Outside my files
- sectors/Retail.java: one comment (P5's "A shop the till pays for outright is not asked the test ... as before" -> since 0.7.113 it is).
- NewGameCheck, ZoningCheck, RefineryCheck (fixtures, 3.) and WellCheck (premise, 3.); RefineryCheck 14 is also I2's (one line each).
