# fixI4 notes (0.7.121): the integrated route and old steel
Worktree /home/claude/git/wt-I4, branch batch/I4 from 676bf69; scratch /home/claude/scratch-i4. Opus, 2026-10-11.

## 0. Progress
- PROBE (goods + rows, yard refused) vs pt07116: moved from m1077 (a pellet plant on imported ore, 0.56%, built and lost),
  LMMs from m1547; pop 724,031 (577,610), unemployment 12.4% (15.6%). pt1 (full): HI under whole 17, 31 backstops - a works'
  fleet in no estimate (★1). pt2 (+ lorries): 1, 16, 9.7%; pt07121 = pt2 to the byte. Commits 7346382, d340b4e, 754627d.

## 1. What I built
- **Good**: PELLETS .160/.125, PIG_IRON .460/.400, MET_COKE "Coke" .420/.320 (stockable), THERMAL_COAL .075/.050 (stockable),
  COKING_COAL .225/.180 (stockable), LIMESTONE .040/.010, LIME .280/.110; freight 3/8 of each wedge; BULK, DRY_BULK; appended.
  NationalAccounts.HELD + MET_COKE, THERMAL_COAL, COKING_COAL on the end.
- **Rows 101-107** (json + twin, scratch-i4/gen/gen_rows.py, the study's 2.4 + spec 2.2): Scrap Yard, Pelletising Plant, Coke
  Ovens (gen 8,000), Mini Blast Furnace, Blast Furnace (gen 60,000), Oxygen Steel Shop (gen 25,000), Large Mini-Mill; all-in
  the study's cost, posts 54/35/9/2, the study's ha, roadLoad 110/2,520 t, coke stock 120,000; consumables = runs - wages -
  power bought - water. nextId 108.
- **Template**: `since` (int, the year it first existed; 0 undated) and `oldMetal` ({STEEL: t a month}); catalog reads both.
- **OldMetal** (new): the pool by seller and source - cars x .9 t, demolitions x .3 t a material unit (the owner; the city's
  to the builders ★5), offcuts .05 t a tonne fabricated, worn sets x 300 t, all at 85%; settle(): pro rata at .70 x SCRAP's
  export price, the rest to landfill; saved. Hooks: Motoring, Game.retire()/closeDemolished(), Manufacturing, Rail.
- **HeavyIndustry**: ids; the route's goods (coke, pig iron, scrap captive); produceFlow(SCRAP) buys from the pool (scrap
  capped at what arose; payment ★3); the yard's feed gate (FEED_GATE of one past the yards standing), share and cost.
- **ProcessingSector**: feedShare/offMarketFeed hooks; vansFor/fleetRunning/fleetCapital (★1); overloads exact when unused.
  **SpreadPlanner.caseEarns()**: a yard's old steel at 70% of SCRAP's export in every case.
- **Sector**: sellOldMetal(), Ledger.oldMetalSold (SectorState), tonnesMoved() less captive (★4). **MoneyAudit** (★3).
  **DataSave.oldMetal** beside sectors/markets; Game's save, load, reset, scale.
- GameVersion 0.7.121 (no format change); CLAUDE.md (OldMetal row, sectors row, 108 cards), README (108 rows).

## 2. Departures, with reasons
- ★1 lorries in the works' estimate (not in the spec): the spec's estimate and the study's runs leave out the fleet the game
  makes every sector buy; without it HI was ordered into works that could not pay (pt1). Not in caseEarns (the study's).
- No recipes list (the brief). Copper old metal waits for I8 (the brief). Not done: a self-powered works is still throttled
  by the grid's energy ratio (I2's open item; no works with gen >= draw stood in any run) - section 7.

## 3. Premises changed (before -> after) and the new assertions
- By the decisions: BuildingDataCheck 101 -> 108 buildings; "no building makes power yet" -> three (103/105/106, 8,000/
  60,000/25,000; sold 5,800 and 8,600, bought 26,600); consumables 3 rows -> 10 (11, 12, 14, 101-107); NEW json = twin on
  oldMetal and since, the one old-steel taker, the seven years. MaterialsCheck 3 "no sector keeps a captive good" -> Iron &
  Steel keeps scrap, coke, pig iron; 6 "two furnaces" -> nine works. MiningCheck "nothing uses ore until I4" -> its buyers
  are 102, 104, 105. OilCheck: crude's HELD slot by indexOf (no longer last). TradeCostCheck: the seven rows.
- NEW: MaterialsCheck 11 (seven rows at parity: cost, posts, kW, gen, ha, consumables, four cases, years; case A <= .25%),
  12 (pool at 85%, pro rata, landfill, 70%, households' savings, named sale/input, the feed gate and share, the lorries, a
  played town's audits, across a save), 13 (captive coke and pig iron, no booking, lorries less captive), 14 (power sold
  and bought, the utility pays, audit). MoneyCheck: a yard buying households' and a sector's old steel, 24 months.
  GdpCheck: HELD's end. SaveFileCheck: the pool across the full-city save. ReadPathCheck: the pool fingerprinted and read.
- FOUR CASES (% a month at parity; study in brackets): Scrap Yard 1.54/1.54/4.69/4.69 (1.5/1.5/4.7/4.7); Pelletising
  0.06/1.77/3.71/2.00 (0.1/1.8/3.7/2.0); Coke Ovens -0.21/0.72/2.23/1.31 (-0.2/0.7/2.2/1.3); Mini BF -1.14/1.66/3.32/0.53
  (-1.1/1.7/3.3/0.5); BF 0.21/1.91/3.02/1.32 (0.2/1.9/3.0/1.3); Oxygen Shop -2.07/-0.64/2.26/0.83 (-2.1/-0.6/2.3/0.8);
  LMM -0.23/1.03/2.91/1.65 (-0.2/1.0/2.9/1.6). Years abroad .972/1.200/1.719/.750/1.125/1.101/1.702 (1.0/1.2/1.7/.8/1.1/1.1/1.7).

## 4. Trace movement (pt07116 -> pt07121) and the ensemble
- pt07121 is pt07116 to the byte through m1,535 (the new goods' markets, the pool and the hooks move nothing while no works
  stands). m1,536: Iron & Steel's first Large Mini-Mill order, on imported scrap replacing imported steel (80,803 t a month
  imported; 0.52-0.77% of cost a month at the city's prices). Mills are built, run at a rate of .6-.8 (the city's power short
  of a 77 MW draw, health .9, vans mobilising), sell near mid-band once they cover the imports (GoodsMarket: price position
  demand/(demand+supply)) and pay nominal interest past what they clear; some are lost and reordered. Scrap Yards from m2,127
  once the pool passes FEED_GATE of one yard; near the end 3 yards and 2 mills stand. HI under whole 1 (pt1 without the
  lorries: 17). End: people 659,072 (577,610), posts 393,556 (321,670), unemployment 9.7% (15.6%), price level 1,265 (906),
  exports $4.94T a month ($2.61T), the rate 806.9 per US$ (563.6), backstops 16 (10); police coverage at the end 38% (84%),
  crime 1.68x Canada's (0.44x) - the bigger city outran its police. "Nothing. Every month passed the audit and every reload
  matched." The gate build reproduced pt07121, 8 of 8 traces identical.
- THE SCRAP POOL (pt07121, I4POOL every 60 months; t a month recovered): m600 96 (offcuts 94), m1200 984 (offcuts 946, cars
  17, sets 21) = 9% of a yard's 10,500; m1800 5,494 (52%); m2100 6,856 (65%, the first yard ordered m2,127); m2400 13,045 (1
  yard bought 8,232, 4,812 to landfill); m3000 20,446 (2 yards, 13,497 bought); m3900 32,750 (3 yards, 20,150 bought; cars
  875, sets 234). Offcuts are 95-97% of it; cars never pass 3% (the spec's 134 t for city2400 is the right size); demolitions
  show only in the odd month (424 t at m2700). Paid at 70% of SCRAP's export x fx (D$186.7k a tonne at m3900).
- ENSEMBLE 07121 against 07116 (runs/ensemble/out/07121/score.md): 21/25 (1 vacuous), was 20/25. HIGH 16/16 runs and SHOCK
  15/16 byte-identical to 07116; ZERO_HOT 8/16 (the eight move at m262-368, where 07116 built arc furnaces in the 0% window's
  weak currency - seed 0 stood 38-76 posts m263-290 - which the lorries now refuse); AUTO2 and ZERO_SLACK all move (from
  m834-1,894). Red as before: A2 (14 months [5-19], was 14 [1-19]), S1 (+1.86%, a 13-month spell; was +1.94%, 17), H1 and
  R3 (identical to 07116); H2 vacuous. HIGH T2 now PASS only because its baseline is 07116 itself (4,148, unchanged). AUTO2:
  T1 16/16 at m1,512 [1,327-1,693] (m1,458); T2 189,988 [114,603-218,436], 96% of 197,342; M1 0, F1 0/16, pairing 64/64.
  ZERO_SLACK T2 113,055 (132,450), 85%. Seeds go both ways (AUTO2 -29% seed 13 to +16% seed 6).
- STEEL JOBS (diag on the frozen build, -Densemble.extra posts): HIGH - none, byte-identical to 07116 (the cities hold 2-7k
  people at m600-720; no works of the route fits, the old chain's 330-440 posts of 07113 do not come back). AUTO2 - every
  seed holds Iron & Steel posts at some point, first m1,068-1,989, at most 400-840 posts (one or two mills and yards), for
  28-464 of 2,400 months; at m2,400 three seeds hold any (400, 440, 40).

## 5. The gate and final commit
Gate on the final tree (scratch-i4/gate.log): both builds silent (0 bytes each); the suite 96 harnesses in 829 s, 96 passed
(HealthCheck green too); BuildMenuCheck PASS, 108 of 108 described; tools.Stale 0 firm, 439 soft (maps behind the sources,
pre-existing names); 0 w/crlf outside .bat; the playtest re-baselined (pt07121) and reproduced on the gate build.
FINAL 754627d (after 7346382, d340b4e). Maps left to the docs pass.

## 6. Star calls
- ★1 (in place of the spec's estimate) A WORKS IS WEIGHED WITH ITS LORRIES: ProcessingSector adds the vans its tonnes need
  (fleetRunning() in earns, fleetCapital() in the whole cost; Jerus's A). Without it pt1: HI under whole 17, 31 backstops,
  13.8% unemployment, a pellet plant on imported ore built and lost. With it: 1, 16, 9.7%. To flip: weigh() without the
  two terms. Not in caseEarns() (the study's cases stay the study's).
- ★2 Kept the spec's outValue: a mill's output valued at the import price for as much as the city imports. Once built it
  covers the imports and the local price falls to mid-band (GoodsMarket), so mills earn less than weighed - the finding of 4.
- ★3 Money: the yard's purchase on its ledger by seller (billForService(); households by Trade.HOUSEHOLDS, no tax credit);
  a selling sector's by Sector.sellOldMetal() (other revenue, named "Old metal sold" apart - Ledger.oldMetalSold, saved);
  the households paid into savings as the yards buy, by cars scrapped. Audit: the real line "- sectors
  OldMetalToHouseholds" (DOMESTIC, from the struck statements); the brief's three names as chk notes.
- ★4 tonnesMoved() less a works' captive tonnes, out and in (I2's open item): its own rails, not lorries.
- ★5 The city's own demolitions' steel is the builders' (Construction sells it), as their salvage share is.
- ★6 Old steel is a month's pool: what no yard takes goes to landfill that month (not carried). 85% recovery on all four
  sources (offcuts too, the brief's wording). The yard's feed gate FEED_GATE (60%) of its intake past the yards standing.
- ★7 since: an int year; 1900 (the start year) for the Scrap Yard, Coke Ovens and both blast furnaces; 1955 Pelletising
  (E4), 1952 Oxygen Steel Shop (E1), 1969 Large Mini-Mill (E13's scrap mini-mill; E18's thin slab, 1989, would also do).
- ★8 Rows: the Scrap Yard's posts at the heavy plants' split (22/14/3/1); water at the Mini-Mill's 320 per 3,700 kW (no
  study figure); all-in exactly the study's cost (cash takes the rounding of the material); MET_COKE labelled "Coke".
- ★9 Not done (I2's other open item): a works whose gen covers its draw is still throttled by the grid's energy ratio; no
  such works stood in any run.

## 7. For the next batch
- The lumpy works: a Large Mini-Mill (125,000 t) replacing imports drops steel's local price to mid-band and runs at the
  sector's post-build rate; the planner sees neither. A price-after-supply outValue for ProcessingSector (not Refining)
  would be the fix if Jerus wants mills that hold; also the energy throttle on self-powered works (★9).
- I5 (mines by type): the pellet plant and the furnaces are ore's first buyers; with a mine's ore exported the pellet case B
  is 1.8% at parity less its lorries (2,538 vans, ~D$1.9M a month) - expect pellets only where the city's own ore is cheap.
- I6/I7: the coals, limestone and lime are imported today; their makers will find Iron & Steel bidding only once a furnace
  stands. I8: OldMetal has Source and seller slots; copper is a second metal key on the template (Good-keyed map).
- I13: the build cards say nothing of gen, old steel or lorries yet (BuildMenuCheck reads only makes/uses).
- Docs pass: maps, dials (OldMetal's seven, HeavyIndustry's ids), harnesses.md (MaterialsCheck 11-14, MoneyCheck's old steel).

## 8. For Jerus to check on the PC
1. Sectors, Iron & Steel: a Large Mini-Mill's month and a Scrap Yard's ("Old metal" an input; Manufacturing's revenue opens
   to "Old metal sold").
2. Build tab: the seven new cards under Iron & Steel; a Scrap Yard's investors' word ("too little old steel for one").
3. A big city's Trade tab: scrap made at home once yards stand; coke, coal, limestone and lime imported only with a furnace.

## 9. Outside my files
Sector.java (sellOldMetal, Ledger.oldMetalSold, strike's naming, tonnesMoved), SectorState.java (the ledger's field),
HouseholdBalance.java (creditScrappedCars), sectors/ProcessingSector.java (feed share, off-market feed, lorries),
sectors/SpreadPlanner.java (caseEarns' old steel), sectors/Rail.java (worn sets), BuildingCatalog.java (since, oldMetal),
MiningCheck.java and OilCheck.java (premises moved by the batch). Nothing written outside the worktree, scratch-i4, these
two files and runs/ensemble/out/07121.
