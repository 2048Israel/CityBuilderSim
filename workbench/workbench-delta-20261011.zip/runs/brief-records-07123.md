# Brief: the records for 0.7.121 to 0.7.123. 2026-10-11

You write the project's records, on **Sonnet**. The orchestrator checks your figures against the notes. Don't ask anything.

## Standing rules
- No command that could raise a permission prompt. No network.
- **Don't use `rm` at all, and never touch `/dev` in any way:** no `2>/dev/null`, no `> /dev/null`, no `/dev/stdout` or `/dev/fd`, no `<(...)`, not in a diff, a cmp or a wait loop. Use the Write and Edit tools for any text that mentions those strings.
- **Write only in `/home/claude/runs/records/`:**
  - `changelog.md`, `todo.md` and `index.md`, each copied to `<name>.pre07123.md` first;
  - one new write-up, `steel-from-the-citys-own-scrap.md`.

  Edit byte-safely and keep line endings. Don't touch `/home/claude/git`. Don't grep across `/home/claude/runs` as a whole.
- **No invented numbers.** Every figure comes from a note or from this brief.

## Sources, in `/home/claude/runs/`
- **Notes:**
  - `fixE4-notes.md` (0.7.121, founding on Earth);
  - `fixC1-notes.md` (0.7.122, the card's interest gate);
  - `fixI4-notes.md` (launched as 0.7.121, **shipped as 0.7.123**: the integrated route and old steel).
- **The changelog's top block** (FOUNDING ON EARTH, THE CARD'S INTEREST GATE, AND THE EARTH FILE SHIPS): the orchestrator already wrote it for 0.7.121, 0.7.122 and f99d62c.

## Facts from the orchestrator
**Shipped:** 0.7.123 I4, merged as 9605b25 (branch 754627d) onto 0.7.122, gated on the merged tree:
- 97 of 97;
- BuildMenuCheck 108 of 108;
- Stale 0 firm;
- the playtest identical to I4's re-baseline (`pt07121` in its notes; `orch-gate/pt07123` in the gate);
- pushed.

E4 shipped 0.7.121 first, so I4 took 0.7.123; its GameVersion entry says so.

**Versions from now on:** `claude/git-workflow.md` says each batch keeps the number it was launched with. From this point the orchestrator launches each batch with a unique number and keeps it. I3 (0.7.116 → 0.7.120) and I4 (0.7.121 → 0.7.123) were renumbered before this was put right.

**Jerus, 2026-10-11:**
- **09:24, the Earth file:** it now ships as the GitHub release `earth-1` (f99d62c). This is already in the changelog's top block, and the todo's CONFIRM is closed.
- **09:39, I4's lorries (★1):** "for i4 the lorries, ill answer it shortly, ill have an md for you either in github or on teh project folder soon, but its anotehr batch, it will be a batch after your batches." Record it as **pending his md**: a batch after the planned ones. I4 stays as built (works weighed with their lorries).

**Running:** the docs pass for 0.7.117–0.7.123, alone; then manual 18 and I5.

## Do
1. **`changelog.md`:**
   - Fold I4 into the top block. Retitle it `### FOUNDING ON EARTH, THE CARD'S INTEREST GATE, THE EARTH FILE, AND STEEL FROM THE CITY'S OWN SCRAP — 2026-10-11, 0.7.121 to 0.7.123, shipped through GitHub, and f99d62c`.
   - Add I4's bullet: the seven rows (ids 101–107); the goods; OldMetal and the Scrap Yard; captive use; ★1 the lorries; ★2 the `outValue` rule kept as a finding.
   - Add the playtest table (pt07121 against pt07116), the ensemble (21 of 25), and the steel jobs: under HIGH no; under AUTO2 only in spells.
   - Add the scrap pool table, condensed, and the four cases (all within the study's rounding).
   - Replace the block's "Running" line.
   - Keep the block at most 55 lines.
2. **`todo.md`:**
   - **Opening paragraph:** at 0.7.123, at most 4 lines.
   - **NEXT:**
     - strike E4, C1 and I4, each with a one-line result;
     - fold the notes' §7 into I5, I6, I13, E6 and research;
     - add "the docs pass for 0.7.117–0.7.123 (running), then manual 18" as next;
     - add "AFTER THE PLANNED BATCHES: Jerus's lorries md (I4 ★1)".
   - **CONFIRM (from 0.7.121 to 0.7.123):** at most 10 items, with recommendations:
     - E4's depth rule (★E4-1) and the floor kept at 37;
     - C1's homes shown a dash;
     - I4's ★2 (the mills sold near mid-band once they cover the imports: a price-after-supply rule, his call);
     - I4's `since` years (★7);
     - I4's pool rules (★6);
     - the steel jobs under HIGH still red.
   - **CHECK 0.7.121 TO 0.7.123 ON THE PC:** at most 6 items, from the notes' §8. The first is founding on Earth: run `Play CityBuilderSim.bat`, which fetches the file.
   - Keep everything else.
3. **The write-up `steel-from-the-citys-own-scrap.md`:** at most 100 lines, for Jerus, in plain words:
   - what the integrated route is;
   - why mills now come and sometimes go;
   - the old steel and where it comes from (offcuts 95–97%);
   - the lorries and his pending md;
   - what the HIGH and AUTO2 runs show;
   - the open calls.
4. **`index.md`:** one line for the write-up.

Reply with what you wrote, the line counts, and anything in the notes that contradicted the brief.
