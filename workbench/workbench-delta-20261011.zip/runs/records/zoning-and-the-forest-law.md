# Zoning, the forest law, and an old save refused (0.7.107 to 0.7.109)

*2026-10-10. Your zoning (2026-10-08) was built in two batches, Z1 (0.7.107, the model, `runs/fixZ1-notes.md`) and Z2 (0.7.109, the screens, `runs/fixZ2-notes.md`), and between them P7 (0.7.108, `runs/fixP7-notes.md`) made the game refuse an old save cleanly, which is the rule you gave at 12:51. This note is all three in plain words, for you and for a session starting cold: what a zone is and does, the forest law, what the three screens show and what the investors and the build cards now say, what P7's floor does, and what is open. The changelog's top block is the state of the tree; the todo's CONFIRM (from 0.7.107 to 0.7.109) and CHECK 0.7.107 TO 0.7.109 ON THE PC hold what is yours. Nothing here has been seen in the game's window yet.*

## 1. What you asked for

Your words, 2026-10-08: "in policy zoning will now exist, and basically the default is free, anything everywhere, but with zoning, you can allocate a % of total land or a specific km² for a specific industry, and even provide the land at a lower rate, or free." The zone shows the industry's tax, sales tax and property tax, editable, "so that some industries can build even tho land is expensive and property tax would kill them," and can "reserve specific space for some industries." Forest is "a resource on the map same as ores and oil, just a lot more common and together," with a global law "of not building on the forest, or always keep a certain % of forest available." You took every recommendation of the design study except Z7, on which you said "yes 120, oh ya obviously for shared dials, aka for that sector, sure." No batch departed from what you decided.

## 2. What a zone is, and what it does

**One zone a sector.** Any of the 17 sectors can have one, Real Estate included (ground held for homes). Its size is a share of the city's dry ground (the default, re-read every month, so 2% stays 2% as the city buys land) or a number of km². Its price is a share, 0 to 100%, of the going price of business ground. Zones are amounts, not places: nothing is painted on the map, because the model has no positions.

**What it holds.** Free ground, bare ground first and then open forest, up to its size. Its sector's buildings standing elsewhere stay where they are and are not in the zone; ground the sector builds on inside the zone stays in it. A zone reads *used* (its sector's buildings in it) and *held* (free ground waiting for it). Short of free ground, a zone holds what is free, fills as the city buys land, and says so; when several zones are short, each gets the same share of what it wants, not first come in the sector list's order (★3).

**Who may build there.** Only its sector. Every other business sees the free ground less what zones hold. Zoned fields do not yield to homes: the farms' rule "nobody breaks ground on a field while somebody is sleeping outside" still holds for fields nobody zoned. When homes are short, the farms plan only if their zone holds ground, and the order is capped at what it holds.

**The price.** The city is paid the zone's price (the price share times the going price) when its sector builds there. Moving the share later refunds and re-charges nothing. A plot given back (a retired building, a buy-out) is bought back at the zone's price for the part that came out of the zone's used ground, and that ground goes back to the zone. What zoning costs the city is the price given up on ground sold and what the held ground would have fetched.

**The property tax.** Zoned ground is assessed at the zone's price in the property-tax roll, as farmland is assessed at its use value; buildings stay taxed at replacement cost. Only the roll reads the zone's price: the books and the sector statements keep the going price (★1).

**The zone's taxes.** The zone's three tax rows are the sector's own offsets: profit and sales up to 30 points either way, property 10. One dial, two doors: a rate moved in the zone is moved for every building of that sector, and Policy › Taxes shows the same move.

**Un-zoning.** Held ground goes back to everyone. Ground already sold in the zone stays with its owner at what it paid, and is assessed at the going price from then on (★6).

**What the investors see.** A sector sees as free the ground its zones hold plus the ground free for anyone; where it builds in its zone the ground costs the zone's price and its standing cost reads the zone's assessment; it builds in its zone first while the zone holds ground, and reads the zone's price only while the zone holds its whole plot. The city's own works build only on ground free for anyone (★7).

## 3. The forest law

The city's forest ground is of three kinds: **protected** (never cut, never built on), **working** (cut, never built on) and **open** (cut or built on). The law is two shares of the city's forest ground: *kept from building* (protected plus working) and *kept from cutting* (protected), the protected taken from the most-standing forest first. The default is 0% and 0%: all open, as before.

Z1 found that forest was dry ground a building could take, and nothing cleared it: nothing cut it, and the map painted a building on forest as grass. Now building on open forest clears it, cut-over ground first and then standing forest. The standing wood counts as extracted, so the world's totals still hold, and it is lost until Forestry exists (I9), which will sell it as a salvage cut. `cuttableForest()` is the read Forestry's crew rule will use (a crew only while the forest it may cut lasts 120 months). Clearing happens when ground is allocated, never takes protected wood, and never takes standing wood past `cuttableForest()` (★4).

On copies of five cities, 12 months each (nothing zoned, so only the clearing moves): city600 cleared 0.996 km² of its forest in the first month (13,647 of 14,216 m³), jerus-old's 11.83 km² all in the first month, and jerus-1008's 376.6 km² none; the world's totals held in all five, and all five load as before.

## 4. The three screens, and the words elsewhere

**Policy › Zoning** is Policy's fifth area: a chip (the land-plot icon) beside Taxes, Wages, Money and Promises, and a fifth card on Policy's hub. It keeps Policy's dial cards, staging and tray.

**Board 1, The ground.** Four figures: ZONED (km², its share of the dry ground, the number of zones), HELD FOR THEM, PRICE GIVEN UP (on what the zones hold, with the tax relief a month) and FOREST KEPT ("none" at 0 and 0). THE CITY'S GROUND is one bar of the dry ground: built, each zone (used solid, held hatched), bare ground free for anyone, and the forest in its three kinds; under it a closer bar of the zones and the bare ground; the parts click through to their zone or the law. THE ZONES has a row each: the sector's icon and name ("holds less than it wants" when short), size and share, used against held, price, the three rates as chips with an offset marked, the month's relief, a door to its page. THE FOREST LAW shows its bar and a sentence. "Zone ground for an industry" opens a picker of every unzoned sector.

**Board 2, a sector's page** (Policy › Zoning › Agriculture). HOW MUCH GROUND (a share of the dry ground or km²; what it carries, what it holds, what is free for anyone, what it holds at the going price). ITS PRICE (0 to 100%; a plot's ground at the zone's price against the going price, the price given up, the property-tax relief a month, THE BUDGET). ITS TAXES (profit, sales and property as the city's rate plus the offset, each with last month in money, and the line "The same dials as Policy › Taxes: a move here moves it for every <sector> building"). "Take the zone off". Nothing applies until the tray's "Apply it" or "Apply all N"; "Leave it as it is" discards. THE BUDGET in the tray is the taxes through the staged policy plus the staged zoning's change.

**Board 3, The forest law.** The forest bar under the staged law (and as it stands, below it, when staged), two ladders on one card (protected; kept from building), and WHAT IT WOULD DO: the forest standing for ever, the most that may be cut, the forest a building may take, the ground free for anyone. Forestry's crews do not exist yet, so it says what the law holds now.

**Elsewhere.** The land office's THE CITY line adds "· 3.2 zoned" (km², at its head). Build's LAND FREE reads "free for anyone · X% …" with a door "zoned for <sector> Y ›" (one zone: its page; several: "zoned for N industries", the area). NEEDS YOU's GROUND names what zones hold when it is listed ("<Sector>'s zone holds X" or "N zones hold X"; the homes' own zone left out). City History flags a zoning decision in sand with the plot icon (a decision kind of its own, ZONING; before, it was logged under TAX).

**What the investors and the build cards say.** One rule for all: the ground a sector can use is the ground free for anyone plus its zone's. The build card's land gate and its "land free", the quote, and both "Could not build" words read it and add "…; X is zoned for others", so the investors' word and "this one:" say it alike; they name the zones whenever another zone holds ground, not only when that alone kept the building out (★9). With no zone nothing changes: a sector's free ground is the old free ground to the bit, and every new word waits for a zone.

## 5. P7: the floor under old saves

At 12:51 you said "old saves do not matter, only once we publish to old saves matter." The rule written for it (CLAUDE.md, README) was: write no conversion code, and if a change would make an older save load wrongly, bump `SAVE_FORMAT` so it is refused cleanly. The docs pass found no such mechanism: the loader refused only a format newer than `SAVE_FORMAT` or older than the first with sectors (21), so a bump alone refused nothing. P7 built it.

`GameVersion.OLDEST_LOADABLE_FORMAT` is 21 (the old `FIRST_SECTOR_FORMAT` became it, so there is one gate). A batch that bumps `SAVE_FORMAT` because an older save would load wrongly raises it to the new format in the same batch, and says so. Below the floor the load stops before anything is applied and the file is left exactly as it was. The log reads "Slot N not loaded (save format F; this build reads formats 21 to 36), its file left as it was", and the slot list's line is the words, since the Load button is off: "This city was saved by build X, and build 0.7.108 can no longer read it. Build X still opens it." (a save with no stamp says "an older build"). Continue's autosave and YOUR CITIES pass such a slot by, as they pass a newer build's save. The floor is 21 today, so nothing that loaded at 0.7.107 is refused. SaveFileCheck's new last section (15 labels) writes a city at the floor, below it, unstamped and from a newer build, and checks each outcome and that every file in the folder is byte for byte as it was; RobustnessCheck 5b follows the constant. With the floor set to `SAVE_FORMAT` on a copy, the same three harnesses stayed green.

What it means for you: the first batch that raises the floor stops your current cities loading in the new build, by design (slots 1 to 9 are still never written); the build that saved them still opens them.

## 6. What it did to play

Nothing. The eight playtest traces are byte-identical to `pt07106` at all three versions: the test player sets no zone, and P7 refuses nothing that loaded before. P7's and Z2's gates ran 4,003 months with every month audited and every reload matched. No ensemble ran. The suite passed 92 of 92 at Z1 (its first run read 91: PlanCheck's 40 ms line read 42.54 ms, and passed alone), 92 at P7 and 93 of 93 at Z2; BuildMenuCheck 101 of 101; Stale 0 firm. Z2's words probe measured 95 strings at 1,389 x 868, none over. Z2's probe on copies of five cities (Agriculture 5% at 50%, Real Estate 1 km², a law of 20 and 40, three months) found the ground bar adding up to the dry ground in all five.

## 7. The ★ calls that are yours

None of them replaced what you asked; each is under the todo's CONFIRM (from 0.7.107 to 0.7.109) with its flip: the books at the going price and only the roll at the zone's (Z1 ★1); the zone's price both ways and un-zoning dropping the used record (★2, ★6); short zones sharing in proportion (★3); how the forest clears (★4, ★7, ★10); the law's two ladders in place of a two-thumb bar (Z2 ★1); PRICE GIVEN UP on the ground held (Z2 ★3); the dials' steps (Z2 ★5); and P7's one gate and its words (★1, ★2).

## 8. What is open

- **The going price does not see held ground.** `LandMarket` still prices land by allocated over owned, so ground the zones hold does not make it dearer for everyone else. A question for you if zones grow large.
- **The price given up on ground already sold is recorded nowhere,** so PRICE GIVEN UP counts only the held ground; recording it is a new saved field.
- **Later by design:** the map's tint of a zone's districts (I14); a zoning line in WHAT IS BITING; Forestry's use of the forest law and the cleared wood (I9).
- **When the floor rises,** the harnesses that load a hand-written older format (ConstructionControlCheck 27, ChartCheck 28, LandCheck and WaterCheck 30, ConversionCheck 31, SectorStatementCheck 32, OilCheck and WellCheck 33 to 35) will be refused, and their conversion sections retire with the formats. The spec's `IronSplit` (I3) is a conversion of an older save, so the I3 brief has to settle it under this rule.
- **A refused load still rebuilds the world first,** as a newer build's did; from the pause menu the city in play would be replaced by a blank one though nothing loads. The load list cannot reach it (the button is off); only code can.
- **Manual 16 stops at 0.7.106:** it has no zoning, and its saves section still carries the docs pass's flag that a bump alone refuses nothing.

## 9. For you to check on the PC

1. Load the 1008 city and play a month; nothing should look different (Z1).
2. Load a city: a slot holding a save from before the sectors (format below 21), if you have one, reads the new line and offers no load (P7).
3. Policy at 1,389 x 868: five chips and five hub cards. Zoning › The ground on a city with forest (the 1008 city): the bar, the hatched held ground, the closer bar.
4. Zone ground for an industry › Agriculture: move HOW MUCH GROUND, switch to km², move ITS PRICE and a tax row, Apply all. Then the zone's row, Build's LAND FREE ("zoned for Agriculture …") and the land office's "· N zoned".
5. The forest law: move each of its two ladders (the effects follow), Apply; then the area's FOREST KEPT and the law card.
6. City History: a zoning decision's flag in sand with the plot icon.
