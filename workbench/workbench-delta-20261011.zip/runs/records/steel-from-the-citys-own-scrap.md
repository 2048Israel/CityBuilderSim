# Steel from the city's own scrap (0.7.123)

*2026-10-11. I4, the integrated route and old steel, is in the game as 0.7.123 (754627d, merged 9605b25 onto 0.7.122). It was launched as 0.7.121; E4 (founding on Earth) shipped 0.7.121 first and C1 took 0.7.122, so I4 took the next number. Its notes are `runs/fixI4-notes.md`. This note is in plain words, for you and for a session starting cold. The changelog's top block is the state of the tree; the todo's CONFIRM (from 0.7.121 to 0.7.123) and CHECK 0.7.121 TO 0.7.123 ON THE PC hold what is yours. Nothing here has been seen in the game's window.*

## 1. What the integrated route is

Until now Iron & Steel could only melt scrap, and the city made no scrap, so every tonne was imported. The route is the whole way from ore to steel, as seven new buildings (ids 101 to 107, 108 cards in all): a Scrap Yard, a Pelletising Plant, Coke Ovens, a Mini Blast Furnace, a Blast Furnace, an Oxygen Steel Shop and a Large Mini-Mill. The Pelletising Plant and the furnaces are the first buyers of iron ore the game has had; the Coke Ovens, the Blast Furnace and the Oxygen Steel Shop make some of their own power (8,000, 60,000 and 25,000), which they sell and buy through the utility. Seven new goods go with them: pellets, pig iron, coke, thermal coal, coking coal, limestone and lime. The coals, limestone and lime are still imported; their own makers come with the coal and stone chains (I6, I7).

Coke, pig iron and scrap stay inside the sector (captive): they move on the works' own rails and are not booked as sales, and `tonnesMoved()`, which sizes the lorries, no longer counts them. Every row costs what the study said, and each carries a `since` year. The four cases at parity (% of cost a month, A / B / C / D) come out as the study's to its rounding:

| building | A | B | C | D |
|---|---|---|---|---|
| Scrap Yard | 1.54 | 1.54 | 4.69 | 4.69 |
| Pelletising Plant | 0.06 | 1.77 | 3.71 | 2.00 |
| Coke Ovens | -0.21 | 0.72 | 2.23 | 1.31 |
| Mini Blast Furnace | -1.14 | 1.66 | 3.32 | 0.53 |
| Blast Furnace | 0.21 | 1.91 | 3.02 | 1.32 |
| Oxygen Steel Shop | -2.07 | -0.64 | 2.26 | 0.83 |
| Large Mini-Mill | -0.23 | 1.03 | 2.91 | 1.65 |

## 2. Why mills now come, and sometimes go

Under I3's prices no furnace was ever built. Now the playtest is the same to the byte through month 1,535, and at month 1,536 Iron & Steel orders its first Large Mini-Mill, on imported scrap, to replace imported steel (80,803 t a month came in; at the city's prices a mill earned 0.52 to 0.77% of its cost a month). The mills are built, but they run at a rate of .6 to .8 (the city's power is short of a 77 MW draw, health is .9, the vans are still mobilising), and once a mill covers the imports the local steel price falls to the middle of its band, so the mill earns less than the planner thought when it ordered it. It pays interest past what it clears, and some are lost and reordered. Near the end of the playtest 3 yards and 2 mills stand.

This is the spec's `outValue` kept as written (a mill's steel is valued at the import price for as much as the city imports), and it is a finding, not a bug: the planner sees neither the price falling nor the rate. A price-after-supply rule for `ProcessingSector` (not Refining) would make mills that hold. That is your call (CONFIRM item 4); I recommend keeping it as built.

## 3. The old steel, and where it comes from

`OldMetal` is the month's pool of steel that something has finished with, by seller and source, at 85% recovery for all four: a scrapped car (0.9 t each; the households are paid into their savings), a demolition (0.3 t per unit of material; the city's own demolitions' steel goes to the builders, as their salvage share does), Manufacturing's offcuts (0.05 t per tonne fabricated) and a worn set of rolling stock (300 t). The Scrap Yard buys the pool pro rata at 70% of scrap's export price, and whatever no yard takes goes to landfill that month; nothing is carried over. A yard is ordered only once the pool passes 60% of a yard's intake (`FEED_GATE`) past the yards already standing.

It is the city's factories that feed it: offcuts are 95 to 97% of the pool, cars never pass 3%, and demolitions show only in the odd month (424 t at month 2,700). Tonnes a month recovered in the playtest:

| month | pool | what happened |
|---|---|---|
| 600 | 96 | offcuts 94 |
| 1,200 | 984 | 9% of a yard's 10,500 |
| 1,800 | 5,494 | 52% of a yard |
| 2,100 | 6,856 | 65%; the first yard is ordered at month 2,127 |
| 2,400 | 13,045 | 1 yard bought 8,232, 4,812 to landfill |
| 3,000 | 20,446 | 2 yards, 13,497 bought |
| 3,900 | 32,750 | 3 yards, 20,150 bought; cars 875, rolling stock 234 |

At month 3,900 the yards pay D$186.7k a tonne. The pool is saved with the city.

## 4. The lorries

The spec's estimate, and the study's runs, leave out the fleet of vans every sector has to buy to move its tonnes. Without it the planner ordered Heavy Industry into works that could not pay: in the probe "HI under whole" read 17, with 31 backstops, unemployment 13.8% and a pellet plant on imported ore built and lost. So I4 weighs a works with its lorries (the vans' running cost in its earnings and their price in its whole cost), on your decision A, and with that the same measures read 1, 16 and 9.7%. It is not in the four cases above, which stay the study's.

This is not in the spec, so it is yours to confirm. At 09:39 you wrote: "for i4 the lorries, ill answer it shortly, ill have an md for you either in github or on teh project folder soon, but its anotehr batch, it will be a batch after your batches." So it is recorded as pending your md, a batch after the planned ones, and I4 stays as built. To undo it, `weigh()` drops the two terms.

## 5. What the runs show

The playtest, `pt07121` (the gate keeps it as `orch-gate/pt07123`) against `pt07116`; every month passed the audit and every reload matched:

| at the end | before | now |
|---|---|---|
| people | 577,610 | 659,072 |
| posts | 321,670 | 393,556 |
| unemployment | 15.6% | 9.7% |
| price level | 906 | 1,265 |
| exports a month | $2.61T | $4.94T |
| the rate per US$ | 563.6 | 806.9 |
| backstops | 10 | 16 |
| police coverage | 84% | 38% |
| crime, against Canada's | 0.44x | 1.68x |

The bigger city outran its police. The ensemble, 07121 against 07116, is 21 of 25 (one vacuous), up from 20. HIGH (16 of 16 runs) and SHOCK (15 of 16) are byte-identical to 07116. ZERO_HOT moves in 8 of 16: 07116 built arc furnaces in the 0% window's weak currency at months 262 to 368, and the lorries now refuse them. AUTO2 and ZERO_SLACK move in every run, from months 834 to 1,894. Still red, as before: A2 (14 months, was 14), S1 (+1.86% over a 13-month spell, was +1.94% over 17), H1 and R3; H2 has nothing to measure, and HIGH T2 passes only because its baseline is 07116 itself. AUTO2's take-off (T1) is 16 of 16 at month 1,512 (1,458 before); its T2 is 189,988, 96% of 197,342; ZERO_SLACK's T2 is 113,055 (132,450), 85%. The seeds go both ways (AUTO2 from -29% on seed 13 to +16% on seed 6).

**Do the steel jobs come back?** Under HIGH, no: the run is byte-identical to 07116, the cities hold 2 to 7 thousand people at months 600 to 720, no works of the route fits, and the old chain's 330 to 440 posts of 07113 do not return. Under AUTO2, only in spells: every seed holds Iron & Steel posts at some point (first at months 1,068 to 1,989, at most 400 to 840 posts, for 28 to 464 of 2,400 months), and at month 2,400 only three seeds hold any (400, 440 and 40). I did not tune anything to change that.

## 6. What it did not do

A works that makes its own power is still throttled by the grid's energy ratio (I2's open item, ★9); no works with `gen` at or above its draw stood in any run. Copper old metal waits for I8, and there is no `recipes` list (the research batches' R1). There is no format change: `SAVE_FORMAT` stays at E4's 38 and the floor at 37.

## 7. The calls that are yours

The todo's CONFIRM (from 0.7.121 to 0.7.123) has eight items, each with a recommendation. From this batch: **the steel jobs under HIGH are still red** (3; accept as built), **the mills sold near mid-band once they cover the imports** (4; keep), **the `since` years** (5: 1900 for the Scrap Yard, Coke Ovens and both blast furnaces, 1955 for pelletising, 1952 for the oxygen shop, 1969 for the Large Mini-Mill; keep), **the pool's rules** (6: a month's pool, 85% on all four sources, the 60% feed gate; keep) and **the lorries** (7: pending your md). The other two are E4's depth rule and the floor kept at 37 (1) and C1's homes shown a dash (2); item 8 gathers the other ★ calls.

## 8. Next

The docs pass for 0.7.117 to 0.7.123 is running, alone; then manual 18 and I5 (iron mines by type and size, where the pellet plant and the furnaces are ore's first buyers: with a mine's ore exported the pellet case B is 1.8% at parity less its lorries, so expect pellets only where the city's own ore is cheap). Your lorries md is a batch after the planned ones.
