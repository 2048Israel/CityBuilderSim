# CityBuilderSim — handover for a session working through GitHub (2026-10-11 06:30, at 0.7.120)

## State
- **GitHub `main` is 04d505c**: 0.7.115 with its docs pass (0.7.107-0.7.115), every merge gated on the merged tree (last: 96 of 96, BuildMenuCheck 101, Stale 0 firm, the playtest identical to `pt07113`). The night's versions: 0.7.109 Z2 (819446b), workbench delta (c952c87), 0.7.110 I1 (39eea4e), 0.7.111 E1 (9021d3a), 0.7.112 I2 (ce5ec19), 0.7.115 E2 (9d70e5d), 0.7.113 I2b (01bf29c; it landed after E2, so 0.7.114 is unused), docs pass (04d505c). Tags `0.7.100`-`0.7.115` exist only in the cloud clone (0.7.113 on the branch tip 9ce5f5a, whose VERSION is 0.7.113).
- **The PC** last confirmed b327419 (0.7.102) at 11:35 on 2026-10-10; the bridge was unconnected at every check since.
- **Since 03:00:** the docs pass (04d505c), manual 17 (published as version 17; bf61c82), 0.7.117 E3 (fefc8ae), 0.7.119 E5 (b4ba4c2), **0.7.120 I3** (676bf69, built as 0.7.116: `SAVE_FORMAT` and the floor 37, so Jerus's saves are refused; 0.7.119 or older opens them). Versions follow the order of the merges (0.7.114, 0.7.116 and 0.7.118 unused); renumber a branch's GameVersion entry at its merge when another shipped first.
- **Running at about 06:30, 2026-10-11:** I4 (0.7.121, the integrated route and old steel, `since` on its rows; `git/wt-I4`) and E4 (0.7.121, founding on Earth, bumps `SAVE_FORMAT`; `git/wt-E4`), both from 676bf69; briefs `runs/brief-batchI4.md`, `brief-batchE4.md`. Whichever merges second takes 0.7.122; E4's save format is 38 (I4 has no bump).
- **References:** the playtest's traces `scratch-ui1/orch-gate/pt07116/` (I3's re-baseline); the ensemble's baseline `runs/ensemble/out/07116/summary.json` (20/25: A2, S1, H1, R3, HIGH T2 red). `scratch-gate/gate.sh` points at pt07116, takes the JVM lock, copies `resources/earth` into the classes, names the Earth file for the suite (`-Dcbs.earth`), and clears its temp folder each run.
- **Disk:** the session's allowance ran down to 1.7 GB free at 02:55 (harness temp folders in `scratch-gate/tmp` and finished batches' scratch); the orchestrator deleted both (28 GB free after). Clear finished scratch folders after each merge.
- **The records** (`claude/changelog.md`, `todo.md`, `index.md`) are current through 0.7.115, with the write-ups `zoning-and-the-forest-law.md` and `the-materials-machinery-and-the-earth.md`. Jerus's open calls: the todo's CONFIRM lists; the newest three are the landlords' homes (I2b ★2), how the Earth file ships (recommended: a GitHub release asset) and I3 stopping his saves.
- **After I3 and E3:** I4 (the integrated route and old steel; it needs the recipes answer or takes today's row shape plus `since`), E4 (founding on Earth: `SAVE_FORMAT`, the data file's place, the sea's depth), then I5-I14 and E5. The build card does not yet show `consider()`'s whole-cost test (docs pass flag 1: a card can pass every gate while the investors decline) - a UI follow-up.

## Found tonight, for the next batches
- **The materials study's prototypes are gone** (`scratch-materials/`: `balance.py`, `gen_buildings.py`, the building and goods rows). I3 onward rebuild the rows from `claude/materials-chains-research.md` (on disk as `runs/materials-chains-research.md`) and the spec's §2.2 conventions.
- **The Earth study's Java prototype is gone.** `earth-1.bin` (52.8 MB) and its Python tooling are in `scratch-earth/e0/` only; E1 copies the tooling into the repo. How the full file ships is Jerus's call, wanted by E4.
- **The research study** (`claude/research-design.md`, another session's): research comes after every planned batch, and the game starts in 1900 (Jerus, 21:24). Its Q3 asks the materials batches to write recipes as data. Asked of Jerus. The recommendation: today's row shape plus `since` on each new row.
- **I3's IronSplit is conversion code** under the old-saves rule. By the rule, I3 bumps `SAVE_FORMAT` and raises `OLDEST_LOADABLE_FORMAT`, which stops his current slots loading; the I3 brief must say so plainly.
- **The project's knowledge is near its limit** (1,766,364 of 2,000,000 before tonight). Recommendation put to Jerus: move old changelog blocks and the todo's struck items into the repo's `docs/notes/`.
- **Manual 17** is due after the next docs pass: 16 predates zoning, and its saves section still says a bump refuses nothing.

## 1. Restore the workbench (the cloud workspace starts empty)
1. **The base** is four parts on the PC in `C:\Users\Jerus\Documents\NetBeansProjects\CityBuilderSim\Claude outputs\`: `workbench-0799.zip.001` to `.003` (28,311,552 bytes each) and `.004` (4,584,190). The whole is 89,518,846 bytes, SHA-256 `8dfd34f068699fd8be1ee911f78bbd1fb051eadd7adb2a3428faffc17aa915f1`. Stage the four, `cat` them in order into `/home/claude/workbench-0799.zip`, check the hash, and `unzip -q` in `/home/claude`.
2. **Attach the repo** with push access (`add_repo`) and clone it to `/home/claude/git/CityBuilderSim`. `register_repo_root` wants `/home/claude/citybuildersim`, so link it. Run `git fetch --deepen=1000 origin main`.
3. **Unzip the delta:** `workbench/workbench-delta-20261010.zip` from the clone, over `/home/claude`. It holds today's briefs, notes, records, the ensemble's P1 premises, the gate's scripts and `pt07106`. Then copy the newest notes from `runs/` if the session got further than the zip.
4. **The gate's settings:**
   - in `scratch-gate/bmc.sh`, `FX=$(ls /home/claude/fx/*.jar | tr '\n' ':')`;
   - Gson is `/opt/apache-maven-3.9.11/lib/gson-2.13.1.jar`.

## 2. How a batch runs (`claude/git-workflow.md`, `claude/brief-shared-git.md`)
- **Agents have no Projects tool.** Quote Jerus's decisions in each brief, and copy any project doc they need to `runs/`. `runs/brief-shared-git.md` is the shared rules' disk copy, including the `OLDEST_LOADABLE_FORMAT` rule.
- **Two at most.** At most two implementers at once, on batches whose files don't overlap; a docs pass runs alone. Every `java` run goes under `flock /home/claude/jvm.lock`, the orchestrator's gates included.
- **Per batch:**
  1. `git worktree add ../wt-<batch> -b batch/<batch> main`; the agent commits there and never pushes.
  2. Merge with `--no-ff`. If the tree differs from the branch's gated tree, gate the merged `main`.
  3. Tag locally, `git fetch origin main`, push `main`.
  4. Check `autopull\log.txt` on the PC when it is reachable.
- **Agents probe before building,** decide and keep going, and never wait on Jerus.

## 3. Standing rules
- **Who does what:**
  - the orchestrator writes no code;
  - implementers and docs passes run on Opus;
  - records run on Sonnet, checked by the orchestrator.
- **Saves:**
  - slots 1–9 are Jerus's;
  - old saves need not load until the game is published: bump `SAVE_FORMAT` and raise `OLDEST_LOADABLE_FORMAT` where one would load wrongly, and write no conversion code.
- **Agents never use `rm` and never touch `/dev` in any form.** Nearly every agent slips once, read-only.
- **"Publish" means releasing the game** (Jerus, 21:15). The manual artifact is published without asking.
- **Never end a turn with work pending** unless agents are running in the background and will report.
