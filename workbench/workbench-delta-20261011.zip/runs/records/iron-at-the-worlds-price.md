# Iron at the world's price, and the Earth's geology and map (0.7.117 to 0.7.120)

*2026-10-11. After the docs pass for 0.7.107 to 0.7.115 and manual 17, three batches went into the game: E3 (0.7.117, deposits on the Earth's geology), E5 (0.7.119, the map on Earth) and I3 (0.7.120, built as 0.7.116: iron's prices and the split of scrap from ore). I3 is the first batch of the materials chains that changes the game, and it stops your saves loading. Their notes are `runs/fixE3-notes.md`, `fixE5-notes.md` and `fixI3-notes.md`; the docs pass and the manual are `runs/docs-07115.md` and `manual-17.md`. This note is in plain words, for you and for a session starting cold. The changelog's top block is the state of the tree; the todo's CONFIRM (from 0.7.117 to 0.7.120) and CHECK 0.7.117 TO 0.7.120 ON THE PC hold what is yours. Nothing here has been seen in the game's window; the PC was offline at every check.*

## 1. What you asked for

On iron, 2026-10-08: split scrap from ore (Q4); the Iron Mine at 20,000 t a month with the same 60 posts, at D$45M (Q5); steel at the world's price, D$650 / 470 a tonne, with fabricated steel and machinery moved by the steel in them (Q6, Q6b); cars, vans and trains the same (C); iron in the ground stays at US$0.40 a tonne (D); Mining and Heavy Industry renamed Iron Mining and Iron & Steel (Q2); every order tested on its whole cost (A, built in 0.7.113). On 2026-10-10: "all rec" to the Earth study (Earth for new cities only, real river courses, no guaranteed iron field, names for search only, no elevation) and "old saves do not matter, only once we publish". I3 applied your decisions as written; E3 and E5 replaced nothing you asked for.

## 2. What I3 changed in the game's iron

Ore and scrap are two goods now. IRON is relabelled "Iron ore" at .115 / .085 (freight .01125); SCRAP is new, .41 / .30, a bulk flow. Steel falls to .650 / .470 (its old ceiling was 1.284). Fabricated steel (-/1.545) and machinery (13.4 / 8.1) follow the steel in them, and so do the vehicles: cars 41.3125 / 33.3125 (the first car is 6% cheaper than at 44), vans 68.135, rolling stock 2,302.2. The figures are the study's, rounded as it rounded them; ManufacturingCheck holds the works' old margin over steel to the rows' rounding (under .3%), and CarCheck, VanCheck and RailCheck hold the vehicle plants' margins to the cent.

The Steel Foundry (id 11) is now the Electric Arc Furnace, 1,320 t of scrap in for 1,200 t of steel; the Steel Mini-Mill (id 12) takes 6,600 t for 6,000. The Iron Mine (id 14) digs 20,000 t a month on 60,000 L of diesel and 600 kW with its 60 posts, and costs D$44,999k all in (the old cost x4.632) plus D$199.8k a month of consumables. All three buy consumables. Heavy Industry now sits on `ProcessingSector`, so the planner chooses what it builds by earnings on cost as the refiners' does, and a mine's order goes through the whole-cost money gate first.

Iron in the ground stays at US$0.40 a tonne, now written as a share of the new export price (1/212.5 of .085), so it follows the price. The old reference, "the founding field's US$180M", has been gone since W1; LandCheck checks a founding field's ore at US$0.40 a tonne exactly instead.

## 3. The four cases

The study scored each building in four cases (A to D) at parity, as a share of its cost a month. MaterialsCheck 9 builds them from the game's own figures through `SpreadPlanner.caseEarns()` and holds them to the study's rounding:

| building | A | B | C | D | the study's A / B / C / D |
|---|---|---|---|---|---|
| Iron Mine | 2.72 | 2.74 | 4.07 | 4.06 | 2.7 / 2.7 / 4.1 / 4.1 |
| Electric Arc Furnace | -0.55 | -0.06 | 0.66 | 0.17 | -0.5 / -0.1 / 0.7 / 0.2 |
| Steel Mini-Mill | -0.50 | 0.11 | 1.01 | 0.41 | -0.5 / 0.1 / 1.0 / 0.4 |

The furnace's A (-0.55 against -0.5) sits at the edge of the study's rounding. Two things differ from the study's arithmetic, and the notes say so: diesel is a feed at the case's price (D$41.3k landed, D$35.2k at export, where the study counted D$36k at D$0.60 in running cost), and standing is 0, as in the study's cases. The three years-abroad figures (2.206, 4.427, 3.541) match the study's 2.2, 4.4 and 3.5.

## 4. Why no furnace is built now

With steel sold at home at the landed price, MiningCheck 3 now walks each works' month by hand: the arc furnace's margin is 8.0% of sales on imported scrap and the mini-mill's 13.8% (on local scrap 26.6% and 32.4%; the spec's bands are 5 to 15% and 20 to 35%, and the gap between the two is the scrap band times the tonnes). The four cases count the works' whole cost, and in case A the furnace earns -0.55% of its cost a month and the mini-mill -0.50%: the investors' test (`wouldPay()`) fails for the furnace, and Iron & Steel builds nothing at all. The city has no local scrap until I4, and nothing in the catalogue uses iron ore either, so no mine is built; steel is imported at .650 times the exchange rate. The jobs throttle that built a Steel Foundry 19 times before now builds Industrial Bakeries (27).

The probe shows what the planner would have done otherwise. With Heavy Industry's old plan on scrap, the player built Electric Arc Furnaces 5 times on the maker's estimate, shed them, and left Heavy Industry a shell from month 1032 (402 default months); the city ended at 433,661 people. With Heavy Industry on `ProcessingSector` it never orders one, and the city ended at 577,610: that run is the playtest.

## 5. What it did to the playtest

Every trace moves from month 4 (the first car is 6% cheaper; the ore at founding is $0.10 a tonne, was $0.28). At the end, `pt07116` against `pt07113`:

| | before | now |
|---|---|---|
| people | 566,444 | 577,610 |
| unemployment | 9.3% | 15.6% |
| GDP a month, price level | $6.2T, 1,456 | $3.1T, 906 (real about -20%) |
| exports / imports a month | $5.71T / $2.81T | $2.61T / $1.03T (net exports real about -12%) |
| the rate per US$ | 916.7 | 563.6 |
| Iron & Steel's credit | $28.8M by month 266 | $0k at all 16 checkpoints |

Every month still passes the audit and every reload matches. The 16-seed ensemble, 07116 against 07113: 20 of 25 (one vacuous) against 24 of 26. Newly red: H1 (ZERO_HOT's second half over its first, +1.83 points, was +0.51), R3 (3 HIGH seeds above +1 point, 2 allowed) and HIGH T2 (4,148 against 4,805); H2 has nothing to measure. A2 (14 months, was 20) and S1 stay red. T1 takes off at month 1,458 (was 1,208) in all 16 seeds; HIGH's unemployment at month 720 is 31.6% (was 18.4%).

The cause, traced on seeds 6, 2 and 12: at month 600 the old city's steel chain (Heavy Industry 330 to 440 posts, Manufacturing about 400, Automotive 0 to 500) kept its posts through 15% rates. The new city has none of it (Manufacturing 133, no assembly yet) and leans on Industrial Bakeries (750 to 1,060 posts, shed to 170 to 235) and Business Services (1,190 to 1,490, closed under 15% in both builds); seed 6 reaches 60% unemployment at month 690. Nothing was tuned and no premise moved; the four stand red for you to judge.

## 6. What I4 brings

I4 (0.7.121) is running. It adds seven Iron & Steel rows (Scrap Yard, Pelletising Plant, Coke Ovens, Mini Blast Furnace, Blast Furnace, Oxygen Steel Shop, Large Mini-Mill), the goods they need (pellets, pig iron, coke, two coals, limestone and lime, imported until their own sectors come) and `OldMetal`: steel arising each month at 85% recovery from scrapped cars (0.9 t each), demolitions (0.3 t a unit of materials), Manufacturing's offcuts (0.05 t a tonne made) and retired rolling stock (300 t a set), which the Scrap Yard buys at 70% of scrap's export price. The coke ovens, blast furnace and oxygen shop make and sell their own power. These are the first buyers of iron ore and the first local supply of scrap, so they are the new candidates the spec expected; I4 is to say plainly whether the steel chain's jobs come back. Each new row carries a `since` year (the orchestrator's recommendation on the recipes question, which you have not answered); there is no recipes list.

## 7. Your saves are refused, and how to open an old city

An older save's IRON maps hold scrap and ore together, so this build would read them wrongly. By your rule there is no conversion code (the spec's `IronSplit` is not written); I3 raises `SAVE_FORMAT` to 37 and `OLDEST_LOADABLE_FORMAT` to 37. Every save at 36 or below, your slots 1 to 9 among them, is refused on this build. Nothing is applied and the file is not touched; the slot list marks it, Load is off, and the screen and the log name the build that saved the city, which still opens it: "This city was saved by build X, and build (the running one) can no longer read it. Build X still opens it." You were told at 23:20 on 2026-10-10 and have not answered; the default was the bump.

To open an old city, run 0.7.119 or any older build (E3 and E5 kept format 36): the repository at b4ba4c2 is 0.7.119 (the tags exist only in the cloud clone), built in a folder of its own beside the live one, since the PC pulls `main` every ten minutes. Or say so, and the I3 merge (676bf69) is reverted in one commit: the cities load again, and I3 would come back with the conversion written (the spec's `IronSplit`).

## 8. The Earth's geology (E3, 0.7.117)

E3 makes an Earth world's deposits follow real geology. `Geology` puts every province of the Earth data in one of seven classes (ocean, shield, fold belt, rift, shelf, basin, other), first by the name rules in `tools/earth/geology.py`, then by a hand table of 287 rows laid over them. The rules left 219 provinces "other"; the table classes 211 of them (104 fold belt, 47 basin, 24 ocean, 23 shield, 11 rift, 2 shelf) and 8 stay other (the Ethiopian and Columbia flood basalts, the Canaries, five basement highs under the Kara, East Siberian and Okhotsk seas). It also corrects 68 provinces the rules had wrong, beyond the 219, each row saying why: Mesopotamia's foreland basin was ocean, the Lufilian Arc and the Copperbelt a basin, Ghawar's arch a fold belt, and the Stuart Shelf (Olympic Dam) a shelf. A geologist's eye on those rows is worth having.

Each resource has a weight per class (the spec's table) and a constant Z that keeps the Earth's total what it is today, so geology moves where deposits are and not how many. A cell's field land is its land times its class's weight times Z; oil also counts the sea over shelves, basins and rifts. A field's type leans on the ground under it: the share of stone fields that are limestone is .8852 in basins and .4908 on shields (the study .886 and .493). Generated worlds are untouched, and the eight playtest traces are byte for byte as before.

Z is not the study's. Its iron, copper and uranium Z cannot be reproduced from its own table: with its own shares iron's mean weight is 1.31 and Z .76, not .888, and .888 would need a shield weight near 3 when its Yilgarn x3.55 is 4 x .888. So Z is built as defined, measured on the file, and the spots come out under the spec's (built / spec). Z: iron .7219 / .888, copper .7322 / .846, uranium .7518 / 1.049, coal .7884 / .959, stone .6915 / .751, oil .6033 / .701. Rotterdam oil x2.58 / 2.99, coal x1.58 / 1.92, iron x0.36 / 0.44; Perth and Paris oil x1.21 / 1.40, iron x0.36 / 0.44; the Yilgarn iron x2.89 / 3.55, oil x0.03 / 0.04. At the study's own Z the spots reproduce to its rounding, so the rest of the arithmetic is right. Z leaves out the ground south of 60 S (East Antarctica as shield under ice would take about a sixth of the reachable world's iron), and oil's Z is over the land with the sea on top, which adds 51.6% to the land's oil count. Nothing in play changes until E4 founds a city on Earth.

## 9. The Earth's map (E5, 0.7.119)

E5 draws an Earth world on the map. Zoomed out, each pixel of a far node is classed at its centre from the data's shares, forest is dithered by a hash, rivers are stroked from their real vectors, small lakes are drawn as discs of their area, and past the rim of the planet the map paints the void. The hover card on an Earth city adds the nearest place by name alone, with distance and direction ("4.1 km south-west of Rotterdam"; no country, since you said no borders) and the province with its class ("Geology: Anglo-Dutch Basin, a basin"); the deposit multipliers wait for E4's founding card. The map view and the oil page now read the world's key, not its seed.

A far node at Rotterdam takes 4.7 to 7.9 ms warm from 2 to 512 plots a pixel and 20.2 ms at 1,024; the spec's figure was 1.4 to 3.7 ms for a 128-pixel node, so this is two to three times that, still inside MapCheck's bound, and the whole world, 36 nodes at 1,024, takes 1.6 s. The words probe measured 59,760 hover lines at 1,389 x 868 against the card's 628.5 px and found none over. One departure: the study said to stroke every river at least 1 px wide, but at 30.7 km a pixel that drew Siberia 45% fresh water, against the data's 0.5%, and took 9.1 s for the world. Rivers are stroked while their median width is at least 30/2500 of a pixel (`FAR_RIVER_SHARE`): every river at 2.5 km a pixel and closer, only the widest at 30.7 km. Recommended: keep it; set it to 0 to flip.

## 10. The docs pass and manual 17

The docs pass for 0.7.107 to 0.7.115 (04d505c) changed no code: Stale went from 436 soft lines to 119 (0 firm), 13 map pages are new, and one player string, the investors' "earns 1.25x its interest" note, which had been false since 0.7.113, now reads "on its whole cost, whether its cash or a loan pays". Manual 17 is published as version 17 of "CityBuilderSim" (its copies in `docs/` merged as bf61c82); it stands at 0.7.115, so it does not yet know about this note's three batches.

## 11. The gates

E3 (merged fefc8ae) and I3 (676bf69): suite 96 of 96, the playtest identical to `pt07113` and `pt07116`. The docs pass (04d505c) and E5 (b4ba4c2): their own branches' gates, trees identical. BuildMenuCheck 101 of 101, Stale 0 firm and no CRLF outside the `.bat` files throughout. 0.7.116 and 0.7.118 are unused; versions follow the order of the merges.

## 12. The calls that are yours

The todo's CONFIRM (from 0.7.117 to 0.7.120) has nine items. **I3's playtest and ensemble:** recommended, judge after I4's integrated route. **Your saves:** as built (refused), or revert the I3 merge. **E3's Z** (as defined, not the study's numbers), **its 68 corrections and the south left out of Z**, and **E5's thinned rivers:** recommended, keep all. Then **oil's Z over the land with the sea on top**, **I3's own calls** (the mine's estimate less consumables, the fixtures) and **E5's hover and void**, each "as built?". The landlords' homes, how the 52 MB Earth file ships, the recipes question and the knowledge limit stay in the earlier lists.

## 13. Next

I4 (0.7.121) and E4 (founding on Earth; it bumps `SAVE_FORMAT`, decides the sea's depth, and lets the game run without the Earth file when it is absent) are running, and whichever merges second takes the next number. After them come I5 to I14 (0.8.0) and research.
