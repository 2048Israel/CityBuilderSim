# Brief: E5, the map on Earth. 0.7.119. 2026-10-11

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## What this is
The map batch of "the world as planet Earth". Read the spec, `/home/claude/runs/spec-earth.md`: §3's "Far views" paragraph, §5's cost table and §8's E5 row. Jerus answered the study's questions "all rec" (2026-10-10): real river courses, WorldCover coasts, names for search only and no borders, no elevation.

What exists:
- **E1 (0.7.111):** `EarthProj` and `EarthData`.
- **E2 (0.7.115):** `World.Key` and `EarthTerrain` (`tileTerrain`, `terrainAt`, `regionTerrain`; a stride ≥ `WATER_STRIDE` 16 draws no rivers or small lakes, no beach, undithered forest; `FAR_STRIDE` 256 and up reads `far.land`/`far.lake`; `nodeTerrain(World.Key)` exists).
- **E3 (0.7.117):** `Geology`, with the province under a point: `World.provinceAt()`, `World.geology().kindOf(row)`, `multiplier(r, row)`, `petroleumOf(row)`, and `EarthData.province(row).name()`.

Read `/home/claude/runs/fixE2-notes.md` and `fixE3-notes.md`, §1 and §7 of each.

**E5 draws an Earth world on the map. Generated worlds must stay byte-identical.** Build:
- **`MapTiles`:** a far node image on Earth strokes rivers from their vectors (at least 1 px wide), draws small lakes from their points and areas, reads the 4′ layers at each pixel's centre, and dithers forest by a hash (spec §3, "Far views"). The study measured 1.4–3.7 ms for a 128² node image.
- **`LandMap`'s hover card on Earth:** the place (the nearest of `EarthData`'s places, for naming only, with no borders) and the province with its class. ★ Whether the deposit multipliers belong on the hover or wait for the founding card (E4).
- **The callers E2 left on the seed:** `ui/MapView` passes `shownMap.seed()` to `MapTiles.nodeTerrain()`; change it to `nodeTerrain(shownMap.worldKey(), ...)`. `OilView` reads `World.of(l.seed())`; change it to `l.key()`. Both are byte-identical on generated worlds.
- **Checks:**
  - **MapCheck:** an Earth far view within its time bound, rivers and lakes drawn, and no seam at 180°.
  - **A words probe** for the hover card at 1,389 × 868, by the screens' width helpers, as earlier UI batches did; grep "words probe" in `/home/claude/runs/fixZ2-notes.md` for the method.
  - Generated maps byte-identical (MapCheck's existing sections).

**Not E5:** founding on Earth, saves, the data file's shipping, the sea's depth. Those are E4's, after I3, because both bump `SAVE_FORMAT`.

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| E5 | 0.7.119 | named in the launch prompt | `/home/claude/scratch-e5` | **byte-identical** to the reference the launch prompt names |

**Your files:**
- `MapTiles`, `LandMap`;
- `ui/MapView`, `OilView` (the key only);
- `EarthTerrain` if a far read needs it;
- `MapCheck`'s new Earth section (or a new harness, ★);
- `GameVersion`;
- `CLAUDE.md`/`README.md` rows and counts.

**Beside you:** I3 (iron's prices and the split, which moves the playtest and bumps `SAVE_FORMAT`) works in `Good`, `buildings.json` and its twin, `Resource`, `sectors/Mining`, `sectors/HeavyIndustry`, `Sectors`, the harnesses that name buildings, and `LongPlaytest`. Keep out of those.

**Building:**
- Copy `src/main/resources/earth/` into your classes folder as well as the json.
- For the suite, set `JDK_JAVA_OPTIONS="-Djava.io.tmpdir=<scratch>/tmp -Dcbs.earth=/home/claude/scratch-earth/e0/out/earth-1.bin"`.
- Read that file only.
- The orchestrator's scripts in `/home/claude/scratch-gate/` do both. Copy them and repoint them.

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** The full suite green (the count at your base, more if you add one); BuildMenuCheck 101.

Reply with:
- a short summary;
- the far view's figures against the spec's;
- the hover card;
- the words probe;
- the gate and your final commit;
- your ★ calls.
