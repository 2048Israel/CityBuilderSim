# E1, Earth's reader, pure (0.7.111): notes

Worktree /home/claude/git/wt-E1, branch batch/E1, from 819446b. Scratch /home/claude/scratch-e1 (build.sh, suite.sh,
pt.sh, bmc.sh, gate.sh: copies of scratch-gate's, pointed here; build.sh and bmc.sh also copy src/main/resources/earth/).

Progress (a line per step, for a restart):
- 5d36cc1: E0's tooling copied to tools/earth/ verbatim (14 files, LF), with FORMAT.txt, ATTRIBUTION.txt, earth-1.sha256.
- 9a353a8: EarthProj, EarthData, EarthCheck, the fixture (src/main/resources/earth/), tools/earth/fixture.py, AllChecks,
  GameVersion 0.7.111, CLAUDE.md/README counts and rows. EarthCheck green on the fixture and with the full file named.
- ec7b3aa (final, after the green gate): docs/harnesses.md's entry for EarthCheck (HarnessMap run into scratch, the
  entry spliced in, the count line +1 file, +48 labels); a -Dcbs.earth naming a missing file FAILS; shorter headers.

## 1. What I built
- **EarthProj** (pure): Lambert azimuthal equal-area on the authalic sphere (RADIUS_M 6,371,007), StrictMath. forward() is
  Snyder's ch. 24; inverse() goes through the point's unit vector (cos c = 1 - 2s^2, sin c / rho = sqrt(1-s^2)/R, no
  arcsine), so it keeps its digits at a pole. Plots <-> metres exactly as spec-earth 2 (metresX/Y, plotX/Y, latLonOfPlot,
  plotOf). areaOnPlanetM2(): a plane rectangle's part within REACH_M (2R), closed form - equal-area makes it the sphere's
  area; cellAreaKm2(cx, cy) for World's cells. sphericalAreaM2(): the same measured on the sphere (edge carried point by
  point, geodesic polygon summed as triangles by spherical excess) - the check's independent measure. blend(): a tile's
  four corners exact, lat/lon bilinear between, longitudes unwrapped at the date line; exact per point above
  BLEND_MAX_LAT (75 deg) or off the planet. distanceM() (haversine), normaliseLon().
- **EarthData** (pure): the reader of FORMAT.txt, ported from earthread.py: header and layer table, the tile/band indexes
  (validated: inflate to 4 x count bytes, blobs sum to the layer's length), an LRU of inflated blobs by bytes
  (CACHE_BYTES 10 MB, spec 5), java.util.zip.Inflater only. Shares by tile/band/cell (grid(), cell()) and by position
  (at(): a cell holds its north and west edges, so a point on a whole degree is in the tile south of it; tileAt() the
  same). rivers(tile) as stored; riversIn(tiles...) each segment once (see 6). smallLakes(); provinceAt(), provinces(),
  province(row); places(); meta(); identity() "earth-1:<sha256>" against EARTH_1; locate() (PROPERTY cbs.earth, else
  DATA_FILE data/earth-1.bin from the working folder); size(), inflations(), cachedBytes(); static inflate().
- **EarthCheck** (new, 48 labelled assertions, nine numbered sections), in AllChecks after the first line.
- **Fixture**: tools/earth/fixture.py cuts src/main/resources/earth/earth-1-fixture.bin (332,111 bytes, sha256
  f3a71aaf...e0fd2d) and earth-1-fixture.expect (145,237 bytes, 2,390 lines of what earthread.py reads: scope
  both/fixture/full). 18 tiles (Rotterdam 6, Perth 4, Paris 4, Fiji 4 on 180 deg) and their 8 bands, blobs copied byte
  for byte; every other index entry 0; geology, provinces, places copied; the meta gains "fixture" (of: EARTH_1, tiles,
  bands). Regenerate: `python3 -I -B tools/earth/fixture.py <earth-1.bin> src/main/resources/earth`.
- tools/earth/: E0's *.py, run.sh, FORMAT.txt, ATTRIBUTION.txt, earth-1.sha256, verbatim; plus fixture.py.

## 2. Departures, with reasons
- The inverse is not the textbook arcsine form (spec gives none; the prototype's is gone): the unit-vector form is
  exact-conditioned. Measured worst round trip 7.6e-9 m against the spec's 2.4e-7.
- Small lakes' areas use a table of 2^(k/8) correctly rounded (hex literals, worked to 60 digits) and Math.scalb:
  StrictMath.pow missed the nearest double at 63 of 256 codes where earthread.py's pow (glibc) did not, so the first run
  failed "equal to earthread.py's". Now 256 of 256 equal.
- normaliseLon() leaves a longitude already in [-180, 180) untouched: +180 % 360 - 180 moved Perth's spot 2.7e-9 m off
  the origin (caught by "the spot is the plane's origin").
- The spec's "91.3% of the Earth in the square" is a cell count (cells with any of 16 samples on the planet); the exact
  area is 91.06%. EarthCheck reproduces the count (12,108 cells, the spec's figure) and prints both.

## 3. Premises changed and new assertions
No premise moved. New: EarthCheck 1-9 (the header lists what each proves).

## 4. Trace movement
None: the playtest's 8 traces are pt07106's byte for byte (nothing in the game calls either class).

## 5. The gate (scratch-e1/gate.sh, gate.log, 23:12-23:29) - final commit ec7b3aa
- Both builds silent (model 0 bytes, ui 0 bytes). AllChecks: 94 harnesses run, 94 passed (HealthCheck too; MapCheck OK
  first time, 29.9 s); EarthCheck 1.5 s. BuildMenuCheck PASS, 101 of 101. tools.Stale 0 firm (3 soft: no map pages for
  the three new classes - the docs pass's Maps run). No w/crlf outside .bat.
- EarthCheck without the full file: exit 0, one plain line for section 9. With -Dcbs.earth=scratch-earth/e0/out/
  earth-1.bin: exit 0, identity = EARTH_1, 951 tiles/bands, 115 tiles' rivers and lakes, 7 segment counts all agree.
  A -Dcbs.earth naming a missing file: exit 1, "the file -Dcbs.earth names is there FAIL".
- EarthCheck's figures against the spec: round trip worst 7.6e-9 m (spec <= 1e-6, measured 2.4e-7); cell area on the
  sphere worst 1.8e-12 relative (spec 1e-9); blend at the spot 0.023 m (spec 0.025), 10,000 km out worst 0.079 m in
  8 directions from 4 spots (spec <= 0.1, measured 0.054), Fiji's 180-degree tile 0.006 m, seams 3e-9 m; 12,108 cells
  off the planet (spec 12,108); inflate median 58 us (spec <= 1 ms, measured 126-130 us).

## 6. Star calls
- ★ Nothing of what Jerus asked replaced.
- ★ Fixture at src/main/resources/earth/ (a classpath resource, as conversion-saves.json is; Maven copies it on the PC).
  The cloud build scripts copy only resources/*.json: build.sh and bmc.sh need `cp -r src/main/resources/earth $OUT/`
  (my copies have it). EarthCheck FAILS, saying so, without it; it also looks in src/main/resources/ from the working
  folder.
- ★ The full file is named by -Dcbs.earth=<path> (EarthData.PROPERTY); in AllChecks through JDK_JAVA_OPTIONS (children
  get only -cp). EarthData.DATA_FILE, data/earth-1.bin from the working folder, is where the game will look until E2/E4
  decide; EarthCheck uses it when present. One plain line when neither.
- ★ EARTH_1 (the identity this build reads) is a constant in EarthData, from tools/earth/earth-1.sha256.
- ★ Rivers over several tiles: kept from the first tile in tile order, dropped from later ones; only segments whose
  quantised box touches the tile's edge are looked up (only those can be stored twice). fixture.py counts the same way.
- ★ Cells hold their north and west edges (rows from 90 N); one rule for every share layer and the geology.
- ★ BLEND_MAX_LAT 75 deg: the blend's bend is ~ side^2 tan(lat)/8R, 6.8 cm at 75 for a 960 m tile.
- ★ AREA_SAMPLES 4096 a side; tolerance read as relative (1e-9 of 3,774.87 km2): measured 1.8e-12.
- ★ earth-1.sha256 copied with the tools (not on the brief's list): it is the file's identity, for sha256sum -c.

## 7. For the next batch
- E2: read tiles through EarthData (one instance, its LRU), project through EarthProj.blend(); a blended tile meets an
  exact one along 75 deg with up to ~7 cm between them. A segment of rivers() may lie partly outside its tile.
- The orchestrator's build.sh/bmc.sh: add `cp -r src/main/resources/earth $OUT/` (or EarthCheck fails in the cloud).
- .gitignore: add `__pycache__/` (running tools/earth/*.py writes one; I moved mine to scratch) and, by E4, `data/`.
- .gitattributes: `*.bin binary` would make the fixture's binary-ness explicit (git already detects it: i/-text).
- docs/harnesses.md: I spliced EarthCheck's entry in (HarnessMap run into scratch); the docs pass regenerates the rest.

## 8. For Jerus to check on the PC
- After the pull, Maven's build copies src/main/resources/earth/ into target/classes; EarthCheck should pass in AllChecks.
- **Shipping the data (his call, wanted by E4). I recommend a GitHub release asset, not git.** Sizes (bake-stats.json):
  52,757,374 bytes in all - rivers 28.80 MB, sea 6.38, lake 6.04, lakes.small 5.75, landcover 4.76, far.land 0.57,
  far.lake 0.25, places 0.14, geology+provinces 0.06; already deflated a tile at a time, so zipping it again saves 1.3%
  (52.06 MB). (a) One file in git: over GitHub's 50 MB warning, and every re-bake adds ~53 MB to the public history for
  good, cloned by every session. (b) A file a layer in git: each under 50 MB (rivers the largest), the same history
  weight, and a reader change. (c) Git LFS: light history, but GitHub's free quota (as I know it: 1 GB stored, 1 GB a
  month fetched - check) is spent by every clone and cloud worktree, about 19 fetches a month. (d) A release asset
  (tag `earth-1`: earth-1.bin, earth-1.sha256, ATTRIBUTION.txt): outside history, versioned, no LFS quota; the repo keeps
  the identity (EarthData.EARTH_1), the tools to rebuild it and the 332 KB fixture; E4 adds a fetch step (download into
  data/, check the hash against EARTH_1, data/ git-ignored) and Steam's depot carries data/earth-1.bin with the game. A
  re-bake is a new release beside the old one, as spec-earth 6 wants (a save names its data).

## 9. Outside my files
None.
