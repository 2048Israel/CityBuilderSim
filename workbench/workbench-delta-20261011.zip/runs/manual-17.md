# Manual edition 17 (0.7.107 to 0.7.115) - the record

Source `runs/manual/index.html` (backup `index.before-07107.html`, 951,956 B) is now 994,525 B, 2,202 lines, ASCII, LF, one `&mp;`;
check.py: tags balance, every internal anchor resolves, no new entity. Edits were byte-safe Python span swaps (each span unique),
scripts e01-e16 and e13b in scratch-manual-17/py, applied once each, in order. Tree read at wt-manual17, `04d505c`.

## Sections changed, and what they say now
- **Masthead, standfirst, vitals, footer:** "Build 0.7.115 · Save format 36 · 11 October 2026"; edition 17; 317 files (~317,000
  lines), 101 buildings, 96 harnesses, a 4,002-month playtest; footer 317 files, 317,046 lines, 96 harnesses green in 717 s at 0.7.115,
  BuildMenuCheck 101/101.
- **01 The month:** step 9 prices every order on its whole cost (0.7.113); step 13 the works' consumables and own power and the
  forest cleared under what is built (0.7.107). "What moved" leads with: nothing moved from 0.7.107 to 0.7.115 (month order
  regenerated from 0.7.106's and 0.7.115's sources, identical but for line numbers) - what changed is inside statements; the old
  lead kept as "From 0.7.70 to 0.7.106". Standing rule's saved items: zoning (0.7.107), field types (0.7.110), the ground (0.7.112).
- **06 Sectors:** Mining on ExtractionSector, the shortest to copy now Materials on Sector; new h3 "Two bases, and machinery the
  chains will use" - ProcessingSector/ExtractionSector, captive use, a works' own power and consumables, and that no sector in play
  uses the machinery yet (the coming chains' iron first).
- **08 The private sector:** the hurdle formula on the order's whole cost × 1.25 since 0.7.113; new h3 "Every order on its whole
  cost" (Game.orderGate, carriesItsWholeCost; what each kind of order counts; what it did: the measured effects from I2b's notes);
  the money gate rewritten (answered: `-Dplaytest.moneyGate=borrowing`); the pipeline and jacket on the whole cost; Oil's At sea note.
- **12 Policy:** property tax row on a zoned assessment; "Setting them: five areas, one proposal" - Zoning the fifth card; RECENT
  DECISIONS carries zoning; figures on every page but Zoning's.
- **14 Borrowing:** an order's interest on its whole cost since 0.7.113.
- **15 and 25, the ensemble:** at 0.7.113, 24 of 26 green (HIGH R3 3 to 1; SHOCK 13,726 to 15,332, at least three quarters of its
  baseline; boom spell median 20 against 14; slack city 1.80 against 2.07).
- **18 Land:** field types (0.7.110: a share of each kind by TYPE_SHARES; nothing in play reads a type yet - said); one paragraph
  "Planet Earth is on its way, and no city can be founded on it yet" (E1's reader, E2's ground; no founding, no screen); new h3s
  "Zones, and the forest law" (zones by sector as a share or km2 at a share of the going price, the law's two shares, the forest
  cleared under building, buy-back at the zone's price, the zone's taxes as the sector's offsets) and "Policy › Zoning" (the page
  step by step); THE CITY line "· 3.2 zoned"; LAND FREE "free for anyone"; the planners' free-ground note answered by zones' price.
- **19 Building:** a site's gen and consumables in the declaration; the investors' land gate names the zone and "zoned for others";
  a card can pass every gate the investors decline (whole cost); the investors' words saved since 0.7.102 (the old "not saved" was
  false).
- **22 The screens:** Policy hub of five; twenty-eight interface files; ZoningScreen (0.7.109); the decision log's zoning kind (since
  0.7.107, a kind of its own since 0.7.109); sand's flags.
- **23 Saves:** the floor (OLDEST_LOADABLE_FORMAT, 0.7.108) - an old save refused cleanly, why (no conversion until publication),
  the words the load screen shows and the log's line, quoted from the code; nothing from 0.7.107 to 0.7.115 needed a bump (36
  holds); older "the last edition" sentences re-dated "an earlier edition".
- **24 The checks:** kicker to ninety-six harnesses, ninety-seven in AllChecks' list, 717 s, all green; rows updated (MoneyCheck,
  PolicyPreviewCheck, InvestCheck, OrderSearchCheck, RefineryCheck, WellCheck, WorldCheck, NewGameCheck, LandCheck, SaveFileCheck,
  ReadPathCheck, BuildingDataCheck); five new rows (ZoningCheck, ZoningViewCheck, EarthCheck, MaterialsCheck, EarthTerrainCheck).
  Counted: 88 named + "eight more" = 96, the tree's 96 *Check files exactly. Tree paragraph: 317 files, 317,046 lines, Game 16,304
  lines and 42 banners, 2,731 dials, 9,259 assertions in 97 files, Stale 119 soft after 0.7.115's pass.
- **25 Open questions:** 82 to 87 rows. "The money gate" answered and removed; four rewritten (newer save in an older build, what no
  harness looks at, planners and free ground, shells and a banned firm: Materials 488 months, 298 defaults); six new (the whole
  cost's edges; zones are amounts not places; a card that passes every gate; a refused load rebuilds the world first; the next
  format and Jerus's cities; where the Earth's file lives).

## Figures checked (against the tree at 04d505c)
- GameVersion: VERSION 0.7.115, SAVE_FORMAT 36, OLDEST_LOADABLE_FORMAT 21 (the log's "formats 21 to 36"); every entry
  0.7.107-0.7.115 read.
- Counts: 317 .java files, 317,046 lines and Game 16,304 (the code map's count, a last line without a newline counted; wc gives
  317,044 and 16,303), 96 *Check files, 97 in AllChecks.HARNESSES, 28 ui files, 42 banners in Game; dials 2,731 and assertions
  9,259 from docs/dials.md and docs/harnesses.md (regenerated at 0.7.115).
- Zoning's constants and the screen's steps (Zoning, LandManager's ZONES AND THE FOREST LAW, ZoningScreen); World.TYPE_SHARES;
  the refusal's words and log line (GameVersion, Game's load path, the load screen); "whole cost" strings (SpreadPlanner, Game,
  BuildCard, OilView) quoted as they print.
- Suite and playtest from docs-07115.md: 96/96 green in 717 s; pt07113 report 4,002 months, 566,444 people at its end.
- Measurements quoted from the batches' notes, not re-run: I2b (whole cost), Z1/Z2 (zoning), I1 (types), E1/E2 (Earth), the ensemble.

## Disagreements and corrections
- Manual 16 said only CarCheck names Automotive: BuildingDataCheck has since 0.7.90. Fixed in 24 and 25.
- Manual 16 (19) said the investors' words are not saved: they are, since 0.7.102. Fixed.
- The playtest: 4,002 months at 0.7.113-0.7.115 (manual 16 had 4,005); the vitals and footer follow the report.
- MaterialsCheck: docs/harnesses.md has 55 labels where I2's notes say 50; no count quoted.
- 0.7.106's docs/month-order.md was generated at 0.7.99 (stale at its tag); I regenerated it from 0.7.106's sources for the compare.

## Judgement calls (Jerus away)
- The Earth gets one paragraph in 18 (there is no "coming" section to put it in), plainly "nothing yet".
- The machinery sits in 06 (sectors), the whole cost in 08 (the investors' rule), zoning's model and page in 18 with pointers from
  12 and 22, the floor in 23.
- 25's open questions rewritten where a batch answered part of one; the money gate removed as answered.

## The publish
- `tools/publish.py` rebuilt the old `manual-publish.html` from `index.before-07107.html` byte for byte (old file kept as
  scratch-manual-17/manual-publish.v16.html); the new one (993,971 B) differs from the old in the same 58 hunks index.html differs
  from its backup, and is index.html's body.
- The live page read before (and again just before) the publish: version 1791677829-de1a, 951,948 B, 2,172 lines, every line read;
  its body byte-identical to the v16 publish file, so version 16. Published: **Version 17, version id 1791699898-4c79**.

## Tree copies
- My classes (wt-manual17 at 04d505c, non-ui, javac under flock): the v16 publish file regenerated the tree's docs/manual.html and
  .md byte for byte (scratch); a dry run on the new file gave no warning; after the publish, `--wrap` -> docs/manual.html (2,207
  lines) and .md (25 sections, 34 tables, 34 formulas, 27 notes, 15 steps, 2,086 lines), no warning, identical to the dry run, LF.
  Committed **e91c376** on batch/manual17 (those two files only). Not pushed.

## Not settled
- Nothing seen in the game's window; Zoning's page described from ZoningScreen and its view harness.
- Figures from notes not re-run (above). 18's Earth paragraph needs rewriting once E3's geology and a founding on the Earth land.
- Rules kept: no rm; nothing on /dev; no <(...); every java and javac under flock; only the allowed files written.
