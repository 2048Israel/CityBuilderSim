# fixC1 notes (0.7.122): the build card asks the investors' interest test. Implementer (Opus), 2026-10-11
Worktree /home/claude/git/wt-C1, branch batch/C1 from 920c08a. Scratch /home/claude/scratch-c1 (no rm; build/suite/pt/bmc/gate copied
from scratch-gate, repointed; gate.sh moves tmp aside instead of deleting it).

## 0. Progress (a line per step)
- Read brief, shared rules, docs-07115 §3, fixI2b notes; worktree clean at 920c08a.
- PROBE (scratch-c1/probe C1Probe on BuildCardCheck's town, base build): 29 market buildings pay; 7 of them do not carry their
  interest on the whole cost - 3 landlords' homes (the mortgage lender's test decides them) and Industrial Bakery ($97.6k a month
  against a bar of $154.7k), Meat Works, Shared Services Centre, Platform Well; the first two showed no gate on the card.
- b0ba673: Game.interestTest() + InterestTest (carriesItsWholeCost() answers from it), BuildCard INTEREST gate, BuildCardCheck 11,
  BuildScreen.interestWords(), SectorScreen (i)s, heads, grid column, so-line, "passes every gate". Both builds silent; BCC green.
- 496b822: GameVersion 0.7.122. Words probe (scratch-c1/probe ui/C1Words, words.txt): 661 measured, 0 over. Targeted harnesses
  (BuildCard, SectorStatement, ZoningView, ReadPath, Invest, Well, Stale) green; tools.Stale 0 firm, 443 soft. Gate started.
- Gate (scratch-c1/gate.log, 08:29:57-08:47:39) on 496b822: green - 5. Final commit 496b822; tree clean.

## 1. What I built
- **Game.interestTest() and InterestTest** (new, beside carriesItsWholeCost()): consider()'s brake for an order with its figures -
  earns, cost, `on` (orderGate().testedOn(), the whole cost), `rate` (judged(): the loan's at its leverage or a bond's blended),
  `real` (realTestRate()), a month's `interest` (on x real / 12, servicesItsOwnDebt()'s own expression), `banned`, `carries`;
  needs() = interest x PROFIT_OVER_INTEREST. carriesItsWholeCost() keeps its early `earns > 0` and answers from it (same arithmetic,
  same boolean; judged() books nothing, so asking it under a ban too changes nothing). sliceFor()'s javadoc names BuildCardCheck 11.
- **BuildCard**: GateKind.INTEREST (last); interestGate() through game.interestTest(owner, estimate, getCostOf(t, 1)); asksInterest()
  (not a landlord's home - Game.buysOnMortgage(), the lender's test); Gate gains `test` (a 5-arg constructor keeps every other gate);
  banWords() under a ban ("borrowing ban, N more months - it would need credit", consider()'s words, WordKind CREDIT); gate() returns
  it after LOSS; appraise() marks it (NONE for a home; a loss fails it too, behind LOSS). THE INVESTORS' LINE banner's new paragraph.
- **ui/BuildScreen**: gateWords() INTEREST -> interestWords() (static): "earns $98k a month, under 1.25× its interest on its whole
  cost ($124k a month at 5.03%)"; a loss "would lose $X a month, so not 1.25× ..."; a ban its why. Shown on the card's "this one:",
  the Investors page's first gate, the every-gate cross's tooltip and its "So:".
- **ui/SectorScreen**: EVERY_GATE_INFO (the interest gate, whoever pays; a home asked the lender's test); ITS BUILDINGS' (i);
  GATE_HEADS + "interest" and a sixth GATE_MARK column (grid 1,042 -> 1,098 px with its box, page 1,234); gateShort(GateMark)
  ("it would not carry its interest" / "a borrowing ban"); soWords(): INTEREST alone "...- at today's rates it would not build
  however the other gates stood."; a loss's INTEREST cross left unsaid; "ground alone would not build it" for land + interest too;
  "passes all five" -> "passes every gate"; gateIcon INTEREST -> Icons.BANK.
- **BuildCardCheck 11** (header item 11) and 6's last assertion. **GameVersion** 0.7.122 and its entry.

## 2. Departures, with reasons
1. **Game.interestTest()** (Game is outside my files, 9.): the brief's door returns a boolean, and the words need the interest and the
   rate. Recomputing them in the card (projectRate(), the bond's blend) would be the recomputation the brief forbids and could
   disagree with the verdict where a bond is cheaper; one method gives both, and carriesItsWholeCost() answers from it.
2. **No new GateKind for the ban**: carriesItsWholeCost() says no under a ban, so the INTEREST gate fails with the ban's words
   (a seventh column would cost 56 px for what consider() files as the same refusal).

## 3. Premises changed (before -> after) and the new assertions
- **BuildCardCheck 6**, last: "a market building that passes every gate has no this one:" - `passes` gains the new gate
  (buysOnMortgage() or carriesItsWholeCost()); label says so. 21 pass (the town).
- **BuildCardCheck 11** (new, 17 lines): the town's 56 market buildings asked, each INTEREST mark == sliceFor(order of one, till +
  abroad, estimate) (56 of 56; 4 earn over nothing and under their interest: Industrial Bakery, Shared Services Centre, Meat Works,
  Platform Well); the 3 homes NONE; a Bakery from a till of twice its cost at prime + 2 x the rate its earnings carry + expected
  inflation (5.07% -> 31.10%): same estimate, fails INTEREST, a == earns, b == needs() == interest x PROFIT_OVER_INTEREST, interest
  to the bit cost x realTestRate(projectRate(bakers, 0)) / 12, the rate to the bit projectRate(bakers, 0), appraise's only failure
  and first; sliceFor refuses; at today's prime passes and sliceFor builds; under a ban (till half its cost) the ban's words, CREDIT,
  sliceFor refuses; till/prime/record put back; a spur's loss fails INTEREST behind LOSS.
- No other harness premise moved. SectorStatementCheck 9's `has` array checks the first five gates' NONE (the sixth unchecked; green).

## 4. Trace movement
- None: the playtest is pt07116's byte for byte (8 of 8). The card is advice; no month path calls BuildCard's gates, and
  carriesItsWholeCost() (Oil's planner) keeps its arithmetic and its boolean.

## 5. The gate, and the final commit
- gate.sh (scratch-gate's, repointed; tmp moved aside, never deleted) on 496b822: model and UI builds silent (0 bytes each);
  **the suite 97 run, 97 passed** (HealthCheck and MapCheck green this run; 823 s); **BuildMenuCheck PASS, 101 of 101**;
  tools.Stale **0 firm, 443 soft**; playtest **8 of 8 identical to pt07116**, findings "Nothing. Every month passed the audit and
  every reload matched."; no w/crlf outside .bat. **Final commit 496b822** on batch/C1 (b0ba673, 496b822).
- Words probe (scratch-c1/probe/src/ham/citybuildersim/ui/C1Words.java, words.txt; Java2D, IBM Plex at each slot's size, 1,389 x
  868, the page 1,234): **661 measured, 0 over**; tightest single line 71% (the "interest" head, 31.2 of 44 px). The town (34 failing
  interest gates), the town at a 31% prime (38), ten years on (44), and the widest figures ($999.9T, 99.99%) and a ban: the card's
  "this one:" at most 2 lines alone (3 with the month's word) in 259 px; the Investors page's first gate 1 line in 501 px; the
  cross's tooltip at most 2 lines in TIP_WIDTH; "So:" 1 line in 1,046 px; the grid 1,098 of 1,234 px; EVERY_GATE_INFO 11 lines and
  ITS BUILDINGS 7 in the 360 px popover; "passes every gate" 72 of 141 px.
## 6. ★ calls
- (No choice in place of what Jerus asked: the card asks consider()'s test, as the brief says.)
- ★1 The door: Game.interestTest() (outside my files), whose `carries` is carriesItsWholeCost()'s answer, so the words' figures and
  the verdict are one computation. Flip: the card could call carriesItsWholeCost() alone, but then its words would have no rate.
- ★2 The till the card counts is carriesItsWholeCost()'s: the sector's cash and what it holds abroad - not the owners' offering
  consider() makes first (Equity.raiseFor()): what the owners are asked is not what they take, and on the whole cost the till moves
  only the rate's leverage and whether a bond is asked. BuildCardCheck 11 holds the card to sliceFor() on that till (56 of 56).
- ★3 A landlord's home has no INTEREST gate (a dash): consider() asks it the mortgage lender's test instead (I2b's ★2). The card
  does not ask the lender's test - see 7.
- ★4 A loss fails INTEREST too in appraise() (the model's answer: earns <= 0 never carries), behind LOSS, which stays first; the
  "So:" line leaves it unsaid (the cross shows it). gate() never returns it for a loss.
- ★5 A borrowing ban fails INTEREST in consider()'s words (carriesItsWholeCost() says no), not a seventh gate.
- ★6 The words quote the real rate the interest is struck at (realTestRate()), so the interest and the rate make each other; the
  Investors rules chip already says the rate is "this sector's own rate less the inflation people expect". In the town they are
  equal (expected inflation 0).
- ★7 Names: GateKind.INTEREST, the head "interest", Icons.BANK; "passes every gate" for "passes all five" (no count to go stale).
- ★8 The card asks an order of one, as its quote and estimate are of one.

## 7. For the next batch
- The landlords' card could ask the mortgage lender's test the same way (a door on Game around Mortgage.decide() with its NOI and
  payment), so a home's card says when the lender would refuse it.
- Docs pass: CLAUDE.md's BuildCard row ("the first gate it fails ... every gate"), docs/map, harnesses.md (BuildCardCheck 11),
  dials.md; SectorStatementCheck 9's `has` array checks the first five gates' NONE - the sixth (a home's) could be added.
- In the town as played, 4 of 56 market buildings earn over nothing but under their interest (2 showed no gate before: Industrial
  Bakery, Meat Works); ten years on, 44 interest gates fail across the catalogue (most behind a loss).

## 8. For Jerus to check on the PC
1. Sectors › a business › Investors: EVERY BUILDING AT EVERY GATE's "interest" column (six marks now) and a cross's tooltip.
2. A Build card for a building that earns but not its interest: "this one: earns $98k a month, under 1.25× its interest on its
   whole cost ($124k a month at 5.03%)".
3. The Investors page's list: "passes every gate".

## 9. Outside my files
- Game.java: InterestTest + interestTest() (new, after carriesItsWholeCost()), carriesItsWholeCost() answering from it (its javadoc
  one clause), sliceFor()'s javadoc naming BuildCardCheck 11. Behaviour unchanged (the playtest).
