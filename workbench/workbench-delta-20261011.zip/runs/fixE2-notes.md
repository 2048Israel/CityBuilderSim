# E2, the Earth's ground (0.7.115): notes

Worktree /home/claude/git/wt-E2, branch batch/E2, from ce5ec19. Scratch /home/claude/scratch-e2 (build.sh, suite.sh,
pt.sh, bmc.sh, gate.sh: copies of scratch-gate's, pointed here; build.sh and bmc.sh copy src/main/resources/earth/).

Progress (a line per step, for a restart):
- 00:26 base build silent; 00:37-00:50 baseline suite: 95 run, 95 passed (684 s); generated 5B screen 25.9 ms.
- 00:50 EarthTerrain, World.Key, the callers, EarthTerrainCheck written; builds silent; first runs (etc1/etc2.txt).
- 00:57 coast rule settled (bilinear shares, unranked coast noise: the study's figures reproduced, section 6 star 1);
  WIDEST_RIVER_M measured 40,650; land check moved to the square's own land; lines drawn alone (draw()).
- 01:16 waiting on the JVM lock (I2b's inflation ensemble); iter.sh queued (build, square probe, EarthTerrainCheck).
- 01:37 EarthTerrainCheck all green with the full file named (etc3.txt); square probe: lines drawn alone cut the Earth
  5B square's terrain from 5.9 s (205k whole tiles) to 1.9 s (206k draws, ~9 us a line). ef6c8a5 committed (WIP).
- 01:40 probe counters removed; gate.sh started (gate.log), 01:49-02:05 under the lock: green. Final commit 32ea094.
- 01:47 RULE SLIP: one wait loop carried '2>/dev/null' inside a bash -c (grep's stderr discarded); nothing else
  touched /dev, and it was not repeated.

## 1. What I built
- **World.Key** (kind GENERATED|EARTH, seed, lat, lon, data identity) and `World.of(Key)`: a generated key's world is
  `World.of(seed)`, the same object; Earth worlds kept apart (KEPT_EARTH, WORLDS_KEPT). `new World(Key)`, `key()`,
  `isEarth()`. On Earth: build() = EarthTerrain's cells pass + snap; seaTheta() = SEA_LEVEL 0.5; river() an empty walk
  with its lake a point at the site (so CityLand.found()'s fresh water is the nearest real water); depthAt() and
  shelfTheta() throw (no heights); searchSites() throws (old saves' conversion only); terrain methods delegate; the
  deposits' cell land/forest come from the cells pass and their sea redraws from EarthTerrain.seaAt(). Generated
  arithmetic untouched (each branch keeps the old expression verbatim).
- **EarthTerrain** (new), spec-earth 3: see its header. Tile = draw() of a sub-rectangle (a line draws its 32 plots
  and their ring alone, byte for byte the tile's). Region at stride 1 = kept tiles; wider = per pixel from the shares
  (15", or the 4' far layers from FAR_STRIDE 256), octaves wider than the pixel, water under WATER_STRIDE 16, no beach.
  Cells pass: 16 points a cell (blended from the cell's corners) of far.land + far.lake (land) and land cover (forest).
  Snap: annuli of one plot from (SIDE/2, SIDE/2), nearest first, test 1 on the drawn ground (kept tiles), to 167 plots.
  Data by identity: `EarthTerrain.use(EarthData)` registers a reader; else `EarthData.locate()` if its identity matches.
- **EarthTerrainCheck** (new, ★), nine sections; AllChecks registry.

## 2. Departures, with reasons
- (see star 1) the coast's noise is unranked; fresh, forest and blobs are ranked.
- No heights on Earth: its sea has no depth in E2 (depthAt() refuses, loudly) - E4 must settle it (star 7).

## 3. Premises changed and new assertions
No premise moved; WorldCheck and MapCheck untouched. New: EarthTerrainCheck 1-9 (its header lists what each proves).

## 4. Trace movement
None: the default playtest's 8 traces are pt07106's byte for byte (a generated key reaches World.of(seed)).

## 5. The gate (scratch-e2/gate.sh, gate.log, 01:49-02:05) - final commit 32ea094
- Both builds silent (model 0 bytes, ui 0 bytes). AllChecks: 96 run, 96 passed (HealthCheck too; MapCheck OK first
  time, 31.0 s; EarthTerrainCheck 17.2 s with the full file named, EarthCheck 1.7 s). BuildMenuCheck PASS, 101 of 101.
  tools.Stale 0 firm (436 soft: 317 map-older, 2 no-map-page for the new classes - the docs pass's Maps run). No
  w/crlf outside .bat. The only change after the gate: one javadoc line's figure in EarthTerrain.cellsPass().
- Earth figures against the spec (EarthTerrainCheck): sea per 15" cell, mean |diff| 1.34 / 0.38 / 0.00 points
  (Rotterdam / Perth / Paris; bound 2; study 1.49 / 0.39); window sea 10.42% vs data 11.28% (study 11.01 vs 11.88),
  Perth 47.99 vs 48.07; forest of the dry 15.0/35.9/39.0% vs data 15.1/36.1/38.9%. Identical twice: 256 tiles, lines,
  plots, a region. Second seed: 20.1 / 19.5 / 40.0% of plots change (bound 10%; study 15.7-28.6), water within
  0.139 / 0.012 / 0.001 points (bound 0.5; study 0.1). A tile 0.081 / 0.049 / 0.057 ms (bound 0.3; study 0.09-0.20).
  Fiji: cells beside 180 degrees 0.32 west, 0.40 east (whole window 0.36). Rivers: 1,415 of 1,415 vertices on fresh
  plots; small lakes 92 of 92 points fresh, 24 lakes clear of other water draw +2.9% of their area; 6,679 beach plots
  all beside the sea in LC_BEACH cells (Perth 4,800). Snap: Rotterdam 212 m (152 plots tested; study 510 m), Perth
  30 m, Paris 42 m (study 0, 0); founding land holds its dry ground, fresh 0.504 / 0.119 / 0.500 km2 (target 0.493).
  Earth screen 41.9-51.8 ms (bound 80; derived 42-64), its 5B square laid in 6.1 s (generated 1.0-2.7 s). Full file:
  cells pass 396 ms cold, 390 warm (bound 1 s; study 370-450); land -0.017% against the square's own (138.07 M km2,
  92.7% of the globe's 148.91 M); widest river 40,650 m.

## 6. Star calls
- ★0 Nothing of what Jerus asked was replaced (his eight answers: Earth for new cities only - unreachable until E4;
  real river courses; WorldCover coasts; no guaranteed iron; no elevation).
- ★1 THE COAST'S NOISE IS UNRANKED (spec 3 says "sea where the interpolated share plus 1.0 x the coast noise (about its
  mean) reaches 0.5"; the ranking sentence names fresh and forest). Ranked, the per-cell sea error was 2.21 points at
  Rotterdam (FAILS the 2-point bound), 0.77 Perth; nearest-cell shares ranked 1.74/0.56. Bilinear + unranked gives
  1.34 / 0.38 against the study's 1.49 / 0.39, and Rotterdam's window 10.42% sea for the data's 11.28% against the
  study's 11.01 for 11.88: the prototype's rule, reproduced. Fresh water, forest and small-lake blobs are ranked.
- ★2 One new harness, EarthTerrainCheck, instead of sections in WorldCheck and MapCheck: WorldCheck's generated sections
  stay byte-untouched, MapCheck (3,124 lines, 30 s) is not lengthened; the Earth screen uses MapCheck's own constants
  (SCREEN_ACROSS/DOWN, SCREEN_MS, PX, WARM/TIMED_ROUNDS, TIMES[1], JERUS_COUNTS, JERUS_FILL, groundKm2()).
- ★3 The lattice: 10 x 10 points 4 plots apart on the world's own grid (x0 - 4 + 4i), read through the tile's blend,
  so neighbouring tiles read shared points alike; shares bilinear between the data's cell centres.
- ★4 Small lakes: blob where (d/r)^2 + BLOB_FRAY x (rank - 0.5) < 1, BLOB_FRAY 1.0 - area pi r^2 in expectation;
  measured +2.9% over the windows' 24 lakes clear of other water.
- ★5 Beach: a dry plot with SALT among its 8 neighbours and LC_BEACH in its 2' cell.
- ★6 Snap: annuli of one plot (k <= d < k+1), nearest first then north, west; test 1 on the drawn ground; out to
  SNAP_PLOTS 167 (5 km, the card's reach), else the world throws (E4 refuses such a spot).
- ★7 No heights on Earth: depthAt()/shelfTheta() throw UnsupportedOperationException rather than invent a depth;
  seaTheta() returns SEA_LEVEL 0.5. E4 must decide the sea's depth before an Earth city holds oil at sea.
- ★8 Earth's river(): no walk, the lake a point at the site, so CityLand.found()'s FOUNDING_FRESH_KM2 is taken from
  the real water nearest the site (Rotterdam 0.504, Paris 0.500 km2; Perth 0.119, all there is within 3.2 km).
- ★9 Data by identity: World.Key.data is EarthData.identity(); EarthTerrain.use() registers a reader (the fixture's
  identity is its own sha, not EARTH_1); an unregistered identity opens EarthData.locate()'s file if it matches.
- ★10 Regions: stride 1 = kept tiles; wider = per-pixel point rule; FAR_STRIDE 256 to the 4' layers; WATER_STRIDE 16
  under which rivers/small lakes are drawn; no beach and no forest dither at a stride (E5's far view).
- ★11 Cells pass: 4 x 4 points a cell blended from its corners (4 inverses a cell); its land = far.land + far.lake
  (the generated world's land holds its lakes), forest = dry x land cover's level. Measured against every 4' cell of
  the globe projected: -0.02%.
- ★12 WATER_PAD_DEG 0.25 (27.8 km): the widest river in earth-1 is 40,650 m wide (measured), 20.3 km a side.
- ★13 Deposits on Earth (E2 only): today's densities on the cells pass's land, redrawn off the sea by seaAt() (the
  coast rule at the point); E3 brings the geology weights.

## 7. For the next batch (E3, E4, E5)
- Saves (E4): nothing saves a key yet - Founding.getWorldKey() is not in DataSave, the CityMap sidecar keeps the seed,
  CityLand.restore(long) is generated. An Earth city saved now would reload on the generated world: E4's format
  (worldKind, earthLat/Lon, earthData) and OLDEST_LOADABLE_FORMAT. Founding.withWorldKey() is the door to found one.
- Callers left on the seed (not the brief's nine; no Earth world reaches them in E2): ui/MapView passes
  shownMap.seed() to MapTiles.nodeTerrain() - use nodeTerrain(shownMap.worldKey(), ...); OilView reads
  World.of(l.seed()) - use l.key(). LandConversion.convert/convertLanes and GridConversion.fromLanes read an older
  save's seed, a generated world by definition.
- The sea's depth (E4): depthAt()/shelfTheta() throw on Earth; LandManager.atSea()/seaFields(), OilView and Oil's
  platform rule call depthAt() - an Earth city with oil fields at sea will throw until E4 decides a depth (GEBCO is not
  shipped; Q8). seaTheta() is 0.5 on Earth (stored as worldSeaTheta).
- E3: deposits on Earth now use today's densities on the cells pass's land (World.landKm2()/totalOf() branch on
  earth) and seaAt() for the redraws - put w x Z there. EarthTerrain.cellLand() is the share of 16 points' far.land +
  far.lake; cellForest() dry x forest level.
- E5: regionTerrain() at a stride >= WATER_STRIDE (16) draws no rivers or small lakes, no beach, undithered forest;
  FAR_STRIDE (256) and up reads far.land/far.lake. nodeTerrain(World.Key) exists.
- Performance: an Earth line is drawn alone (~9 us); a whole 5B square city laid at once takes ~6 s against ~1-2.7 s
  generated (its runs). DISTRICTS_KEPT 256 / DATA_TILES_KEPT 64 / TILES_KEPT 1024 are first guesses.
- EarthData.DATA_FILE: EarthTerrain.source() opens it (or -Dcbs.earth) when a key names EARTH_1 and nothing was
  registered; E4 ships the file. The fixture's identity is its own sha (EarthTerrain.use() returns it).
- Docs pass: EarthProj's and EarthData's headers still say nothing in the game reads them; docs/map pages and
  docs/harnesses.md for EarthTerrain/EarthTerrainCheck (Maps, HarnessMap).

## 8. For Jerus to check on the PC
- After the pull, AllChecks runs EarthTerrainCheck on the fixture (and section 9 if data/earth-1.bin is there).
- Nothing in play changes: no Earth city can be founded until E4.

## 9. Outside my files
- AllChecks.java: one name added to HARNESSES ("EarthTerrainCheck"), the new harness's registration.
