# Brief: I3, iron's prices and the split. 0.7.116. 2026-10-11

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## What this is
The third batch of the materials chains and **the first that changes the game** (★, it moves the playtest). Read:
- the spec, `/home/claude/runs/spec-materials.md`: §1, §2.1–§2.3, §2.6b, §3 (IronSplit), §4 and §5's I3 row;
- the study, `/home/claude/runs/materials-chains-research.md`: §1.2, §2.1–§2.6 and §10 Q4, Q5, Q6, A, C and D.

Jerus decided every question these rest on (2026-10-08):
- Q4: split scrap from ore.
- Q5: the Iron Mine at 20,000 t a month with the same 60 posts, at D$ 45M.
- Q6/6b: steel to the world's price, D$ 650 / 470, with fabricated steel and machinery moved by the steel in them.
- A: every order tested on its whole cost.
- C: cars, vans and trains move with the steel in them.
- D: iron in the ground stays at US$ 0.40 a tonne.
- Q2: rename Mining → **Iron Mining** and Heavy Industry → **Iron & Steel**, keeping the saved keys.

**Build (the spec's I3 row):**
- **Goods:**
  - `IRON` relabelled "Iron ore", .115/.085, freight .01125.
  - **SCRAP**, new: the study's 410/300; flow; BULK.
  - `STEEL` .650/.470 (.0675).
  - `FABRICATED_STEEL` –/1.545 (.3398).
  - `MACHINERY` 13.4/8.1 (1.98).
  - CARS 41.3125/33.3125 (3.0), VANS 68.135, ROLLING_STOCK 2,302.2.
  - Spec §2.3 has each figure and its reason.
- **Buildings:**
  - id 11, Steel Foundry → **Electric Arc Furnace**: 1,320 t SCRAP → 1,200 t STEEL.
  - id 12, Steel Mini-Mill: 6,600 SCRAP → 6,000.
  - id 14, Iron Mine: 20,000 t; 60,000 L DIESEL; 600 kW; water 20; cash, points and materials × 4.632 to D$ 45M; roadLoad 3,360; posts unchanged.
  - Consumables: the study's runs (§2.4, D$ 469k a month for the Iron Mine) less wages, power, water and diesel, through I2's `consumables` field.
- **Sectors:**
  - the two labels;
  - `HeavyIndustry` onto I2's `ProcessingSector`, with SpreadPlanner choosing what it builds;
  - Mining's extraction on the whole-cost MONEY gate (spec §2.6b).
- **Iron in the ground: D, exactly.** US$ 0.40 a tonne in the ground: `inGroundShare` × IRON's export price, so 1/212.5 at .085.
  - The study's reference, "the founding field's US$ 180M", is gone since W1.
  - Check it instead on LandCheck 19's fixture field: world 35's nearest dry field, 27 sites, 463 Mt, US$ 185M at $0.40.
  - I1 measured a mean new field at 25.2 sites × 15 Mt = 378 Mt before richness, US$ 151M (`runs/fixI1-notes.md` §7).
- **Names to ids:** every lookup by "Steel Foundry" or "Iron Mine", in 21 harnesses, `LongPlaytest` and the test player's foundry rule, goes by id 11, 12 or 14 (spec §4).

**Harnesses (spec §4):**
- **MiningCheck:** the arc furnace margin is 5–15% of sales on imported scrap and 20–35% on local scrap; ore .115/.085; the Iron Mine at 20,000 t.
- **ManufacturingCheck:** the new prices, with margins in D$ unchanged to the cent.
- **CarCheck, VanCheck, RailCheck:** the vehicles' prices, Automotive's margins unchanged to the cent.
- **TradeCostCheck, ForeignCheck:** their goods.
- **BuildingDataCheck, BuildCardCheck:** the renamed groups.
- **MaterialsCheck, a new section after I2's eight** (I2's sections 1-8 are the value split, the gate, captive use, power, consumables, the plan, idle-then-shed and Mining; the spec's own section numbers no longer apply): the study's four cases (A–D, §2.5) for the Iron Mine (2.7/2.7/4.1/4.1%), the Electric Arc Furnace (−0.5/−0.1/0.7/0.2%) and the Steel Mini-Mill (−0.5/0.1/1.0/0.4%), at parity, to the study's rounding. Build them from the game's own figures through I2's `SpreadPlanner.caseEarns()`. **The study's `balance.py` is gone** (the workspace restarted on 2026-10-09), so where `caseEarns()` and the study's §1.2/§2.5 arithmetic differ, say how. If a case misses, find why before touching a figure.

## The old save: the rule, not IronSplit
The spec's `IronSplit.convert()` (spec §3) is conversion code for an older save. The standing rule now forbids it (Jerus, 2026-10-10: "old saves do not matter, only once we publish to old saves matter"; CLAUDE.md; `brief-shared-git.md`). An older save's `IRON` maps hold scrap and ore together, so it would load wrongly.

**So: bump `SAVE_FORMAT` (36 → 37) and raise `GameVersion.OLDEST_LOADABLE_FORMAT` to 37 in the same batch. Write no IronSplit.**
- ★ Only if you find an older save loads *rightly* without conversion may you skip the bump; say why in plain words.
- **This stops every save Jerus has from loading on this build.** P7's refusal names the build that saved each city, and that build still opens it. Say so plainly in your reply and in notes §8.
- **Probe on cities founded and played on your own build.** The five probe cities are older saves.
- A harness that loads a save older than 37 through the load path now sees it refused. That is the rule changing the premise: list each one, before and after.
- Harnesses that test conversion functions directly (GridConversion, FuelSplit, LandConversion) stay as they are.
- In place of the spec's IronSplit section, a new MaterialsCheck section (or SaveFileCheck's): a format-36 save is refused with P7's words and its file is untouched.

## The playtest (★)
**Probe first** (rule 1): the goods' prices and id 14's figures alone, one playtest run. The spec expects these moves:
- the first mine's ore (8× and cheaper);
- the first car (6% cheaper);
- then the mills: the arc furnaces shed by distress (−.12 to −.29% on imported scrap), and steel imported at 650.

Then:
- **Re-baseline** `pt07116` in your scratch, explaining each trace's moves by their causes.
- **Run the ensemble** against `runs/ensemble/out/07113/summary.json` (I2b's, the newest).
- **Guardrails:** the money audit closes every month; the city does not stall or collapse; jobs and the trade balance are said in plain figures (spec §6's "Measure first" 2).
- If a variant is needed, decide and keep going (rule 2).

## What changed since the spec
- **I1 (0.7.110):** `runs/fixI1-notes.md` §1 and §7: types, `site`, `fits()` (I5's, not yours).
- **I2 (0.7.112):** `runs/fixI2-notes.md` (§1 and §7 above all): `ProcessingSector`, `ExtractionSector` (Mining is on it, with today's money test, ★I2-10), `consumables`, `gen`, MaterialsCheck. It leaves you:
  - Heavy Industry onto `ProcessingSector`;
  - the whole-cost money gate added to `ExtractionSector.plan()`;
  - the new rows held to `SpreadPlanner.caseEarns()` (the four cases, pure).

  `-Dplaytest.moneyGate=borrowing` is the counterfactual switch for a probe.
- **I2b (0.7.113):** `runs/fixI2b-notes.md`: every order through `Game.consider()` is tested on its whole cost (`Game.orderGate()`), Mining's included; the playtest moved (pt07113). Its ★2, the landlords' homes left on the lender's test, waits on Jerus.
- **E2 (0.7.115), the Earth's ground:** `World.Key`; generated worlds unchanged. Nothing for you.
- **P2/P2b:** automatic building and the advice. Leave them alone, but if the advice names "Steel Foundry" or "Iron Mine" by name, move it to the id.
- **Versions:** 0.7.114 was skipped (0.7.115 shipped first). Your version is 0.7.116.

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| I3 | 0.7.116 | named in the launch prompt | `/home/claude/scratch-i3` | moves from `/home/claude/scratch-ui1/orch-gate/pt07113/`: re-baseline `pt07116` |

**Your files:**
- `Good`;
- `buildings.json` and the twin (`BuildingManager`) for ids 11, 12 and 14;
- `Resource`;
- `sectors/Mining`, `sectors/HeavyIndustry`, `Sectors`' labels;
- `GameVersion` (VERSION, SAVE_FORMAT, OLDEST_LOADABLE_FORMAT);
- the harnesses named above and those that look things up by name;
- `LongPlaytest`;
- `CLAUDE.md`/`README.md` counts and rows.

Keep out of `Game`'s THE LARGEST SLICE and `BusinessInvestment`'s order test (I2b's).

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** The full suite green (the count at your base); BuildMenuCheck 101.

Reply with:
- a short summary;
- the probe and the playtest's moves, explained;
- the ensemble;
- the four cases against the study's;
- the old-save decision (plainly: whether Jerus's saves stop loading);
- the gate and your final commit;
- your ★ calls.
