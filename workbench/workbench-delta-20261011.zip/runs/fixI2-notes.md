# fixI2 notes (0.7.112): the shared machinery of the materials chains
Worktree /home/claude/git/wt-I2, branch batch/I2 from 39eea4e. Scratch /home/claude/scratch-i2 (no rm, no /dev).

## 0. Progress (a line per step)
- Read brief, shared rules, spec 1/2.1/2.5-2.8/4/5, study 1.2/1.3/1.6, P6 and I1 notes. Worktree clean at 39eea4e.
- PROBE (rule 1): SpreadPlanner's default gate switched to ON_ITS_WHOLE_COST, built, playtest pt-probe: 8 of 8 traces
  byte-identical to scratch-ui1/orch-gate/pt07106 (the report differs in the gate's name and the run time only).
- Rough switch, targeted: RefineryCheck 11b (the brief's premise) and 14 (its fixture's lever) red; OilCheck, OilViewCheck,
  PortCheck, RefineryViewCheck, BuildCardCheck, MiningCheck green.
- 6d92694 model; pt-model 8/8 identical. f5392f9 harnesses (MaterialsCheck green first run). 29906d9 version, counts.
- Gate run (gate.sh) - see 5. Slip: a watch loop of mine had grep's stderr to /dev/null for ~1 minute (a write, no read);
  stopped at once and re-armed writing to scratch-i2/err.txt.

## 1. What I built
- **SpreadPlanner** (A): DEFAULT_MONEY_GATE = ON_ITS_WHOLE_COST (setMoneyGate(null) puts it back); ON_ITS_BORROWING kept,
  named "the rule to 0.7.111". outValue(m, imported, u) / inValue(m, exported, u) (pure; the market-tally overloads; the
  Values interface and values(markets)): made here, net import price up to the month's imports, net export past it; used
  here the mirror; a non-number price reads the local price (cityValue()'s fallback), so the first unit = cityValue() to
  the bit. ownCosts(t, rate, factor, tariff) = consumables x rate x factor - gen x tariff. Case {A,B,C,D} and caseEarns()
  (pure four-case reading at nameplate, for I3's rows). idleKinds(), restoreIdle(extras) (kinds read off the keys).
- **sectors/ProcessingSector** (abstract): plan() - one order in flight; every works that makes something (weighs())
  estimated: gross() (makes at outValue, uses at inValue, at the rate) - running - standing - ownCosts; judge() over
  FEED (feedRefusal(), none by default)/LAND/STAFF/MONEY; best() ordered, else the land case, else the best-fed refusal's
  words. estimatedMonthlyProfit() = the estimate (what Game.consider() tests). captive() = made and used. Idle, then
  shed: endOfMonth() counts each kind standing idle when lastEarns() < 0 (the last one standing: makes at inValue, uses
  at outValue); mayRetire() the idle-long kinds only while one is (else all, the distress rule's);
  retirementDemandAndCapacity() {0, idle kinds' buildings}; unitsOf() 1 a works; extras idleMonths.<template id>.
- **sectors/ExtractionSector** (abstract; resource()): Mining's plan, groundLimit()/dig(), potential, the retirement once
  worked out and the page, generic on the resource (getSites/committedOn/getRemaining/extract). **Mining** extends it:
  constructor + dig() = LandManager.extractIron() (keeps the month's tally). Same arithmetic as before, same words.
- **Captive use** (Sector): captive(g) false; captiveUnits(g); bid(), getPlannedOutput(), getExportBoundOutput(),
  produceFlow(), produceStock(), inputCostAtRate() net of it; Output.captive. Every path is unchanged when not captive.
- **The works' own power**: BuildingsTemplate gen (setGen/getGen, powerBought(), powerSold(): the whole draw exactly when
  gen is 0); Sector powerSurplus (setPowerSurplus, getPowerSoldValue); Statement.powerSold = surplus x tariff, in
  revenue (not in the sales), saved (SectorState); EconomyManager sets each sector's net draw and surplus;
  ServicesManager: grid consumption and billed draw from the net draws, setWorksPower(sum of powerSold);
  UtilitiesHandler: production += worksPower (unscaled), setBilledRevenue(e, w, powerBought) from the statements,
  electricity income less getPowerBought(). MoneyAudit notes "chk + sectors PowerSold" and "chk - utilities PowerBought".
- **Consumables**: BuildingsTemplate consumables; Sector.CONSUMABLES, getConsumablesAtNameplate(), consumablesBill() (x
  operating rate x markets' exchange rate), buyConsumables() -> bookImportedService("Consumables") (imports, TRADE);
  Markets calls it for every sector after runFleet. Catalog reads "gen" and "consumables"; buildings.json readme lines.
- Refining: the money-gate paragraph only. LongPlaytest: -Dplaytest.moneyGate=borrowing is now the counterfactual.

## 2. Departures, with reasons
1. outValue/inValue read the market's tally, not the sum of the sectors' unitsImported/Exported (★I2-1).
2. The audit's power pair is noted, not declared as DOMESTIC in/out lines (★I2-2).
3. Shedding reads the last standing works' earnings, not the candidate's (★I2-6).
4. RefineryCheck 14's fixture moved too (★I2-9) - the brief named 11b as the only premise.
5. docs/harnesses.md not hand-edited: it is tools.Maps' output, left to the docs pass with the maps.

## 3. Premises changed (before -> after) and the new assertions
- **RefineryCheck 11b**: "the rule in force (ON_ITS_BORROWING) ... with the order's cost in the till it asks nothing but
  that the order earn something" -> "the rule in force (ON_ITS_WHOLE_COST, DEFAULT_MONEY_GATE) ... and with the order's
  cost in the till the same hurdle, to the bit: the whole cost is tested whoever pays"; ON_ITS_BORROWING asserted as the
  named history; null puts the default back.
- **RefineryCheck 14** (fixture only): "...the cost of any unit in their till (0.7.103), orders within two years" ->
  "...and their planner on the rule to 0.7.111 (ON_ITS_BORROWING; on the whole cost no unit here pays, 11b)": its best
  unit, a Small Cracking Unit, earns $0.4k a month on $30.2M against a $161k hurdle (measured). The section is the order
  path (values, best, consider()'s estimate, the ground), not the gate; its lever was the old rule's cash.
- New **MaterialsCheck** (8 sections, 50 assertions): 1 outValue/inValue split to the bit; 2 the whole-cost gate refuses a
  cash-rich sector's case A that ON_ITS_BORROWING passed (fixture: steel's export price set so case A earns half the
  hurdle), the four cases by hand, ownCosts; 3 captive: flow and stock, min(made, needed), bid net, no sale or purchase
  booked, no sector in the game captive; 4 power: net bill, powerSold in revenue, grid consumption/production, the
  utility pays the statements' figure, audit closes, crosses a save; 5 consumables: rate x factor, imports, TRADE, audit;
  6 the plan's estimate and lastEarns to the bit, FEED refusal, consider() reads it; 7 idle then shed (6 months, {0, 4},
  planRetirement sells 1, extras by id, a working month clears); 8 Mining on the base (counts, plan, dig = iron's tally,
  spare once worked out).
- **MoneyCheck 4**: bakeries with gen and consumables: powerSold = utility's PowerBought, consumables in Industry's
  imports, the audit closes 36 months and names both. **BuildingDataCheck**: gen and consumables json = twin; none has
  either; every building buys its whole draw.

## 4. Trace movement: none
- pt-probe (the switch alone), pt-model (the whole model) and the gate's: 8/8 byte-identical to pt07106. No ensemble.

## 5. The gate, and the final commit
- gate.sh at 29906d9 (23:58-00:13; scratch-i2/gate.log): both builds silent; the suite 94 run, 94 passed (HealthCheck and
  MapCheck green this time; BuildMenuCheck run apart): BuildMenuCheck PASS 101 of 101; tools.Stale 0 firm (429 soft: map
  ages, no map page yet for MaterialsCheck/ProcessingSector/ExtractionSector, a fuzzy "eight sections" - the docs
  pass's); the playtest's 8 traces byte-identical to pt07106; no w/crlf but .bat files.
- Final commit 29906d9 on batch/I2 (6d92694 model, f5392f9 harnesses, 29906d9 version and counts); tree clean.

## 6. ★ calls
- (No choice in place of what Jerus asked: decision A is in force for every SpreadPlanner user, as asked.)
- ★I2-1 outValue/inValue on the market's tally (GoodsMarket.getImported/getExported), as cityValue() reads: the planner
  weighs at the top of the month, after the strike, and bank() has cleared the sectors' rows by then (the spec's source).
- ★I2-2 the power pair as "chk + sectors PowerSold" / "chk - utilities PowerBought" notes: declared as an in and an out
  they would cancel in the identity whatever each side booked, so a works paid more than the utility gave would vanish
  from the residual; noted, each off its own book, a mismatch is the residual's (the electricity bills' own pattern).
- ★I2-3 Statement.powerSold inside revenue, outside localSales/exports/otherRevenue: every bottom line adds up (the
  formal statements' PROFIT, SectorBooks) without a new case, and the VAT and the sales by good never see it.
- ★I2-4 gen at nameplate, as the draw is billed; the surplus sold undimmed by a brownout, the bought part at the ratio.
- ★I2-5 consumables at the operating rate (a variable cost, as inputs are bought) and the markets' exchange rate (the
  foreign rate x the world price level), booked beside the fleet at the top of the market pass (Markets, one line).
- ★I2-6 a works kind counts idle when the LAST one standing earns below nothing - its output at inValue (what losing it
  costs the city), its feed at outValue - the mirror of a candidate; the candidate's own earnings would shed a works
  that replaces imports whenever one more would have to export.
- ★I2-7 idle months keyed by template id (permanent; I3 renames buildings), not name.
- ★I2-8 Refining stays a Sector: it overrides every part ProcessingSector holds (flow, package, run, Tank Farm, kinds
  of unit); moving it would be the same code under a new name, not simpler.
- ★I2-9 RefineryCheck 14's fixture on ON_ITS_BORROWING (the named history), the lever it was built on (0.7.103).
- ★I2-10 ExtractionSector keeps today's test (Game.consider()); its planner money gate is I3's.
- ★I2-11 MaterialsCheck's ProcessingSector is a fixture keyed on Heavy Industry (none in the registry until I3).
- ★I2-12 a works' retirement measure is buildings (unitsOf 1); ProcessingSector.captive() = every good made and used.

## 7. For the next batch
- **I2b** (Game.Slices, the sea): ProcessingSector orders still pass Game.consider() -> Slices after the planner's
  whole-cost test; once Slices tests the whole cost at the slice's projectRate the two agree (same estimate,
  estimatedMonthlyProfit()). The planner rates at projectRate(sector, cost) (SpreadPlanner.rateFor); if I2b blends a
  cheaper bond rate, say whether the planner should too. LongPlaytest's switch now reads "borrowing" for the old rule.
- **I3**: HeavyIndustry extends ProcessingSector (plan moves: the playtest's foundries); Mining onto the MONEY gate
  (ExtractionSector.plan(): SpreadPlanner's money test before the order). Hold the rows to SpreadPlanner.caseEarns()
  (Case A-D) against the study's tables; MaterialsCheck's Works fixture can become the real sector.
- **I4 (the first gen)**: SectorFlow (SectorFlowCheck's revenueMoney = m.revenue()) and the UI's opened Revenue need a
  "Power sold" line (Statement.powerSold is in revenue, not in the sales); SectorStatements adds up already. A works whose
  gen covers its draw is still throttled by the grid's energyRatio (Sector's) - decide; tonnesMoved() counts captive
  goods in and out (vans for internal transfer) - decide. BusinessInvestment.runningCostOf() charges the whole draw:
  only ProcessingSector adds gen back (a non-processing template with gen would be under-estimated).
- I5: ExtractionSector.dig()/groundLimit() by type and the site's dig; fits() in plan(). Docs pass: maps, dials
  (DEFAULT_MONEY_GATE, Sector.CONSUMABLES), harnesses.md (MaterialsCheck, RefineryCheck 11b/14, MoneyCheck 4,
  BuildingDataCheck), the manual (the whole-cost rule).

## 8. For Jerus to check on the PC
1. Nothing on screen should change: no building makes power or buys consumables yet, and the refiners order as before.
2. Load any city (no new key but Statement.powerSold, read as none); save and load again.

## 9. Outside my files
- EconomyManager.setElectricityConsumption() (net draws + setPowerSurplus) and getSectorPowerSold(); Game: the three
  setBilledRevenue() calls pass getSectorPowerSold() (finalUpdateEconomy and the two load paths - not THE LARGEST SLICE or
  consider()) and one comment; Markets.clearMonth(): one line (buyConsumables); SectorState: powerSold saved and read;
  LongPlaytest: the money-gate switch's property and javadoc; buildings.json: five readme lines.
