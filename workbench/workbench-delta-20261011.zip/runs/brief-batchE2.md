# Brief: E2, the Earth's ground. 0.7.115. 2026-10-11

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## What this is
The second batch of "the world as planet Earth" (`/home/claude/runs/spec-earth.md`: read §2, §3, §6 and §8's E2 row, and its E3–E4 rows for what comes after). Jerus answered the study's eight questions "all rec" (2026-10-10):
- Earth for new cities only, and the default once E4 ships;
- real river courses;
- WorldCover coasts;
- sea and ice refused, deserts and dry spots warned;
- no guaranteed iron;
- names for search only;
- today's river-water rule;
- no elevation.

E1 (0.7.111) built the reader:
- `EarthProj` (the projection, `blend()` for a tile's corners);
- `EarthData` (the file's layers, an LRU of tiles);
- `EarthCheck`, on a fixture of 18 tiles (Rotterdam 6, Perth 4, Paris 4, Fiji 4) in `src/main/resources/earth/`, and on the full file when `-Dcbs.earth=<path>` names it.

Read `/home/claude/runs/fixE1-notes.md` whole (§1 and §7 above all).

**E2 makes an Earth world a world the game can stand on**, still unreachable from the founding screen (E4) and byte-identical for every generated world:
- **`World` gains a key** (kind, seed, lat, lon, data). `World.of(seed)` stays for generated worlds.
- **`EarthTerrain`** (new) implements spec §3's rule: `tileTerrain`, `terrainAt` and `regionTerrain`; small lakes drawn as seeded blobs of their own area from their points; rivers from their vectors.
  - On Earth, the cells pass replaces the sea pass.
  - The founding is the snap, with no founding river.
  - The study's Java prototype (`EarthWorld`) is gone (lost in the workspace restart on 2026-10-09). Build from spec §3's words:
    - a 34 × 34 region a tile, shares read on a 10 × 10 lattice and blended;
    - each class's value noise in octaves of 480 m to 60 m, falling off by World's 0.55;
    - `COAST_FRAY` 1.0;
    - `QUANTILE`, 2^18 fixed samples;
    - a beach is ≥ 2% bare;
    - forest ranked in the dry ground;
    - real land use ignored.

    The project's `claude/earth-prototype.py` is an earlier GLOBE-mask prototype of the same idea, and is not on disk; the spec is enough.
- **The callers take the key** (the spec names nine: `CityMap`, `MapTiles`, `LandMap`, `CityLand`, `LandConversion`, `GridConversion`, `LandManager`, `Game`, `Founding`). Change each only as far as passing the key through; a generated world must reach exactly the code it reaches today.

**Checks (spec §8 E2):**
- WorldCheck's generated sections unchanged.
- New Earth assertions, on the fixture's three windows:
  - shares per cell within a mean of 2 points (the study measured 0.39–1.49);
  - identical twice;
  - a second seed changes ≥ 10% of plots, with water within 0.5 points;
  - a tile ≤ 0.3 ms (measured 0.09–0.20);
  - no seam at 180° (Fiji);
  - MapCheck's Earth screen ≤ 80 ms.
- "The cells pass ≤ 1 s" needs the whole planet's far layers, so it runs when the full file is named and prints one plain line when it isn't (as EarthCheck does).
- Timing checks run under the JVM lock, like all of them.

**Saves:** none in E2. The format bump (worldKind, earthLat/Lon, earthData) is E4's. An Earth world here is built by harnesses only.

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| E2 | 0.7.115 | named in the launch prompt | `/home/claude/scratch-e2` | **byte-identical** to the reference the launch prompt names |

**Your files:**
- `World` (the key) and `EarthTerrain` (new);
- the callers above, the key only;
- `WorldCheck`'s and `MapCheck`'s new Earth sections (or a new harness, ★, if they grow too big);
- `GameVersion`;
- `CLAUDE.md`/`README.md` counts and rows.

**Beside you:** I2b (0.7.113, every order on its whole cost) works in `Game`'s THE LARGEST SLICE and `consider()`, `BusinessInvestment`, the order tests of `sectors/Oil` and `Ports`, and `InvestCheck`/`OrderSearchCheck`; later I3 (0.7.114, iron) in `Good`, `buildings.json` and its twin, `Resource`, `sectors/Mining`, `sectors/HeavyIndustry`, `Sectors`' labels, the harnesses that name buildings, and `LongPlaytest`. Keep out of those. If you must touch `Game` or `LandManager` beyond passing the key, list it under "Outside my files".

**Building:** copy `src/main/resources/earth/` into your classes folder as well as the json. Set `JDK_JAVA_OPTIONS="-Djava.io.tmpdir=<scratch>/tmp -Dcbs.earth=/home/claude/scratch-earth/e0/out/earth-1.bin"` for the suite. Read that file only; never write into `/home/claude/scratch-earth/`.

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** The full suite green (the count at your base, more if you add one); BuildMenuCheck 101.

Reply with:
- a short summary;
- the Earth assertions' figures against the spec's;
- what each caller needed;
- the gate and your final commit;
- your ★ calls.
