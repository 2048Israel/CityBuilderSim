#!/bin/bash
G=/home/claude/scratch-gate; T=/home/claude/git/CityBuilderSim
GSON=/opt/apache-maven-3.9.11/lib/gson-2.13.1.jar
cd $G
echo "start $(date +%T)" > $G/gate.log
rm -rf -- /home/claude/scratch-gate/tmp && mkdir -p /home/claude/scratch-gate/tmp   # harness temp folders pile up ~5 GB a run
flock /home/claude/jvm.lock bash $G/build.sh model $T > $G/b-model.txt 2>&1; echo "build model bytes: $(wc -c < $G/b-model.txt)" >> $G/gate.log
flock /home/claude/jvm.lock bash $G/build.sh ui $T > $G/b-ui.txt 2>&1; echo "build ui bytes: $(wc -c < $G/b-ui.txt)" >> $G/gate.log
flock /home/claude/jvm.lock bash $G/suite.sh $G/suite.txt; echo "suite: $(cat $G/suite.txt.done); $(tail -1 $G/suite.txt)" >> $G/gate.log
grep -E "FAILED" $G/suite.txt | grep -E "^[A-Za-z]+(Check|Playtest)" >> $G/gate.log
echo "bmc: $(flock /home/claude/jvm.lock bash $G/bmc.sh $T)" >> $G/gate.log
(cd $T && flock /home/claude/jvm.lock java -Djava.io.tmpdir=$G/tmp -cp "$G/classes:$GSON" ham.citybuildersim.tools.Stale > $G/stale.txt 2>&1); echo "stale: $(grep -i -m2 'firm\|soft' $G/stale.txt | tr '\n' ' ')" >> $G/gate.log
flock /home/claude/jvm.lock bash $G/pt.sh pt-main /home/claude/scratch-ui1/orch-gate/pt07123 > $G/pt-main.txt 2>&1; echo "pt: $(grep -c identical $G/pt-main.txt) identical, $(grep -c DIFFERS $G/pt-main.txt) differ" >> $G/gate.log
echo "eol crlf (non-bat): $(cd $T && git ls-files --eol | grep 'w/crlf' | grep -v '\.bat$' | wc -l)" >> $G/gate.log
echo "done $(date +%T)" >> $G/gate.log
