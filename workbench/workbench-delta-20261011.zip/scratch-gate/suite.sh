#!/bin/bash
# suite.sh [out] - AllChecks on scratch-w1/classes, every JVM's tmpdir in scratch; output to suite.txt
S=/home/claude/scratch-gate
O=${1:-$S/suite.txt}
GSON=/opt/apache-maven-3.9.11/lib/gson-2.13.1.jar
mkdir -p $S/run
cd $S/run
start=$(date +%s)
JDK_JAVA_OPTIONS="-Djava.io.tmpdir=$S/tmp -Dcbs.earth=/home/claude/scratch-earth/e0/out/earth-1.bin" java -cp "$S/classes:$GSON" ham.citybuildersim.AllChecks > $O 2>&1
echo "exit $? after $(( $(date +%s) - start )) s" > $O.done
