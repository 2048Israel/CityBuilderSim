#!/bin/bash
# buildmenu-check.sh [tree] - BuildMenuCheck, run in the cloud (0.7.21).
#
# BuildMenuCheck is the one harness that needs the window class, so build.sh
# leaves it out and AllChecks skips it here. Constructing the window does not
# start the JavaFX toolkit, so the Windows JavaFX jars serve to compile and run
# it on Linux. This compiles the whole tree against them into the tree's own
# build folder, runs the check, and prints one line:
#
#   BuildMenuCheck: PASS - ...      exit 0
#   BuildMenuCheck: FAIL - ...      exit 1
#   BuildMenuCheck: could not ...   exit 2
#
# Nothing is deleted. It writes only under <tree>/build/ (bmc-classes,
# bmc-sources.txt, bmc-javac.txt, bmc-output.txt) and the harness's scratch
# city under BMC_TMP (default <tree>/build/bmc-tmp) - set BMC_TMP to point
# the JVM's temp directory somewhere else.
T=${1:-/home/claude/git/CityBuilderSim}
GSON=/opt/apache-maven-3.9.11/lib/gson-2.13.1.jar
FX=$(ls /home/claude/fx/*.jar | tr '\n' ':')
if [ -z "$FX" ]; then
  echo "BuildMenuCheck: could not run - no JavaFX jars under /mnt/user-data/uploads/openjfx/"
  exit 2
fi
if [ ! -d "$T/src/main/java" ]; then
  echo "BuildMenuCheck: could not run - $T has no src/main/java"
  exit 2
fi
OUT=/home/claude/scratch-gate/bmc-classes
TMP="${BMC_TMP:-/home/claude/scratch-gate/bmc-tmp}"
mkdir -p "$OUT" "$TMP"
find "$T/src/main/java" -name '*.java' > /home/claude/scratch-gate/bmc-sources.txt
if ! javac -nowarn -Xmaxerrs 1000 -d "$OUT" -cp "$GSON:$FX" @/home/claude/scratch-gate/bmc-sources.txt > /home/claude/scratch-gate/bmc-javac.txt 2>&1; then
  echo "BuildMenuCheck: could not build - see /home/claude/scratch-gate/bmc-javac.txt"
  exit 2
fi
cp "$T"/src/main/resources/*.json "$OUT"/
if [ -d "$T"/src/main/resources/earth ]; then cp -r "$T"/src/main/resources/earth "$OUT"/; fi
LOG=/home/claude/scratch-gate/bmc-output.txt
java -Djava.io.tmpdir="$TMP" -cp "$OUT:$GSON:$FX" ham.citybuildersim.BuildMenuCheck > "$LOG" 2>&1
ran=$?
described=$(grep -m1 '^Buildings described:' "$LOG" | sed 's/^Buildings described: //')
if [ $ran -eq 0 ] && grep -q '^All checks passed' "$LOG"; then
  echo "BuildMenuCheck: PASS - all checks passed, ${described:-?} buildings described (output in $LOG)"
  exit 0
fi
failed=$(grep -m1 'check(s) failed' "$LOG" | sed 's/ check(s) failed//')
first=$(grep -m1 '  FAIL: ' "$LOG" | sed 's/^  FAIL: //')
if [ -n "$failed" ]; then
  echo "BuildMenuCheck: FAIL - $failed check(s) failed; the first: $first (output in $LOG)"
else
  echo "BuildMenuCheck: FAIL - it did not finish (exit $ran; output in $LOG)"
fi
exit 1
