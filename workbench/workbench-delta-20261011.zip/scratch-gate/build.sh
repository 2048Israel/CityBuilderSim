#!/bin/bash
# build.sh [model|ui] [tree] [out] - bin/build.sh and bin/build-ui.sh without the delete line and without /tmp; classes into scratch-w1
S=/home/claude/scratch-gate
KIND=${1:-model}
T=${2:-/home/claude/git/CityBuilderSim}
GSON=/opt/apache-maven-3.9.11/lib/gson-2.13.1.jar
cd $T
if [ "$KIND" = "ui" ]; then
  OUT=${3:-$S/ui-classes}
  FX=$(ls /home/claude/fx/*.jar | tr '\n' ':')
  find src/main/java -name '*.java' > $S/uisrcs.txt
  mkdir -p $OUT
  javac -J-Djava.io.tmpdir=$S/tmp -nowarn -Xmaxerrs 1000 -d $OUT -cp "$GSON:$FX" @$S/uisrcs.txt 2>&1 | grep -v '^Picked up' | grep -v '^Note:' || true
  cp src/main/resources/*.json $OUT/
  if [ -d src/main/resources/earth ]; then cp -r src/main/resources/earth $OUT/; fi
else
  OUT=${3:-$S/classes}
  find src/main/java -name '*.java' ! -path '*/ui/*' ! -name 'CityBuilderSim.java' ! -name 'BuildMenuCheck.java' > $S/srcs.txt
  mkdir -p $OUT
  javac -J-Djava.io.tmpdir=$S/tmp -nowarn -Xmaxerrs 1000 -d $OUT -cp "$GSON" @$S/srcs.txt 2>&1 | grep -v '^Picked up' | grep -v '^Note:' || true
  cp src/main/resources/*.json $OUT/
  if [ -d src/main/resources/earth ]; then cp -r src/main/resources/earth $OUT/; fi
fi
