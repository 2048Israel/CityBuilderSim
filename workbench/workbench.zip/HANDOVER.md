# CityBuilderSim — handover for a fresh session (2026-10-07, at 0.7.62)

**STATE, 2026-10-07 07:30 ADT:** Jerus's PC has **0.7.62's code** (tag 1007a: 87 files, sources and `buildings.json` only, deployed early on his word so nothing is lost if the cloud resets). **Not yet done for 0.7.55–0.7.62:** the docs pass (comments, `docs/map`, `dials.md`, the manual source), manual version 14, the records (changelog, todo, a write-up), and the project docs. **Next, in order:** (1) batch L, brief ready at `runs/brief-batchL.md` (0.7.63): Jerus's decision "whole iron fields as one offer, yes that means significant investment" (undo J1c's site sharing; the test player buys a whole field when it can pay, with the bond if needed), saves that reload exactly (his autosave reloads with cash off by -7,447k; also on 0.7.61), the audit's floor; (2) one docs pass for 0.7.55–0.7.63; (3) manual v14; (4) deploy; (5) records (Sonnet). The chain's design is `runs/spec-land.md` (project: `claude/spec-land.md`); each batch's notes are `runs/fixI`, `fixJ1a`…`fixJ4`, `fixK-notes.md`; the chain's standing brief is `runs/brief-batchJ.md`. Reference traces: `pt0762`. Ensemble at 0.7.62: 22/26 like-for-like (the scorer leaves a passing A3 out of its count). Before this chain: Read this, then `claude/todo.md` section 0 and the top block of `claude/changelog.md` in the project. The game on Jerus's PC is **0.7.54**, deployed as tag 1006c (140 files, code verified byte for byte): counts are `long` and the three order loops search, so a city can pass 2.1 billion people (`claude/spec-scale.md`: 5B and 10B run at about 50 ms a month after the fixes). Before it, tag 1006b (0.7.52): the autosave holds a whole month, and the central bank's strictness dial. Then tag 1006a: the chart crash (0.7.50) and the build advice behind "Build all three" (0.7.51); see `claude/chart-crash-and-build-advice.md`. Before it: tag 1005b, 0.7.46–0.7.49 (`claude/model-fixes-fund-and-transit.md`), and tag 1005a, 0.7.42–0.7.45 (`claude/inflation-that-answers-to-money.md`). **Next: the land, water and the world's deposits, then fuel** (the todo's new NEXT item; a map mockup is at https://claude.ai/artifact/2qoejEU7PqCG4xCAce4a1K, awaiting his reaction). 0.7.50–0.7.51 work on his PC ("seems to be working fine").

## 1. Restore the workbench (the cloud workspace starts empty)

Ask for these folders: `C:\Users\Jerus\Documents\NetBeansProjects\CityBuilderSim`, `C:\Users\Jerus\AppData\Roaming\CityBuilderSim` and `C:\Users\Jerus\.m2\repository\org\openjfx`. Then stage:

1. **`CityBuilderSim\workbench\workbench.zip`**, and `unzip` it into `/home/claude/`. It holds:
   - `cbs/`: the tree at 0.7.62, the same as the PC (code; docs not yet passed). Re-stage any file Jerus changed since; compare the src mtimes with `device_list_dir`. Then `cp -a cbs cbs-base` before any edit.
   - `bin/`: the build and check scripts (see §2 on `rm`).
   - `scratch-ui1/orch-gate/pt0749/`: **the current reference traces** (the zip holds only `pt0762`, the current reference). Older: `pt0744` (0.7.44–0.7.45), `pt0` (0.7.41).
   - `runs/ensemble/`: **the 16-seed × 5-policy harness**. Run it with `bash runs/ensemble/run.sh <tree> <label>`, about 21 minutes. Its scores are under `out/<label>/score.md` (0741, 0744, 0749); the CSVs aren't in the zip.
   - `runs/`: every brief, spec and set of notes. The newest are `crash-0749.txt`, `spec-build-advice.md`, `fixE`/`fixF-notes.md` and `docs-0751.md`; before them `spec-model-fixes.md`, `spec-transit.md`, `fixA`–`fixD-notes.md`.
   - `runs/manual/index.html`: the manual's source at 0.7.54 (the published artifact is still version 13, at 0.7.51; publish version 14 with the next batch); `manual-publish.html` is what gets published (skeleton stripped; keep `&mp;`, it is ∓).
   - `cities/` and `probe/`, as before.
2. **The JavaFX 21 Windows jars** go into `/home/claude/fx/`; their staged copies sit at `/mnt/user-data/uploads/openjfx/<name>/21/`.
3. **gson:** `/opt/apache-maven-3.9.11/lib/gson-2.13.1.jar`.

## 2. The gate, and the hard lessons from 2026-10-04/05

**The gate:**
- both builds silent;
- the suite 73/74, HealthCheck the known red;
- BuildMenuCheck PASS 73 of 73;
- Stale 0 firm;
- the playtest byte-identical to `pt0749` (or re-baselined, with each change explained, only for a model change Jerus approved);
- endings clean;
- Maps last.

**The lessons:**
- **`rm` and `/dev`.** An agent deleted `/dev/null` with a stray `rm -r /dev/null`. It was recreated with `mknod -m 666 /dev/null c 1 3`; check `ls -la /dev/null` shows `crw-rw-rw-` before running the suite. Briefs forbid `rm` outright and any use of `/dev`; agents still slip into `2>/dev/null` or `/dev/stdout` now and then (no harm since), so check after each agent. `bin/build.sh` and `build-ui.sh` contain `rm -rf build/...`, so agents run copies without it.
- **Never end the orchestrator's turn while work is pending.** A session restart killed an agent, and the orchestrator then sent a progress message and stopped, so nothing ran for six hours. After any interruption, launch the next agent in the same turn; send mid-run updates with SendUserMessage and keep working.
- **Republishing the manual** is refused until the live page has been read in full. Have a Sonnet agent read the saved live file whole (all of it) and compare it with the last publish file; the live copy carries the publish skeleton (537 bytes at the head, `</body></html>` at the tail), which is expected. Then publish the new `manual-publish.html`.
- **Jerus's log** is `C:\Users\Jerus\AppData\Roaming\CityBuilderSim\log.txt` (and `log-previous.txt`); for a crash, stage it and find the FIRST uncaught exception. Since 0.7.50 failures still go in past the 2 MB cap.

## 3. The batch shape (Jerus's)
- **Orchestrator:** briefs, gate, deploy. **It writes no code** (Jerus, 2026-10-04: "remember you dont code, only the agents you spawn").
- **Agents:** a research or design spec for big work → an Opus implementer → a fresh Opus docs pass → the orchestrator gates and deploys → records on Sonnet. The manual: two Opus writers splitting the sections, then a Sonnet publish step.
- **Parallel work:** a worktree (`cbs-b`) plus `git merge-file`, or a read-only spec running beside an implementer (the transit study ran beside the fund batch). Run at most one JVM per agent, because the machine has 2 cores.
- **Notes are capped:** 120–150 lines.
- **Rules for every agent:** no permission prompts; no `rm`; no `/dev`; keep line endings; never move a harness premise or loosen a tolerance (premises change only where Jerus's approved design makes them wrong, each listed); no invented numbers; verdict colours only for verdicts.

## 4. Deploy to the PC
1. Diff the tree against what the PC has. Deploy the sources and only the documents whose content changed; ignore the map date lines and put those files back to the PC's copies.
2. Run `device_commit_files` at most 50 at a time.
3. Stage the sources back and `cmp` each one; size-check the documents with `device_list_dir`.
4. Refresh `workbench\workbench.zip` at the end.

## 5. Saves
Slots 1–9 are Jerus's; never write them. Slot 10 is the test slot. Jerus checks the screens himself from the todo's CHECK lists. SAVE_FORMAT is still 30, but a 0.7.46+ save won't load in a 0.7.45 build.

## 6. Open, in order
1. **Jerus's PC check:** 0.7.53–0.7.54 (big figures; AllChecks on his PC), 0.7.52 (the strictness ladder on Policy › Money), then 0.7.50–0.7.51 (the todo's CHECK 0.7.50 TO 0.7.51: try to reproduce the freeze; the Build Overview's cards and "Build all three"), then 0.7.46–0.7.49, 0.7.42–0.7.45 and the older lists.
2. **His answers:** the land premium at scale and history trimming (CONFIRM from 0.7.53 to 0.7.54), and his go for the land batch; then CONFIRM (from 0.7.52) (the dial's ends), then **CONFIRM (from 0.7.50 to 0.7.51):** the build advice's ★ calls (5% slack, 6-month horizon, no cash cap, land at the office's price, the higher-education pipeline), the Home Daycare counts. Then **CONFIRM (from 0.7.46 to 0.7.49):** B8's large effect on the default playtest; the ensemble's new fails K2 and R3; the fare cap at 27.6% of an unskilled take-home; fuel real and imported; the withdrawal's sale asking at fair value; the fund summary amber while the dial sells; the SAVE_FORMAT note. Then CONFIRM (0.7.42 to 0.7.45) and the older lists.
3. **The ensemble at 0.7.49: 20/25** (not rerun for 0.7.50–0.7.54, which left the traces byte-identical; K2 and R3 accepted by Jerus on 2026-10-06) (0.7.44: 22/25). New fails K2 (shock tail 3.18% against ≤3.00%) and R3 (3 seeds over +1 point against ≤2); still failing A2 (worst spell 18 months), S1 and H1.
4. **The manual:** version 13 at 0.7.51, source at 0.7.54 (https://claude.ai/artifact/BkBAN1RDiQTpCj79WPbpCp). Keep it current with each docs pass's list of false sections.
