package ham.citybuildersim;

import java.io.OutputStream;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Automatic building (0.7.73, batch N4): AutoBuilder's month held to its
 * rules, in a city it builds for decades and in fixtures that cause each of
 * the things that hold it back.
 *
 * WHY. Jerus: "an automatic build and acquire debt button for basically
 * automatic building, with a required slack button that you add, aka
 * maintain say 15% surplus service of everything ... right in the build
 * menu, and on/off, so that one can focus on other things." A switch that
 * spends the treasury and borrows by itself every month has to be shown to
 * keep its word over a city's life, not on one order: what it builds, what
 * it borrows, and that a saved city plays on as the one it was saved from.
 *
 * What this has to prove:
 *   1. THE SETTINGS: a new city has it off, at a 15% margin and a 15% debt
 *      limit; the sliders keep to their steps and their ends; switching it
 *      and moving a slider are decisions; off, a month's pass does nothing;
 *      a save from before it loads with it off at its defaults.
 *   2. THE ADVICE'S CARD: the first order a pass places is the build
 *      advice's card for that measure at the player's margin - its building
 *      and its count - where nothing cuts it.
 *   3. A CITY ON IT FOR DECADES, played by the test player with the city's
 *      works left to it (-Dplaytest.autobuild's player): after every pass
 *      every service it keeps is at or above the margin's target, or has
 *      works under way, or the pass said why not - and each reason it gave
 *      is true; it builds nothing outside its remit and buys no ground; it
 *      never borrows past the debt limit, nor spends the cash under a
 *      month's tax; and a staffed order fits what the budget leaves.
 *   4. A SAVED CITY PLAYS ON AS THE ONE IT WAS SAVED FROM: the city at the
 *      end of section 3, saved and loaded, and both run on with it on - the
 *      cash, the debt, every building and site, the people and its own log,
 *      month by month, to the cent.
 *   5. WHAT HOLDS IT BACK, CAUSED: no ground, a debt limit of nothing, a
 *      limit that binds and one that does not, a budget that cannot run a
 *      building, and a first police station a town does not need - each one
 *      held as it says, and the inbox's notice raised while it holds and
 *      settled when it is switched off.
 *
 * Every fixture causes its condition.
 */
public class AutoBuildCheck {

    static int fails = 0;
    static PrintStream out;
    static PrintStream quiet;

    static void assertTrue(String label, boolean ok) {
        if (!ok) fails++;
        out.printf("%-110s %s%n", label, ok ? "OK" : "FAIL");
    }

    /** Two money figures, in thousands, equal to the cent. */
    static void cents(String label, double actual, double expected) {
        boolean ok = Math.abs(actual - expected) <= .00001;
        if (!ok) fails++;
        out.printf("%-110s %s  %.5f against %.5f%n", label, ok ? "OK" : "FAIL", actual, expected);
    }

    static void quietly(Runnable r) {
        PrintStream real = System.out;
        System.setOut(quiet);
        try { r.run(); } finally { System.setOut(real); }
    }

    public static void main(String[] args) throws Exception {
        Locale.setDefault(Locale.CANADA);
        out = System.out;
        quiet = new PrintStream(new OutputStream() { @Override public void write(int b) { } });
        Path root = Files.createTempDirectory("autobuildcheck");
        // ChildcareCheck's town is the fixture for sections 2 and 5: its quiet stream too.
        ChildcareCheck.out = quiet;
        ChildcareCheck.quiet = quiet;

        theSettings(root);
        theAdvicesCard(root);
        Game decades = decades(root);
        savedAndLoaded(root, decades);
        whatHoldsIt(root);

        out.println(fails == 0 ? "\nAll checks passed." : "\n" + fails + " FAILED");
        System.exit(fails == 0 ? 0 : 1);
    }

    /* ---------------------------------------------------------------- 1 */

    static void theSettings(Path root) {
        out.println("--- 1. the settings ---");
        Game g = new Game(new GameFiles(root.resolve("new"), root.resolve("new-no-legacy")));
        quietly(g::newGame);
        AutoBuilder ab = g.getAutoBuilder();
        assertTrue("a new city has it off", !ab.isOn());
        assertTrue("...its spare margin at DEFAULT_SLACK, 15%, and its debt limit at DEFAULT_DEBT_LIMIT, 15% of revenue",
                ab.getSlack() == AutoBuilder.DEFAULT_SLACK && ab.getDebtLimit() == AutoBuilder.DEFAULT_DEBT_LIMIT
                        && AutoBuilder.DEFAULT_SLACK == .15 && AutoBuilder.DEFAULT_DEBT_LIMIT == .15);
        int decided = g.getDecisions().size();
        ab.setSlack(.987, g.getDecisions());
        boolean top = ab.getSlack() == AutoBuilder.SLACK_MOST;
        ab.setSlack(-.3, g.getDecisions());
        boolean bottom = ab.getSlack() == 0;
        ab.setSlack(.1234, g.getDecisions());
        boolean step = Math.abs(ab.getSlack() - .12) < 1e-12;
        assertTrue("the margin's slider keeps to its ends, 0 and SLACK_MOST, and to whole per cents", top && bottom && step);
        ab.setDebtLimit(.6, g.getDecisions());
        boolean limitTop = ab.getDebtLimit() == AutoBuilder.DEBT_LIMIT_MOST
                && AutoBuilder.DEBT_LIMIT_MOST == CityNeeds.SERVICE_CONSTRAINED;
        ab.setDebtLimit(.07, g.getDecisions());
        assertTrue("...the debt limit's to 0 and DEBT_LIMIT_MOST, the Finances tab's \"constrained\" line",
                limitTop && Math.abs(ab.getDebtLimit() - .07) < 1e-12);
        ab.setOn(true, g.getDecisions());
        DecisionLog.Entry last = g.getDecisions().last();
        assertTrue("switching it and moving a slider are decisions, in the construction kind",
                g.getDecisions().size() == decided + 6 && last != null && DecisionLog.CONSTRUCTION.equals(last.kind())
                        && last.label().startsWith("Automatic building on"));
        ab.setOn(false, g.getDecisions());
        int months = 12;
        quietly(() -> g.simulateMonths(months));
        assertTrue("off, " + months + " months' passes order nothing and take no step",
                ab.getOrders() == 0 && ab.log().isEmpty() && ab.steps().isEmpty() && ab.getLastPass() == 0);
        AutoBuilder older = new AutoBuilder();
        older.setOn(true, null);
        older.setSlack(.3, null);
        older.restore(null);
        assertTrue("a save from before it (no state) loads with it off, at its defaults, with nothing done",
                !older.isOn() && older.getSlack() == AutoBuilder.DEFAULT_SLACK
                        && older.getDebtLimit() == AutoBuilder.DEFAULT_DEBT_LIMIT && older.getOrders() == 0);
    }

    /* ---------------------------------------------------------------- 2 */

    static void theAdvicesCard(Path root) {
        out.println("\n--- 2. the advice's card ---");
        Game g = ChildcareCheck.town(root, "card");
        AutoBuilder ab = g.getAutoBuilder();
        ab.setOn(true, null);
        ab.setSlack(BuildAdvice.SLACK, null);
        BuildAdvice.Suggestion[] first = new BuildAdvice.Suggestion[1];
        int[] expected = new int[1];
        g.autoBuildProbeForTest = after -> {
            if (after || first[0] != null) return;
            // What the pass will see first: the first measure it keeps that the advice has a card for.
            List<CityNeeds.Need> all = CityNeeds.measure(g, CityNeeds.PLAIN);
            for (BuildAdvice.Measure m : AutoBuilder.remit(g, all)) {
                if (BuildAdvice.ahead(g, m, BuildAdvice.onSite(g, m), BuildAdvice.opening(g, 0, ab.getSlack()))) continue;
                BuildAdvice.Suggestion s = BuildAdvice.suggestFor(g, AutoBuilder.rowFor(all, m), m, g.getCash(),
                        g.getLandManager().getAvailableSqFt(), ab.getSlack());
                if (s == null) continue;
                first[0] = s;
                // The builders' rule, worked here: the most that opens inside MAX_ORDER_MONTHS, one when none would.
                int k = s.count();
                while (k > 1 && AutoBuilder.wait(g, s, k) > BusinessInvestment.MAX_ORDER_MONTHS) k--;
                expected[0] = k;
                return;
            }
        };
        quietly(() -> g.simulateMonths(1));
        g.autoBuildProbeForTest = null;
        AutoBuilder.Step placed = null;
        for (AutoBuilder.Step s : ab.steps()) if (s.outcome() == AutoBuilder.Outcome.ORDERED) { placed = s; break; }
        assertTrue("fixture: the town is short of something the advice has a card for, at the advice's own margin (SLACK)",
                first[0] != null);
        assertTrue("fixture: ...a building the budget does not run, and ground for all of it", first[0] != null
                && !AutoBuilder.staffedBuilding(first[0].template()) && (first[0].paving()
                || first[0].template().getLandSqFt() * (double) first[0].count() <= g.getLandManager().getAvailableSqFt()));
        if (first[0] != null && placed != null) {
            assertTrue(String.format("the pass's first order is the card's building, %s for %s, and its count, %d - cut by"
                            + " the builders' rule to the %d that open inside a year", first[0].template().getName(),
                            first[0].measure().label(), first[0].count(), expected[0]),
                    placed.measure().equals(first[0].measure()) && placed.building().equals(first[0].template().getName())
                            && placed.wanted() == first[0].count() && placed.ordered() == expected[0]);
        } else {
            assertTrue("the pass's first order is the card", false);
        }
    }

    /* ---------------------------------------------------------------- 3 */

    /** What a pass found, measure by measure, over the run. */
    static int passes, kept, atTarget, works, held, nothing, unexplained, borrowingPasses, ordered;
    static int outsideRemit, groundBought, underReserve, overBudget, overLimit, falseHolds;
    static final Map<AutoBuilder.Cut, Integer> heldBy = new LinkedHashMap<>();
    static final Map<String, Integer> builtBy = new LinkedHashMap<>();
    static double worstShare = 0;

    static Game decades(Path root) {
        out.println("\n--- 3. a city on it for decades ---");
        int months = 600;
        Path dir = root.resolve("decades");
        GameFiles files = new GameFiles(dir.resolve("data"), dir.resolve("no-legacy"));
        PrintStream was = LongPlaytest.out;
        boolean flag = LongPlaytest.AUTOBUILD;
        LongPlaytest.out = quiet;
        LongPlaytest.AUTOBUILD = true;
        Game g = new Game(files, LongPlaytest.founding());
        AutoBuilder ab = g.getAutoBuilder();
        int[][] before = new int[1][];
        double[] snap = new double[3];      // land owned, cash, reserve
        g.autoBuildProbeForTest = after -> {
            if (!ab.isOn()) return;
            if (!after) {
                before[0] = standingAndOnSite(g);
                snap[0] = g.getLandManager().getOwnedSqFt();
                snap[1] = g.getCash();
                snap[2] = AutoBuilder.reserve(g);
                return;
            }
            look(g, ab, before[0], snap);
        };
        try {
            quietly(() -> {
                g.run();
                g.getDebtManager().setAutopilot(LongPlaytest.AUTOPILOT);
                g.setRolloverMode(LongPlaytest.ROLLOVER);
                g.setRescueMode(TreasuryFund.RescueMode.AUTOMATIC);
                ab.setOn(true, g.getDecisions());
                // The test player's founding, by hand, and its rhythm after (LongPlaytest.main()).
                LongPlaytest.villageBuild(g, "House", 40);
                LongPlaytest.villageBuild(g, "Convenience Store", 3);
                LongPlaytest.villageBuild(g, "Mixed Farm", 2);
                LongPlaytest.run(g, 3);
                LongPlaytest.villageBuild(g, "House", 20);
                LongPlaytest.run(g, 4);
                LongPlaytest.villageBuild(g, "Convenience Store", 2);
                LongPlaytest.villageBuild(g, "Construction Depot", 1);
                LongPlaytest.run(g, 5);
                LongPlaytest.advise(g);
                LongPlaytest.run(g, 6);
                int stop = 0;
                while (g.getMonth() < months) {
                    stop++;
                    int skip = switch (stop % 6) { case 0 -> 100; case 1 -> 12; case 2 -> 24; case 3 -> 60; case 4 -> 6; default -> 120; };
                    LongPlaytest.run(g, Math.min(skip, months - g.getMonth()));
                    if (g.getMonth() >= months) break;
                    for (int move = 0; move < LongPlaytest.movesPerLook(); move++) {
                        if (LongPlaytest.advise(g) == null) break;
                        LongPlaytest.run(g, 1);
                    }
                    LongPlaytest.run(g, 2);
                }
            });
        } finally {
            g.autoBuildProbeForTest = null;
            LongPlaytest.AUTOBUILD = flag;
            LongPlaytest.out = was;
        }
        out.printf("    (%d months, %,d people at the end; %d passes, %d orders: %s)%n", g.getMonth(),
                g.getPopulationManager().getPopulation(), passes, ordered, builtBy);
        out.printf("    (after each pass, of %d services kept: %d at the target, %d with works under way, %d held %s,"
                + " %d with nothing to build)%n", kept, atTarget, works, held, heldBy, nothing);
        assertTrue("fixture: it ran a pass every month and placed orders for at least three services",
                passes >= months - 1 && builtBy.size() >= 3);
        assertTrue("fixture: it borrowed, on the funding page's bond, at least once", borrowingPasses > 0);
        assertTrue("after every pass every service it keeps is at the margin's target, has works under way, or the"
                + " pass said why not (" + unexplained + " otherwise)", unexplained == 0);
        assertTrue("...and every reason it gave was true: no ground for one, a bond for one past the limit, a budget"
                + " short of one's running, no site output (" + falseHolds + " not)", falseHolds == 0);
        assertTrue(String.format("...and most of the time at the target itself: %.1f%% of the services kept, the"
                + " rest works under way or held", 100.0 * atTarget / Math.max(1, kept)), atTarget * 2 > kept);
        assertTrue("it builds nothing outside its remit (" + outsideRemit + " other buildings rose in a pass)", outsideRemit == 0);
        assertTrue("...and buys no ground (" + groundBought + " passes in which the city's ground grew)", groundBought == 0);
        assertTrue(String.format("it never borrows past the debt limit: %d passes borrowed, debt payments after them at"
                + " most %.2f%% of revenue against %.0f%%", borrowingPasses, worstShare * 100, ab.getDebtLimit() * 100),
                overLimit == 0);
        assertTrue("...nor spends the cash under a month's tax, the reserve (" + underReserve + " passes did)", underReserve == 0);
        assertTrue("...and a pass's staffed orders leave the budget's room at nothing or more, what is on site counted ("
                + overBudget + " passes did not)",
                overBudget == 0);
        return g;
    }

    /** Every template's standing and on-site count, by id. */
    static int[] standingAndOnSite(Game g) {
        BuildingManager bm = g.getBuildingManager();
        int[] site = bm.getUnderConstructionById();
        int[] out = new int[bm.getMaxTemplateId() + 1];
        for (BuildingsTemplate t : bm.getTemplates()) {
            out[t.getId()] = bm.getQuantity(t.getId()) + (t.getId() < site.length ? site[t.getId()] : 0);
        }
        return out;
    }

    /** One pass, read: what rose, what it did measure by measure, the debt, the cash and the budget. */
    static void look(Game g, AutoBuilder ab, int[] before, double[] snap) {
        passes++;
        int[] now = standingAndOnSite(g);
        for (BuildingsTemplate t : g.getBuildingManager().getTemplates()) {
            int id = t.getId();
            if (id < before.length && now[id] > before[id] && !AutoBuilder.inRemit(t)) outsideRemit++;
        }
        if (g.getLandManager().getOwnedSqFt() != snap[0]) groundBought++;
        double raised = 0;
        boolean staffed = false;
        for (AutoBuilder.Step s : ab.steps()) {
            raised += s.borrowed();
            if (s.outcome() == AutoBuilder.Outcome.ORDERED) {
                ordered++;
                builtBy.merge(s.measure().label(), s.ordered(), Integer::sum);
                BuildingsTemplate t = g.getBuildingManager().getTemplateByName(s.building());
                if (t != null && AutoBuilder.staffedBuilding(t)) staffed = true;
            }
        }
        // Each staffed order fits the room the budget left, what is on site counted - this pass's too - so none leaves it under nothing.
        if (staffed && ab.budgetRoom(g) < -1e-6) overBudget++;
        if (raised > 0) {
            borrowingPasses++;
            double share = ab.serviceShare(g);
            worstShare = Math.max(worstShare, share);
            if (!(share <= ab.getDebtLimit() + 1e-12)) overLimit++;
        }
        if (g.getCash() < Math.min(snap[1], snap[2]) - 1e-6) underReserve++;

        List<CityNeeds.Need> all = CityNeeds.measure(g, CityNeeds.PLAIN);
        Map<BuildAdvice.Measure, AutoBuilder.Step> stepOf = new LinkedHashMap<>();
        for (AutoBuilder.Step s : ab.steps()) stepOf.put(s.measure(), s);
        for (BuildAdvice.Measure m : AutoBuilder.remit(g, all)) {
            AutoBuilder.Step s = stepOf.get(m);
            if (s == null) continue;               // kept after the pass, not before it: its first building came due
            kept++;
            boolean at = ab.atTarget(g, m);
            boolean site = BuildAdvice.units(BuildAdvice.onSite(g, m)) > 0;
            if (at) atTarget++;
            else if (site) works++;
            else if (s.outcome() == AutoBuilder.Outcome.HELD) {
                held++;
                heldBy.merge(s.cut(), 1, Integer::sum);
                if (!holdIsTrue(g, ab, s)) {
                    falseHolds++;
                    if (falseHolds <= 3) out.println("    (a hold not true at m" + g.getMonth() + ": " + s + ")");
                }
            } else if (s.outcome() == AutoBuilder.Outcome.NOTHING) nothing++;
            else unexplained++;
        }
    }

    /** A hold, checked after the pass against the city as the pass left it. */
    static boolean holdIsTrue(Game g, AutoBuilder ab, AutoBuilder.Step s) {
        BuildingsTemplate t = g.getBuildingManager().getTemplateByName(s.building());
        switch (s.cut()) {
            case GROUND:
                return t != null && t.getLandSqFt() > g.getLandManager().getAvailableSqFt();
            case BUDGET:
                return t != null && BuildAdvice.running(g, t, new LinkedHashMap<>()) > ab.budgetRoom(g);
            case BUILDERS:
                return t != null && Double.isNaN(g.quoteBuild(t, 1).months);
            case DEBT: {
                if (t == null) return false;
                double gap = AutoBuilder.gapFor(g, g.quoteBuild(t, 1).total);
                if (!(gap > 0)) return false;
                if (!(ab.getDebtLimit() > 0)) return true;
                DebtQuote q = AutoBuilder.bondFor(g, gap);
                return q == null || ab.serviceShareWith(g, q.monthlyInterest()) > ab.getDebtLimit();
            }
            default:
                return false;
        }
    }

    /* ---------------------------------------------------------------- 4 */

    static void savedAndLoaded(Path root, Game g) {
        out.println("\n--- 4. a saved city plays on as the one it was saved from ---");
        int slot = 10;
        boolean[] saved = new boolean[1];
        quietly(() -> saved[0] = g.saveGame(slot, "autobuildcheck").ok);
        assertTrue("fixture: the decades' city, auto-build on, saved", saved[0] && g.getAutoBuilder().isOn());
        GameFiles files = new GameFiles(root.resolve("decades").resolve("data"), root.resolve("decades").resolve("no-legacy"));
        Game back = new Game(files);
        quietly(() -> back.loadGameSave(slot));
        AutoBuilder a = g.getAutoBuilder(), b = back.getAutoBuilder();
        assertTrue("it loads on, at the same margin and limit, with the same log, totals and holds",
                back.getLoadFailure() == null && b.isOn() && b.getSlack() == a.getSlack() && b.getDebtLimit() == a.getDebtLimit()
                        && b.log().size() == a.log().size() && b.getOrders() == a.getOrders()
                        && b.getBuildings() == a.getBuildings() && b.held().equals(a.held()));
        cents("...the revenue it reads the limit and the budget against", b.revenue(back), a.revenue(g));
        int months = 36, drift = 0, ordersBefore = a.getOrders();
        // Ground for both, the same: the decades ended short of it, and a city that can build nothing proves little.
        for (Game c : new Game[] { g, back }) c.getLandManager().setOwnedSqFt(c.getLandManager().getOwnedSqFt() + 50_000_000L);
        double worst = 0;
        String first = null;
        for (int i = 0; i < months; i++) {
            quietly(() -> { g.simulateMonths(1); back.simulateMonths(1); });
            double[][] pairs = {
                    { g.getCash(), back.getCash() },
                    { g.getDebtManager().getAllPrincipal(), back.getDebtManager().getAllPrincipal() },
                    { a.getSpent(), b.getSpent() }, { a.getBorrowed(), b.getBorrowed() },
                    { g.getPopulationManager().getPopulation(), back.getPopulationManager().getPopulation() } };
            String[] names = { "cash", "debt", "spent", "borrowed", "people" };
            for (int k = 0; k < pairs.length; k++) {
                double d = Math.abs(pairs[k][0] - pairs[k][1]);
                worst = Math.max(worst, d);
                if (d > .00001) { drift++; if (first == null) first = "m" + g.getMonth() + " " + names[k]; }
            }
            if (!java.util.Arrays.equals(standingAndOnSite(g), standingAndOnSite(back))) {
                drift++;
                if (first == null) first = "m" + g.getMonth() + " buildings";
            }
            if (a.getOrders() != b.getOrders() || !a.held().equals(b.held())) {
                drift++;
                if (first == null) first = "m" + g.getMonth() + " its log";
            }
        }
        assertTrue(String.format("both run on %d months, it ordering in both (%d orders now): the cash, the debt, what it"
                        + " spent and borrowed, the people, every building and site and its log the same each month, to"
                        + " the cent (worst %.2g%s)", months, a.getOrders(), worst, first == null ? "" : ", first " + first),
                drift == 0);
        assertTrue("fixture: ...and it placed orders in those months (" + (a.getOrders() - ordersBefore) + ")",
                a.getOrders() > ordersBefore);
        AutoBuilder.State st = a.toState();
        String json = new com.google.gson.Gson().toJson(st);
        AutoBuilder c = new AutoBuilder();
        c.restore(new com.google.gson.Gson().fromJson(json, AutoBuilder.State.class));
        assertTrue("its state through the save's own Gson: the same settings, log and totals",
                c.isOn() == a.isOn() && c.getSlack() == a.getSlack() && c.log().size() == a.log().size()
                        && c.getSpent() == a.getSpent() && c.getBorrowed() == a.getBorrowed());
    }

    /* ---------------------------------------------------------------- 5 */

    static void whatHoldsIt(Path root) {
        out.println("\n--- 5. what holds it back, caused ---");
        BuildAdvice.Measure general = BuildAdvice.Measure.care(CareType.GENERAL);
        BuildAdvice.Measure roads = BuildAdvice.Measure.of(BuildAdvice.Kind.ROADS);

        // No ground.
        Game g = ChildcareCheck.town(root, "noground");
        LandManager land = g.getLandManager();
        land.setOwnedSqFt((long) Math.ceil(land.getAllocatedSqFt()));
        AutoBuilder ab = g.getAutoBuilder();
        ab.setOn(true, null);
        int site0 = siteCount(g);
        quietly(() -> g.simulateMonths(1));
        AutoBuilder.Step s = stepFor(ab, general);
        assertTrue("fixture: the town short of general care, with no ground free",
                s != null && s.outcome() != AutoBuilder.Outcome.AHEAD && land.getAvailableSqFt() < 1);
        assertTrue("with no ground for one, it holds - nothing placed, no ground bought", s != null
                && s.outcome() == AutoBuilder.Outcome.HELD && s.cut() == AutoBuilder.Cut.GROUND && siteCount(g) == site0
                && land.getAvailableSqFt() < 1);
        Notice n = g.getInbox().live("autobuild");
        assertTrue("...and the inbox says so, a line a service, naming the land office", n != null
                && String.join(" ", n.getBody()).contains("land office"));
        ab.setOn(false, g.getDecisions());
        quietly(() -> g.simulateMonths(1));
        assertTrue("...settled the month it is switched off", g.getInbox().live("autobuild") == null);

        // The debt limit.
        Game d = ChildcareCheck.town(root, "limit");
        AutoBuilder ad = d.getAutoBuilder();
        d.setCashForTest(AutoBuilder.reserve(d));
        ad.setDebtLimit(0, null);
        ad.setOn(true, null);
        int[] paper = new int[2];
        d.autoBuildProbeForTest = after -> paper[after ? 1 : 0] = d.getDebtManager().getDebt().size();
        quietly(() -> d.simulateMonths(1));
        d.autoBuildProbeForTest = null;
        AutoBuilder.Step sd = stepFor(ad, roads);
        assertTrue("fixture: the town short of road, its cash at a month's tax", sd != null
                && sd.outcome() != AutoBuilder.Outcome.AHEAD);
        assertTrue("a debt limit of 0%: it holds and borrows nothing", sd != null && sd.outcome() == AutoBuilder.Outcome.HELD
                && sd.cut() == AutoBuilder.Cut.DEBT && ad.getBonds() == 0 && paper[1] == paper[0]);
        Game e = ChildcareCheck.town(root, "limit2");
        AutoBuilder ae = e.getAutoBuilder();
        e.setCashForTest(AutoBuilder.reserve(e));
        ae.setDebtLimit(AutoBuilder.DEBT_LIMIT_MOST, null);
        ae.setOn(true, null);
        double cashBefore = e.getCash(), reserve = AutoBuilder.reserve(e);
        double[] shareAfter = { Double.NaN };
        e.autoBuildProbeForTest = after -> { if (after) shareAfter[0] = ae.serviceShare(e); };
        quietly(() -> e.simulateMonths(1));
        e.autoBuildProbeForTest = null;
        AutoBuilder.Step se = stepFor(ae, roads);
        assertTrue(String.format("at %.0f%%, it borrows on the funding page's bond for what the cash over the reserve does"
                        + " not cover, and orders: debt payments then %.2f%% of revenue", AutoBuilder.DEBT_LIMIT_MOST * 100,
                        shareAfter[0] * 100), se != null && se.outcome() == AutoBuilder.Outcome.ORDERED && se.borrowed() > 0
                && shareAfter[0] <= AutoBuilder.DEBT_LIMIT_MOST && ae.getBonds() >= 1 && cashBefore <= reserve + 1e-6);

        // The budget.
        Game f = ChildcareCheck.town(root, "budget");
        AutoBuilder af = f.getAutoBuilder();
        af.setOn(true, null);
        double[] room = { Double.NaN };
        f.autoBuildProbeForTest = after -> { if (!after) room[0] = af.budgetRoom(f); };
        // A month's spending past what the year's revenue brings: every one of its services' bills, and as much again.
        f.getEconomyManager().setHealthcare(f.getEconomyManager().getNationalAccounts().getTotalRevenue() * 2, 0);
        f.getEconomyManager().refreshGovernmentAccounts(0, 0, 0, 0);
        quietly(() -> f.simulateMonths(1));
        f.autoBuildProbeForTest = null;
        AutoBuilder.Step sf = stepFor(af, general);
        assertTrue(String.format("fixture: the budget leaves nothing to run a clinic (%,.0fk a month)", room[0]), room[0] <= 0
                && sf != null && sf.outcome() != AutoBuilder.Outcome.AHEAD);
        assertTrue("a staffed service the budget cannot run is held, every building that serves it passed over",
                sf != null && sf.outcome() == AutoBuilder.Outcome.HELD && sf.cut() == AutoBuilder.Cut.BUDGET);
        Notice nf = f.getInbox().live("autobuild");
        assertTrue("...and the inbox names the Policy tab", nf != null && String.join(" ", nf.getBody()).contains("Policy tab"));

        // A first police station.
        Game p = ChildcareCheck.town(root, "police");
        BuildAdvice.Measure police = BuildAdvice.Measure.of(BuildAdvice.Kind.POLICE);
        BuildingsTemplate station = p.getBuildingManager().getTemplateByName("Police Station");
        quietly(() -> p.getBuildingManager().retire(station, p.getBuildingManager().getQuantity(station.getId())));
        double[] sdp = BuildAdvice.supplyDemand(p, police, new LinkedHashMap<>());
        List<CityNeeds.Need> all = CityNeeds.measure(p, CityNeeds.PLAIN);
        assertTrue(String.format("fixture: a town with no station, needing %,.0f officers - under half a station's %d",
                sdp[1], station.getCapacity()), AutoBuilder.serving(p, police) == 0
                && sdp[1] - sdp[0] < AutoBuilder.FIRST_SHARE * station.getCapacity());
        assertTrue("a first police station waits for half a station's worth of need: police is not a service it keeps",
                !AutoBuilder.remit(p, all).contains(police));
        int warranted = (int) Math.ceil(AutoBuilder.FIRST_SHARE * station.getCapacity() * 100_000.0
                / Crime.FULL_OFFICERS_PER_100K);
        assertTrue(String.format("...which comes at %,d people (%.0f officers for 100,000, Crime.FULL_OFFICERS_PER_100K);"
                + " the town has %,d", warranted, Crime.FULL_OFFICERS_PER_100K, p.getPopulationManager().getPopulation()),
                warranted > p.getPopulationManager().getPopulation());
        quietly(() -> p.buildStack(station, 1, true));
        assertTrue("...and with one standing, it is kept again", AutoBuilder.remit(p, CityNeeds.measure(p, CityNeeds.PLAIN))
                .contains(police));
    }

    static AutoBuilder.Step stepFor(AutoBuilder ab, BuildAdvice.Measure m) {
        for (AutoBuilder.Step s : ab.steps()) if (s.measure().equals(m)) return s;
        return null;
    }

    static int siteCount(Game g) {
        int n = 0;
        for (int v : g.getBuildingManager().getUnderConstructionById()) n += v;
        return n;
    }
}
