package ham.citybuildersim;

import java.util.*;

/**
 * Scratch only (fund research, 0.7.39 spec): a shadow cost-basis ledger fed by
 * taps in patched copies of Exchange and BondMarket. The proposed design's
 * arithmetic, average cost (Canadian ACB): a buy adds its cost; a sale takes
 * ACB out in proportion to the units sold; realized = proceeds less that ACB;
 * a write-down takes ACB out with no proceeds; a maturity realizes face less ACB.
 */
public final class FundTap {
    static final int N = 32;
    static double[] acbMarket = new double[N], acbRescue = new double[N], realizedShare = new double[N];
    static double[] boughtShares = new double[N], soldShares = new double[N];
    static final Map<Integer, double[]> bond = new TreeMap<>(); // id -> {acb, realized, coupons}
    static double purchases, proceeds, writtenOffAcb;
    static int ruleFills, handFills, ruleBondFills, handBondFills;
    static final List<String> handLog = new ArrayList<>();
    static final Map<String, Integer> fillKeys = new HashMap<>(); // month|instr|side|who aggregation
    static boolean verboseHand = true;
    static int watch = -1;

    static double[] b(int id) { return bond.computeIfAbsent(id, k -> new double[3]); }

    static void key(int month, String instr, String side, String who) {
        fillKeys.merge(month + "|" + instr + "|" + side + "|" + (who.contains("hand") ? "hand" : "rule"), 1, Integer::sum);
    }

    static void shareBought(int c, String buyer, String seller, double q, double price, int month) {
        double cash = q * price;
        acbMarket[c] += cash;
        boughtShares[c] += q;
        purchases += cash;
        key(month, "S" + c, "B", buyer);
        if (buyer.contains("hand")) {
            handFills++;
            if (verboseHand) handLog.add(String.format("  m%d HAND BUY  %s %,.4f shares at %.6f from %s = %,.3f", month, Equity.COMPANIES[c], q, price, seller, cash));
        } else ruleFills++;
    }

    static void shareSold(int c, String seller, String buyer, double q, double price, double fromRescue,
                          double marketBefore, double rescueBefore, int month) {
        double cash = q * price;
        double fromMarket = q - fromRescue;
        double basisM = marketBefore > 0 ? acbMarket[c] * Math.min(1, fromMarket / marketBefore) : 0;
        double basisR = rescueBefore > 0 ? acbRescue[c] * Math.min(1, fromRescue / rescueBefore) : 0;
        acbMarket[c] -= basisM;
        acbRescue[c] -= basisR;
        realizedShare[c] += cash - basisM - basisR;
        soldShares[c] += q;
        proceeds += cash;
        key(month, "S" + c, "S", seller);
        if (seller.contains("hand")) {
            handFills++;
            if (verboseHand) handLog.add(String.format("  m%d HAND SELL %s %,.4f shares at %.6f to %s = %,.3f; ACB out %,.3f (rescue %,.3f); realized %,.3f",
                    month, Equity.COMPANIES[c], q, price, buyer, cash, basisM + basisR, basisR, cash - basisM - basisR));
        } else {
            ruleFills++;
            if (c == watch) handLog.add(String.format("  m%d RULE SELL %s %,.4f shares at %.6f to %s = %,.3f; realized %,.3f", month, Equity.COMPANIES[c], q, price, buyer, cash, cash - basisM - basisR));
        }
    }

    static void bondBought(int id, String buyer, String seller, double q, double price, int month) {
        double cash = q * price;
        b(id)[0] += cash;
        purchases += cash;
        key(month, "B" + id, "B", buyer);
        if (buyer.contains("hand")) {
            handBondFills++;
            if (verboseHand) handLog.add(String.format("  m%d HAND BUY  bond #%d %,.3f face at %.6f from %s = %,.3f", month, id, q, price, seller, cash));
        } else ruleBondFills++;
    }

    static void bondSold(int id, String seller, String buyer, double q, double price, double cityBefore, int month) {
        double cash = q * price;
        double[] x = b(id);
        double basis = cityBefore > 0 ? x[0] * Math.min(1, q / cityBefore) : 0;
        x[0] -= basis;
        x[1] += cash - basis;
        proceeds += cash;
        key(month, "B" + id, "S", seller);
        if (seller.contains("hand")) {
            handBondFills++;
            if (verboseHand) handLog.add(String.format("  m%d HAND SELL bond #%d %,.3f face at %.6f = %,.3f; realized %,.3f", month, id, q, price, cash, cash - basis));
        } else ruleBondFills++;
    }

    static void bondWrittenDown(int id, double before, double after) {
        double[] x = b(id);
        double basis = before > 0 ? x[0] * (1 - Math.max(0, after) / before) : 0;
        x[0] -= basis;
        x[1] -= basis;
        writtenOffAcb += basis;
        handLog.add(String.format("  WRITE-DOWN bond #%d face %,.3f -> %,.3f; ACB out %,.3f as a realized loss", id, before, after, basis));
    }

    static void bondMatured(int id, double face, int month) {
        double[] x = b(id);
        x[1] += face - x[0];
        proceeds += face;
        handLog.add(String.format("  m%d MATURED bond #%d face %,.3f against ACB %,.3f: realized %,.3f", month, id, face, x[0], face - x[0]));
        x[0] = 0;
    }

    static void couponStruck(int id, double amount) { b(id)[2] += amount; }

    static double acbTotal() {
        double t = 0;
        for (int c = 0; c < N; c++) t += acbMarket[c] + acbRescue[c];
        for (double[] x : bond.values()) t += x[0];
        return t;
    }

    static double realizedTotal() {
        double t = 0;
        for (int c = 0; c < N; c++) t += realizedShare[c];
        for (double[] x : bond.values()) t += x[1];
        return t;
    }
}
