package ham.citybuildersim;

import java.io.PrintStream;
import java.nio.file.*;
import java.util.*;

/**
 * Fund-as-a-brokerage research probe (scratch only). Loads a played research
 * city from a scratch copy and prints what the fund holds, every figure a
 * position card would read, a hand order's quote, and - through FundTap's
 * taps in patched copies of Exchange and BondMarket - the hand's actual fills
 * and a shadow average-cost ledger, reconciled each month against the fund's
 * own lifetime counters.
 *
 * args: root label
 */
public class ProbeFund {

    static PrintStream real = System.out;
    static PrintStream quiet = new PrintStream(java.io.OutputStream.nullOutputStream());
    static String m(double k) { return Formats.INSTANCE.amount(k); }
    static void quietly(Runnable r) { System.setOut(quiet); try { r.run(); } finally { System.setOut(real); } }
    static void say(String f, Object... a) { real.println(String.format(f, a)); }

    static Game load(Path root) {
        Game[] box = new Game[1];
        quietly(() -> {
            box[0] = new Game(new GameFiles(root.resolve("data"), root.resolve("no-legacy")));
            try { box[0].loadGameSave(10); } catch (Exception e) { throw new RuntimeException(e); }
        });
        return box[0];
    }

    public static void main(String[] a) throws Exception {
        Locale.setDefault(Locale.CANADA);
        Path root = Paths.get(a[0]);
        String label = a.length > 1 ? a[1] : root.getFileName().toString();

        say("################ %s ################", label);
        if (a.length > 2 && a[2].equals("limit")) { FundTap.verboseHand = false; overLimit(root); return; }
        if (a.length > 2 && a[2].equals("life")) { life(load(root)); return; }
        Game g = load(root);
        portfolio(g, "AS LOADED");
        seed(g);
        Snap s0 = snap(g);

        /* ---- the experiment: a hand buy, a bond buy and a hand sell, a month ---- */
        Equity reg = g.getEquity();
        Exchange ex = g.getExchange();
        int n = Equity.COMPANIES.length;
        int x = -1; double bestCap = 0;
        for (int c = 0; c < n; c++) {
            if (c == Equity.BANK || reg.getShares(c) <= 0) continue;
            double room = TreasuryFund.OWNERSHIP_LIMIT * reg.getShares(c) - reg.getCityMarketShares(c);
            double cap = ex.marketCap(reg, c);
            if (room > 0 && cap > bestCap) { bestCap = cap; x = c; }
        }
        double amount = Math.max(1_000, Math.round(g.fundValue() * .01 / 1_000) * 1_000.0);
        if (x >= 0) {
            say("\n=== QUOTE: buy %s of %s now ===", m(amount), Equity.COMPANIES[x]);
            quote(g, x, amount);
        }
        CorporateBond bond = null;
        for (CorporateBond b : g.getBondMarket().getBonds()) {
            if (b.isMatured(g.getMonth()) || b.remainingMonths(g.getMonth()) < 12) continue;
            if (bond == null || b.face() > bond.face()) bond = b;
        }
        if (bond != null) {
            say("\n=== QUOTE: buy %s of bond #%d now ===", m(amount), bond.id());
            bondQuote(g, bond, amount);
        }
        int z = -1; double most = 0;
        for (int c = 0; c < n; c++) if (c != x && reg.getCityMarketShares(c) * ex.price(c) > most) { most = reg.getCityMarketShares(c) * ex.price(c); z = c; }

        double need = amount * 2 - g.getFund().getCash();
        if (need > 0) { double moved = g.fundPayIn(need + 1); say("(paid %s into the fund from the treasury for the experiment)", m(moved)); }
        if (x >= 0) g.fundBuyShares(x, amount);
        if (bond != null) g.fundBuyBond(bond.id(), amount);
        double sellQ = z >= 0 ? reg.getCityMarketShares(z) * .25 : 0;
        if (z >= 0) g.fundSellShares(z, sellQ);
        say("\nqueued: buy %s of %s; buy %s of bond #%s; sell %,.4f %s shares (a quarter of its market book)",
                m(amount), x >= 0 ? Equity.COMPANIES[x] : "-", m(amount), bond == null ? "-" : bond.id(), sellQ, z >= 0 ? Equity.COMPANIES[z] : "-");
        FundTap.handLog.clear();
        quietly(() -> g.simulateMonths(1));
        say("\n=== ONE MONTH ON (%s) - the hand's fills, by the taps ===", CityCalendar.format(g.getMonth()));
        for (String l : FundTap.handLog) real.println(l);
        say("  rule fills this month: shares %d, bonds %d; hand fills: shares %d, bonds %d",
                FundTap.ruleFills, FundTap.ruleBondFills, FundTap.handFills, FundTap.handBondFills);
        reconcile(g, s0);
        if (x >= 0) card(g, x);
        if (z >= 0) card(g, z);
        if (bond != null) bondCard(g, bond.id());
        portfolio(g, "AFTER THE MONTH");

        /* ---- twelve more months: how busy the ledger is, and does it hold ---- */
        Map<Integer, Integer> perMonth = new TreeMap<>();
        for (int k = 0; k < 12; k++) {
            int before = FundTap.ruleFills + FundTap.ruleBondFills + FundTap.handFills + FundTap.handBondFills;
            int keys0 = FundTap.fillKeys.size();
            quietly(() -> g.simulateMonths(1));
            int after = FundTap.ruleFills + FundTap.ruleBondFills + FundTap.handFills + FundTap.handBondFills;
            perMonth.put(g.getMonth(), after - before);
            say("  %s: %d fills, %d aggregated activity rows", CityCalendar.formatShort(g.getMonth()), after - before, FundTap.fillKeys.size() - keys0);
        }
        say("non-hand log lines in the 13 months:");
        for (String l : FundTap.handLog) if (!l.contains("HAND")) real.println(l);
        reconcile(g, s0);
        portfolio(g, "THIRTEEN MONTHS ON");
    }

    /** The lifetime counters in full, and the resolutions and preferred, in thousands. */
    static void life(Game g) {
        TreasuryFund f = g.getFund();
        say("month %d %s", g.getMonth(), CityCalendar.format(g.getMonth()));
        say("value %,.1f cash %,.1f sharesV %,.1f marketV %,.1f rescueV %,.1f bondsV %,.1f prefV %,.1f warrV %,.1f",
                g.fundValue(), f.getCash(), g.fundSharesValue(), g.fundMarketSharesValue(), g.fundRescueSharesValue(), g.fundBondsValue(), g.fundPreferredValue(), g.fundWarrantsValue());
        say("paidInSurplus %,.1f paidInCash %,.1f handIn %,.1f handOut %,.1f transfers %,.1f short %,.1f", f.getPaidInFromSurplus(), f.getPaidInFromCash(), f.getHandPaidIn(), f.getHandDrawnOut(), f.getTransfersPaid(), f.getTransfersShort());
        say("divMarket %,.1f divRescue %,.1f coupons %,.1f principal %,.1f faceLost %,.1f", f.getDividendsMarket(), f.getDividendsRescue(), f.getCoupons(), f.getPrincipal(), f.getBondFaceLost());
        say("sharesBought %,.1f sharesSold %,.1f bondsBought %,.1f bondsSold %,.1f rescueSold %,.1f", f.getSharesBought(), f.getSharesSold(), f.getBondsBought(), f.getBondsSold(), f.getRescueSold());
        say("prefBought %,.1f prefDivs %,.1f prefRedeemed %,.1f warrantsBack %,.1f warrantShares %,.3f rescueCost %,.1f offers %d/%d/%d",
                f.getPreferredBought(), f.getPreferredDividends(), f.getPreferredRedeemed(), f.getWarrantsBoughtBack(), f.getWarrantSharesTaken(), f.getRescueCost(),
                f.getOffersMade(), f.getOffersAccepted(), f.getOffersDeclined());
        for (TreasuryFund.Resolution r : f.getResolutions())
            say("resolution %s: paid %,.1f (cash %,.1f advanced %,.1f) shortfall %,.1f exit %,.1f shares %,.3f hh %,.3f/%,.1f world %,.3f/%,.1f fund %,.3f/%,.1f prefCancelled %,.1f warrCancelled %,.1f",
                    CityCalendar.format(r.month()), r.paid(), r.fromCash(), r.advanced(), r.shortfall(), r.exitCapital(), r.shares(),
                    r.householdsShares(), r.householdsValue(), r.worldShares(), r.worldValue(), r.fundShares(), r.fundValue(), r.preferredCancelled(), r.warrantsCancelled());
        Equity reg = g.getEquity();
        for (int c = 0; c < Equity.COMPANIES.length; c++)
            if (reg.getLifetimeDividendsCity(c) > 0 || reg.getCityShares(c) > 0)
                say("  %s: held %,.4f (rescue %,.4f) lifetime divs to the city %,.1f; price %.6f fair %.6f last trade m%d", Equity.COMPANIES[c], reg.getCityShares(c), reg.getCityRescueShares(c),
                        reg.getLifetimeDividendsCity(c), g.getExchange().price(c), g.getExchange().fair(c), g.getExchange().bookOf(c).lastTradeMonth());
        HistorySave h = g.getHistorySave();
        say("history months %d (first %d, last %d); bank price series length %d", h.getMonth().size(), h.getMonth().get(0), h.getMonth().get(h.getMonth().size() - 1),
                h.aligned(HistorySave.priceKey("Bank")).length);
        say("decisions FUND: %s", g.getDecisions().toString().length() > 0 ? "(see log)" : "none");
    }

    /* ------------------------------ the experiment's limit ------------------------------ */

    /** A second load: a hand buy at twice the room under 10% in the smallest listed company, then two months. */
    public static void overLimit(Path root) {
        Game g = load(root);
        Equity reg = g.getEquity();
        Exchange ex = g.getExchange();
        int y = -1; double small = Double.MAX_VALUE;
        for (int c = 0; c < Equity.COMPANIES.length; c++) {
            if (c == Equity.BANK || reg.getShares(c) <= 0 || ex.fair(c) <= 0) continue;
            double cap = ex.marketCap(reg, c);
            if (cap > 0 && cap < small) { small = cap; y = c; }
        }
        // A company the market bids at or over fair, so an ask at fair meets a buyer.
        y = -1; small = Double.MAX_VALUE;
        for (int c = 0; c < Equity.COMPANIES.length; c++) {
            if (c == Equity.BANK || reg.getShares(c) <= 0 || ex.fair(c) <= 0) continue;
            if (ex.bestBid(c) >= ex.fair(c) && ex.marketCap(reg, c) < small) { small = ex.marketCap(reg, c); y = c; }
        }
        if (y < 0) { say("no company bid at or over fair"); return; }
        // The hand's buy that filled past the cap, put on the register directly (a fixture: fair-value hand bids fill nothing here).
        double to = .15 * reg.getShares(y);
        reg.moveCity(y, to - reg.getCityMarketShares(y));
        g.getFund().receive(1);
        say("\n=== OVER THE LIMIT: %s - its market book set to %.3f%% (as if a hand buy had filled past the cap); best bid %.5f, fair %.5f ===",
                Equity.COMPANIES[y], 100 * reg.getCityMarketShares(y) / reg.getShares(y), ex.bestBid(y), ex.fair(y));
        double before = reg.getCityMarketShares(y);
        FundTap.watch = y;
        FundTap.acbMarket[y] = reg.getCityMarketShares(y) * ex.price(y);
        FundTap.handLog.clear();
        Map<String, Integer> keys0 = new HashMap<>(FundTap.fillKeys);
        quietly(() -> g.simulateMonths(1));
        int ruleSells = 0;
        for (Map.Entry<String, Integer> e : FundTap.fillKeys.entrySet()) {
            if (e.getKey().contains("|S" + y + "|S|rule")) ruleSells += e.getValue() - keys0.getOrDefault(e.getKey(), 0);
        }
        say("  a month on (%s): market book %.3f%% (was %.3f%%); the rule's sell fills in it this month: %d; its ask resting at fair: %s",
                CityCalendar.formatShort(g.getMonth()), 100 * reg.getCityMarketShares(y) / reg.getShares(y),
                100 * before / reg.getShares(y), ruleSells,
                g.getExchange().bookOf(y).asks().stream().filter(o -> o.who().equals(Exchange.FUND)).map(o -> String.format("%,.3f @ %.6f", o.quantity(), o.price())).toList());
        for (String l : FundTap.handLog) real.println(l);
        say("  10%% of it is %,.3f shares; it holds %,.3f; fair %.5f, price %.5f", TreasuryFund.OWNERSHIP_LIMIT * reg.getShares(y), reg.getCityMarketShares(y), ex.fair(y), ex.price(y));
    }

    /* ------------------------------ seeding and reconciling ------------------------------ */

    /** The recommended seed for a holding bought before cost tracking: its market value at load; the rescue book at its recorded cost. */
    static void seed(Game g) {
        Equity reg = g.getEquity();
        Exchange ex = g.getExchange();
        for (int c = 0; c < Equity.COMPANIES.length; c++) {
            FundTap.acbMarket[c] = reg.getCityMarketShares(c) * ex.price(c);
            FundTap.acbRescue[c] = 0;
        }
        double rescueShares = 0;
        for (int c = 0; c < Equity.COMPANIES.length; c++) rescueShares += reg.getCityRescueShares(c);
        if (rescueShares > 0) FundTap.acbRescue[Equity.BANK] = g.getFund().getRescueCost();
        BondMarket bm = g.getBondMarket();
        for (CorporateBond b : bm.getBonds()) if (b.city() > 0) FundTap.b(b.id())[0] = b.city() * bm.modelPrice(b, g.getMonth());
    }

    record Snap(double mv, double acb, double realized, double bought, double sold, double principal, double rescuePaid, double warrantShares) { }

    static Snap snap(Game g) {
        TreasuryFund f = g.getFund();
        double paid = 0;
        for (TreasuryFund.Resolution r : f.getResolutions()) paid += r.paid();
        return new Snap(g.fundSharesValue() + g.fundBondsValue(), FundTap.acbTotal(), FundTap.realizedTotal(),
                f.getSharesBought() + f.getBondsBought(), f.getSharesSold() + f.getBondsSold(), f.getPrincipal(), paid,
                f.getWarrantSharesTaken());
    }

    /** The harness's identity: realized + change in unrealized = change in value + proceeds - purchases (- rescues paid). */
    static void reconcile(Game g, Snap s0) {
        Snap s = snap(g);
        double lhs = (s.realized - s0.realized) + ((s.mv - s.acb) - (s0.mv - s0.acb));
        double rhs = (s.mv - s0.mv) + (s.sold - s0.sold) + (s.principal - s0.principal) - (s.bought - s0.bought) - (s.rescuePaid - s0.rescuePaid);
        say("  RECONCILE: realized %s + change in unrealized %s = %s; value change %s + proceeds %s + principal %s - purchases %s = %s; residual %.3e",
                m(s.realized - s0.realized), m((s.mv - s.acb) - (s0.mv - s0.acb)), m(lhs),
                m(s.mv - s0.mv), m(s.sold - s0.sold), m(s.principal - s0.principal), m(s.bought - s0.bought), m(rhs), lhs - rhs);
        say("  ...and the taps' purchases %s against the fund's own counter's %s; proceeds %s against %s",
                m(FundTap.purchases), m(s.bought - s0.bought), m(FundTap.proceeds), m(s.sold - s0.sold + s.principal - s0.principal));
    }

    /* ------------------------------ the pages' reads ------------------------------ */

    static void portfolio(Game g, String title) {
        TreasuryFund f = g.getFund();
        Equity reg = g.getEquity();
        Exchange ex = g.getExchange();
        BondMarket bm = g.getBondMarket();
        HistorySave h = g.getHistorySave();
        int month = g.getMonth();
        say("\n=== %s: %s (month %d), treasury %s ===", title, CityCalendar.format(month), month, m(g.getCash()));
        say("FUND value %s = cash %s + shares %s (market %s, rescue %s) + bonds %s + preferred %s + warrants %s",
                m(g.fundValue()), m(f.getCash()), m(g.fundSharesValue()), m(g.fundMarketSharesValue()), m(g.fundRescueSharesValue()),
                m(g.fundBondsValue()), m(g.fundPreferredValue()), m(g.fundWarrantsValue()));
        say("  dial %.0f%%, rescue %s, equity share %.1f%%, transfer due next %s, last paid %s short %s",
                f.getDial() * 100, f.getRescueMode(), g.fundEquityShare() * 100, m(g.fundTransferDue()), m(f.getTransferPaid()), m(f.getTransferShort()));
        double paid = 0;
        for (TreasuryFund.Resolution r : f.getResolutions()) paid += r.paid();
        say("  LIFE: paid in surplus %s cash %s hand %s, drawn %s; transfers %s (short %s); dividends market %s rescue %s; coupons %s; principal %s; face lost %s",
                m(f.getPaidInFromSurplus()), m(f.getPaidInFromCash()), m(f.getHandPaidIn()), m(f.getHandDrawnOut()),
                m(f.getTransfersPaid()), m(f.getTransfersShort()), m(f.getDividendsMarket()), m(f.getDividendsRescue()),
                m(f.getCoupons()), m(f.getPrincipal()), m(f.getBondFaceLost()));
        say("  LIFE: bought shares %s bonds %s; sold shares %s bonds %s (rescue %s); preferred bought %s divs %s redeemed %s; warrants back %s; warrant shares %,.3f; rescues %d paid %s; rescueCost %s",
                m(f.getSharesBought()), m(f.getBondsBought()), m(f.getSharesSold()), m(f.getBondsSold()), m(f.getRescueSold()),
                m(f.getPreferredBought()), m(f.getPreferredDividends()), m(f.getPreferredRedeemed()), m(f.getWarrantsBoughtBack()),
                f.getWarrantSharesTaken(), f.getResolutions().size(), m(paid), m(f.getRescueCost()));
        // Cash identity: what came in less what went out.
        double in = f.getPaidInFromSurplus() + f.getPaidInFromCash() + f.getHandPaidIn() + f.getDividendsMarket() + f.getDividendsRescue()
                + f.getCoupons() + f.getPrincipal() + f.getPreferredDividends() + f.getPreferredRedeemed() + f.getWarrantsBoughtBack()
                + f.getSharesSold() + f.getBondsSold();
        double out = f.getSharesBought() + f.getBondsBought() + f.getTransfersPaid() + f.getHandDrawnOut();
        say("  CASH IDENTITY: in %s - out %s = %s against its cash %s (gap %s)", m(in), m(out), m(in - out), m(f.getCash()), m(f.getCash() - (in - out)));
        // Since the fund began, exactly, from the counters: value + taken out - put in.
        double putIn = f.getPaidInFromSurplus() + f.getPaidInFromCash() + f.getHandPaidIn() + paid + f.getPreferredBought();
        double takenOut = f.getHandDrawnOut() + f.getTransfersPaid();
        double gain = g.fundValue() + takenOut - putIn;
        say("  SINCE IT BEGAN: put in %s (pay-ins %s, rescues %s, preferred %s); taken out %s (transfers %s, draws %s); worth %s; gain %s = %.1f%% of what was put in",
                m(putIn), m(f.getPaidInFromSurplus() + f.getPaidInFromCash() + f.getHandPaidIn()), m(paid), m(f.getPreferredBought()),
                m(takenOut), m(f.getTransfersPaid()), m(f.getHandDrawnOut()), m(g.fundValue()), m(gain), putIn > 0 ? 100 * gain / putIn : 0);
        double income = f.getDividendsMarket() + f.getDividendsRescue() + f.getCoupons() + f.getPreferredDividends();
        say("  ...of which income %s (dividends %s, coupons %s, preferred %s); price and the rest %s",
                m(income), m(f.getDividendsMarket() + f.getDividendsRescue()), m(f.getCoupons()), m(f.getPreferredDividends()), m(gain - income));

        say("  SHARES (price = last trade or fair; per share; ACB here = the probe's seed or its ledger):");
        say("  %-18s %12s %12s %10s %10s %7s %7s %7s %10s %10s %10s %10s %8s %8s %8s",
                "company", "held", "rescue", "price", "fair", "stake", "mkt%", "room", "value", "ACB", "unreal", "real.", "divYld", "1Y", "5Y");
        for (int c = 0; c < Equity.COMPANIES.length; c++) {
            if (reg.getShares(c) <= 0) continue;
            String name = Equity.COMPANIES[c];
            double held = reg.getCityShares(c), rescue = reg.getCityRescueShares(c);
            double price = ex.price(c);
            double v = held * price;
            double acb = FundTap.acbMarket[c] + FundTap.acbRescue[c];
            double[] series = h.aligned(HistorySave.priceKey(name));
            double now = ex.pricePerFoundingShare(c);
            String y1 = change(series, 12, now), y5 = change(series, 60, now);
            double mkt = reg.getShares(c) > 0 ? reg.getCityMarketShares(c) / reg.getShares(c) : 0;
            double room = TreasuryFund.OWNERSHIP_LIMIT * reg.getShares(c) - reg.getCityMarketShares(c);
            say("  %-18s %,12.3f %,12.3f %10.5f %10.5f %6.2f%% %6.2f%% %7.0f %10s %10s %10s %10s %7.2f%% %8s %8s",
                    name, held, rescue, price, ex.fair(c), reg.cityShare(c) * 100, mkt * 100, Math.max(0, room),
                    m(v), m(acb), m(v - acb), m(FundTap.realizedShare[c]), ex.yieldAt(reg, c, price) * 100, y1, y5);
            say("  %-18s   traded %s (last month %d), split x%s, in issue %,.0f, cap %s, div/sh/yr %.6f, lifetime divs to the city %s, this month %s; book: bid %.5f ask %.5f; asks at/under fair %,.3f in %d levels",
                    "", ex.hasTraded(c), ex.bookOf(c).lastTradeMonth(), fmtK(ex.getSplitFactor(c)), reg.getShares(c), m(ex.marketCap(reg, c)),
                    reg.dividendPerShareAnnual(c), m(reg.getLifetimeDividendsCity(c)), m(reg.getDividendCityThisMonth(c)),
                    ex.bestBid(c), ex.bestAsk(c), asksUnder(ex.bookOf(c), ex.fair(c)), levelsUnder(ex.bookOf(c), ex.fair(c)));
        }
        List<CorporateBond> all = bm.getBonds();
        int held = 0;
        for (CorporateBond b : all) if (b.city() > 0) held++;
        say("  BONDS: %d outstanding (%d issuers), the fund holds %d; face held %s", all.size(), bm.byIssuer().size(), held, m(bm.faceHeldByCity()));
        for (CorporateBond b : all) {
            if (!(b.city() > 0)) continue;
            double mp = bm.modelPrice(b, month);
            double acb = FundTap.bond.containsKey(b.id()) ? FundTap.bond.get(b.id())[0] : 0;
            double real = FundTap.bond.containsKey(b.id()) ? FundTap.bond.get(b.id())[1] : 0;
            double cps = FundTap.bond.containsKey(b.id()) ? FundTap.bond.get(b.id())[2] : 0;
            say("   #%-5d %-16s face %s of %s, coupon %.3f%%, due %s (%dm), value %.4f (yield %.3f%%, EL %.3f%%), last %.4f; worth %s, ACB %s, unreal %s, real %s, coupons since %s; book bid %.4f ask %.4f",
                    b.id(), b.issuer(), m(b.city()), m(b.face()), b.coupon() * 100, CityCalendar.formatShort(b.maturityMonth()),
                    b.remainingMonths(month), mp, bm.modelYield(b, month) * 100, bm.expectedLoss(b.issuer()) * 100,
                    bm.lastPrice(b), m(b.city() * mp), m(acb), m(b.city() * mp - acb), m(real), m(cps),
                    bm.bookOf(b).bestBid(), bm.bookOf(b).bestAsk());
        }
        say("  closed or gone bonds in the ledger: %s", closed(bm));
    }

    static String closed(BondMarket bm) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<Integer, double[]> e : FundTap.bond.entrySet()) {
            CorporateBond b = bm.bond(e.getKey());
            if (b == null || !(b.city() > 0)) sb.append(String.format("#%d real %s cpn %s; ", e.getKey(), m(e.getValue()[1]), m(e.getValue()[2])));
        }
        return sb.length() == 0 ? "none" : sb.toString();
    }

    static String fmtK(double k) { return k >= 1 ? String.format("%,.0f", k) : String.format("%.4f", k); }

    static String change(double[] s, int back, double now) {
        int i = s.length - 1 - back;
        if (i < 0 || Double.isNaN(s[i]) || !(s[i] > 0)) return "n/a";
        return String.format("%+.1f%%", 100 * (now / s[i] - 1));
    }

    static double asksUnder(OrderBook b, double limit) {
        double q = 0;
        for (OrderBook.Level l : b.levels(OrderBook.Side.SELL)) if (l.price() <= limit) q += l.quantity();
        return q;
    }

    static int levelsUnder(OrderBook b, double limit) {
        int k = 0;
        for (OrderBook.Level l : b.levels(OrderBook.Side.SELL)) if (l.price() <= limit) k++;
        return k;
    }

    static void quote(Game g, int c, double amount) {
        Exchange ex = g.getExchange();
        Equity reg = g.getEquity();
        double fair = ex.fair(c);
        say("  fair %.6f, price %.6f (%s), best bid %.6f, best ask %.6f; units at fair %,.4f", fair, ex.price(c),
                ex.hasTraded(c) ? "last trade" : "fair, never traded", ex.bestBid(c), ex.bestAsk(c), amount / fair);
        double left = amount / fair, spent = 0, got = 0;
        List<OrderBook.Level> asks = ex.bookOf(c).levels(OrderBook.Side.SELL);
        for (OrderBook.Level l : asks) {
            if (l.price() > fair || left <= 0) break;
            double take = Math.min(left, l.quantity());
            say("    resting ask %.6f x %,.4f (%d orders): would take %,.4f", l.price(), l.quantity(), l.orders(), take);
            spent += take * l.price(); got += take; left -= take;
        }
        say("  ON TODAY'S BOOK: %,.4f shares for %s (avg %.6f), %,.4f would rest at fair; asks over fair: %d levels, the first %s",
                got, m(spent), got > 0 ? spent / got : 0, left, (int) asks.stream().filter(l -> l.price() > fair).count(),
                asks.stream().filter(l -> l.price() > fair).findFirst().map(l -> String.format("%.6f x %,.3f", l.price(), l.quantity())).orElse("-"));
        double room = TreasuryFund.OWNERSHIP_LIMIT * reg.getShares(c) - reg.getCityMarketShares(c);
        say("  10%% CAP: market book %.3f%% -> %.3f%% if it all filled; room %,.3f shares = %s at fair",
                100 * reg.getCityMarketShares(c) / reg.getShares(c), 100 * (reg.getCityMarketShares(c) + amount / fair) / reg.getShares(c),
                room, m(room * fair));
        say("  the fund's cash %s; the rule's own bids resting now: %s", m(g.getFund().getCash()),
                ex.bookOf(c).bids().stream().filter(o -> o.who().equals(Exchange.FUND)).map(o -> String.format("%,.3f @ %.6f", o.quantity(), o.price())).toList());
    }

    static void bondQuote(Game g, CorporateBond b, double amount) {
        BondMarket bm = g.getBondMarket();
        int month = g.getMonth();
        double v = bm.modelPrice(b, month);
        say("  #%d %s: face %s, coupon %.3f%%, due %s, value %.4f a unit of face (yield %.3f%%), last trade %.4f; face at value %s",
                b.id(), b.issuer(), m(b.face()), b.coupon() * 100, CityCalendar.formatShort(b.maturityMonth()), v,
                bm.modelYield(b, month) * 100, bm.lastPrice(b), m(amount / v));
        double left = amount / v, spent = 0, got = 0;
        for (OrderBook.Level l : bm.bookOf(b).levels(OrderBook.Side.SELL)) {
            if (l.price() > v || left <= 0) break;
            double take = Math.min(left, l.quantity());
            spent += take * l.price(); got += take; left -= take;
        }
        say("  ON TODAY'S BOOK: %s face for %s, %s would rest at value; holders: households %s bank %s world %s companies %s city %s",
                m(got), m(spent), m(left), m(b.households()), m(b.bank()), m(b.world()), m(b.companiesTotal()), m(b.city()));
    }

    static void card(Game g, int c) {
        Equity reg = g.getEquity();
        Exchange ex = g.getExchange();
        double held = reg.getCityShares(c), price = ex.price(c);
        double acb = FundTap.acbMarket[c] + FundTap.acbRescue[c];
        double v = held * price;
        say("\n  POSITION CARD %s: %,.4f shares (rescue %,.4f), avg cost %.6f, ACB %s, value %s at %.6f, unrealized %s (%.2f%%), realized %s, dividends since founding %s; bought %,.4f sold %,.4f by the taps",
                Equity.COMPANIES[c], held, reg.getCityRescueShares(c), held > 0 ? acb / held : 0, m(acb), m(v), price,
                m(v - acb), acb > 0 ? 100 * (v - acb) / acb : 0, m(FundTap.realizedShare[c]), m(reg.getLifetimeDividendsCity(c)),
                FundTap.boughtShares[c], FundTap.soldShares[c]);
    }

    static void bondCard(Game g, int id) {
        BondMarket bm = g.getBondMarket();
        CorporateBond b = bm.bond(id);
        double[] x = FundTap.bond.getOrDefault(id, new double[3]);
        if (b == null) { say("  POSITION CARD bond #%d: gone; realized %s", id, m(x[1])); return; }
        double v = b.city() * bm.modelPrice(b, g.getMonth());
        say("  POSITION CARD bond #%d: face %s, avg cost %.4f a unit, ACB %s, value %s, unrealized %s (%.2f%%), realized %s, coupons by the taps %s",
                id, m(b.city()), b.city() > 0 ? x[0] / b.city() : 0, m(x[0]), m(v), m(v - x[0]), x[0] > 0 ? 100 * (v - x[0]) / x[0] : 0,
                m(x[1]), m(x[2]));
    }
}
