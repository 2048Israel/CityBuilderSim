# TimeChart.java - 1,540 lines · 84 methods · 20 constants · interface

`ham/citybuildersim/ui/TimeChart.java` - generated 2026-10-06 by CodeMap; line numbers are as of that run.

> A chart of months (0.7.23): lines over a window the player drags, wheels
> and ranges through, years on its axis, recessions named on their bands,
> the episodes on a lane under it, the player's decisions as flags, a
> crosshair that reads every line, and an overview of the whole history
> with the window on it - or, small, the same lines and years without the
> controls, and since 0.7.38 the decisions it is handed on a smaller lane.
> 
> WHY. Jerus: "in teh graphs you should be able to pan the chart just like
> yahoo finance does if you get what i mean, and it actually have interactive
> graph, and like also the crisis labels and all". City History drew a
> JavaFX LineChart - a node per point, three chips for the window, a month
> number on the axis that nobody could read as a date, grey bands nothing
> named - and a LineChart has no pan, no wheel and one y-axis. This draws on
> a canvas: one pass a frame, every month of a four-thousand-month city
> without thinning it to keep the node count down, two axes of its own, and
> the bands, lanes and flags in the same coordinates as the lines.
> 
> NOTHING HERE IS ARITHMETIC ABOUT THE CITY. The window, the ticks, the
> scales, the lanes and the flags are ChartModel's, which ChartCheck holds
> to, and since 0.7.50 so are the copy of what it is handed that it draws
> from and the stack's runs and reach (setData(); ChartModel, WHAT A CHART
> DRAWS FROM); the bands and episodes YearBook's; the decisions the
> DecisionLog's; each line's values the screen's, in its stored units, with
> the screen's own formatter to read them. This draws and listens.

**Uses:** [Palette](Palette.md) (93), [ChartModel](ChartModel.md) (72), [YearBook](YearBook.md) (35), [CityCalendar](CityCalendar.md) (17), [DecisionLog](DecisionLog.md) (4), [HistoryScreen](HistoryScreen.md) (2), [UserInterface](UserInterface.md) (1), [GameLog](GameLog.md) (1)

**Used by (9):** [BankScreen](BankScreen.md), [FinancesScreen](FinancesScreen.md), [FundScreen](FundScreen.md), [GovernmentScreen](GovernmentScreen.md), [HistoryScreen](HistoryScreen.md), [Pieces](Pieces.md), [PolicyScreen](PolicyScreen.md), [TradeScreen](TradeScreen.md), [UserInterface](UserInterface.md)

## Sections

| line | section |
|---:|---|
| 62 | · the dials |
| 115 | · what it is handed |
| 177 | · its nodes |
| 191 | · geometry |
| 196 | · interaction |
| 297 | WHAT IT DRAWS, HANDED OVER ON EVERY REBUILD |
| 435 | THE LEGEND AND THE RANGES |
| 487 | THE GEOMETRY |
| 537 | THE SCALES, FIT TO WHAT IS SHOWN |
| 606 | DRAWING |
| 1067 | · the overview |
| 1166 | WHAT IS UNDER THE POINTER, AND THE CARD |
| 1381 | LISTENING: THE DRAG, THE WHEEL, THE CLICK, THE OVERVIEW |
| 1513 | · small helpers |

## Constants

| line | constant | value | says |
|---:|---|---|---|
| 65 | `TimeChart.AXIS_W` | `64` | How wide a y-axis's labels are held. |
| 68 | `TimeChart.NO_AXIS_W` | `14` | The margin on a side with no axis. |
| 71 | `TimeChart.BAND_ROW` | `20` | The row above the plot that recessions' names sit in. |
| 74 | `TimeChart.TIME_ROW` | `20` | The row under the plot that the years sit in. |
| 77 | `TimeChart.EPISODE_ROW` | `18` | One row of the episode lane. |
| 80 | `TimeChart.FLAG_ROW` | `24` | The decision lane. |
| 83 | `TimeChart.SMALL_FLAG_ROW` | `18` | ...on a small chart handed decisions (0.7.38): the same lane, smaller. |
| 86 | `TimeChart.OVERVIEW` | `52` | The overview strip under the lanes. |
| 89 | `TimeChart.HANDLE` | `7` | How close, in pixels, the pointer must be to the overview window's edge to take it. |
| 92 | `TimeChart.FLAG_GAP` | `16` | A flag closer than this many pixels to the first of the group before it is drawn in that group, as one flag with the count. |
| 95 | `TimeChart.RECESSION_SHADE` | `.10` | How strongly a recession is shaded: enough to see, not enough to read as a colour. |
| 98 | `TimeChart.DRAG_SLOP` | `3` | How far a press may wander and still be a click rather than a drag. |
| 101 | `TimeChart.SETTLE_MS` | `280` | How long the window must rest before the page under the chart is redrawn for it, in milliseconds. |
| 104 | `TimeChart.CARD_W` | `300` | The card's widest. |
| 107 | `TimeChart.NOTCH` | `40` | A wheel notch, in the pixels JavaFX reports it as. |
| 110 | `TimeChart.WHEEL_OWNER` | `"TimeChart.wheel"` | Which node owns the wheel: the window's page-scroll filter leaves a wheel over this alone (UserInterface). |
| 113 | `TimeChart.OVERHANG` | `2000` | How far above and below its own box the chart's clip reaches (0.7.40): it cuts the sides only. |
| 774 | `TimeChart.MARK_REACH` | `5` | How near a mark the pointer must be, in pixels, for the card to say it (0.7.45). |
| 1344 | `TimeChart.CARD_DECISIONS` | `10` | At most this many decisions are listed on a flag's card; the rest are counted. |
| 1516 | `TimeChart.MEASURE` | `new javafx.scene.text.Text()` | One Text node, reused to measure a string's width in a font (textWidth()). |

## Fields (state)

| line | field | says |
|---:|---|---|
| 160 | `private final ChartModel window` |  |
| 161 | `private final Set<String> hidden` |  |
| 162 | `private final boolean main` |  |
| 164 | `private List<Integer> months` |  |
| 165 | `private List<Line> lines` |  |
| 166 | `private Axis left, right` |  |
| 167 | `private boolean squashed, log` |  |
| 168 | `private Stack stack` |  |
| 169 | `private List<YearBook.Band> bands` |  |
| 170 | `private List<YearBook.Episode> episodes` |  |
| 171 | `private int[] lanes` |  |
| 172 | `private List<ChartModel.Flag> flags` |  |
| 174 | `private List<ChartModel.Mark> marks` | What the model did on its own that a line answers to (0.7.45: the basket's links), drawn over the plot on the big chart. |
| 175 | `private String emptySays` |  |
| 179 | `private final Canvas plot` |  |
| 180 | `private final Canvas strip` |  |
| 181 | `private final Pane over` |  |
| 182 | `private final VBox card` |  |
| 183 | `private final FlowPane legend` |  |
| 184 | `private final HBox ranges` |  |
| 185 | `private final HBox lead` |  |
| 186 | `private final Label fullButton` |  |
| 187 | `private final Label spanSays` |  |
| 188 | `private final Label hint` |  |
| 189 | `private final HBox toolbar` |  |
| 193 | `private double width` |  |
| 194 | `private double plotLeft, plotRight, top` |  |
| 198 | `private double hoverX` |  |
| 199 | `private Object pinned` |  |
| 200 | `private double pinnedX` |  |
| 201 | `private double pressX` |  |
| 202 | `private double pressLo, pressHi, pressMonth` |  |
| 203 | `private boolean dragging` |  |
| 204 | `private int stripMode` |  |
| 205 | `private boolean full` |  |
| 206 | `private final List<Runnable> followers` |  |
| 207 | `private Runnable onSettled, onFullScreen` |  |
| 208 | `private final javafx.animation.PauseTransition settle` |  |
| 633 | `private boolean faultLogged` | Whether this chart has written a fault to the log: once a chart, so a fault on every frame is one entry (0.7.50). |

## Methods, in file order, under their sections

| line | len | member | says |
|---:|---:|---|---|
| 60 | 1481 | **type** `final class TimeChart extends VBox` | A chart of months (0.7.23): lines over a window the player drags, wheels and ranges through, years on its axis, recessions named on their bands, the episodes on a lane under it, the player's decisions as flags, a cros... |

### the dials (lines 62-114)

### what it is handed (lines 115-176)

| line | len | member | says |
|---:|---:|---|---|
| 123 | 16 | **type** `record Line(String key, String label, String colour, int side, double[] values, DoubleUnaryOperator toPlot,...` | One line: its key and name, its colour, the axis it reads against (0 left, 1 right), its values in their stored units aligned to the months, what turns a stored value into the axis's units, how a stored value is read ... |
| 126 | 4 | `Line(String key, String label, String colour, int side, double[] values, DoubleUnaryOperator toPlot, DoubleFunction<String> rea...` _(in TimeChart.Line)_ | ...drawn solid, as every line was until 0.7.45. |
| 132 | 1 | `Line asDashed()` _(in TimeChart.Line)_ | The same line drawn dashed (0.7.45): what people expect beside what happened. |
| 135 | 3 | `Line alignedTo(int n)` _(in TimeChart.Line)_ | The same line with its own copy of its values, exactly n months long (0.7.50; ChartModel.aligned()). |
| 141 | 1 | **type** `record Axis(java.util.function.BiFunction<Double, Double, String> tick, boolean fromZero)` | One value axis: what a gridline says, from the value and the step; and whether it starts at zero. |
| 144 | 15 | **type** `record Stack(double[][] layers, String[] names, String[] colours, DoubleUnaryOperator toPlot, DoubleFunctio...` | Layers stacked from zero under the first line (GDP in layers, 0.7.6): their values, names and colours. |
| 147 | 5 | `Stack alignedTo(int n)` _(in TimeChart.Stack)_ | The same stack with its own copy of every layer, exactly n months long (0.7.50; ChartModel.aligned()). |
| 154 | 1 | `String name(int p)` _(in TimeChart.Stack)_ | Layer p's name, or nothing for a layer handed no name. |
| 157 | 1 | `String colour(int p)` _(in TimeChart.Stack)_ | Layer p's colour, or the muted ink for a layer handed none. |

### its nodes (lines 177-190)

### geometry (lines 191-195)

### interaction (lines 196-296)

| line | len | member | says |
|---:|---:|---|---|
| 217 | 79 | `TimeChart(ChartModel window, Set<String> hidden, boolean main)` | one draws the decision lane alone, and only when it is handed flags) |

### WHAT IT DRAWS, HANDED OVER ON EVERY REBUILD (lines 297-434)

| line | len | member | says |
|---:|---:|---|---|
| 313 | 5 | `void setData(List<Integer> months, List<Line> lines, Axis left, Axis right, boolean squashed, boolean log, Stack stack, List<Ye...` | Everything the chart draws. |
| 325 | 29 | `void setData(List<Integer> months, List<Line> lines, Axis left, Axis right, boolean squashed, boolean log, Stack stack, List<Ye...` | ...and the marks over the plot (0.7.45): the basket's links, which City History hands the big chart while it draws an index line. |
| 356 | 3 | `private static<T> List<T> fixed(List<T> list)` | A list as the chart keeps it: its own copy, so the caller's can change afterwards. |
| 360 | 4 | `private Object sameBand(YearBook.Band b)` |  |
| 366 | 5 | `void setSize(double width, double plotHeight)` | The width the chart is drawn at, and the plot's height; the lanes and the overview take what they need. |
| 373 | 4 | `double heightBesidePlot()` | The height everything but the plot takes, for a caller fitting the chart to a space (full screen). |
| 379 | 1 | `void follow(TimeChart leader)` | Called with nothing when the window moves - a chart that shows the same window redraws. |
| 382 | 1 | `void onSettled(Runnable r)` | What runs once the window has rested: the screen's redraw, for the readings that follow the window. |
| 385 | 1 | `void onFullScreen(Runnable r)` | What the full-screen button does. |
| 388 | 1 | `void withoutFullScreen()` | A big chart on another tab (0.7.35: Trade's rate over time) has no full-screen button: only City History lays a chart out full screen. |
| 391 | 1 | `boolean isDragging()` | True while a drag is in hand on a chart that is on screen: a month's redraw waits for the release. |
| 401 | 7 | `void letGo()` | Leaves the chart at rest (after the docs pass): no drag in hand, no overview edge held, no redraw waiting. |
| 410 | 1 | `HBox lead()` | The slot at the left of the toolbar: the title and the date, in full screen. |
| 413 | 21 | `void setFull(boolean full)` | Full screen or not: the button's words and icon. |

### THE LEGEND AND THE RANGES (lines 435-486)

| line | len | member | says |
|---:|---:|---|---|
| 439 | 24 | `private void buildLegend()` |  |
| 464 | 11 | `private void buildRanges()` |  |
| 477 | 9 | `private void paintRanges()` | The range button lit is the one the window still shows exactly; a pan or a wheel lights none. |

### THE GEOMETRY (lines 487-536)

| line | len | member | says |
|---:|---:|---|---|
| 491 | 1 | `private int laneRows()` |  |
| 493 | 5 | `private boolean anyOnRight()` |  |
| 499 | 1 | `private double plotBottom()` |  |
| 500 | 1 | `private double episodesTop()` |  |
| 501 | 1 | `private double flagsTop()` |  |
| 502 | 1 | `private double canvasHeight()` |  |
| 509 | 1 | `private boolean flagLane()` | Whether the decision lane is drawn: always on the big chart, and on a small one handed a decision to show (0.7.38: the Bank's rates and Finances' debt and rate were handed theirs and drew none). |
| 512 | 1 | `private double flagRow()` | The lane's height: the big chart's, or a small chart's. |
| 514 | 16 | `private void layoutCanvases()` |  |
| 531 | 1 | `private double plotW()` |  |
| 533 | 1 | `private double xOf(double month)` |  |
| 535 | 1 | `private double monthAt(double x)` |  |

### THE SCALES, FIT TO WHAT IS SHOWN (lines 537-605)

| line | len | member | says |
|---:|---:|---|---|
| 541 | 1 | `private boolean shown(Line l)` |  |
| 544 | 11 | `private double plotted(Line l, int i, double[] own)` | A line's value at index i in the axis's units, or NaN: through toPlot, the log, or its own low-to-high. |
| 557 | 5 | `private double[][] ownRanges()` | Each shown line's low and high in the window, for the squashed chart. |
| 564 | 36 | `private ChartModel.Scale[] scales(double[][] own)` | The two axes' scales for the window: {left, right}; null for a side with nothing on it. |
| 602 | 3 | `private double[] stackReach()` | What the stack's first three layers reach in the window, summed from zero (ChartModel.stackReach()). |

### DRAWING (lines 606-1066)

| line | len | member | says |
|---:|---:|---|---|
| 624 | 7 | `void draw()` | Draws the chart, its overview and its card, and lights the range button the window still matches. |
| 636 | 5 | `private void fault(String what, RuntimeException e)` | A fault in this chart, written to the log with its stack trace the first time only. |
| 647 | 15 | `private void skipFrame(RuntimeException e)` | A frame that failed, skipped: the state a drawing step saved put back (each saves one at a time, and a restore with nothing saved does nothing), the canvases cleared, the card hidden, and the fault logged. |
| 668 | 9 | `private<T extends javafx.event.Event> javafx.event.EventHandler<T> guarded(javafx.event.EventHandler<T> h)` | A handler that cannot throw into JavaFX's event dispatch (0.7.50): what it throws is the chart's fault, logged once, and the event is dropped. |
| 679 | 65 | `private void paint()` | One frame: draw()'s, which catches what it throws. |
| 745 | 27 | `private void drawBands(GraphicsContext g, double bottom)` |  |
| 777 | 17 | `private void drawMarks(GraphicsContext g, double bottom)` | The marks in view: a dashed hairline in the muted ink through the plot, and its word at the plot's top (0.7.45). |
| 796 | 8 | `private ChartModel.Mark markAt(double x)` | The mark within MARK_REACH of the pointer, or null. |
| 805 | 19 | `private void drawStack(GraphicsContext g, ChartModel.Scale s, double bottom)` |  |
| 825 | 12 | `private void fillRun(GraphicsContext g, List<double[]> run)` |  |
| 838 | 5 | `private void clipToPlot(GraphicsContext g)` |  |
| 845 | 45 | `private boolean drawLines(GraphicsContext g, ChartModel.Scale[] scale, double[][] own, double bottom)` | The lines, each month a point, or each bucket of months one where they outnumber the pixels. |
| 891 | 25 | `private void drawAxes(GraphicsContext g, ChartModel.Scale[] scale, double bottom)` |  |
| 917 | 20 | `private void drawTime(GraphicsContext g, List<ChartModel.Tick> ticks, double bottom)` |  |
| 944 | 3 | `public static String episodeColour(String kind)` | An episode's colour: a crisis or a depression is bad news, the rest are a watch - verdicts, which is what these are. |
| 948 | 33 | `private void drawEpisodes(GraphicsContext g)` |  |
| 983 | 7 | `static String flagColour(String kind)` | A flag's colour: the area its decision is about - money blue, people teal, building pink. |
| 991 | 3 | `private List<ChartModel.Cluster> clusters()` |  |
| 995 | 47 | `private void drawFlags(GraphicsContext g)` |  |
| 1043 | 23 | `private void drawCrosshair(GraphicsContext g, ChartModel.Scale[] scale, double[][] own, double bottom)` |  |

### the overview (lines 1067-1165)

| line | len | member | says |
|---:|---:|---|---|
| 1069 | 3 | `private double stripX(double month)` |  |
| 1073 | 3 | `private double stripMonth(double x)` |  |
| 1077 | 88 | `private void drawStrip()` |  |

### WHAT IS UNDER THE POINTER, AND THE CARD (lines 1166-1380)

| line | len | member | says |
|---:|---:|---|---|
| 1170 | 3 | `private boolean inPlot(double x, double y)` |  |
| 1175 | 1 | `private Object hovered()` | The band, the episode or the flag under the pointer, or null. |
| 1177 | 33 | `private Object itemAt(double x, double y)` |  |
| 1212 | 34 | `private void fillCard(ChartModel.Scale[] scale, double[][] own)` | Fills the card for what is pinned, or else what is under the pointer; hides it when there is nothing. |
| 1247 | 7 | `private static Label caption(String text, String colour)` |  |
| 1255 | 7 | `private static Label head(String text)` |  |
| 1263 | 19 | `private static HBox row(String colour, String name, String value)` |  |
| 1283 | 30 | `private void crosshairCard(YearBook.Band in)` |  |
| 1314 | 17 | `private void bandCard(YearBook.Band b)` |  |
| 1332 | 10 | `private void episodeCard(YearBook.Episode e)` |  |
| 1346 | 32 | `private void flagCard(ChartModel.Cluster c)` |  |
| 1379 | 1 | `private static String months(int n)` |  |

### LISTENING: THE DRAG, THE WHEEL, THE CLICK, THE OVERVIEW (lines 1381-1512)

| line | len | member | says |
|---:|---:|---|---|
| 1385 | 56 | `private void listen()` |  |
| 1442 | 13 | `private void wheel(ScrollEvent e)` |  |
| 1456 | 43 | `private void listenToStrip()` |  |
| 1501 | 5 | `private void moved(boolean settled)` | The window moved: this chart, the charts that follow it, and - once it rests - the page. |
| 1508 | 4 | `void unpin()` | Drops a pinned card: going into full screen and coming out of it, Esc's way out included (HistoryScreen.setChartFull()). |

### small helpers (lines 1513-1540)

| line | len | member | says |
|---:|---:|---|---|
| 1518 | 5 | `static double textWidth(String s, Font f)` |  |
| 1525 | 9 | `static String fit(String text, double room, Font f)` | The text, cut with an ellipsis to fit `room` pixels; empty when not even a few letters fit. |
| 1535 | 5 | `private static String trim(double v)` |  |

