# SectorState.java - 215 lines · 6 methods · 0 constants · model

`ham/citybuildersim/SectorState.java` - generated 2026-10-05 by CodeMap; line numbers are as of that run.

> One sector, as a save carries it.
> 
> KEYED BY NAME, EVERYWHERE. The sector by its key, the stocks by the good's
> name, the purchases by the supplier's key, the extras by whatever the
> sector called them. Gson matches by name, so a save from a build with a
> sector or a good this one does not have loses that line and not the load,
> and a build that adds a field reads zero from an older save - which is
> what the older city had.
> 
> This replaced five differently-shaped report arrays, three arrays indexed
> by BuildingType.ordinal(), and a dozen loose fields (commercialCash,
> industryFoodInventory, retailFillBasis...) that DataSave carried one by
> one. Jerus: "clean break" - the save format moved, and nothing here reads
> the old shape.

**Uses:** [Sector](Sector.md) (16), [Good](Good.md) (13), [Statement](Statement.md) (4)

**Used by (7):** [DataSave](DataSave.md), [EconomyManager](EconomyManager.md), [RailCheck](RailCheck.md), [Sector](Sector.md), [SectorBooksCheck](SectorBooksCheck.md), [Sectors](Sectors.md), [VanCheck](VanCheck.md)

## Fields (state)

| line | field | says |
|---:|---|---|
| 24 | `public String key` |  |
| 25 | `public double cash` |  |
| 28 | `public double interest, propertyTax, maintenance, taxRate` | The three bills of the month and the rate it was taxed at, as set at the top of it. |
| 39 | `public boolean vansKnown` | Whether this sector's van fleet is a fact about the sector. |
| 41 | `public Map<String, Double> stock` |  |
| 42 | `public Map<String, Double> pantry` |  |
| 43 | `public Map<String, Double> pantryUsed` |  |
| 45 | `public LedgerState ledger` |  |
| 46 | `public StatementState statement` |  |
| 56 | `public Map<String, Double> exported` | The month's trade in units by good name: what it shipped and what it landed in the month the save was taken (A1, 0.7.46). |
| 57 | `public Map<String, Double> imported` |  |
| 69 | `public double atHome, abroad` |  |
| 97 | `public Map<String, Double> extras` | A sector's own state - a price it walks, an order book - by name. |
| 101 | `public double localSales, exports, otherRevenue, imports, salesToHouseholds` |  |
| 102 | `public Map<String, Double> purchasesBySupplier` |  |
| 103 | `public Map<String, Double> unitsSold` |  |
| 104 | `public Map<String, Double> unitsBought` |  |
| 105 | `public Map<String, SplitState> sold` |  |
| 106 | `public Map<String, SplitState> bought` |  |
| 108 | `public Map<String, Double> otherInputs` | The named non-goods part of the month's purchases. |
| 110 | `public double paidEarlier` | Sector.Ledger.paidEarlier (0.7.8); an older save reads none. |
| 112 | `public Map<String, Double> capitalBySupplier` | Sector.Ledger.capitalBySupplier (0.7.19): the builders' work on its premises this month, which the tax credit is struck on at the next strike. |
| 159 | `public double revenue, inputs, payroll, electricity, water, maintenance` |  |
| 160 | `public double operatingIncome, interest, propertyTax, salesTax, preTaxIncome, profitTax, netIncome` |  |
| 161 | `public double localSales, exports, otherRevenue, salesToHouseholds, localPurchases, imports` |  |
| 162 | `public Map<String, Double> purchasesBySupplier` |  |
| 163 | `public Map<String, SplitState> sold` |  |
| 164 | `public Map<String, SplitState> bought` |  |
| 165 | `public Map<String, Double> otherParts` |  |
| 167 | `public Map<String, Double> otherInputs` | The named non-goods part of the input line. |
| 169 | `public double paidEarlier` | Sector.Statement.paidEarlier (0.7.8); an older save reads none. |
| 171 | `public Map<String, Double> capitalBySupplier` | Sector.Statement.capitalBySupplier and capitalTaxCredit (0.7.19); an older save reads none. |
| 172 | `public double capitalTaxCredit` |  |

## Methods, in file order

| line | len | member | says |
|---:|---:|---|---|
| 22 | 194 | **type** `public final class SectorState` | One sector, as a save carries it. |
| 68 | 3 | **type** `public static final class SplitState` | A good's money in a save: what it sold or bought at home and abroad. |
| 72 | 10 | `static Map<String, SplitState> splitsOf(Map<Good, Sector.Split> from)` |  |
| 83 | 12 | `static Map<Good, Sector.Split> splitsTo(Map<String, SplitState> from)` |  |
| 100 | 56 | **type** `public static final class LedgerState` | The month in progress, unstruck. |
| 114 | 17 | `static LedgerState of(Sector.Ledger l)` _(in SectorState.LedgerState)_ |  |
| 132 | 23 | `Sector.Ledger toLedger()` _(in SectorState.LedgerState)_ |  |
| 158 | 57 | **type** `public static final class StatementState` | The month last struck. |
| 174 | 19 | `static StatementState of(Sector.Statement t)` _(in SectorState.StatementState)_ |  |
| 194 | 20 | `Sector.Statement toStatement()` _(in SectorState.StatementState)_ |  |

