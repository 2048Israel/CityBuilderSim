# HistorySave.java - 1,419 lines · 44 methods · 1 constants · model

`ham/citybuildersim/HistorySave.java` - generated 2026-10-06 by CodeMap; line numbers are as of that run.

> Every month the city has ever lived, one number at a time.
> 
> WHY THE SERIES ARE NAMED FIELDS AND NOT A MAP
> 
> A Map<String, List<Double>> would be shorter and would let a series be added
> without touching anything. It is not used, and the reason is on disk: this
> class IS the file format. Gson matches JSON to fields BY NAME, so a history
> written before a series existed still loads into this build - the missing
> list simply stays empty - and a history written by this build still loads
> into an older one, which ignores what it does not recognise. Moving to a map
> would change the shape of every history file ever written and break both
> directions at once, to save a few lines.
> 
> WHAT A SHORT SERIES MEANS
> 
> It means the city was ALIVE before that number was being kept, so the series
> lines up with the END of the month axis and not the start. A save from before
> sickness was recorded has 400 months and no sick rate; play ten more and it
> has 410 months and ten sick rates, describing months 401-410. aligned() is
> the only correct way to read one, and the graph goes through it - drawing a
> short series from the left would silently place the last decade's data in the
> founding years.
> 
> WHAT IS NOT HERE
> 
> Anything derivable. Unemployment is workforce and jobs, GDP per capita is GDP
> and population, the average wage is the wage bill and the workforce. Storing
> a derived series would double the file to hold numbers that can disagree with
> the ones they came from, and the first time they did, nothing would say which
> was right. Derived() computes them on the way to the screen.

**Uses:** [AgeBand](AgeBand.md) (7), [PriceIndex](PriceIndex.md) (6), [Crime](Crime.md) (4), [FamilyStructure](FamilyStructure.md) (3), [Equity](Equity.md) (3), [GameFiles](GameFiles.md) (2), [Game](Game.md) (1), [EconomyManager](EconomyManager.md) (1), [NationalAccounts](NationalAccounts.md) (1), [PopulationManager](PopulationManager.md) (1), [PopulationCohorts](PopulationCohorts.md) (1), [Migration](Migration.md) (1), [LabourMarket](LabourMarket.md) (1), [JobType](JobType.md) (1), [WageBand](WageBand.md) (1), [Education](Education.md) (1), [Good](Good.md) (1), [ForeignAccounts](ForeignAccounts.md) (1), [Bank](Bank.md) (1), [CentralBank](CentralBank.md) (1), [Unemployment](Unemployment.md) (1), [FamilyModel](FamilyModel.md) (1), [Sickness](Sickness.md) (1), [Exchange](Exchange.md) (1), [Sector](Sector.md) (1), [Retail](Retail.md) (1), [HouseholdBalance](HouseholdBalance.md) (1)

**Used by (25):** [BankScreen](BankScreen.md), [ChartCheck](ChartCheck.md), [ChartModel](ChartModel.md), [DeathRecordCheck](DeathRecordCheck.md), [EconomyManager](EconomyManager.md), [FinancesScreen](FinancesScreen.md), [FundScreen](FundScreen.md), [FundView](FundView.md), [Game](Game.md), [GovernmentScreen](GovernmentScreen.md), [HistoryCheck](HistoryCheck.md), [HistoryScreen](HistoryScreen.md), [HouseholdMemoryCheck](HouseholdMemoryCheck.md), [LandScreen](LandScreen.md), [PeopleScreen](PeopleScreen.md), [PolicyScreen](PolicyScreen.md), [ReadPathCheck](ReadPathCheck.md), [SaveFileCheck](SaveFileCheck.md), [ScaleCheck](ScaleCheck.md), [SectorScreen](SectorScreen.md), [ServicesScreen](ServicesScreen.md), [TradeScreen](TradeScreen.md), [UserInterface](UserInterface.md), [YearBook](YearBook.md), [YearBookCheck](YearBookCheck.md)

## Sections

| line | section |
|---:|---|
| 46 | · THE AXIS |
| 55 | · money |
| 65 | · people |
| 106 | · what throttles |
| 123 | · prices |
| 134 | · the edge |
| 161 | · money and credit |
| 188 | · what the bank could carry, and how hard |
| 209 | · the price of money (0.7.7) |
| 224 | · the bank's capital (0.7.8) |
| 253 | · the budget |
| 269 | · housing |
| 279 | · school and care |
| 285 | · outside the families |
| 314 | · THE CENTRAL BANK, 0.7.0. The Money page's year and the year book's: |
| 328 | · THE LONG SICK, 2026-09-11. How many have been sick more than two |
| 336 | · THE HOUSEHOLDS, BY SHAPE, 2026-09-11. Jerus: a record of how many |
| 346 | · WHO DIED, 2026-09-11. The month's dead by age band, and how many of |
| 362 | · CRIME, THE POLICE AND THE PRISONS, 2026-09-11 (night). The rate a |
| 384 | · what runs out |
| 388 | · the market |
| 412 | · the sectors (0.7.4) |
| 437 | · GDP in layers (0.7.6) |
| 454 | · the city's fund (0.7.39) |
| 470 | · the new price model, read (0.7.45) |
| 522 | RECORDING |
| 595 | · · the edge |
| 605 | · · money and credit |
| 650 | · · the budget |
| 660 | · · housing |
| 665 | · · school and care |
| 672 | · · outside the families |
| 719 | · · what runs out |
| 723 | · · the market |
| 736 | · · the sectors |
| 744 | · · the new price model, read (0.7.45) |
| 766 | · · the city's fund (0.7.39) |
| 1019 | READING |
| 1056 | · a series' record, counted (0.7.9) |

## Constants

| line | constant | value | says |
|---:|---|---|---|
| 794 | `HistorySave.SHARE_PRICE_DIGITS` | `6` | Share prices are recorded to six significant figures: a consolidated company's price per founding share is far under a ten-thousandth (C5). |

## Fields (state)

| line | field | says |
|---:|---|---|
| 53 | `private List<Integer> month` |  |
| 56 | `private List<Double> cash` |  |
| 57 | `private List<Double> gdp` |  |
| 58 | `private List<Double> debt` |  |
| 59 | `private List<Double> interestRate` |  |
| 62 | `private List<Double> revenue` | Government revenue and what it kept, both monthly. |
| 63 | `private List<Double> surplus` |  |
| 66 | `private List<Long> jobs` |  |
| 67 | `private List<Long> workforce` |  |
| 76 | `private List<Long> outOfWork` | The people out of work - the labour force less the posts FILLED, the People screen's figure (PopulationManager.getUnemployed()). |
| 77 | `private List<Long> population` |  |
| 80 | `private List<Long> births` | The four flows that move the population, and only these four move it. |
| 81 | `private List<Long> deaths` |  |
| 82 | `private List<Long> arrivals` |  |
| 83 | `private List<Long> departures` |  |
| 86 | `private List<Double> totalWage` | The wage BILL, not the average - the average needs the workforce too. |
| 89 | `private List<Double> minimumWage` | The dial the player sets, and what the labour market did with it. |
| 99 | `private List<Double> unskilledPremium` | What an unskilled hour costs relative to its base, and how much of the workforce has any training at all. |
| 100 | `private List<Double> skilledShare` |  |
| 103 | `private List<Double> schoolCoverage` | The schools: how much of the basic ladder is covered, and what it costs. |
| 104 | `private List<Double> schoolBill` |  |
| 107 | `private List<Double> energyRatio` |  |
| 108 | `private List<Double> waterRatio` |  |
| 109 | `private List<Double> roadRatio` |  |
| 110 | `private List<Double> sickRate` |  |
| 111 | `private List<Double> careCoverage` |  |
| 121 | `private List<Double> outbreak` | The outbreak running, as extra absence on top of what the city's care explains (Health.getOutbreakSeverity()); 0 between outbreaks. |
| 129 | `private List<Double> landPrice` | What the world asks the city for a square foot of ground, in thousands of US DOLLARS since 0.7.6 (LandManager.getGroundUsdPerSqFt()); the months an older save recorded are local money, and stay as recorded. |
| 130 | `private List<Double> foodPrice` |  |
| 131 | `private List<Double> materialsPrice` |  |
| 132 | `private List<Double> orePrice` |  |
| 147 | `private List<Double> fxRate` |  |
| 154 | `private List<Double> fxParity` | Parity beside the rate (0.7.35): where a basket costs the same here and abroad, in the rate's own units (ForeignAccounts.getParity()), so the Trade tab can draw the two on one chart. |
| 155 | `private List<Double> reservesUsd` |  |
| 156 | `private List<Double> foreignDebtUsd` |  |
| 157 | `private List<Double> currentAccount` |  |
| 158 | `private List<Double> exportsAbroad` |  |
| 159 | `private List<Double> importsAbroad` |  |
| 167 | `private List<Double> priceIndex` |  |
| 174 | `private List<Double> expectedInflation` | THE ANCHOR (0.7.42): what the city expected inflation to be, a fraction a year, and how far it believed the bank (Expectations) - both ratios, so a reform leaves them alone. |
| 175 | `private List<Double> credibility` |  |
| 176 | `private List<Double> businessDebt` |  |
| 183 | `private List<Double> bankDeposits` | bankPremium WAS HERE until 0.7.7: the points the strained bank added to every rate in the city. |
| 184 | `private List<Double> bankLent` |  |
| 185 | `private List<Double> bankEquity` |  |
| 186 | `private List<Double> bankWriteOffs` |  |
| 203 | `private List<Double> bankCapacity` |  |
| 204 | `private List<Double> bankStrain` |  |
| 205 | `private List<Double> bankProfit` |  |
| 206 | `private List<Double> bankBranches` |  |
| 207 | `private List<Double> householdSavings` |  |
| 219 | `private List<Double> policyRate` |  |
| 220 | `private List<Double> bankPrime` |  |
| 221 | `private List<Double> bankDepositRate` |  |
| 222 | `private List<Double> bankFees` |  |
| 234 | `private List<Double> bankCapitalRatio` |  |
| 235 | `private List<Double> bankCapitalTarget` |  |
| 236 | `private List<Double> bankAllowance` |  |
| 237 | `private List<Double> bankProvisions` |  |
| 238 | `private List<Double> bankDividends` |  |
| 239 | `private List<Double> bankReturnOnEquity` |  |
| 250 | `private List<Double> bankLeverageRatio` | ...AND THE OTHER MEASURE (A7, 0.7.46; the Bank spec's D11): its equity over everything on its sheet (Bank.leverageRatio()) and the target it holds on that measure (leverageTarget()). |
| 251 | `private List<Double> bankLeverageTarget` |  |
| 260 | `private List<Double> taxWage` |  |
| 261 | `private List<Double> taxProperty` |  |
| 262 | `private List<Double> taxSales` |  |
| 263 | `private List<Double> taxBusiness` |  |
| 264 | `private List<Double> taxIndustrial` |  |
| 265 | `private List<Double> contributions` |  |
| 266 | `private List<Double> pensionBill` |  |
| 267 | `private List<Double> healthBill` |  |
| 275 | `private List<Double> rentPrice` |  |
| 276 | `private List<Long> homes` |  |
| 277 | `private List<Double> households` |  |
| 280 | `private List<Double> students` |  |
| 281 | `private List<Double> graduates` |  |
| 282 | `private List<Double> licences` |  |
| 283 | `private List<Double> unburied` |  |
| 292 | `private List<Double> outOfWorkOnEi` |  |
| 293 | `private List<Double> outOfWorkOffEi` |  |
| 294 | `private List<Double> unhoused` |  |
| 295 | `private List<Double> orphans` |  |
| 296 | `private List<Double> evicted` |  |
| 297 | `private List<Double> eiPaid` |  |
| 298 | `private List<Double> eiPremiums` |  |
| 300 | `private List<Double> healthPremiums` | The health premium collected, a month at a time - the EI premium's shape (2026-09-19). |
| 301 | `private List<Double> studentGrants` |  |
| 308 | `private List<Double> foodAssistance` | FOOD ASSISTANCE (0.7.43): what the treasury paid toward the households' groceries a month, and the baskets that bought at the price charged. |
| 309 | `private List<Double> fedByAssistance` |  |
| 310 | `private List<Double> studentLoansOwed` |  |
| 312 | `private List<Double> studentLoanInterest` | Interest the graduates paid on their student loans, a month at a time - the premiums' shape (2026-09-21). |
| 322 | `private List<Double> m0` |  |
| 323 | `private List<Double> m2` |  |
| 324 | `private List<Double> advancesToTreasury` |  |
| 325 | `private List<Double> reserves` |  |
| 326 | `private List<Double> remittance` |  |
| 332 | `private List<Double> sickPastTwoMonths` |  |
| 333 | `private List<Double> diedOfIllness` |  |
| 334 | `private List<Double> sickRecovery` |  |
| 344 | `private Map<String, List<Double>> householdsByShape` |  |
| 352 | `private List<Double> deathsBabies` |  |
| 353 | `private List<Double> deathsChildren` |  |
| 354 | `private List<Double> deathsTeens` |  |
| 355 | `private List<Double> deathsAdults` |  |
| 356 | `private List<Double> deathsSeniors` |  |
| 358 | `private List<Double> deathsElders` | The over-85s, since the band was split on 2026-09-15. |
| 359 | `private List<Double> deathsOrphans` |  |
| 360 | `private List<Double> deathsUnhoused` |  |
| 369 | `private List<Double> crimeRate` |  |
| 370 | `private List<Double> policeCoverage` |  |
| 371 | `private List<Double> prisoners` |  |
| 372 | `private List<Double> caughtNotHeld` |  |
| 373 | `private List<Double> stolen` |  |
| 374 | `private List<Double> deathsKilled` |  |
| 375 | `private List<Double> safetyBill` |  |
| 376 | `private Map<String, List<Double>> crimeByCause` |  |
| 385 | `private List<Long> constructionCapacity` |  |
| 386 | `private List<Double> landUse` |  |
| 405 | `private Map<String, List<Double>> sharePrice` |  |
| 406 | `private Map<String, List<Double>> shareValue` |  |
| 429 | `private Map<String, List<Double>> sectorNetIncome` |  |
| 430 | `private Map<String, List<Double>> sectorWorkers` |  |
| 449 | `private List<Double> consumption` |  |
| 450 | `private List<Double> investment` |  |
| 451 | `private List<Double> government` |  |
| 452 | `private List<Double> netExports` |  |
| 466 | `private List<Double> fundValue` |  |
| 467 | `private List<Double> fundPutIn` |  |
| 468 | `private List<Double> fundTakenOut` |  |
| 486 | `private List<Double> expectedLevel` |  |
| 487 | `private List<Double> indexGroceries` |  |
| 488 | `private List<Double> indexRent` |  |
| 489 | `private List<Double> indexMeals` |  |
| 490 | `private List<Double> indexLuxury` |  |
| 491 | `private List<Double> indexServices` |  |
| 492 | `private List<Double> weightGroceries` |  |
| 493 | `private List<Double> weightRent` |  |
| 494 | `private List<Double> weightMeals` |  |
| 495 | `private List<Double> weightLuxury` |  |
| 496 | `private List<Double> weightServices` |  |
| 497 | `private List<Double> basketLinkedAt` |  |
| 498 | `private List<Double> shelfPrice` |  |
| 499 | `private List<Double> shelfFloor` |  |
| 500 | `private List<Double> basketsAsked` |  |
| 501 | `private List<Double> basketsHanded` |  |
| 502 | `private List<Double> hunger` |  |
| 503 | `private List<Double> hungerPricedOut` |  |
| 504 | `private List<Double> householdsAssisted` |  |
| 505 | `private List<Double> mealMargin` |  |
| 506 | `private List<Double> mealTargetMargin` |  |
| 507 | `private List<Double> luxuryMargin` |  |
| 508 | `private List<Double> luxuryTargetMargin` |  |

## Methods, in file order, under their sections

| line | len | member | says |
|---:|---:|---|---|
| 44 | 1376 | **type** `public class HistorySave` | Every month the city has ever lived, one number at a time. |

### THE AXIS (lines 46-54)

### money (lines 55-64)

### people (lines 65-105)

### what throttles (lines 106-122)

### prices (lines 123-133)

### the edge (lines 134-160)

### money and credit (lines 161-187)

### what the bank could carry, and how hard (lines 188-208)

### the price of money (0.7.7) (lines 209-223)

### the bank's capital (0.7.8) (lines 224-252)

### the budget (lines 253-268)

### housing (lines 269-278)

### school and care (lines 279-284)

### outside the families (lines 285-313)

### THE CENTRAL BANK, 0.7.0. The Money page's year and the year book's: (lines 314-327)

### THE LONG SICK, 2026-09-11. How many have been sick more than two (lines 328-335)

### THE HOUSEHOLDS, BY SHAPE, 2026-09-11. Jerus: a record of how many (lines 336-345)

### WHO DIED, 2026-09-11. The month's dead by age band, and how many of (lines 346-361)

### CRIME, THE POLICE AND THE PRISONS, 2026-09-11 (night). The rate a (lines 362-383)

| line | len | member | says |
|---:|---:|---|---|
| 379 | 1 | `public static String crimeKey(Crime.Cause cause)` | The series name the screens ask for, per reason for crime. |
| 382 | 1 | `public static String householdKey(FamilyStructure shape)` | The series name the screens ask for, per household shape. |

### what runs out (lines 384-387)

### the market (lines 388-411)

| line | len | member | says |
|---:|---:|---|---|
| 409 | 1 | `public static String priceKey(String company)` | The series name the screens ask for, per company. |
| 410 | 1 | `public static String valueKey(String company)` |  |

### the sectors (0.7.4) (lines 412-436)

| line | len | member | says |
|---:|---:|---|---|
| 433 | 1 | `public static String netIncomeKey(String sector)` | The series name the screens ask for, per sector: the month's net income after tax. |
| 435 | 1 | `public static String workersKey(String sector)` | ...and its posts filled. |

### GDP in layers (0.7.6) (lines 437-453)

### the city's fund (0.7.39) (lines 454-469)

### the new price model, read (0.7.45) (lines 470-521)

| line | len | member | says |
|---:|---:|---|---|
| 511 | 1 | `public static String indexKey(int component)` | The name each component's chained level is kept under (PriceIndex.COMPONENTS order): "indexGroceries" and so on. |
| 514 | 1 | `public static String weightKey(int component)` | ...and its weight in the basket in force: "weightGroceries" and so on. |
| 516 | 1 | `private static String capitalised(String s)` |  |
| 519 | 1 | `private List<List<Double>> indexLists()` | The component lists in COMPONENTS order, for the recording and the reform. |
| 520 | 1 | `private List<List<Double>> weightLists()` |  |

### RECORDING (lines 522-1018)

| line | len | member | says |
|---:|---:|---|---|
| 537 | 237 | `public void recordMonth(Game game)` | One month, read off the city itself. |
| 783 | 6 | `private static double sum(double[] values)` | A whole array in one figure. |
| 790 | 1 | `private static double round2(double v)` |  |
| 791 | 1 | `private static double round4(double v)` |  |
| 797 | 4 | `static double roundSig(double v)` | A price per founding share to SHARE_PRICE_DIGITS significant figures; 0 stays 0, and a figure that is not a number is kept as 0, as finite() keeps the rest (JSON holds no NaN). |
| 802 | 1 | `private static double round6(double v)` | Six places, for a price in thousands that four would round to a dime - and to nothing after a reform (0.7.45: the shelf). |
| 804 | 1 | `private static double finite(double v)` | A reading the file can hold: JSON has no NaN, so a figure not struck yet is kept as 0 (0.7.45's series). |
| 817 | 169 | `public void restoreFrom(HistorySave loaded)` | Takes over another history wholesale - the load path. |
| 988 | 6 | `private static Map<String, List<Double>> copyMap(Map<String, List<Double>> from)` | A map of series, copied list by list, and never null - see copy(). |
| 1005 | 3 | `private static<T> List<T> copy(List<T> from)` | A copy, and never null. |
| 1014 | 4 | `public GameFiles.Result saveHistory(GameFiles files, int slot)` | The graph history. |

### READING (lines 1019-1055)

| line | len | member | says |
|---:|---:|---|---|
| 1024 | 1 | `public int months()` | How many months the city has lived. |
| 1026 | 1 | `public List<Integer> getMonth()` |  |
| 1041 | 14 | `public double[] aligned(String name)` | A series as doubles, padded at the FRONT to the full month axis. |

### a series' record, counted (0.7.9) (lines 1056-1419)

| line | len | member | says |
|---:|---:|---|---|
| 1066 | 8 | `public int monthsUnder(String series, String line)` | Months in which both series were recorded and the first stood under the second: the bank's months under its capital target (bankCapitalRatio against bankCapitalTarget). |
| 1076 | 5 | `public int monthsUnder(String series, double level)` | ...and under a fixed level: its months under the city's minimum. |
| 1083 | 5 | `public int monthsRecorded(String series)` | Months a series was recorded in. |
| 1090 | 5 | `public double total(String series)` | A flow added up over the months it was recorded. |
| 1103 | 7 | `public double changeOver(String series, int months)` | How far a series has moved over the last `months` months, as a share of where it stood then: the last recorded value over the one `months` entries before it, less one (0.7.35: the Trade tab's rate this month and over ... |
| 1112 | 6 | `public double recentTotal(String series, int months)` | A flow added up over the last `months` months only, those recorded among them (0.7.35: the Trade tab's year of exports and imports). |
| 1124 | 14 | `public double worstYear(String series)` | A flow's worst year: the largest sum of any twelve months in a row since it was first recorded - over fewer than twelve, what there is. |
| 1145 | 15 | `public static double[] runningTotal(double[] monthly)` | A monthly series summed from its first recorded month, for the running totals of the dead. |
| 1162 | 174 | `public Map<String, List<? extends Number>> seriesByName()` | Every stored series, by the name the screen asks for. |
| 1338 | 1 | `public List<Double> getCash()` | The originals, still here because other code and the harnesses read them. |
| 1339 | 1 | `public List<Double> getGdp()` |  |
| 1340 | 1 | `public List<Double> getDebt()` |  |
| 1341 | 1 | `public List<Double> getInterestRate()` |  |
| 1342 | 1 | `public List<Long> getJobs()` |  |
| 1343 | 1 | `public List<Long> getWorkforce()` |  |
| 1344 | 1 | `public List<Long> getOutOfWork()` |  |
| 1345 | 1 | `public List<Long> getPopulation()` |  |
| 1358 | 49 | `public void redenominate(double scale)` | Redraws the city's whole history in the new unit. |
| 1409 | 9 | `private static void scaleAll(double scale, List<Double>...series)` |  |

