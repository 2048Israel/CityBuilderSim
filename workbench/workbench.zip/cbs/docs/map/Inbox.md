# Inbox.java - 577 lines · 23 methods · 1 constants · model

`ham/citybuildersim/Inbox.java` - generated 2026-10-02 by CodeMap; line numbers are as of that run.

> Everything the city has had to say for itself, newest first.
> 
> WHAT THIS REPLACED
> 
> Four red boxes that appeared in the middle of the main screen and had to be
> dismissed before you could get on with anything. They worked - the shedding
> banner is the reason a 4,000-month playtest stopped freezing at 660 people -
> but they had two faults a banner cannot fix. A dismissed banner was gone: no
> record it had ever appeared, and nothing to go back to when the player
> changed their mind three months later. And a banner only exists on the screen
> it was written for, so a warning raised during a fifty-month skip was
> announced to an empty room.
> 
> A notice does neither. It is raised by the CITY, once a month, whether
> anybody is watching; it stays in the list after it is read; and it stays
> after it is resolved, greyed, for two years, so "what went wrong in the
> forties" has an answer.
> 
> WHY THE TEXT IS BUILT HERE AND NOT ON THE SCREEN
> 
> Because the screen is not always there. These sentences used to be built
> inside UserInterface, which meant they could only be built while somebody was
> looking at the main menu - so a condition that arose and passed inside a skip
> produced no words at all. Built here, they are written the month the
> condition is true, and the screen's only job is to draw them.

**Uses:** [Notice](Notice.md) (12), [Game](Game.md) (12), [Healthcare](Healthcare.md) (6), [ConstructionControl](ConstructionControl.md) (5), [Bank](Bank.md) (5), [Crime](Crime.md) (5), [CareType](CareType.md) (5), [Health](Health.md) (4), [AgeBand](AgeBand.md) (4), [TreasuryFund](TreasuryFund.md) (2), [BuildingManager](BuildingManager.md) (2), [Sickness](Sickness.md) (2), [Migration](Migration.md) (2), [BusinessDebtManager](BusinessDebtManager.md) (1), [PopulationCohorts](PopulationCohorts.md) (1)

**Used by (3):** [Game](Game.md), [InboxCheck](InboxCheck.md), [UserInterface](UserInterface.md)

## Sections

| line | section |
|---:|---|
| 47 | THE MONTH |
| 195 | READING |
| 248 | SAVE AND LOAD |
| 269 | WHAT EACH ONE SAYS |

## Constants

| line | constant | value | says |
|---:|---|---|---|
| 39 | `Inbox.KEEP_MONTHS` | `24` | How long a resolved notice stays readable. |

## Fields (state)

| line | field | says |
|---:|---|---|
| 45 | `private List<Notice> notices` | Newest LAST, because that is the order they happened in and appending is the honest way to record a sequence. |

## Methods, in file order, under their sections

| line | len | member | says |
|---:|---:|---|---|
| 36 | 542 | **type** `public class Inbox` | Everything the city has had to say for itself, newest first. |

### THE MONTH (lines 47-194)

| line | len | member | says |
|---:|---:|---|---|
| 58 | 70 | `public void takeMonth(Game game)` | Raise what is newly true, refresh what still is, resolve what is not. |
| 134 | 16 | `private static List<String> overtimeBody(Game game)` | Every city's site on overtime whose next month is its third or later (ConstructionControl, B. |
| 152 | 12 | `private static List<String> demolishedBody(Game game)` | The demolitions that finished this month: the material sold to the builders, the ground freed. |
| 173 | 15 | `private void take(Game game, int month, String key, boolean nowTrue, String title, List<String> body)` | One condition, this month. |
| 190 | 4 | `private void cull(int month)` | Drop what has been settled longer than anybody needs to remember. |

### READING (lines 195-247)

| line | len | member | says |
|---:|---:|---|---|
| 200 | 5 | `public List<Notice> newestFirst()` | Newest first, which is the order the screen wants and nothing else does. |
| 207 | 1 | `public List<Notice> all()` | In the order they happened. |
| 209 | 1 | `public int size()` |  |
| 221 | 6 | `public Notice urgent()` | The one that interrupts: newest unread notice whose condition still holds. |
| 229 | 5 | `public int unread()` | What goes on the envelope. |
| 236 | 7 | `public Notice live(String key)` | The live notice for a condition, or null if there is not one. |
| 244 | 3 | `public void markRead(Notice notice, int month)` |  |

### SAVE AND LOAD (lines 248-268)

| line | len | member | says |
|---:|---:|---|---|
| 262 | 4 | `public void restoreFrom(List<Notice> loaded)` | Takes over a loaded inbox wholesale. |
| 267 | 1 | `public void reset()` |  |

### WHAT EACH ONE SAYS (lines 269-577)

| line | len | member | says |
|---:|---:|---|---|
| 278 | 21 | `private static List<String> sheddingBody(Game game)` |  |
| 300 | 22 | `private static List<String> landLockBody(Game game)` |  |
| 323 | 27 | `private static List<String> bankBody(Game game)` |  |
| 352 | 20 | `private static List<String> resolvedBody(Game game, TreasuryFund.Resolution r)` | The month the city resolved the bank (0.7.14): the log's sentence, with its figures. |
| 374 | 22 | `private static List<String> preferredBody(Game game)` | The bank's offer (0.7.14): the popup's sentence, TARP's terms. |
| 405 | 37 | `private static List<String> defaultsBody(Game game)` | FIRMS GOING BUST (0.7.8). |
| 444 | 8 | `private static String money(double thousands)` | Thousands - the unit the model counts in - as a player reads money: $1.3M, $450k. |
| 459 | 33 | `private static List<String> crimeBody(Game game)` | Crime at one and a half times Canada's rate or worse, or people the police caught with no cell to hold them (2026-09-11). |
| 505 | 72 | `private static List<String> healthcareBody(Game game)` | The three things healthcare is silently costing the city, when they apply. |

