package ham.citybuildersim;

import java.text.NumberFormat;
import java.util.Arrays;
import java.util.Locale;

/**
 * The working population: the workforce by skill band, the city's posts and
 * their wages by job type, and who fills which post (fillByBand()).
 *
 * @author Jerus
 */
public class PopulationManager {
    private int population;
    //dont use this one for anything other than create different jobs
    JobType[] jobTypes = JobType.values();
    //
    private int[] jobs = new int[jobTypes.length];
    private double[] jobWage = new double[jobs.length];
    private double[] totalWagePerType = new double[jobWage.length];
    private int totalJobs;
    //temporary
    private double adultPercent = .5;
    private int workforce;

    /* =====================================================================
       WHO THE WORKFORCE ACTUALLY IS

       The workforce used to be one integer, and getJobVacancy() handed it to
       the most-skilled posts first. A measured city of 9,016 people staffed 220
       doctor posts at 100% with no school, college or university anywhere in
       the game, while a third of its workers sat idle. Every JobType
       distinction was real on the demand side and imaginary on the supply side.

       A SHARE, NOT A COUNT, and that is deliberate. The pyramid still owns how
       many adults there are - it knows who was born, who aged in and who died,
       and none of that is this class's business. What is tracked here is only
       the MIX, which is the thing migration moves and which nothing else knows.
       Four doubles that sum to one, against a headcount that stays exactly
       where it was.

       Everyone starts unskilled because, until education buildings exist, the
       only source of a skill is somebody who already had one moving in.
       ===================================================================== */
    /**
     * HEADS, and only the skilled ones. Index 0 is unused.
     *
     * The first version of this kept four shares that summed to one, and it was
     * subtly wrong in a way that took a measurement to see: multiplying an
     * existing share by a GROWN workforce hands the new workers the city's
     * current skill mix, so a city that had attracted graduates went on
     * producing them out of its own births. Over 240 months it drifted to 8.5%
     * university-educated in a game with no universities.
     *
     * Storing the skilled heads instead makes the rule true by construction
     * rather than by arithmetic: skilled counts move ONLY when somebody skilled
     * arrives or leaves, and the unskilled band is whatever is left of the
     * workforce. A child growing into work is unskilled because they are not in
     * this array, not because a formula remembered to dilute them.
     */
    private final double[] skilledHeads = new double[WageBand.values().length];

    /**
     * People licensed to hold a GATED job, by job type.
     *
     * The four professional schools do not raise anybody's band - a medical
     * student is already a university graduate - so this is a second, narrower
     * fact about the same people: a subset of skilledHeads[UNIVERSITY] who may
     * additionally practise medicine. Every entry for an ungated job stays zero
     * and is never read.
     *
     * WITHOUT THIS, within-band fungibility means a university graduate can be
     * a doctor, which is the simplification the professional schools exist to
     * remove. See EducationType.
     */
    private final double[] licensed = new double[JobType.values().length];
    
    
    
    
    
    /**
     * Takes the population the demographics arrived at, and works out who can
     * work this month.
     *
     * THIS USED TO DECIDE THE POPULATION. It computed
     * `min(householdCapacity, totalJobs * 2.25)` and returned it, which meant
     * the city had no memory at all - the number was rebuilt from scratch every
     * month, so a finished tower filled instantly and a demolished one erased
     * its residents. That expression still exists, in `Migration`, but it is now
     * a TARGET the city migrates toward rather than the answer.
     *
     * THE WORKFORCE IS NOW THE CITY'S ACTUAL ADULTS. It used to be
     * `population * 0.5` - a flat share, typed in, that took no notice of who
     * actually lived here. The pyramid has known the real figure for three
     * batches and nothing read it, which made a city of pensioners staff its
     * factories exactly as well as a city of thirty-year-olds.
     *
     * A settled pyramid runs about 57% adults rather than 50%, so this is worth
     * roughly a seventh more workers at the same population - but the point is
     * not the level, it is that the number now MOVES. A city that ages loses
     * workers without losing residents, and the dependency ratio on the People
     * screen stops being decoration.
     *
     * Taken from the adults who ALREADY LIVED HERE, before this month's
     * arrivals, and that ordering is deliberate rather than accidental: the
     * people who worked this month are the ones who were here. Somebody who
     * moves in this month starts work next month. That property is the reason
     * this method still exists rather than the caller just assigning the field.
     *
     * It is also why the workforce has to be SAVED rather than recomputed - see
     * recomputeWorkforce(). Leave the order alone unless you mean to change how
     * fast a growing city staffs itself, which is a balance decision, not a
     * tidy-up.
     *
     * @param newPopulation      what the demographics arrived at
     * @param adultsAlreadyHere  the adult band before this month's migration
     */
    public int applyPopulation(int newPopulation, double adultsAlreadyHere){
        workforce = (int) Math.max(0, adultsAlreadyHere);
        return population = Math.max(0, newPopulation);
    }
    
    public void updateJobs(int[] newJobs){
        //change later
        totalJobs = 0;
        for(int i = 0; i < jobs.length; i++){
            jobs[i] = newJobs[i];
            totalJobs += jobs[i];
        }
       
    }
    
    
    
    //getters
    public int getTotalJobs(){
        return totalJobs;
    }
    
    public int getPopulation(){
        return population;
    }
    
    public double[] getTotalWagePerType(){
        return totalWagePerType;
    }
    
    /**
     * Positions actually staffed, across every tier.
     *
     * getTotalJobs() counts posts that exist; this counts the ones with someone
     * in them, which is what the wage bill is actually paid on and therefore
     * the right denominator for an average wage.
     */
    public int getJobsFilled(){
        double[] fillRate = getJobFillRate();
        double filled = 0;
        for(int i = 0; i < jobs.length; i++) {
            filled += jobs[i] * fillRate[i];
        }
        return (int) Math.round(filled);
    }

    public double getTotalWage(){
        double totalWage = 0;
        double[] fillRate = getJobFillRate().clone();
        for(int i = 0; i < totalWagePerType.length; i++) {
            totalWage += totalWagePerType[i]*fillRate[i];
        }
        // ...and the overtime on the city's rushed sites (0.7.22), when there
        // is any: see overtimeWages.
        double[] overtime = overtimeWages == null ? null : overtimeWages.get();
        if (overtime != null) {
            for (int i = 0; i < overtime.length && i < totalWagePerType.length; i++) totalWage += overtime[i];
        }
        return totalWage;
    }

    /**
     * THE OVERTIME ON A RUSHED SITE IS WAGES (0.7.22; ConstructionControl,
     * B. RUSH). The builders pay their crews on the city's rushed sites the
     * premium the city pays them (sectors.Construction.getOvertimeWages()),
     * so the households are paid it - on top of the posts' wages, by job
     * type, through the same two figures every wage reaches them by
     * (getTotalWage() and getStaffedWagePerType()), so the wage tax, the
     * contributions and every tier's income see it too, and the builders'
     * payroll and the households' pay stay one figure. Read through a hook
     * Game sets; none, or null from it, adds nothing.
     */
    private java.util.function.Supplier<double[]> overtimeWages;

    public void setOvertimeWages(java.util.function.Supplier<double[]> overtimeWages) {
        this.overtimeWages = overtimeWages;
    }
    
    public double[] getWagesPerType(){
        return jobWage;
    }

    /**
     * The wage bill per job type with the fill rate already applied.
     *
     * The banded wage tax needs the split behind getTotalWage(), and it must be
     * the SAME split: this sums to getTotalWage() by construction, because it is
     * that method's loop body with the accumulation taken out.
     *
     * Handing out the unstaffed array and a separately-sampled fill rate looked
     * equivalent and was not - the fill rate is recomputed live on every call,
     * so the two were sampled at different moments and a reloaded city taxed a
     * different wage bill from the live one it was supposed to match.
     */
    public double[] getStaffedWagePerType(){
        double[] fillRate = getJobFillRate();
        double[] staffed = new double[totalWagePerType.length];
        for (int i = 0; i < totalWagePerType.length; i++) {
            staffed[i] = totalWagePerType[i] * fillRate[i];
        }
        // ...and the rushed sites' overtime (0.7.22), as getTotalWage() adds it.
        double[] overtime = overtimeWages == null ? null : overtimeWages.get();
        if (overtime != null) {
            for (int i = 0; i < overtime.length && i < staffed.length; i++) staffed[i] += overtime[i];
        }
        return staffed;
    }
    
    /**
     * The same staffed wage bill, collapsed onto the six pay tiers.
     *
     * Migration watches a tier's cashflow for twelve months of decline, and a
     * tier is a group of job types - so somebody has to do this mapping. Doing
     * it HERE rather than at the call site is the whole point: this method is one
     * line of aggregation over getStaffedWagePerType(), so it cannot disagree
     * with the wage bill the tax is charged on. A second copy of the fill-rate
     * arithmetic somewhere else is exactly the bug this codebase keeps finding -
     * the copy is right the day it is written and wrong the first time the
     * original changes.
     */
    public double[] getStaffedWagePerTier(){
        double[] byType = getStaffedWagePerType();
        double[] byTier = new double[PayTier.values().length];
        for (JobType type : JobType.values()) {
            byTier[PayTier.of(type).ordinal()] += byType[type.ordinal()];
        }
        return byTier;
    }

    //setters
    /**
     * Wages, read from PayTier rather than typed out here.
     *
     * This used to be eleven hand-written figures with TEN distinct values -
     * UNIV_FINANCE and UNIV_HIGHTECH_ENG were both 6.5 - which made "group
     * families by what they earn" a ten-way split. PayTier collapses that to
     * six by role, and owns the numbers, so there is one wage table rather than
     * one table and a copy of it that agrees until somebody edits the wrong one.
     *
     * Measured cost of the collapse on a city of 8,792: the whole wage bill
     * moved -1.08%.
     */
    public void setWagesPerType(){
        for (JobType type : JobType.values()) {
            jobWage[type.ordinal()] = PayTier.wageOf(type);
        }
    }

    /**
     * Takes this month's wages from the market instead of the constants.
     *
     * setWagesPerType() above is kept as the starting position and as the
     * fallback: PayTier is still the one definition of the LADDER, and
     * LabourMarket anchors to it, so at the default minimum wage these two
     * produce the same eleven numbers. What changes is that after this call
     * they can move.
     */
    public void takeWagesFrom(LabourMarket market){
        if (market == null) return;
        double[] priced = market.getWages();
        System.arraycopy(priced, 0, jobWage, 0, Math.min(priced.length, jobWage.length));
    }
    public void setPopulation(int population){
        this.population = population;
    }

    /**
     * Recomputes workforce from the current population, without touching
     * population itself.
     *
     * NOTE: workforce was previously assigned in exactly one place - updatePop()
     * - which only the normal monthly path reaches. Game.rebuildSimulationState()
     * never called it, so after loading a save workforce stayed 0, getJobVacancy()
     * marked every position vacant, and getJobFillRate() returned 0 for every job
     * tier. That zeroed retail revenue and payroll, industrial output, utility and
     * construction expense, wage tax, and the construction-speed discount - which
     * is why a loaded game took two or three months to settle back to its real
     * numbers.
     *
     * updatePop() can't just be called here instead: it also recomputes population
     * from totalJobs, which hasn't been rebuilt yet at that point in
     * rebuildSimulationState(), and would clamp the restored city to 0.
     */
    public void recomputeWorkforce(){
        workforce = (int)(population * adultPercent);
    }

    /**
     * Puts back the workforce the month was actually worked by.
     *
     * recomputeWorkforce() above was the first fix for this and is no longer
     * the right one. It derives the workforce from the population the save was
     * taken WITH, but updatePop() derives it from the population the month
     * STARTED with - so in any city that is still growing, a reloaded save came
     * back with a month's extra workers. Measured at 418 against the 386 that
     * actually worked, on a city of 836: a 5% overstatement of the wage bill,
     * the wage tax, and every fill rate downstream of it.
     *
     * The third value in this codebase to be re-derived on load from state that
     * had since moved, after the property-tax charge and the month's income
     * statements. Same answer as both: it is a fact about a month, so carry it.
     *
     * recomputeWorkforce() stays as the fallback for saves written before this,
     * where it is still much better than the zero it originally replaced.
     */
    public void restoreWorkforce(int workforce){
        this.workforce = Math.max(0, workforce);
    }

    public int getWorkforceForSave(){
        return workforce;
    }
    
    public void UpdateTotalWagePerType(){
        for(int i = 0; i < totalWagePerType.length; i++){
            totalWagePerType[i] = jobs[i]*jobWage[i];
        }
    }
    
    /**
     * Positions nobody qualified is available to fill.
     *
     * THIS METHOD USED TO INVENT DOCTORS. It walked the job array from the top
     * index down - `for (int i = length - 1; i >= 0; i--)` - handing an
     * undifferentiated pool of adults to the most-skilled posts first and
     * passing the remainder downward. So a city with no education of any kind
     * staffed 220 doctor posts at 100% while its factories went empty, and the
     * eleven job types were a demand-side fiction.
     *
     * It then allocated by BAND, top down, cascading each band's surplus into
     * the bands below it. Downward substitution only: a graduate can labour, a
     * labourer cannot doctor. That is still the rule, but the top-down order is
     * not (0.7.18): how many of each band's posts are filled is now
     * fillByBand()'s - workers take the best-paid posts they qualify for - and
     * this spreads each band's count over its job types. Within a band the
     * workers are fungible and the posts pay alike, so a short band's posts
     * are filled proportionally rather than in enum order - which matters,
     * because enum order is arbitrary and would otherwise decide that the city
     * staffs its lawyers before its doctors.
     */
    public int[] getJobVacancy() {

        int[] vacancy = new int[totalWagePerType.length];
        BandFill fill = fillByBand(staffablePostsByBand());

        for (int b = 0; b < WageBand.values().length; b++) {

            // The gated posts' holders were booked first, whole people; see fillByBand().
            double gatedTaken = 0;
            for (JobType job : JobType.values()) {
                if (WageBand.of(job).ordinal() != b || !isGated(job)) continue;
                int i = job.ordinal();
                vacancy[i] = Math.max(0, jobs[i] - fill.licensedIn[i]);
                gatedTaken += fill.licensedIn[i];
            }

            double openPosts = 0;
            for (JobType job : JobType.values()) {
                if (WageBand.of(job).ordinal() == b && !isGated(job)) openPosts += jobs[job.ordinal()];
            }

            double filled = Math.min(Math.max(fill.placed[b] - gatedTaken, 0), openPosts);
            double share = openPosts > 0 ? filled / openPosts : 1;

            /*
             * SHARED OUT CUMULATIVELY, so the band cannot staff more people than
             * it has.
             *
             * Rounding each job type on its own looks harmless and is not: five
             * types each rounding up by less than half a person put two and a
             * half people into the city who do not live there. LabourCheck
             * exists to assert exactly that this cannot happen, and it caught it
             * the moment a change to the bank's job mix moved the numbers into a
             * range where the rounding bit - 639 College posts staffed by 638
             * College workers.
             *
             * Running the ideal total and taking differences means the whole
             * band always hands out exactly round(filled) jobs, however many
             * types it is split across.
             */
            double idealSoFar = 0, givenSoFar = 0;
            for (JobType job : JobType.values()) {
                if (WageBand.of(job).ordinal() != b) continue;
                if (isGated(job)) continue;
                int i = job.ordinal();
                idealSoFar += jobs[i] * share;
                double give = Math.max(0, Math.min(jobs[i], Math.round(idealSoFar) - givenSoFar));
                givenSoFar += give;
                vacancy[i] = Math.max(0, jobs[i] - (int) give);
            }
        }

        return vacancy;
    }

    /* =====================================================================
       WORKERS TAKE THE BEST-PAID JOB THEY QUALIFY FOR (0.7.18)

       Jerus: "Workers take the best-paid job they qualify for, instead of
       skilled jobs being filled first. Unskilled pay could then never pass
       diploma pay, but hospitals and schools would lose some staff."

       WHAT IT REPLACED. The bands were filled from the top down and only a
       band's SURPLUS went down the ladder. So a city short of hands put the
       whole shortage on its bottom rung, whatever that rung paid: in Jerus's
       year-149 city all 185,132 missing workers were empty unskilled posts,
       8.5% staffed at $68.6k a month - more than a doctor's $60.4k - while
       182,209 diploma holders filled diploma posts at $25.5k. Nobody takes
       the $25.5k job with the $68.6k one open to them. The rule people
       actually follow is occupational choice with skill downgrading: take
       the best-paid work you are qualified for, and when the lower rung pays
       as well, the better-qualified move down the ladder and push the
       shortage up it (Beaudry, Green and Sand 2016, "The Great Reversal in
       the Demand for Skill and Cognitive Tasks", Journal of Labor Economics
       34(S1): S199-S247, on graduates moving into the jobs the less educated
       used to hold). No number is taken from it; it is the rule.

       THE RULE. A worker may hold any post at or below their band. Posts are
       filled so that no worker holds a lower-paid post while a better-paid
       post they qualify for is empty, at the wages this month's scarcity
       sets - each band's base times LabourMarket.multipleAt() of its
       tightness, which is what the wages walk toward.

       THE FORM. Bands are filled from the top, as before, and any band that
       still has empty posts and would pay MORE than the band above it is
       joined to it: the two are one market, filled together at one wage,
       lambda. The pooled workers are split so that each band's posts pay
       exactly lambda - a band with base b and P posts holds P x
       tightnessAt(lambda / b)^-1 of them, or all P when that is more, when it
       is full and the workers it queues price it at lambda. A joined market
       that now out-pays the band above it joins that too (pool-adjacent
       violators, the standard way to put an order back into a sequence).
       Then a band left full keeps its price no lower than the best-paid band
       below it that is still hiring: its members could go there, so the ones
       queueing for it are only the ones who would still take its posts.

       WHY NOT SORT THE POSTS BY THE WAGE THEY PAID LAST MONTH, the simplest
       form: the fill would then decide the wage and the wage the fill, a
       month apart, with nothing continuous between them. Whichever band paid
       least would take the whole shortage, its wage would climb past the
       other's, the order would flip, and in Jerus's city 185,000 missing
       workers would move between the unskilled and the diploma posts every
       month or two, and so would the hospitals' staff. The joined market is
       where that sequence settles, so it is filled there.

       WHY IT HAS THE PROPERTY. (i) Inside a joined market every post pays
       lambda. (ii) A market with an empty post absorbs its whole pool, so
       nobody is carried past it to a lower post. (iii) A band that is short
       pays at least its base, and a full band pays at most its own, lower
       one, so a short band never sits above a band that out-pays it and is
       still hiring without the two having been joined. (iv) A full band pays
       no less than any band below it that is hiring. So nobody is in a
       lower-paid post while a better-paid one they could hold is empty.
       Lowest-qualified first: an unskilled post takes the unskilled before
       anyone, so the graduates in unskilled posts are the posts filled less
       the unskilled workers.

       WHAT DOES NOT CHANGE. How many are employed: every worker a short band
       could use is used either way, so unemployment is the same; only WHICH
       posts stand empty moves. Where the wages already fall with the ladder -
       every city without a shortage at the bottom - nothing is joined and
       this is the top-down fill. Gated posts still go to licence holders
       alone, first: they pay more than anything else their holders could
       take. A worker in a post is paid the post's wage, whatever their band.
       ===================================================================== */

    /**
     * Each band's base as a multiple of the unskilled floor: what its ungated
     * posts pay at the going rate (LabourMarket.ratioOf()). The minimum wage
     * and the cost of living multiply every band alike, so this is all the
     * ladder the allocator needs to compare wages on.
     */
    private static final double[] BAND_BASE = bandBases();

    private static double[] bandBases() {
        double[] base = new double[WageBand.values().length];
        java.util.Arrays.fill(base, Double.MAX_VALUE);
        for (JobType job : JobType.values()) {
            if (isGated(job)) continue;
            int b = WageBand.of(job).ordinal();
            base[b] = Math.min(base[b], LabourMarket.ratioOf(job));
        }
        for (int b = 0; b < base.length; b++) if (base[b] == Double.MAX_VALUE) base[b] = 1;
        return base;
    }

    /**
     * One month's workers against one count of posts, by band (0.7.18) - the
     * single definition of who can fill a post. getJobVacancy() spreads it
     * over the job types, supplyByBand() hands the market its supply, and
     * Sector.staffing() asks it what a new building could be given.
     */
    public static final class BandFill {
        /** Workers holding each band's posts. */
        public final double[] placed;
        /** Each band's supply: its posts over this are its tightness, the figure LabourMarket prices. */
        public final double[] supply;
        /** Licence holders in each gated job type's posts, by JobType ordinal: whole people, booked first. */
        public final int[] licensedIn;
        /** The highest band of the market each band was filled in: its own when alone, the top of the tie when joined. */
        public final int[] market;

        BandFill(int bands, int types) {
            placed = new double[bands];
            supply = new double[bands];
            licensedIn = new int[types];
            market = new int[bands];
        }

        /** Whether this band was filled as one market with the band above it. */
        public boolean joinedAbove(WageBand band) {
            int b = band.ordinal();
            return b + 1 < market.length && market[b] == market[b + 1];
        }
    }

    /**
     * The fill against this month's posts offered.
     */
    public BandFill fillByBand() {
        return fillByBand(staffablePostsByBand());
    }

    /**
     * The fill against a given count of staffable posts per band: this
     * month's (staffablePostsByBand()), or a planner's, which also counts the
     * posts no employer offers this month (Sector.staffing()).
     */
    public BandFill fillByBand(double[] posts) {
        int bands = WageBand.values().length;
        BandFill f = new BandFill(bands, jobs.length);
        double[] own = workforceByBand();

        /*
         * GATED JOBS FIRST, AND ONLY FROM PEOPLE WHO HOLD THE LICENCE.
         *
         * A medical post can be filled by a doctor and by nobody else. It
         * is not enough to be a university graduate - that is precisely the
         * within-a-band fungibility the professional schools exist to
         * remove, and without this a city with no medical school would go on
         * staffing its hospitals out of the general graduate pool, which is
         * the 220-doctors bug wearing a different hat.
         *
         * Taken off the band's pool because a licence holder IS one of the
         * band's workers - the licence is a second fact about the same
         * person, not a second person. A surplus of licence holders stays in
         * the pool and competes for the ungated posts like anybody else,
         * which is right: a doctor with no hospital can do research. Booked
         * before anything is joined, because a gated post pays its band's
         * multiple times the licence premium on the dearest bases in the game
         * (15.6 and 9.6 against 8.2 for the band's other posts), so a
         * licence holder is never better paid elsewhere while one is empty.
         */
        double[] gated = new double[bands];
        double[] left = own.clone();
        for (JobType job : JobType.values()) {
            if (!isGated(job)) continue;
            int b = WageBand.of(job).ordinal(), i = job.ordinal();
            double staffed = Math.min(jobs[i], Math.min(licensed[i], Math.max(0, left[b])));
            // Rounded ONCE, and the same rounded figure taken off the pool.
            // Booking a fractional person against the pool while filling a
            // whole one leaves half a worker behind on every gated type.
            int taken = (int) Math.round(staffed);
            f.licensedIn[i] = taken;
            left[b] -= taken;
            gated[b] += taken;
        }

        // The chain, from the top: a stack of markets, each a run of bands.
        int[] top = new int[bands], bottom = new int[bands];
        double[] wage = new double[bands], carriedIn = new double[bands];
        int n = 0;
        double carried = 0;
        for (int b = bands - 1; b >= 0; b--) {
            top[n] = b;
            bottom[n] = b;
            carriedIn[n] = carried;
            carried = fillMarket(f, b, b, carried, posts, own, gated, wage, n);
            n++;
            // A market still hiring that out-pays the one above it is joined to it.
            while (n >= 2 && hiring(f, posts, top[n - 1], bottom[n - 1]) && wage[n - 1] > wage[n - 2]) {
                bottom[n - 2] = bottom[n - 1];
                n--;
                carried = fillMarket(f, top[n - 1], bottom[n - 1], carriedIn[n - 1], posts, own, gated, wage, n - 1);
            }
        }

        /*
         * A FULL BAND IS PAID NO LESS THAN THE BEST-PAID BAND BELOW IT THAT IS
         * STILL HIRING. Its members could take those posts, so the ones queueing
         * for its own are only the ones who would still take them: its supply is
         * what prices it at that wage, never more than it had.
         */
        double best = Double.NEGATIVE_INFINITY;
        for (int b = 0; b < bands; b++) {
            if (posts[b] <= 0) continue;
            double w = BAND_BASE[b] * LabourMarket.multipleAt(posts[b] / Math.max(f.supply[b], 1));
            boolean hiringHere = f.placed[b] < posts[b] - 1e-9;
            if (!hiringHere && w < best) {
                double t = Math.min(1, LabourMarket.tightnessAt(best / BAND_BASE[b]));
                f.supply[b] = Math.min(f.supply[b], posts[b] / t);
                w = BAND_BASE[b] * LabourMarket.multipleAt(posts[b] / Math.max(f.supply[b], 1));
            }
            if (hiringHere) best = Math.max(best, w);
        }
        return f;
    }

    /** Whether any band in a market has posts it has not filled. */
    private static boolean hiring(BandFill f, double[] posts, int hi, int lo) {
        for (int b = lo; b <= hi; b++) {
            if (posts[b] > 0 && f.placed[b] < posts[b] - 1e-9) return true;
        }
        return false;
    }

    /**
     * Fills bands hi down to lo as one market: sets what each holds, its
     * supply and the market it is in, puts the market's wage in wage[k] (as a
     * multiple of the unskilled base; minus infinity for a market with no
     * posts, which never out-pays anything) and returns the workers it leaves
     * for the bands below.
     */
    private static double fillMarket(BandFill f, int hi, int lo, double carriedIn, double[] posts,
                                     double[] own, double[] gated, double[] wage, int k) {
        double pool = carriedIn;
        double room = 0;
        for (int b = lo; b <= hi; b++) {
            pool += own[b];
            room += Math.max(0, posts[b]);
            f.market[b] = hi;
        }

        if (hi == lo || pool >= room) {
            // Alone, or with no empty post among them: the cascade, band by band.
            double c = carriedIn;
            double best = Double.NEGATIVE_INFINITY;
            for (int b = hi; b >= lo; b--) {
                double w = c + own[b];
                f.placed[b] = Math.max(gated[b], Math.min(Math.max(0, posts[b]), w));
                f.supply[b] = w;
                if (posts[b] > 0) {
                    best = Math.max(best, BAND_BASE[b] * LabourMarket.multipleAt(posts[b] / Math.max(w, 1)));
                }
                c = Math.max(0, w - f.placed[b]);
            }
            wage[k] = best;
            return c;
        }

        // One market, one wage: the lambda at which the bands' posts take the pool.
        double low = Double.MAX_VALUE, high = 0;
        for (int b = lo; b <= hi; b++) {
            low = Math.min(low, BAND_BASE[b]);
            high = Math.max(high, BAND_BASE[b]);
        }
        low *= 1e-3;
        high *= 1e6;
        for (int it = 0; it < 200 && high / low > 1 + 1e-15; it++) {
            double mid = Math.sqrt(low * high);
            if (heldAt(mid, hi, lo, posts, gated) > pool) low = mid; else high = mid;
        }
        double lambda = Math.sqrt(low * high);

        double held = 0;
        for (int b = hi; b >= lo; b--) {
            if (posts[b] <= 0) {
                f.placed[b] = 0;
                f.supply[b] = own[b] + (b == hi ? carriedIn : 0);
                continue;
            }
            double t = LabourMarket.tightnessAt(lambda / BAND_BASE[b]);
            double take = Math.max(gated[b], Math.min(posts[b], posts[b] / t));
            f.placed[b] = take;
            // Short: priced on the workers it holds. Full: on the queue that puts it at lambda.
            f.supply[b] = take < posts[b] ? take : posts[b] / Math.min(1, t);
            held += take;
        }
        wage[k] = lambda;
        return Math.max(0, pool - held);
    }

    /** The workers bands hi down to lo would hold if every one of their posts paid lambda. */
    private static double heldAt(double lambda, int hi, int lo, double[] posts, double[] gated) {
        double held = 0;
        for (int b = lo; b <= hi; b++) {
            if (posts[b] <= 0) continue;
            double t = LabourMarket.tightnessAt(lambda / BAND_BASE[b]);
            held += Math.max(gated[b], Math.min(posts[b], posts[b] / t));
        }
        return held;
    }

    /**
     * True for a job no amount of general education qualifies anybody for.
     *
     * Asked of EducationType rather than listed here, so adding a fifth
     * professional school gates its profession automatically and there is no
     * second list to forget.
     */
    public static boolean isGated(JobType job) {
        for (EducationType type : EducationType.values()) {
            if (type.licenses() == job) return true;
        }
        return false;
    }

    /**
     * The workforce split by skill.
     *
     * The skilled bands are carried counts; the unskilled band is the
     * remainder. If the city has shrunk below the number of skilled workers it
     * was carrying - a plague, an exodus - the skilled counts are scaled back
     * to fit rather than allowed to exceed the workforce, because a city cannot
     * have more doctors than adults.
     */
    public double[] workforceByBand() {
        double[] out = new double[skilledHeads.length];

        double skilled = 0;
        for (int b = 1; b < skilledHeads.length; b++) skilled += Math.max(0, skilledHeads[b]);

        double scale = (skilled > workforce && skilled > 0) ? workforce / skilled : 1;
        double used = 0;
        for (int b = 1; b < out.length; b++) {
            out[b] = Math.max(0, skilledHeads[b]) * scale;
            used += out[b];
        }
        out[WageBand.NONE.ordinal()] = Math.max(0, workforce - used);

        /*
         * LESS THE STUDENTS. A diploma-holder two years into a degree is still
         * a diploma-holder - the head stays in skilledHeads, and graduates out
         * of it when the course ends - but they are not in the labour supply,
         * not filling a post, not counted as surplus. Full-time students do
         * not work (Jerus, 2026-09-06). This is the ONE place the supply is
         * read from, so every consumer sees the same workforce.
         */
        if (studying != null) {
            for (int b = 0; b < out.length && b < studying.length; b++) {
                out[b] = Math.max(0, out[b] - studying[b]);
            }
        }

        /*
         * ...AND THE PRISONERS (2026-09-11). Out of the supply for as long as
         * they are inside, and taken off the BOTTOM of the ladder: who goes to
         * prison is mostly who is out of work, and who is out of work is the
         * surplus at the bottom - see UnemployedHousehold.stockGroup(). Past
         * the unskilled band, from the rest in proportion.
         */
        if (imprisoned > 0) {
            int none = WageBand.NONE.ordinal();
            double left = imprisoned;
            double fromNone = Math.min(out[none], left);
            out[none] -= fromNone;
            left -= fromNone;
            if (left > 0) {
                double rest = 0;
                for (int b = 0; b < out.length; b++) if (b != none) rest += out[b];
                double k = rest > 0 ? Math.max(0, 1 - left / rest) : 0;
                for (int b = 0; b < out.length; b++) if (b != none) out[b] *= k;
            }
        }
        return out;
    }

    /** Adults serving a sentence, set from Crime each month. */
    private double imprisoned;
    public void setImprisoned(double adults) { this.imprisoned = Math.max(0, adults); }
    public double getImprisoned() { return imprisoned; }

    /** Adults studying full time, by band, set from Education each month. */
    private double[] studying;
    public void setStudying(double[] byBand) { this.studying = byBand; }
    public double getStudyingTotal() {
        double total = 0;
        if (studying != null) for (double v : studying) total += v;
        return total;
    }

    /** Posts that exist at each skill level. The demand side of the same axis. */
    public double[] postsByBand() {
        double[] out = new double[WageBand.values().length];
        for (JobType job : JobType.values()) {
            out[WageBand.of(job).ordinal()] += jobs[job.ordinal()];
        }
        return out;
    }

    /**
     * Posts a band's own members could actually be put into.
     *
     * NOT postsByBand(). A gated post is only a job for somebody who holds the
     * licence, so a hospital with two hundred doctor posts and five doctors is
     * offering the graduate band five jobs, not two hundred - the other
     * hundred and ninety-five are a shortage, not an opportunity.
     *
     * FOUND BY A HARNESS, 2026-09-07. supplyByBand() cascaded against raw
     * posts, so a city whose university posts were mostly gated showed its
     * graduates as fully absorbed while the allocator was quietly sending a
     * hundred of them down to college work. The staffed count then exceeded
     * the supply the market had priced, which is the 220-doctors bug's shadow:
     * not people invented, but people counted in a band that had no room for
     * them.
     *
     * It matters beyond the arithmetic. The band tightness is what
     * Migration reads to decide whether to pull graduates at all, so with raw
     * posts an empty HOSPITAL pulled ordinary graduates - which is precisely
     * the coupling LabourMarket.licencePremium() exists to break.
     */
    public double[] staffablePostsByBand() {
        double[] out = new double[WageBand.values().length];
        for (JobType job : JobType.values()) {
            int j = job.ordinal();
            double open = jobs[j];
            if (isGated(job)) open = Math.min(open, Math.max(0, licensed[j]));
            out[WageBand.of(job).ordinal()] += open;
        }
        return out;
    }

    /**
     * Workers actually available to each band: what the labour market prices
     * against, a band's staffable posts over this being its tightness.
     *
     * NOT the same as workforceByBand(): a band's supply is its own workers
     * PLUS everyone above it who could not find work at their own level, which
     * is what makes an oversupply of graduates depress the diploma wage rather
     * than sitting in a separate pool being unemployed on its own.
     *
     * AND SINCE 0.7.18 IT IS READ OFF THE FILL ITSELF (fillByBand()): a band
     * joined to the band above it is supplied what the joined market gives
     * it, so a band whose workers have gone down the ladder for better pay is
     * short, and priced short, and a full band's queue holds only the ones who
     * would still take its posts. Where nothing is joined this is the cascade
     * it always was.
     *
     * Cascades against STAFFABLE posts, not posts - see above.
     */
    public double[] supplyByBand() {
        return fillByBand(staffablePostsByBand()).supply;
    }

    /** The same fill against a given count of posts per band - a planner's, which counts posts no employer offers this month (0.7.17; Sector.staffing()). */
    public double[] supplyByBand(double[] posts) {
        return fillByBand(posts).supply;
    }

    /**
     * How many more workers of this band the city has than posts for them.
     *
     * Migration's push factor reads this. Counted against the band's OWN posts
     * rather than against the cascade, because a graduate labouring is employed,
     * not surplus - they are simply employed below their training, which is a
     * different complaint and not one that makes people leave a city.
     *
     * STAFFABLE posts, for the same reason supplyByBand() uses them: a post
     * only a licence holder can fill is not work this band's members can have.
     * The two must agree - one definition of "posts you could take" - or a band
     * is short for the wage and full for the departure in the same month.
     */
    public double surplusInBand(WageBand band) {
        return Math.max(0,
                workforceByBand()[band.ordinal()] - staffablePostsByBand()[band.ordinal()]);
    }

    /** The mix as shares, for anything that wants proportions. Derived. */
    public double[] getBandShare() {
        double[] heads = workforceByBand();
        double[] share = new double[heads.length];
        double total = 0;
        for (double h : heads) total += h;
        if (total <= 0) { share[WageBand.NONE.ordinal()] = 1; return share; }
        for (int b = 0; b < share.length; b++) share[b] = heads[b] / total;
        return share;
    }

    /** The carried skilled counts, for the save. */
    public double[] getSkilledHeads() { return skilledHeads; }

    public double getLicensed(JobType job) {
        return job == null ? 0 : licensed[job.ordinal()];
    }

    public double[] getLicensedHeads() { return licensed; }

    /**
     * Licence holders the city is not already working.
     *
     * Holders less the posts of that type actually staffed. The allocator fills
     * a gated post with min(posts, licences, people available), so the staffed
     * count is jobs less vacancy - not jobs, which counts the desk nobody is
     * sitting at, and not licences, which counts the engineer already employed.
     *
     * Used by the licence gate: see BuildingsTemplate.requiresLicence.
     */
    public double spareLicences(JobType job) {
        if (job == null) return 0;
        int i = job.ordinal();
        int[] posts = getJobs();
        int[] vacant = getJobVacancy();
        double staffed = 0;
        if (posts != null && i < posts.length) {
            staffed = posts[i] - (vacant != null && i < vacant.length ? vacant[i] : 0);
        }
        return Math.max(0, licensed[i] - Math.max(0, staffed));
    }

    public void restoreLicensed(double[] saved) {
        if (saved == null || saved.length != licensed.length) return;
        System.arraycopy(saved, 0, licensed, 0, licensed.length);
    }

    /**
     * New graduates of the professional schools.
     *
     * Only ever grows here. A licence is not lost by working somewhere else -
     * a doctor driving a bus is still a doctor - so the only things that reduce
     * it are death and departure, which arrive through trim() below.
     */
    public void addLicences(double[] newly) {
        if (newly == null) return;
        for (int i = 0; i < licensed.length && i < newly.length; i++) {
            licensed[i] = Math.max(0, licensed[i] + newly[i]);
        }
    }

    /**
     * Death and retirement, which take the skilled along with everybody else.
     *
     * A RATCHET, AND IT WAS REAL. Skilled counts only ever moved by migration,
     * while the workforce also shrank by mortality and by adults ageing into
     * SENIOR - and the unskilled band is the REMAINDER, so every one of those
     * losses came out of the unskilled band alone. A doctor was, in effect,
     * immortal and never retired, and the city drifted more educated every
     * month for no reason anybody chose.
     *
     * The correction is the obvious one: an adult who dies or turns seventy is
     * a random adult, and a random adult is skilled in proportion to the mix.
     * Rate taken from AgeBand's own numbers rather than typed in here, so the
     * day somebody retunes adult mortality this follows it.
     *
     * Small - about two tenths of a per cent a month - and it compounds over
     * four hundred, which is exactly the kind of slow wrong that never looks
     * like a bug on any single screen.
     */
    public void retireSkilled(double leaveRate) {
        if (leaveRate <= 0) return;
        double survive = Math.max(0, 1 - leaveRate);
        for (int b = 1; b < skilledHeads.length; b++) skilledHeads[b] *= survive;
        for (int i = 0; i < licensed.length; i++) licensed[i] *= survive;
    }

    /**
     * Keeps the licensed counts inside the band that contains them.
     *
     * A licence holder is a university graduate first. When the graduate count
     * falls - people die, people leave - the licences have to fall with it or
     * the city ends up with more doctors than it has graduates, and the
     * allocator will happily staff posts out of the difference. Scaled rather
     * than subtracted, because there is no way to know WHICH of them went.
     */
    public void trimLicencesToBand() {
        double[] heads = workforceByBand();
        for (WageBand band : WageBand.values()) {
            double held = 0;
            for (JobType job : JobType.values()) {
                if (WageBand.of(job) == band) held += licensed[job.ordinal()];
            }
            if (held <= heads[band.ordinal()] || held <= 0) continue;

            double keep = heads[band.ordinal()] / held;
            for (JobType job : JobType.values()) {
                if (WageBand.of(job) == band) licensed[job.ordinal()] *= keep;
            }
        }
    }

    public void restoreSkilledHeads(double[] saved) {
        if (saved == null || saved.length != skilledHeads.length) return;
        System.arraycopy(saved, 0, skilledHeads, 0, skilledHeads.length);
        skilledHeads[WageBand.NONE.ordinal()] = 0;   // derived, never carried
    }

    /**
     * This month's schooling, as a net movement between bands.
     *
     * Education hands over +1 at the destination and -1 at the source, so a
     * degree is a person MOVING rather than a person appearing - a city that
     * sends a thousand diploma-holders to university has a thousand fewer
     * diploma-holders, which is the difference between a labour market and a
     * wish. Index 0 is deliberately ignored: the unskilled band is not stored,
     * it is whatever is left of the workforce, so it shrinks on its own.
     */
    public void applyBandFlow(double[] flow) {
        if (flow == null) return;
        for (int b = 1; b < skilledHeads.length && b < flow.length; b++) {
            skilledHeads[b] = Math.max(0, skilledHeads[b] + flow[b]);
        }
    }

    /**
     * Who moved in and who moved out, by skill.
     *
     * The ONLY thing that changes the skilled counts, which is the whole rule:
     * until schools exist, a skill in this city arrived here in somebody's
     * head. The unskilled band is not touched because it is not stored - it is
     * whatever is left of the workforce, so births and deaths move it for free.
     */
    public void applySkilledFlows(double[] arrivals, double[] departures) {
        for (int b = 1; b < skilledHeads.length; b++) {
            double in  = arrivals   == null || b >= arrivals.length   ? 0 : arrivals[b];
            double out = departures == null || b >= departures.length ? 0 : departures[b];
            skilledHeads[b] = Math.max(0, skilledHeads[b] + in - out);
        }
    }

    /**
     * Reads a plausible skill mix off the jobs the city is currently staffing.
     *
     * FOR SAVES WRITTEN BEFORE SKILL EXISTED, which have a workforce and no
     * record of what any of them can do. Resetting them all to unskilled would
     * close every hospital in the city on load; assuming everyone is a graduate
     * would be a gift. Reading it off the posts they are demonstrably filling
     * is the only inference that leaves the city exactly as the player left it.
     */
    public void inferBandShareFromJobs() {
        java.util.Arrays.fill(skilledHeads, 0);

        double[] posts = postsByBand();
        double assigned = 0;
        // Everyone holding a skilled post must have that skill; whoever is left
        // over is unskilled, which is the safe direction to be wrong in.
        for (int b = skilledHeads.length - 1; b >= 1; b--) {
            skilledHeads[b] = Math.min(posts[b], Math.max(0, workforce - assigned));
            assigned += skilledHeads[b];
        }
    }
    
    public double[] getJobFillRate(){
        double[] fillRate = new double[jobs.length];
        int[] vacancy = getJobVacancy().clone();
        for(int i = 0; i < jobs.length; i++){
            if(jobs[i]>0){
                fillRate[i] = (jobs[i] - vacancy[i]) / (double) jobs[i];
            }else{
            fillRate[i] = 1;
            }
        }
        
        return fillRate;
    }
    
    public int getWorkforce(){
        return workforce;
    }

    /**
     * Adults who want work and have none.
     *
     * Defined against getJobsFilled() rather than against the raw job count,
     * because a city can have more posts than workers AND unemployment at the
     * same time - a mine with nobody willing to take the shift does not employ
     * the shop assistant it could not hire either. The fill rate already
     * allocates the workforce across the posts; this is whatever it could not
     * place.
     *
     * Lives here rather than at the two screens that show it. The wage bill was
     * once computed in two places from a separately-sampled fill rate and the
     * copies disagreed, which is how a reloaded city came to tax a different
     * payroll from the live one; one definition, and it cannot happen again.
     */
    public int getUnemployed(){
        return (int) Math.max(0, Math.round(getLabourForce() - getJobsFilled()));
    }

    /**
     * Adults who could take a post this month: the workforce less the
     * full-time students.
     *
     * WHY, 2026-09-11. getUnemployed() was `workforce - getJobsFilled()`, and
     * workforceByBand() takes the students off the supply while `workforce`
     * never did - so every full-time student was counted as out of work, on
     * the People screen and in the playtest's rate. Found designing the
     * unemployed households: a student is not looking for work (Jerus,
     * 2026-09-06), and since 2026-09-11 a student is a household of their own.
     */
    public double getLabourForce() {
        // ...and less the prisoners, since 2026-09-11 (night). See workforceByBand().
        return Math.max(0, workforce - getStudyingTotal() - imprisoned);
    }

    /** Unemployed as a share of everyone who could work, 0-1. */
    public double getUnemploymentRate(){
        double force = getLabourForce();
        return force > 0 ? getUnemployed() / force : 0;
    }
    
    public int[] getJobs(){
        return jobs.clone();
    }
    
    public double getAdultPercent(){
        return adultPercent;
    }
    
    public void printPopulationInfo() {

        System.out.println("\n====================== DEMOGRAPHIC & LABOR REPORT ======================");

        /* -------------------------------------------------------------------
       POPULATION OVERVIEW
       ------------------------------------------------------------------- */
        System.out.println("\nPOPULATION OVERVIEW");
        System.out.printf("Total Population:        %,d citizens%n", population);
        System.out.printf("Workforce Share:         %.1f%%%n", adultPercent * 100);
        System.out.printf("Total Workforce:         %,d workers%n", workforce);

        /* -------------------------------------------------------------------
       LABOR MARKET SUMMARY
       ------------------------------------------------------------------- */
        int[] vacancies = getJobVacancy();
        double[] fillRates = getJobFillRate();

        int totalVacancies = 0;
        for (int v : vacancies) {
            totalVacancies += v;
        }

        double utilization
                = (totalJobs > 0)
                        ? ((double) (workforce - Math.max(0, workforce - totalJobs)) / totalJobs) * 100
                        : 0;

        System.out.println("\nLABOR MARKET SUMMARY");
        System.out.printf("Total Jobs Available:    %,d positions%n", totalJobs);
        System.out.printf("Total Vacancies:         %,d positions%n", totalVacancies);
        System.out.printf("Workforce Utilization:   %.2f%%%n", utilization);

        /* -------------------------------------------------------------------
       JOB DISTRIBUTION TABLE
       ------------------------------------------------------------------- */
        System.out.println("\nLABOR SUPPLY BY EDUCATION / JOB TIER");

        System.out.printf("%-20s | %-14s | %-9s | %-10s | %-14s%n",
                "Job Type (Enum)", "Jobs Available", "Vacancies", "Fill Rate", "Monthly Payroll");

        System.out.println("-------------------------------------------------------------------------------");

        for (int i = 0; i < jobs.length; i++) {

            if (jobs[i] > 0) {

                String jobName = jobTypes[i].name();

                double payroll = jobWage[i] * jobs[i];

                System.out.printf("%-20s | %,14d | %,9d | %8.1f%% | $%13s%n",
                        jobName,
                        jobs[i],
                        vacancies[i],
                        fillRates[i] * 100,
                        formatter.format(payroll)
                );
            }
        }

        /* -------------------------------------------------------------------
       LABOR MARKET STATUS
       ------------------------------------------------------------------- */
        if (workforce > totalJobs) {

            System.out.println("\nSTATUS: LABOR SURPLUS");
            System.out.printf("%,d citizens are currently seeking employment.%n",
                    (workforce - totalJobs));

        } else if (totalVacancies > 0) {

            System.out.println("\nWARNING: LABOR SHORTAGE");
            System.out.printf("%,d positions across the city remain unfilled.%n",
                    totalVacancies);
        }

        System.out.println("==========================================================================\n");
    }

    public void resetPopulationManager() {
        population = 0;
        totalJobs = 0;
        workforce = 0;
        imprisoned = 0;
    }
    
    private static final NumberFormat formatter = NumberFormat.getNumberInstance(Locale.CANADA);

    static {
        formatter.setMaximumFractionDigits(2);
        formatter.setMinimumFractionDigits(0);
    }
    
    

    /**
     * The wage table, in the new unit.
     *
     * jobWage is a COPY of the labour market's wages, taken at the top of each
     * month by takeWagesFrom(), and totalWagePerType is that copy times the
     * posts staffed. Both are money and neither is re-derived until the next
     * month begins - so a reform that scaled LabourMarket and stopped there
     * left the households being paid the OLD wage out of the NEW money for one
     * month. Measured at a factor of two: row wages of 1,069 where 534 was
     * wanted, households twice as rich as they should be, and a spending plan
     * that never came back into line.
     *
     * Everything else here is people: cohorts, workforce, jobs, vacancies,
     * licences and who is at school. None of it moves.
     */
    public void redenominate(double scale) {
        for (int i = 0; i < jobWage.length; i++)         jobWage[i] *= scale;
        for (int i = 0; i < totalWagePerType.length; i++) totalWagePerType[i] *= scale;
    }

}
