package ham.citybuildersim;

import java.util.List;

/**
 * How the painted map draws each building type: its class and colour, its footprint, whether it is a road and of which kind, whether it stands on a resource's sites, whether the map places it from the outside of the city in - and how many buildings a tile draws for the people and jobs its model buildings hold.
 *
 * WHY THIS EXISTS (0.7.60, batch J3; the project's spec-land.md 2.5 and 2.6,
 * star 10). Jerus's map mockup (city-map.html) drew ten kinds of building -
 * homes, shops, offices, industry, farms, utilities, schools, health, safety,
 * and mines and wells - each with its fill, its edge and its footprint (the
 * mockup's star 8), and the game has its building types in eighteen
 * categories. This is the one table between them, so the tile painter, the
 * raster, the districts' pyramid and the legend J4 draws all read one answer.
 * It is the picture only: nothing in the model reads it.
 *
 * WHAT IT DECIDES, AND FROM WHAT. A type's category gives its class; three
 * things are read off the template rather than its name, as the house rule
 * asks (BuildingsTemplate's care field): a road is an INFRASTRUCTURE type with
 * a road capacity and no transit, its kind by its freight grade (none gravel,
 * some paved, all a highway); flats are the homes with more than one dwelling
 * (the apartment types, the mockup's star 9 by type, not by people); a mine
 * or well stands on the sites of the resource whose good it makes. Two types
 * are named by their permanent ids, home daycare (15) and home care (22),
 * drawn as homes because they are homes (spec-land star 10).
 *
 * WHAT A TILE DRAWS (J3b, THE VISUAL COUNTS below): not one building for
 * every model building - the model's homes are blocks of up to 252 people -
 * but its homes from the people they house and its shops, offices and
 * plants from their jobs, the mockup's way, so Jerus's city of half a
 * million reads as a city; flats then are the homes of a dense tile, by the
 * people each holds.
 */
public final class BuildingVisual {

    private BuildingVisual() { }

    /* =====================================================================
       THE TEN CLASSES (the mockup's TYPES, in its order)
       ===================================================================== */

    /** Homes: houses, and the flats drawn darker. */
    public static final int HOME = 0;
    /** Shops: convenience and grocery stores, the bank's branches, boutiques, diners. */
    public static final int SHOP = 1;
    /** Offices: business services. */
    public static final int OFFICE = 2;
    /** Industry: bakeries to steel, construction, the railway and the car plants. */
    public static final int INDUSTRY = 3;
    /** Farms: on open grass only. */
    public static final int FARM = 4;
    /** Utilities: power, water and the transit depots. */
    public static final int UTILITY = 5;
    /** Schools, colleges and universities. */
    public static final int SCHOOL = 6;
    /** Health: clinics, hospitals, care and the cemeteries. */
    public static final int HEALTH = 7;
    /** Safety: police and the jails. */
    public static final int SAFETY = 8;
    /** Mines and wells: on their resource's sites. */
    public static final int MINE = 9;

    /** How many classes: ten - what the pyramid sums a node's buildings by (spec-land 2.5). */
    public static final int CLASSES = 10;

    /** The classes' names, as the legend writes them (the mockup's). */
    public static final String[] CLASS_NAMES = { "Homes", "Shops", "Offices", "Industry", "Farms", "Utilities",
            "Schools", "Health", "Safety", "Mines and wells" };

    /** Each class's fill, 0xAARRGGBB - the mockup's TYPES. */
    public static final int[] FILL = { 0xffeaa572, 0xfff2c94c, 0xff5b8fd6, 0xff9076ba, 0xffe0cb84, 0xff2ea89e,
            0xffd0587a, 0xfff7f4ee, 0xffd8442f, 0xff8e9093 };

    /** ...and its edge, drawn from 6 px a plot (the mockup's). */
    public static final int[] EDGE = { 0xff9a5a2c, 0xff987718, 0xff2c5590, 0xff55407a, 0xffa99550, 0xff17635d,
            0xff86304a, 0xff8f8a82, 0xff86251a, 0xff3d3f42 };

    /** Flats' fill: the mockup's FLATS, a darker orange than a house. */
    public static final int FLATS_FILL = 0xffd07a44;

    /** ...and their edge. */
    public static final int FLATS_EDGE = 0xff7e4119;

    /* --------------------------------------------------------- road kinds */

    /** Not a road. */
    public static final int NOT_A_ROAD = 0;
    /** A gravel road: no freight grade. */
    public static final int GRAVEL = 1;
    /** A paved road: a freight grade under one. */
    public static final int PAVED = 2;
    /** An elevated highway: a freight grade of one. */
    public static final int HIGHWAY = 3;

    /** The permanent ids of the two care types drawn as homes, because they are run from homes (spec-land star 10): Home Daycare (15) and Home Care Service (22). */
    static final int[] DRAWN_AS_HOMES = { 15, 22 };

    /** Plots in a footprint past which a health building is drawn 3 x 2, a hospital's, rather than 1 x 1: 40 (387,500 sq ft) - the prototype's line, which puts the general and regional hospitals and the larger cemeteries there and the clinics and care homes on one plot. */
    public static final double HOSPITAL_PLOTS = 40;

    /** Square feet in a plot: 30 m squared in square feet, 9,687.5 - what a template's land is turned into plots by. */
    public static final double SQ_FT_PER_PLOT = World.KM2_PER_PLOT * LandManager.SQ_FT_PER_KM2;

    /* =====================================================================
       ONE TYPE
       ===================================================================== */

    /**
     * One building type as the map draws it.
     *
     * @param id        the template's permanent id (a visual kind's VISUAL_ID + its kind)
     * @param category  its category
     * @param cls       its class, HOME to MINE
     * @param flats     a home of more than one dwelling, drawn darker
     * @param road      its road kind, NOT_A_ROAD to HIGHWAY
     * @param site      the resource whose sites it stands on, or null
     * @param outer     placed from the outside of the city in: farms, utilities, mines and wells, rail and car plants (spec-land 2.5)
     * @param plots     its land in plots: what it takes of a district's room, and a road's budget
     * @param transit   a transit network's depot, drawn as a one-plot utility
     * @param sqFt      its land in whole square feet: what a district's room is kept in, exactly
     * @param people    the people a home of it holds (its capacity; 0 for anything but a home): what its tile's homes are drawn from
     * @param jobs      the jobs it holds: what its tile's shops, offices and plants are drawn from
     */
    public record Type(int id, BuildingType category, int cls, boolean flats, int road, Resource site,
                       boolean outer, double plots, boolean transit, long sqFt, int people, int jobs) {

        /** Whether it is drawn as a building: not a road. */
        public boolean drawn() { return road == NOT_A_ROAD; }

        /** Its fill. */
        public int fill() { return flats ? FLATS_FILL : FILL[cls]; }

        /** Its edge. */
        public int edge() { return flats ? FLATS_EDGE : EDGE[cls]; }
    }

    /** A template as the map draws it. */
    public static Type of(BuildingsTemplate t) {
        BuildingType c = t.getCategory();
        int id = t.getId();
        double plots = Math.max(0, t.getLandSqFt()) / SQ_FT_PER_PLOT;
        int road = NOT_A_ROAD;
        if (c == BuildingType.INFRASTRUCTURE && !t.isTransit() && t.getCapacity() > 0) {
            double g = t.getFreightGrade();
            road = g <= 0 ? GRAVEL : g < 1 ? PAVED : HIGHWAY;
        }
        Resource site = null;
        if (c == BuildingType.MINING) {
            for (Resource r : Resource.values()) {
                if (r.good() != null && t.makes(r.good()) > 0) site = r;
            }
        }
        boolean flats = c == BuildingType.RESIDENTIAL && t.getDwellings() > 1;
        int cls = classOf(c);
        for (int h : DRAWN_AS_HOMES) if (h == id) cls = HOME;
        boolean outer = c == BuildingType.AGRICULTURE || c == BuildingType.ELECTRICITY || c == BuildingType.WATER
                || c == BuildingType.MINING || c == BuildingType.RAIL || c == BuildingType.AUTOMOTIVE;
        int people = c == BuildingType.RESIDENTIAL ? Math.max(0, t.getCapacity()) : 0;
        return new Type(id, c, cls, flats, road, site, outer, plots, t.isTransit(), Math.round(Math.max(0, t.getLandSqFt())),
                people, Math.max(0, t.getTotalJobs()));
    }

    /** A category's class (the mockup's ten). */
    public static int classOf(BuildingType c) {
        if (c == null) return INDUSTRY;
        switch (c) {
            case RESIDENTIAL:                                   return HOME;
            case COMMERCIAL: case LUXURY: case HOSPITALITY:     return SHOP;
            case BUSINESS_SERVICES:                             return OFFICE;
            case AGRICULTURE:                                   return FARM;
            case ELECTRICITY: case WATER: case INFRASTRUCTURE:  return UTILITY;
            case EDUCATION:                                     return SCHOOL;
            case HEALTHCARE:                                    return HEALTH;
            case SAFETY:                                        return SAFETY;
            case MINING:                                        return MINE;
            default:                                            return INDUSTRY;
        }
    }

    /**
     * Every type of a list of templates, indexed by id (null where no
     * template has that id): the table the map is drawn from.
     */
    public static Type[] table(List<BuildingsTemplate> templates) {
        int max = -1;
        for (BuildingsTemplate t : templates) max = Math.max(max, t.getId());
        Type[] out = new Type[max + 1];
        for (BuildingsTemplate t : templates) if (t.getId() >= 0) out[t.getId()] = of(t);
        return out;
    }

    /* =====================================================================
       FOOTPRINTS (the mockup's star 8, not true land: spec-land star 10)
       ===================================================================== */

    /** The share of industry drawn 2 x 2 rather than 3 x 2: 60% (the mockup's). */
    public static final double INDUSTRY_SQUARE = 0.6;

    /** A farm's side, in plots, at the least: 3... */
    public static final int FARM_MIN = 3;

    /** ...plus up to this many more: 2, so 3 to 5 a side (the mockup's). */
    public static final int FARM_SPAN = 2;

    /**
     * The footprint the j-th building of a type takes, {width, height, grass
     * only}: most things one plot; industry 2 x 2 (60%) or 3 x 2; schools and
     * utilities 2 x 2 (a transit depot one); a hospital-sized health building
     * 3 x 2; farms 3 to 5 a side, on grass only. From the tile's own hash, so
     * the same building always takes the same shape.
     */
    public static int[] footprint(Type t, int j, long tileSeed) {
        double u = World.unit(World.mix(tileSeed ^ ((long) t.id() << 20) ^ j ^ 0x51EDL));
        switch (t.cls()) {
            case INDUSTRY: return u < INDUSTRY_SQUARE ? new int[] { 2, 2, 0 } : new int[] { 3, 2, 0 };
            case FARM: {
                double v = World.unit(World.mix(Double.doubleToLongBits(u) ^ 0xFA4AL));
                return new int[] { FARM_MIN + (int) (u * (FARM_SPAN + 1)), FARM_MIN + (int) (v * (FARM_SPAN + 1)), 1 };
            }
            case UTILITY: return t.transit() ? new int[] { 1, 1, 0 } : new int[] { 2, 2, 0 };
            case SCHOOL:  return new int[] { 2, 2, 0 };
            case HEALTH:  return t.plots() > HOSPITAL_PLOTS ? new int[] { 3, 2, 0 } : new int[] { 1, 1, 0 };
            default:      return new int[] { 1, 1, 0 };
        }
    }

    /** The plots a building of a type takes on the map, on average over its footprints: industry 4.8 (60% at 2 x 2, the rest 3 x 2), a farm 16 (3 to 5 a side), schools and utilities 4 (a transit depot 1), a hospital 6, the rest 1. */
    public static double meanPlots(Type t) {
        switch (t.cls()) {
            case INDUSTRY: return INDUSTRY_SQUARE * 4 + (1 - INDUSTRY_SQUARE) * 6;
            case FARM: {
                double side = FARM_MIN + FARM_SPAN / 2.0;
                return side * side;
            }
            case UTILITY: return t.transit() ? 1 : 4;
            case SCHOOL:  return 4;
            case HEALTH:  return t.plots() > HOSPITAL_PLOTS ? 6 : 1;
            default:      return 1;
        }
    }

    /* =====================================================================
       THE VISUAL COUNTS: HOMES FROM PEOPLE, WORKPLACES FROM JOBS (0.7.60,
       batch J3b)

       The model's homes are blocks: one Low-Rise Apartments holds 252
       people, and J3 drew it as one dot, so Jerus's city of half a million
       showed a home a seventh of its plots and read as scattered dots on a
       field. The mockup drew a home for every 3 to 75 people - houses at the
       edge, flats in the core - so the map now draws what the buildings
       hold rather than how many there are: a tile's homes from the people
       its homes house, its shops, offices and plants from the jobs its
       workplaces hold, each at so many a building, and its schools,
       clinics, utilities, farms and mines one for one, being few and large.
       Every number here comes from the model's counts on the tile, so a
       tile that gains people never loses homes, and the counts still sum to
       what the model's buildings imply.
       ===================================================================== */

    /** The four kinds drawn from people and jobs rather than one for one: homes, shops, offices and plants - each class's visual building. */
    public static final int[] VISUAL_CLASSES = { HOME, SHOP, OFFICE, INDUSTRY };

    /** How many: four. */
    public static final int VISUAL_KINDS = VISUAL_CLASSES.length;

    /** The visual kinds' ids, VISUAL_ID + their index: past any template's id and fixed, so where a visual building stands never hangs on how many templates the game has. */
    public static final int VISUAL_ID = 4096;

    /** People a home holds where the city is thinnest: 5, the mockup's house (3 people and up to 4 more by its hash). */
    public static final double HOUSE_PEOPLE = 5;

    /** The density, in people a dry plot, from which a tile's homes hold more people each: a quarter of a person a plot (star) - so a town's houses hold 5 to 11, and flats come in only where a tile is about as dense as Jerus's city's average (4.7 people a plot)... */
    public static final double HOME_GROWS_FROM = 0.25;

    /** ...and the power they grow by: a half, so ten times the people make about three times the people a home and three times the homes - a denser city is drawn both darker and fuller. */
    public static final double HOME_GROWTH = 0.5;

    /** The most of a tile's owned dry ground its homes cover: 26% - with the workplaces' caps and their road, 58% of a tile at the very most, and less where it counts, since the plants lean out of the middle where the homes peak: the densest middle is never a solid carpet (spec-land star 10: true land filled 92%, a carpet). */
    public static final double HOME_COVER_MOST = 0.26;

    /** A home of more people than this is drawn as flats, darker: 30, the mockup's FLATS_AT. */
    public static final double FLATS_AT = 30;

    /** Each home's own people about its tile's mean, by its hash: 40% either way, so a tile's homes turn from houses to flats gradually as it grows dense (all houses below 21 people a home, all flats above 50). */
    public static final double HOME_SPREAD = 0.4;

    /** Jobs a visual shop holds: 8 - the model's shops hold 6 to 11 a plot (a diner 4 and a convenience store 5 on half a plot, a boutique 7 on 0.6), and a shop is drawn on one. */
    public static final double SHOP_JOBS = 8;

    /** Jobs a visual office holds: 38.75 - the model's offices hold that many a plot (the Engineering Services Office 120 on 30,000 sq ft, the Contact Centre 300 on 75,000), and an office is drawn on one. */
    public static final double OFFICE_JOBS = 120 / (30_000 / SQ_FT_PER_PLOT);

    /** Jobs a visual plant holds: 150 (star) - a plant is drawn on the mockup's 4.8 plots, not its true land (spec-land star 10), so this is a judgement: it keeps the plants secondary to the homes, as the mockup's were (Jerus's 140,574 jobs in plants are 892 plants on 4% of his ground; his homes take 18%). */
    public static final double PLANT_JOBS = 150;

    /** The most of a tile's ground each visual kind's workplaces cover (shops, offices, plants): 4%, 4% and 10% - room for the plants' strips along the highways and the shops of the middle, so the caps cost Jerus's city 6% of its plants and 4% of its shops; with the homes' 26%, 44% at the very most, their road on top. */
    public static final double[] WORK_COVER_MOST = { 0, 0.04, 0.04, 0.10 };

    /** Plots of road a tile grows for every plot its buildings take: 0.31 - the mockup's at its default step, 550 plots grown (15.7 km paved, 0.8 gravel) beside 1,777 plots of buildings. */
    public static final double ROAD_PER_PLOT = 0.31;

    /** A tile's road budget moves a step at a time: 12 plots, about two of the mockup's extensions (3 to 8 plots) - so most buildings added leave its roads as they are (at 6, a model building stepped its tile's road in 14% of MapCheck's cases, at 12 in 6%). */
    public static final int ROAD_STEP = 12;

    /** People and jobs a dry plot at or below which a tile's roads are all gravel: half (star) - a village, the fringe of a town... */
    public static final double ALL_GRAVEL = 0.5;

    /** ...and at or above which they are all paved: 3 (star) - a town's streets; Jerus's city averages 6.3 (472,000 people housed and 160,000 jobs on 100,000 plots), the playtest's at month 1,000 about 3. Between, paved in proportion, in tenths. */
    public static final double ALL_PAVED = 3;

    /** The painter's table of types: the map's types by id, then the four visual kinds at the end (their ids VISUAL_ID + kind) - what a tile's counts index. */
    public static Type[] paintTable(Type[] types) {
        Type[] out = java.util.Arrays.copyOf(types, types.length + VISUAL_KINDS);
        BuildingType[] cat = { BuildingType.RESIDENTIAL, BuildingType.COMMERCIAL, BuildingType.BUSINESS_SERVICES, BuildingType.INDUSTRIAL };
        for (int k = 0; k < VISUAL_KINDS; k++) {
            out[types.length + k] = new Type(VISUAL_ID + k, cat[k], VISUAL_CLASSES[k], false, NOT_A_ROAD, null, false, 1, false,
                    Math.round(SQ_FT_PER_PLOT), 0, 0);
        }
        return out;
    }

    /** Whether a type is one of the four visual kinds. */
    public static boolean visual(Type t) { return t != null && t.id() >= VISUAL_ID; }

    /** The visual kind a type's people or jobs are drawn as (0 homes to 3 plants), or -1 when it is drawn one for one: a road, a service, a utility, a farm, a mine, a transit depot. Home daycare and home care are run from homes (spec-land star 10), so they are drawn as the homes they are and take nothing of their own. */
    public static int visualKindOf(Type t) {
        if (t == null || t.road() != NOT_A_ROAD || visual(t)) return -1;
        if (t.category() == BuildingType.RESIDENTIAL) return 0;
        for (int h : DRAWN_AS_HOMES) if (h == t.id()) return 0;
        switch (t.cls()) {
            case SHOP:     return 1;
            case OFFICE:   return 2;
            case INDUSTRY: return 3;
            default:       return -1;
        }
    }

    /**
     * The people a tile's homes hold each, on average, at `perPlot` people
     * a dry plot: HOUSE_PEOPLE x (1 + perPlot / HOME_GROWS_FROM) ^
     * HOME_GROWTH - 5 in an empty field, 9 at half a person a plot, 22 at
     * Jerus's average of 4.7 - and never so few that its homes would cover
     * more than HOME_COVER_MOST of its ground: past about 7 people a plot,
     * 28 and up (54 at 14).
     */
    public static double peoplePerHome(double perPlot) {
        double p = Math.max(0, perPlot);
        return Math.max(HOUSE_PEOPLE * Math.pow(1 + p / HOME_GROWS_FROM, HOME_GROWTH), p / HOME_COVER_MOST);
    }

    /** How many homes a tile of `plots` plots to build on draws for `people` people: people / peoplePerHome, rounded - more people, or more ground, never fewer homes; none on no ground. */
    public static int homes(double people, int plots) {
        if (people <= 0 || plots <= 0) return 0;
        return (int) Math.round(people / peoplePerHome(people / plots));
    }

    /** How many workplaces of visual kind k (1 shops, 2 offices, 3 plants) a tile of `plots` plots to build on draws for `jobs` jobs: jobs / the kind's jobs each, rounded (at least one), and never covering more than WORK_COVER_MOST of the tile - more jobs, or more ground, never fewer; none on no ground. */
    public static int workplaces(int k, double jobs, int plots) {
        if (jobs <= 0 || plots <= 0) return 0;
        double each = k == 1 ? SHOP_JOBS : k == 2 ? OFFICE_JOBS : PLANT_JOBS;
        double plotsEach = k == 3 ? INDUSTRY_SQUARE * 4 + (1 - INDUSTRY_SQUARE) * 6 : 1;
        long n = Math.max(1, Math.round(jobs / each));
        return (int) Math.min(n, Math.max(1, (long) Math.floor(WORK_COVER_MOST[k] * plots / plotsEach)));
    }

    /** Whether the j-th home of a tile is drawn as flats: its own people, its tile's mean HOME_SPREAD either way by its hash, more than FLATS_AT. */
    public static boolean flats(double peoplePerHome, int j, long tileSeed) {
        return peopleIn(peoplePerHome, j, tileSeed) > FLATS_AT;
    }

    /** The people the j-th home of a tile holds, for its colour and a hover: its tile's mean, HOME_SPREAD either way by its own hash. */
    public static double peopleIn(double peoplePerHome, int j, long tileSeed) {
        double u = World.unit(World.mix(tileSeed ^ ((long) VISUAL_ID << 20) ^ j ^ 0xF1A75L));
        return peoplePerHome * (1 + HOME_SPREAD * (2 * u - 1));
    }

    /** The share of a tile's road paved, in tenths: by its people and jobs a dry plot, ALL_GRAVEL to ALL_PAVED, and never below `floor` (the model's own paved share). */
    public static double pavedShare(double perPlot, double floor) {
        double s = (perPlot - ALL_GRAVEL) / (ALL_PAVED - ALL_GRAVEL);
        s = Math.max(s, floor);
        s = Math.min(1, Math.max(0, s));
        return Math.floor(s * 10 + 1e-9) / 10;
    }

    /** The road a tile grows for `buildingPlots` plots of buildings: ROAD_PER_PLOT of them, in whole ROAD_STEPs and at least one step when it has anything. */
    public static int roadBudget(double buildingPlots, boolean anything) {
        if (!anything && buildingPlots <= 0) return 0;
        long steps = (long) Math.ceil(ROAD_PER_PLOT * buildingPlots / ROAD_STEP - 1e-9);
        return (int) (ROAD_STEP * Math.max(1, steps));
    }
}
