package ham.citybuildersim;

/**
 * An older city's land put on the world, and a city's land drawn again to hold a new figure: the site found for it, the centre holding exactly the dry ground it owned, its iron as its save had it, and forty offers listed from the centre's edge.
 *
 * WHY THIS EXISTS (0.7.57, batch J1b; the project's spec-land.md 2.9). A save
 * of format 30 or older carries the land as one figure, the square feet owned,
 * a pool of iron sites and tonnes, and nine parcels with no place. Loaded as
 * it was, its pooled ore and its listing would be read wrongly by a build
 * whose ground is real (hence SAVE_FORMAT 31), so the load converts it, once:
 *
 *   the seed    the save's own (DataSave.getFounding(): kept since 0.7.56, or
 *               derived from its name, founding treasury, ground and month);
 *   the site    the founding search, a coastal cell at a time, with a fifth
 *               test: the L-infinity square holding the city's dry ground is
 *               at least CENTRE_DRY_MIN dry, with the sea within its half-side
 *               and CENTRE_SEA_KM - the founding site itself passes for a new
 *               city's 0.28 km2, not for a played city's 90 km2 on a coast;
 *               if none of the nearest SITE_CELLS passes, the driest found;
 *   the centre  sized to hold exactly the ground the save owned;
 *   the iron    the save's sites, raised to cover the mines standing and on
 *               order, and its tonnes, never more (spec-land star 9) - the
 *               centre's own fields are the map's, scaled to that (batch J3),
 *               or one legacy field when the world put none in it;
 *   the offers  forty, at today's prices; the old nine parcels go, once;
 *   E           nothing taken out yet.
 *
 * Restating (restate()) draws a city's land again round the same site, the
 * centre holding the whole of a new figure: what LandManager.setOwnedSqFt()
 * does once the land exists - a harness's ground by fiat, and the load of a
 * save whose square feet disagree with its ground, which is what a copy of a
 * city K times over is (ScaleCheck). The city's iron and what it has taken out
 * are kept as they were; the other resources are what the world holds in the
 * new centre.
 */
public final class LandConversion {

    private LandConversion() { }

    /** The least share of a converted city's centre that is dry ground: 80% (spec-land 2.9), so a played city is not put on a peninsula two-thirds sea. */
    public static final double CENTRE_DRY_MIN = 0.8;

    /** ...with the sea within its half-side and this many kilometres: 2, a city on a coast. */
    public static final double CENTRE_SEA_KM = 2;

    /** The last save format whose land is converted rather than read: 30, the format before the land was on the world (GameVersion.SAVE_FORMAT 31). */
    public static final int LAST_FORMAT_BEFORE = 30;

    /** How near a save's square feet must be to its land's dry ground to be the same ground: a part in a billion of it (spec-land 2.9) - a centre's dry ground is stored in square kilometres, and back in square feet it is the same figure to within rounding. */
    public static final double SAME_GROUND = 1e-9;

    /** How many coastal cells' sites are tried, nearest the world's middle first: 64. */
    public static final int SITE_CELLS = 64;

    /** A legacy iron field stands at least this far from the site: 1 km (spec-land 2.4). */
    public static final double LEGACY_FIELD_KM = 1;

    /** Draws for the legacy field's dry plot: 64. */
    static final int LEGACY_DRAWS = 64;

    /** The stream the legacy field's plot is drawn from. */
    private static final long LEGACY_STREAM = 0x1E6AC7L;

    /**
     * Where an older city's centre goes: the first site of the founding
     * search, a coastal cell at a time, whose square holding dryKm2 passes the
     * fifth test; or, when none of the nearest SITE_CELLS does, the one whose
     * square out to the test's reach is driest. {x, y} as plots.
     */
    public static long[] site(World world, double dryKm2) {
        double reach = CityLand.idealHalf(dryKm2) / Math.sqrt(CENTRE_DRY_MIN);
        double sea = CENTRE_SEA_KM * 1000 / World.PLOT_M;
        long[][] driest = { null };
        double[] driestShare = { -1 };
        long[] found = world.searchSites(SITE_CELLS, s -> {
            double[] within = CityLand.within(world, s[0], s[1], dryKm2, reach);
            double share = within[CityLand.TOTAL] > 0 ? within[CityLand.DRY] / within[CityLand.TOTAL] : 0;
            if (share > driestShare[0]) {
                driestShare[0] = share;
                driest[0] = s;
            }
            if (within[CityLand.DRY] < dryKm2) return false;
            double half = CityLand.sizeCentre(world, s[0], s[1], dryKm2).half();
            return CityLand.within(world, s[0], s[1], dryKm2, half + sea)[CityLand.SEA] > 0;
        });
        if (found != null) return found;
        if (driest[0] != null) return driest[0];
        return new long[] { world.foundingX(), world.foundingY() };
    }

    /**
     * Converts an older city's land (spec-land 2.9): on the world its seed
     * makes, the site site() finds, a centre holding drySqFt of dry ground,
     * its iron the save's - at least the mines standing and on order - and
     * its tonnes; nothing taken out; the offers listed at the prices the
     * office last struck (the load has put them back).
     */
    public static void convert(LandManager lm, long seed, double drySqFt, int ironSites, double ironTonnes,
                               int minesCommitted) {
        World world = World.of(seed);
        double dryKm2 = LandManager.km2(drySqFt);
        long[] at = site(world, dryKm2);
        CityLand land = CityLand.found(world, at[0], at[1], dryKm2);
        boolean worldIron = land.centreSites(Resource.IRON) > 0;
        int sites = Math.max(Math.max(0, ironSites), Math.max(0, minesCommitted));
        land.setCentre(Resource.IRON, sites, Math.max(0, ironTonnes));
        if (!worldIron && sites > 0) legacyField(world, land, sites);
        lm.install(land, new double[CityLand.KINDS], world.totals(), world.seaTheta());
        lm.restoreOwnedSqFt(drySqFt);
        lm.getMarket().listMissing();
    }

    /**
     * The map's iron for a converted centre the world put none in: one field
     * of the city's sites at a dry plot drawn from the seed, at least
     * LEGACY_FIELD_KM from the site and within the centre when the centre
     * reaches that far (spec-land 2.4).
     */
    static void legacyField(World world, CityLand land, int sites) {
        double near = LEGACY_FIELD_KM * 1000 / World.PLOT_M;
        double half = Math.max(land.centreHalf(), near);
        long h = World.mix(land.seed() ^ LEGACY_STREAM);
        long fx = land.siteX() + Math.round(near), fy = land.siteY();
        for (int k = 0; k < LEGACY_DRAWS; k++) {
            h = World.mix(h);
            double dx = (2 * World.unit(h) - 1) * half;
            h = World.mix(h);
            double dy = (2 * World.unit(h) - 1) * half;
            if (dx * dx + dy * dy < near * near) continue;
            long x = land.siteX() + Math.round(dx), y = land.siteY() + Math.round(dy);
            byte c = world.terrainAt(x, y);
            if (c == World.SALT || c == World.FRESH) continue;
            fx = x;
            fy = y;
            break;
        }
        land.setLegacyField(fx, fy, sites);
    }

    /**
     * Draws a city's land again to hold drySqFt of dry ground: the centre
     * round the same site, holding all of it, the purchases folded in and the
     * lanes back at its edge; the city's iron sites and tonnes and what it has
     * taken out of every resource kept as they were; the other resources what
     * the world holds in the new centre; forty offers listed from its edge at
     * the prices the office last struck.
     */
    public static void restate(LandManager lm, double drySqFt) {
        CityLand land = lm.land();
        World world = World.of(land.seed());
        long ironSites = land.totalSites(Resource.IRON);
        double ironTonnes = land.totalAmount(Resource.IRON);
        land.drawCentre(world, LandManager.km2(drySqFt));
        land.setCentre(Resource.IRON, (int) Math.min(Integer.MAX_VALUE, ironSites), ironTonnes);
        lm.restoreOwnedSqFt(drySqFt);
        lm.getMarket().attach(land);
        lm.getMarket().listMissing();
    }
}
