package ham.citybuildersim;

/**
 * Verifies the residents' books and the demolition log.
 *
 * The household statement is the last missing side of this economy's ledger, so
 * what matters most here is that it is the OTHER SIDE of figures that already
 * exist rather than a second, differently-computed version of them. If the
 * people can be shown paying a different rent from the one landlords are shown
 * receiving, the statement is worse than useless.
 */
public class HouseholdCheck {

    static int fails = 0;

    static void check(String label, double actual, double expected) {
        boolean ok = Math.abs(actual - expected) < 1e-6;
        if (!ok) fails++;
        System.out.printf("%-54s %13.4f  expected %13.4f  %s%n",
                label, actual, expected, ok ? "OK" : "FAIL");
    }

    static void assertTrue(String label, boolean ok) {
        if (!ok) fails++;
        System.out.printf("%-54s %s%n", label, ok ? "OK" : "FAIL");
    }

    /** One stock across every cell: per household times households. */
    static double across(HouseholdBalance b, java.util.function.ToDoubleFunction<Household> perHousehold) {
        double total = 0;
        for (Household c : b.cells()) total += perHousehold.applyAsDouble(c) * c.households();
        return total;
    }

    public static void main(String[] args) {

        /* ==================== 1. the statement ==================== */
        System.out.println("--- the month ---");

        HouseholdAccounts hh = new HouseholdAccounts();

        // 1,000 of wages, 15% tax, 300 of rent, 400 in the shops.
        hh.update(1000, 150, 300, 400, 500, 250, 240);

        check("wages", hh.getWages(), 1000);
        check("wage tax", hh.getWageTax(), 150);
        check("take-home", hh.getDisposableIncome(), 850);
        check("rent", hh.getRent(), 300);
        check("shopping", hh.getShopping(), 400);
        check("total spending", hh.getSpending(), 700);
        check("saved", hh.getNetSaving(), 150);

        // Take-home less spending, not gross less spending: the tax is gone
        // before the people ever see it.
        check("saving rate is on take-home", hh.getSavingRate(), 150.0 / 850);
        check("effective tax rate", hh.getEffectiveTaxRate(), .15);
        check("rent burden", hh.getRentBurden(), 300.0 / 850);

        /* ============ 2. spending more than they earn ============ */
        System.out.println("\n--- living beyond it ---");

        // The case worth catching. Retail spending is driven by how many people
        // there are, not by what they earn, so nothing in the model prevents
        // this - and if it happens, money is arriving from nowhere.
        HouseholdAccounts squeezed = new HouseholdAccounts();
        squeezed.update(1000, 150, 600, 400, 500, 250, 240);

        assertTrue("spending over take-home is flagged", squeezed.isLivingBeyondIncome());
        check("...as a negative", squeezed.getNetSaving(), -150);
        assertTrue("...and a negative saving rate", squeezed.getSavingRate() < 0);
        assertTrue("rent over a third of income", squeezed.getRentBurden() > .35);
        System.out.printf("   short $%.0f a month, rent at %.0f%% of take-home%n",
                -squeezed.getNetSaving(), squeezed.getRentBurden() * 100);

        // Exactly breaking even is not living beyond it.
        HouseholdAccounts breakeven = new HouseholdAccounts();
        breakeven.update(1000, 150, 450, 400, 500, 250, 240);
        check("nothing left", breakeven.getNetSaving(), 0);
        assertTrue("...but not a shortfall", !breakeven.isLivingBeyondIncome());

        /* ==================== 3. accumulating ==================== */
        System.out.println("\n--- over time ---");

        HouseholdAccounts saver = new HouseholdAccounts();
        for (int i = 0; i < 12; i++) {
            saver.update(1000, 150, 300, 400, 500, 250, 240);
        }
        check("a year of saving 150", saver.getCumulativeSaving(), 1800);
        check("the month itself is still just one month", saver.getNetSaving(), 150);

        // A bad year eats into it, and the total can go negative - which is the
        // honest reading of a city whose people have been underpaid for years.
        for (int i = 0; i < 24; i++) {
            saver.update(1000, 150, 700, 400, 500, 250, 240);
        }
        check("two years of losing 250", saver.getCumulativeSaving(), 1800 - 24 * 250);
        assertTrue("cumulative can go negative", saver.getCumulativeSaving() < 0);

        /* ==================== 4. per head ==================== */
        System.out.println("\n--- per head ---");

        check("income per resident", hh.getIncomePerResident(), 1000.0 / 500);
        check("spending per resident", hh.getSpendingPerResident(), 700.0 / 500);
        check("average filled job pays", hh.getAverageWage(), 1000.0 / 240);
        check("people per worker", hh.getDependencyRatio(), 500.0 / 250);

        // An empty city divides by nothing and must not produce infinity.
        HouseholdAccounts empty = new HouseholdAccounts();
        empty.update(0, 0, 0, 0, 0, 0, 0);
        check("no people -> no income per head", empty.getIncomePerResident(), 0);
        check("no workers -> no average wage", empty.getAverageWage(), 0);
        check("no dependency ratio either", empty.getDependencyRatio(), 0);
        check("no income -> no saving rate", empty.getSavingRate(), 0);
        check("...nor a rent burden", empty.getRentBurden(), 0);
        check("no wages -> no tax rate", empty.getEffectiveTaxRate(), 0);

        HouseholdAccounts reset = new HouseholdAccounts();
        reset.update(1000, 150, 300, 400, 500, 250, 240);
        reset.reset();
        check("reset clears the running total", reset.getCumulativeSaving(), 0);
        check("...and the month", reset.getWages(), 0);

        /* ============ 5. it is the other side of consumption ============ */
        System.out.println("\n--- the same money, from the other end ---");

        // What households pay out IS consumption in the national accounts. If
        // these two ever diverge, one of them is wrong.
        NationalAccounts na = new NationalAccounts();
        na.update(400, 300, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0); // 400 retail, 300 rent

        HouseholdAccounts paired = new HouseholdAccounts();
        paired.update(1000, 150,
                na.getConsumptionHousing(), na.getConsumptionGoods(),
                500, 250, 240);

        check("what the people paid in rent", paired.getRent(), na.getConsumptionHousing());
        check("what they spent in shops", paired.getShopping(), na.getConsumptionGoods());
        check("household spending IS consumption",
                paired.getSpending(), na.getConsumption());

        /* ==================== 6. the demolition log ==================== */
        System.out.println("\n--- what the city lost ---");

        DemolitionLog log = new DemolitionLog();
        check("nothing lost yet", log.size(), 0);
        assertTrue("...and nothing to show", log.recent(1).isEmpty());

        log.record("Construction Depot", 3, "Construction", 10, 180);
        check("recorded", log.size(), 1);

        DemolitionLog.Entry entry = log.recent(10).get(0);
        check("quantity", entry.quantity, 3);
        assertTrue("building", "Construction Depot".equals(entry.building));
        assertTrue("sector", "Construction".equals(entry.sector));
        assertTrue("the city paid for the plot", entry.wasPaidFor());

        assertTrue("this month", "this month".equals(entry.when(10)));
        assertTrue("last month", "last month".equals(entry.when(11)));
        assertTrue("three months ago", "3 months ago".equals(entry.when(13)));
        check("months ago", entry.monthsAgo(13), 3);

        // A clock that somehow went backwards must not produce negative ages.
        check("never negative", entry.monthsAgo(5), 0);

        // Abandoned plots read differently from ones the city bought back.
        log.record("Steel Foundry", 1, "Heavy Industry", 11, 0);
        assertTrue("abandoned plot", !log.recent(11).get(0).wasPaidFor());

        /* ==================== 7. it fades out ==================== */
        System.out.println("\n--- and stops showing eventually ---");

        assertTrue("still visible after a year", log.recent(10 + 12).size() == 2);
        assertTrue("still there at the limit",
                !log.recent(10 + DemolitionLog.KEEP_MONTHS).isEmpty());
        assertTrue("gone a month later",
                log.recent(11 + DemolitionLog.KEEP_MONTHS + 1).isEmpty());
        assertTrue("...but not forgotten by all()", log.all().size() == 2);

        // Newest first, so the eye lands on what just happened.
        assertTrue("newest first", "Steel Foundry".equals(log.recent(11).get(0).building));

        // Nonsense is refused rather than stored.
        DemolitionLog strict = new DemolitionLog();
        strict.record(null, 3, "Retail", 5, 0);
        strict.record("House", 0, "Real Estate", 5, 0);
        strict.record("House", -2, "Real Estate", 5, 0);
        check("nothing nonsensical stored", strict.size(), 0);

        // Bounded, so a city demolishing every month cannot grow this forever.
        DemolitionLog busy = new DemolitionLog();
        for (int m = 1; m <= 200; m++) {
            busy.record("House", 1, "Real Estate", m, 8);
        }
        assertTrue("the log is capped", busy.size() <= 40);
        assertTrue("and keeps the newest",
                busy.all().get(0).month == 200);

        log.clear();
        check("cleared", log.size(), 0);

        /* ==================== 8. the same books, per tier ==================== */
        System.out.println("\n--- split seven ways ---");

        /*
         * THE ROWS MUST ADD UP TO THE TOTAL. That is the only claim worth making
         * about a breakdown: if the parts and the whole disagree, one of them is
         * a second, differently-computed version of the other, which is the
         * failure this whole file exists to prevent.
         */
        HouseholdAccounts split = new HouseholdAccounts();
        split.update(1000, 150, 300, 400, 500, 250, 240);

        int rows = HouseholdAccounts.RETIRED + 1;
        double[] wagesByTier = new double[PayTier.values().length];
        double[] taxByTier   = new double[PayTier.values().length];
        wagesByTier[PayTier.UNSKILLED.ordinal()] = 600;
        wagesByTier[PayTier.SKILLED.ordinal()]   = 400;
        taxByTier[PayTier.UNSKILLED.ordinal()]   = 60;
        taxByTier[PayTier.SKILLED.ordinal()]     = 90;

        double[] people = new double[rows];
        double[] houses = new double[rows];
        people[PayTier.UNSKILLED.ordinal()] = 300;
        people[PayTier.SKILLED.ordinal()]   = 150;
        people[HouseholdAccounts.RETIRED]   = 50;
        houses[PayTier.UNSKILLED.ordinal()] = 150;
        houses[PayTier.SKILLED.ordinal()]   = 70;
        houses[HouseholdAccounts.RETIRED]   = 40;

        split.updateByTier(wagesByTier, taxByTier, people, houses);

        double sumWages = 0, sumTax = 0, sumRent = 0, sumShop = 0, sumPeople = 0;
        for (int r = 0; r < rows; r++) {
            sumWages += split.getRowWages(r);
            sumTax   += split.getRowTax(r);
            sumRent  += split.getRowRent(r);
            sumShop  += split.getRowShopping(r);
            sumPeople += split.getRowPeople(r);
        }
        check("the tiers' wages add up to the city's", sumWages, split.getWages());
        check("...and their tax", sumTax, split.getWageTax());
        check("...and their rent", sumRent, split.getRent());
        check("...and their shopping", sumShop, split.getShopping());
        check("everybody is in exactly one row", sumPeople, 500);

        /*
         * RENT FOLLOWS FRONT DOORS, THE SHOP FOLLOWS HEADS, and the two must not
         * be the same rule - which they were until 2026-09-07.
         *
         * ham.citybuildersim.sectors.RealEstate.getRentIncome() charges every let home the same
         * figure whoever is in it, because that is what a landlord charges for:
         * the flat. Splitting it by headcount instead billed a family of five
         * five times what it billed a single adult in the identical flat, so
         * every large household read as unable to afford to live here. The shop
         * genuinely is a headcount - retail demand is min(coverage, population)
         * - so it keeps the old rule.
         *
         * 150 of 260 homes carry 57.7% of the rent; 300 of 500 people carry 60%
         * of the shopping. That the two figures now DIFFER is the point of the
         * assertion: identical numbers here is what the bug looked like.
         */
        check("rent follows front doors", split.getRowRent(PayTier.UNSKILLED.ordinal()),
                300 * (150 / 260.0));
        check("the shop follows heads",
                split.getRowShopping(PayTier.UNSKILLED.ordinal()), 240);
        assertTrue("...and the two are not the same split",
                Math.abs(split.getRowRent(PayTier.UNSKILLED.ordinal()) / split.getRent()
                        - split.getRowShopping(PayTier.UNSKILLED.ordinal()) / split.getShopping())
                        > .01);

        /*
         * ONE HOUSEHOLD, AND THE SHAPES INSIDE A TIER.
         *
         * The tier row averages across every shape in it, which is the one
         * household nobody lives in. statementFor() splits it: same rent per
         * door for all of them, shopping by size, wages by earners. These
         * assert the three rules rather than the numbers, because the numbers
         * are the fixture's and the rules are the model's.
         */
        assertTrue("rent per door is the city's rent over its households",
                Math.abs(split.rentPerHousehold() - 300 / 260.0) < 1e-9);
        assertTrue("the shop per head is its shopping over its people",
                Math.abs(split.shoppingPerHead() - 400 / 500.0) < 1e-9);

        /*
         * THE RETIRED ROW EARNS NOTHING. There is no pension in this game, so a
         * pensioner household is pure outgoing - and it must not be quietly
         * folded into the unskilled row, which is where FamilyModel stores it by
         * convention. If this ever reads non-zero, somebody has summed a tier
         * column instead of asking for the working households in it.
         */
        check("pensioners earn nothing",
                split.getRowWages(HouseholdAccounts.RETIRED), 0);
        assertTrue("...so their row is a deficit",
                split.getRowSaving(HouseholdAccounts.RETIRED) < 0);
        assertTrue("...and it is labelled as theirs",
                split.getRowLabel(HouseholdAccounts.RETIRED).contains("Retired"));

        // A malformed split is refused whole rather than half-applied.
        split.updateByTier(wagesByTier, taxByTier, new double[]{1, 2}, houses);
        check("a malformed split is refused",
                split.getRowPeople(PayTier.UNSKILLED.ordinal()), 0);

        /* ---- and the tax split is the tax the city actually charges ---- */
        TaxPolicy policy = new TaxPolicy();
        policy.setIncomeTaxRate(.20);
        policy.setWageOffset(WageBand.values()[0], -.10);
        policy.setWageOffset(WageBand.values()[WageBand.values().length - 1], .10);

        double[] perType = new double[JobType.values().length];
        for (int i = 0; i < perType.length; i++) perType[i] = 100 * (i + 1);

        double[] perTier = policy.wageTaxPerTier(perType, null);
        double tierSum = 0;
        for (double t : perTier) tierSum += t;

        /*
         * The bug this replaced: Game computed the residents' tax as
         * `wages * incomeTaxRate` while the city collected the banded figure.
         * They agreed exactly whenever every offset was zero, which is why it
         * survived - so this check deliberately sets two offsets first, and
         * measures a 23% gap on a played city when it is not applied.
         */
        check("the tier split IS the wage tax", tierSum,
                policy.wageTaxOn(perType, null));

        double flatWay = 0;
        for (double w : perType) flatWay += w;
        flatWay *= policy.getIncomeTaxRate();
        assertTrue("...and a flat rate on the total is NOT the same number",
                Math.abs(flatWay - tierSum) > 1);

        /* ==================== 9. rent is per home, not per head ==================== */
        System.out.println("\n--- what a home costs ---");

        /*
         * THE COMPLAINT THIS ANSWERS. Jerus, reading the per-tier statement:
         * "not only is there no room for rent to increase... but already people
         * are broke." Rent was $350 a month PER RESIDENT, so a family of six
         * paid $2,099 on two unskilled wages of $1,600 - 131% - while a childless
         * couple on the same two wages paid 44%. Children cost rent and earned
         * nothing.
         *
         * The claim now is that a household pays for its HOME and nothing else,
         * so every shape with the same earners pays the same share whatever its
         * size. That is the whole fix, in one assertion.
         */
        BuildingManager rentBm = new BuildingManager();
        rentBm.initializeTemplates();
        BuildingsTemplate house = rentBm.getTemplateByName("House");

        /*
         * THE YARDSTICK AND THE HOUSE ARE DIFFERENT NUMBERS NOW.
         *
         * This asserted that the House held exactly REFERENCE_HOME_CAPACITY, on
         * the reasoning that the rent price was derived from it. It is not: the
         * reference is the four-person home the affordability target is struck
         * against, and the House grew to six so that a large family and a
         * five-adult flatshare have somewhere to live. What survives is the
         * relationship - a House is at least the reference home, in one
         * dwelling, and therefore costs at least the reference rent.
         */
        assertTrue("a House is at least the home the rent target is struck against",
                house.getCapacity() >= ham.citybuildersim.sectors.RealEstate.REFERENCE_HOME_CAPACITY);
        assertTrue("...and it is the biggest home in the game",
                house.homeSize() >= rentBm.getTemplateByName("Low-Rise Apartments").homeSize()
                        && house.homeSize() >= rentBm.getTemplateByName("Studio Apartments").homeSize());
        assertTrue("...so it costs more than the reference home does",
                house.getCapacity() * 1.0 / ham.citybuildersim.sectors.RealEstate.REFERENCE_HOME_CAPACITY > 1);
        check("...in a single dwelling", house.getDwellings(), 1);

        ham.citybuildersim.sectors.RealEstate rentCh = new ham.citybuildersim.sectors.RealEstate();
        rentCh.setHousehold(1600);      // 400 houses of four
        rentCh.setHomes(400);
        rentCh.setPopulation(1218);
        rentCh.setOccupiedHomes(400);

        check("a home is charged for its size, not its occupants",
                rentCh.getRentIncome(), 1600 * rentCh.getRentPrice());
        check("the average home here holds four", rentCh.averageHomeSize(), 4);

        double homeRent = rentCh.averageHomeSize() * rentCh.getRentPrice();
        double coupleIncome = 2 * PayTier.UNSKILLED.getMonthlyWage();
        System.out.printf("   one home costs $%.0f; two unskilled wages are $%.0f%n",
                homeRent * 1000, coupleIncome * 1000);
        check("a working couple pays the burden the price was set for",
                homeRent / coupleIncome, ham.citybuildersim.sectors.RealEstate.TARGET_RENT_BURDEN);
        assertTrue("...and a family of six pays exactly the same, not three times it",
                Math.abs(homeRent / coupleIncome - ham.citybuildersim.sectors.RealEstate.TARGET_RENT_BURDEN) < 1e-9);

        /*
         * EMPTY HOMES EARN NOTHING, and this is the assertion that caught a
         * regression. The first version charged for every home the city had
         * built rather than every home somebody lived in, which meant a city
         * that overbuilt housing raised its own rent bill without gaining a
         * single tenant - worse than the per-head version it replaced, which at
         * least capped rent at the population.
         */
        rentCh.setOccupiedHomes(200);
        check("half let, half the rent", rentCh.getRentIncome(),
                200 * 4 * rentCh.getRentPrice());
        rentCh.setOccupiedHomes(0);
        check("nobody home, no rent", rentCh.getRentIncome(), 0);

        // More households than front doors: everybody crowds into what exists,
        // and nobody pays twice for the same roof.
        rentCh.setOccupiedHomes(900);
        check("a crowded city still only has 400 rents to pay",
                rentCh.getRentIncome(), 1600 * rentCh.getRentPrice());

        /* ==================== 10. pensions ==================== */
        System.out.println("\n--- contributions and pensions ---");

        /*
         * THE ROW THIS EXISTS FOR. Splitting the books by tier put
         * "Retired (no earner)  earned $0  -$95.8k" on screen: a seventh of the
         * city's households with NO income of any kind, paying rent out of money
         * that did not exist. Jerus: "add cpp to everyones pay, aka they pay a
         * tad, and make it so that the government pays for the seniors."
         */
        check("the pension follows the wage table, not a typed-in figure",
                SocialSecurity.pensionPerSenior(),
                SocialSecurity.PENSION_REPLACEMENT * PayTier.UNSKILLED.getMonthlyWage());
        check("contributions are a slice of the wage bill",
                SocialSecurity.contributionsOn(1000),
                1000 * SocialSecurity.CONTRIBUTION_RATE);
        assertTrue("...and it really is only a tad",
                SocialSecurity.CONTRIBUTION_RATE < .10);

        /*
         * THE TWO HALVES DO NOT BALANCE, ON PURPOSE. Contributions scale with
         * workers and pensions with pensioners, so coverage is a pure function
         * of the dependency ratio - a city that ages buys a structural deficit
         * without changing a single policy. Asserted as a DIRECTION rather than
         * a level, since the level depends on the city.
         */
        double youngCoverage = SocialSecurity.coverage(1000, 50);
        double oldCoverage   = SocialSecurity.coverage(1000, 200);
        System.out.printf("   same wage bill, 50 pensioners: %.0f%% covered;"
                + " 200 pensioners: %.0f%%%n", youngCoverage * 100, oldCoverage * 100);
        assertTrue("an ageing city covers less of its own pension bill",
                oldCoverage < youngCoverage);
        check("a city with no pensioners owes nothing",
                SocialSecurity.pensionsFor(0), 0);
        check("...and is fully covered by definition",
                SocialSecurity.coverage(1000, 0), 1);
        check("the shortfall is what contributions do not reach",
                SocialSecurity.shortfall(1000, 200),
                SocialSecurity.pensionsFor(200) - SocialSecurity.contributionsOn(1000));


        /* ---- and a household outside the families can have mouths in it ----

           A STUDENT AND A LAID-OFF PARENT GO ON BEING PARENTS. Since 2026-09-15
           the children of an adult who leaves work go with them rather than
           into the orphan section, so these two cells hold dependants - a
           fraction per household, because a cell is an average of thousands.

           THE MOUTHS AND THE EARNERS ARE DIFFERENT NUMBERS AND BOTH ARE USED.
           A student with children shops and is billed for all of them, out of a
           grant and a loan; the income split is by GROWN-UPS, and a student
           with two children is still one wallet. Reading the wrong one of those
           is how the over-85s came to draw no pension three days earlier, so
           both are asserted here against one household rather than left to a
           row total that would hide either.
           ------------------------------------------------------------------ */
        HouseholdBalance kin = new HouseholdBalance();
        kin.setOutsideCensus(c -> c instanceof StudentHousehold ? 100 : 0);
        kin.setOutsideDependants(c -> c instanceof StudentHousehold ? 0.6 : 0);
        double[] kinIncome = new double[HouseholdBalance.ROWS];
        kinIncome[Household.STUDENT_ROW] = 100 * 2.0;      // two apiece
        double[] kinNone = new double[HouseholdBalance.ROWS];
        kin.advanceMonth((s, t) -> 0, kinIncome, 0, kinNone, kinNone, 0, .05, 1);

        Household student = kin.students();
        check("fixture: a hundred student households", student.households(), 100);
        check("one of them is an adult and their dependants", student.headcount(), 1.6);
        check("...so the cell is a hundred and sixty people", student.people(), 160);
        check("a student with children is still ONE wallet", student.grownUps(), 1);
        check("...so the row's income is split by wallets and they take home a whole one",
                student.disposable(), 2.0);

        HouseholdBalance kinSolo = new HouseholdBalance();
        kinSolo.setOutsideCensus(c -> c instanceof StudentHousehold ? 100 : 0);
        kinSolo.advanceMonth((s, t) -> 0, kinIncome, 0, kinNone, kinNone, 0, .05, 1);
        check("a student with nobody is one person, as they always were",
                kinSolo.students().headcount(), 1);

        /*
         * AND THE FEES FOLLOW THE MOUTHS, asserted in the one row that can tell
         * the difference. A fee kinSplit is PRO RATA within a row, so a row with a
         * single cell in it hands that cell the whole total whatever its
         * headcount - the students' row would have passed this reading size()
         * or headcount() or anything else. The out-of-work row has three cells,
         * so giving two of them different numbers of children is a fixture that
         * can actually fail: the one with a child in it must carry twice the
         * share of the city's doctors' bill.
         */
        HouseholdBalance kinSplit = new HouseholdBalance();
        kinSplit.setOutsideCensus(c -> c instanceof UnemployedHousehold u
                && u.status() != UnemployedHousehold.Status.UNHOUSED ? 100 : 0);
        kinSplit.setOutsideDependants(c -> c instanceof UnemployedHousehold u
                && u.status() == UnemployedHousehold.Status.ON_EI ? 1 : 0);
        double[] outIncome = new double[HouseholdBalance.ROWS];
        outIncome[Household.UNEMPLOYED_ROW] = 200 * 8.0;
        double[] outFees = new double[HouseholdBalance.ROWS];
        outFees[Household.UNEMPLOYED_ROW] = 300;            // 300 over 300 people
        kinSplit.advanceMonth((s, t) -> 0, outIncome, 0, outFees, kinNone, 0, .05, 1);

        Household kinParent = kinSplit.unemployed(UnemployedHousehold.Status.ON_EI);
        Household kinAlone   = kinSplit.unemployed(UnemployedHousehold.Status.OFF_EI);
        check("fixture: two out-of-work cells, one of them with a child in it",
                kinParent.headcount() - kinAlone.headcount(), 1);
        check("the claimant with a child is billed for two heads",
                kinParent.disposable() - kinParent.afterFixed(), 2);
        check("...and the one without a child for one",
                kinAlone.disposable() - kinAlone.afterFixed(), 1);
        check("...so the row's bill is still all of it and no more",
                100 * (kinParent.disposable() - kinParent.afterFixed())
                        + 100 * (kinAlone.disposable() - kinAlone.afterFixed()), 300);
        /*
         * AND A CHILD DRAWS NO EI, which is the other half of the same point
         * and it corrected this fixture on its first run. The income split is
         * by earningWeight(), and UnemployedHousehold overrides that to ONE
         * while the claim is live and ZERO after it runs out - so the whole
         * benefit goes to the hundred households still on EI, whatever anybody
         * is feeding. The first draft asserted the two cells drew the same and
         * was wrong about the model, not about the change.
         */
        check("the benefit goes to the claimants, and a child does not draw one",
                kinParent.disposable(), outIncome[Household.UNEMPLOYED_ROW] / 100);
        check("...so a household whose EI has run out draws nothing, child or no child",
                kinAlone.disposable(), 0);

        /* ---- and a pensioner is a pensioner in whichever band ----

           THE BUG THIS EXISTS FOR, found 2026-09-15 the day the senior band
           split. RetiredHousehold.grownUps() answered "members of SENIOR", and
           HouseholdBalance splits each row's income across its cells BY THAT
           WEIGHT - so the moment the over-85s got their own shapes, an elder
           household weighed nothing in the split and drew no pension at all.
           Nobody noticed for a batch: the pension BILL was right, the money
           audit balanced (the same total went out, just to the wrong cells),
           and every harness passed. What it did was quiet and slow - an elder
           paid rent out of savings until there were none, the landlord's
           revenue fell, and it shed plant under the rule that a firm which
           cannot pay must. Measured on DenominationCheck's founding: 7,955
           homes and 18,400 people down to 2,881 and 4,200 over fifteen years,
           where the same city on the shipped build never lost one home.

           Asserted against the SHAPE'S OWN CENSUS rather than a list of band
           names, so a third retired band cannot reintroduce it.
           ------------------------------------------------------------------ */
        for (FamilyStructure shape : FamilyStructure.values()) {
            if (!shape.isRetired()) continue;
            check("every one of a " + shape.getLabel().toLowerCase() + " is a pensioner",
                    RetiredHousehold.pensionersIn(shape), shape.size());
            check("...and the row split weighs them all",
                    new RetiredHousehold(shape).grownUps(), shape.size());
        }

        /*
         * AND IN A LIVE BOOK, which is where the weight is actually used: one
         * senior alone and one elder alone, the row handed two pensions, and
         * each must come away with one. The census CAUSES the condition - two
         * retired cells in different bands - and the assertion is against the
         * model's own pension, not a number typed here.
         */
        HouseholdBalance retired = new HouseholdBalance();
        double pensionEach = SocialSecurity.pensionPerSenior();
        double[] retIncome = new double[HouseholdBalance.ROWS];
        retIncome[Household.RETIRED_ROW] = 2 * pensionEach;
        double[] retNone = new double[HouseholdBalance.ROWS];
        double[] retSpent = new double[HouseholdBalance.ROWS];
        retired.advanceMonth((s, t) -> s == FamilyStructure.SENIOR_ALONE
                        || s == FamilyStructure.ELDER_ALONE ? 1 : 0,
                retIncome, 0, retNone, retSpent, 0, .05, 1);
        Household senior = retired.cell(FamilyStructure.SENIOR_ALONE);
        Household elder  = retired.cell(FamilyStructure.ELDER_ALONE);
        check("a senior living alone draws one pension", senior.disposable(), pensionEach);
        check("...and an elder living alone draws the same one",
                elder.disposable(), pensionEach);


        /* ============ THE BUDGET CONSTRAINT ============

           Until 2026-09-07 the shops sold `min(coverage, population)` - one
           basket a person, at no price anybody had to be able to pay. So a
           household could be shown spending more than it earned every month for
           three hundred months and the money came from nowhere, which is the
           one failure this whole file exists to catch.

           HouseholdBalance is the constraint. These assert the waterfall Jerus
           specified - savings, then credit, then hunger - at the level of the
           rule rather than of any city's numbers.
           ========================================================= */
        System.out.println("\n--- a household short of money spends its savings, then borrows ---");

        /*
         * PER CELL, since 2026-09-10. The balance is handed a CENSUS - who
         * lives in each shape at each tier - and the row's money, and splits
         * the money across the cells itself. So a fixture says which
         * households it has: a hundred unskilled couples, two people each,
         * with the whole of the row's take-home between them.
         */
        HouseholdBalance bal = new HouseholdBalance();
        int R = HouseholdBalance.ROWS;
        int U = PayTier.UNSKILLED.ordinal();

        double[][] fixtureMix = new double[FamilyStructure.values().length][PayTier.values().length];
        java.util.function.ToDoubleBiFunction<FamilyStructure, PayTier> census =
                (s, t) -> fixtureMix[s.ordinal()][t.ordinal()];

        double[] income = new double[R];
        double[] fees = new double[R];
        double[] spent = new double[R];
        fixtureMix[FamilyStructure.COUPLE.ordinal()][U] = 100;   // two people a household
        income[U] = 100 * 1.0;   // $1.00 a household, in the game's thousands
        double rentEach = .60;   // more than half of it, so the shop cannot be covered
        double basket = .25;     // per head, so a household of two needs .50

        /*
         * THE SPEND FOLLOWS THE PLAN, as it does in the game: the shops sell
         * what the households said they could buy. A fixture that charged a
         * fixed amount every month would be testing a household nobody has,
         * and its debt would grow without a ceiling because nothing was
         * telling it to stop.
         */
        bal.advanceMonth(census, income, rentEach, fees, spent, basket, .05, 1);
        double opening = bal.getSavings(U);
        assertTrue("a founding household is not destitute on day one", opening > 0);
        assertTrue("...by about the buffer the dial names",
                opening >= 1.0 * HouseholdBalance.OPENING_BUFFER_MONTHS - 1e-9);

        spent[U] = bal.getHouseholds(U) * bal.getPlanned(U);
        double savingsBefore = bal.getSavings(U);
        bal.advanceMonth(census, income, rentEach, fees, spent, basket, .05, 1);
        assertTrue("SAVINGS GO FIRST", bal.getSavings(U) < savingsBefore);
        assertTrue("...and nothing is borrowed while there are savings",
                bal.getDebt(U) == 0);
        // With nothing owed the line's rate is the bank's household rate it
        // was handed, and nothing over it (0.7.7: it was the city's rate plus
        // HouseholdBalance.BASE_SPREAD, three points).
        double rateWhenClear = bal.getRate(U);
        assertTrue("...and with nothing owed its line is priced at the bank's household rate, no more",
                Math.abs(rateWhenClear - .05) < 1e-12);

        // Run it until the savings are gone.
        for (int m = 0; m < 40; m++) {
            spent[U] = bal.getHouseholds(U) * bal.getPlanned(U);
            bal.advanceMonth(census, income, rentEach, fees, spent, basket, .05, 1);
        }
        assertTrue("the savings run out", bal.getSavings(U) < 1e-9);
        assertTrue("...THEN THEY BORROW", bal.getDebt(U) > 0);
        assertTrue("...at a rate over the risk-free one",
                bal.getRate(U) > .05 + 1e-9);
        assertTrue("...which climbs with what they already owe",
                bal.getRate(U) > rateWhenClear + HouseholdBalance.RISK_SLOPE * 1e-3);
        assertTrue("...and never past the cap",
                bal.getRate(U) <= HouseholdBalance.MAX_RATE + 1e-9);

        /*
         * And keep going until the credit runs out too.
         *
         * MEASURED OVER THE CYCLE, NOT IN THE MONTH THE LOOP STOPS ON, and
         * that is a correction rather than a flourish. A household that has
         * been discharged is locked out for a year and then gets its credit
         * line back, so it eats short for eleven months and buys a full basket
         * in the twelfth. The first version of this assertion read whichever
         * month the loop happened to end in, and once bankruptcy went in it
         * landed on that twelfth month and failed - a fixture reading the
         * phase of an oscillation rather than its level.
         */
        double shortMonths = 0, fullMonths = 0, plannedTotal = 0, subsistenceTotal = 0;
        for (int m = 0; m < 400; m++) {
            spent[U] = bal.getHouseholds(U) * bal.getPlanned(U);
            bal.advanceMonth(census, income, rentEach, fees, spent, basket, .05, 1);
            if (m >= 100) {   // past the savings and the first slide into debt
                plannedTotal += bal.getPlanned(U);
                subsistenceTotal += bal.getSubsistence(U);
                if (bal.getPlanned(U) < bal.getSubsistence(U) - 1e-9) shortMonths++;
                else fullMonths++;
            }
        }
        assertTrue("the debt stops at the ceiling, it does not run away",
                bal.getDebt(U) <= HouseholdBalance.CREDIT_LIMIT_MONTHS * 1.0 + .5);
        System.out.printf("   short in %.0f months of %.0f; planned $%.3fk against $%.3fk of subsistence%n",
                shortMonths, shortMonths + fullMonths,
                plannedTotal / (shortMonths + fullMonths),
                subsistenceTotal / (shortMonths + fullMonths));
        assertTrue("...AND THEN THEY EAT LESS", plannedTotal < subsistenceTotal - 1e-9);
        assertTrue("...in most months, not just on average", shortMonths > fullMonths);
        assertTrue("...which the health service can see", bal.getHungerRate() > 0);

        System.out.println("\n--- and a household with money to spare pays it down, then banks it ---");

        HouseholdBalance rich = new HouseholdBalance();
        income[U] = 100 * 4.0;
        spent[U] = 0;
        for (int m = 0; m < 6; m++) {
            rich.advanceMonth(census, income, rentEach, fees, spent, basket, .05, 1);
            spent[U] = rich.getHouseholds(U) * rich.getPlanned(U);
        }
        assertTrue("a household with a surplus banks it", rich.getSavings(U) > 0);
        assertTrue("...and owes nothing", rich.getDebt(U) == 0);
        assertTrue("...and is not hungry", rich.getHungerRate() == 0);

        /*
         * SPENDING FOLLOWS INCOME UPWARD TOO, which is the half that is easy to
         * forget. Without it the rich bank everything - measured at $715,012 a
         * household after three hundred months - and the constraint only ever
         * bites downward.
         */
        assertTrue("a rich household WANTS more than a basket",
                rich.getWant(U) > rich.getSubsistence(U));
        assertTrue("...but a poor one wants exactly a basket, not less",
                Math.abs(bal.getWant(U) - bal.getSubsistence(U)) < 1e-9);

        System.out.println("\n--- the supply side starves people who had the money ---");

        HouseholdBalance shelves = new HouseholdBalance();
        income[U] = 100 * 4.0;
        spent[U] = 0;
        shelves.advanceMonth(census, income, rentEach, fees, spent, basket, .05, 1);
        spent[U] = shelves.getHouseholds(U) * shelves.getPlanned(U);
        shelves.advanceMonth(census, income, rentEach, fees, spent, basket, .05, 0);
        assertTrue("empty shelves are hunger even in a rich city",
                shelves.getHungerRate() > 0);

        /* ============ SIXTY-EIGHT CELLS, AND THE MONEY FOLLOWS THE PEOPLE ============

           Jerus, 2026-09-10: "I need it per household and pay tier type...
           an object, being the basic, and then each extends... that way it's
           a lot easier to sum everything up, or modify across all."

           Every cell of the family matrix is a Household with its own books.
           FamilyModel still re-allocates every household each month, so the
           thing that makes a per-cell stock mean anything is the rule that
           moves the money with the people when the cells change - and every
           claim below is CAUSED: a census is changed and the money is read.
           ======================================================================== */
        System.out.println("\n--- every cell has its own books, and they sum to the rows ---");

        HouseholdBalance cellsBal = new HouseholdBalance();
        int S = PayTier.SKILLED.ordinal();
        double[][] city = new double[FamilyStructure.values().length][PayTier.values().length];
        java.util.function.ToDoubleBiFunction<FamilyStructure, PayTier> who =
                (s, t) -> city[s.ordinal()][t.ordinal()];
        int single = FamilyStructure.SINGLE_ADULT.ordinal();
        int couple = FamilyStructure.COUPLE.ordinal();
        int large  = FamilyStructure.LARGE_FAMILY.ordinal();
        int shared = FamilyStructure.SHARED_ADULTS.ordinal();
        int withChild = FamilyStructure.COUPLE_CHILD.ordinal();
        int withTeen  = FamilyStructure.COUPLE_TEEN.ordinal();
        int seniorAlone  = FamilyStructure.SENIOR_ALONE.ordinal();

        city[single][U] = 100;      // 100 earners
        city[couple][U] = 100;      // 200 earners
        city[large][U]  = 50;       // 100 earners: 400 in the row
        city[seniorAlone][0]  = 40;       // pensioners, no tier
        double[] pay = new double[R];
        pay[U] = 400 * 2.0;         // $2.00 an earner
        pay[HouseholdAccounts.RETIRED] = 40 * 1.0;
        double[] noFees = new double[R];
        double[] bought = new double[R];
        cellsBal.advanceMonth(who, pay, .50, noFees, bought, .20, .05, 1);

        // Since 2026-09-11: and eight outside the families - the out of work in
        // three situations, the students, the orphans of three bands, and
        // (that night) the prisoners' ledger.
        // Four retired rows since the seniors split at 85 (2026-09-15): the two
        // senior shapes and the two elder ones, one cell each.
        assertTrue("seventy-eight cells: eleven working shapes by six tiers, four retired, eight outside the families",
                cellsBal.cellCount() == 11 * 6 + 4 + 3 + 1 + 3 + 1);
        Household one = cellsBal.cell(FamilyStructure.SINGLE_ADULT, PayTier.UNSKILLED);
        Household two = cellsBal.cell(FamilyStructure.COUPLE, PayTier.UNSKILLED);
        Household six = cellsBal.cell(FamilyStructure.LARGE_FAMILY, PayTier.UNSKILLED);
        Household old = cellsBal.cell(FamilyStructure.SENIOR_ALONE);
        check("a single adult takes home one wage", one.disposable(), 2.0);
        check("a couple takes home two", two.disposable(), 4.0);
        check("a large family, two earners, takes home two", six.disposable(), 4.0);
        check("a pensioner draws the pension", old.disposable(), 1.0);
        assertTrue("a working cell is a WorkingHousehold", one instanceof WorkingHousehold);
        assertTrue("a retired cell is a RetiredHousehold, with no tier",
                old instanceof RetiredHousehold && old.tier() == null);
        check("the cells' take-home sums to the row's",
                cellsBal.sumRow(U, c -> c.disposable() * c.households()), pay[U]);
        // What they opened with is what they hold less what the month banked.
        check("the buffer is per household of the CELL, not of the tier",
                two.savings() - two.banked(), 4.0 * HouseholdBalance.OPENING_BUFFER_MONTHS);
        check("...so a single adult opens with half a couple's",
                one.savings() - one.banked(), 2.0 * HouseholdBalance.OPENING_BUFFER_MONTHS);
        check("the row's per-household figure is the cells' weighted average",
                cellsBal.getSavings(U),
                (one.totalSavings() + two.totalSavings() + six.totalSavings()) / 250);
        check("sum() adds up every cell",
                cellsBal.sum(Household::totalSavings), cellsBal.totalSavings());
        check("...and the households in every cell are the city's",
                cellsBal.sum(Household::households), 290);

        // Modify across all: forEach reaches every cell.
        cellsBal.forEach(c -> c.redenominate(1));
        check("forEach touches every cell and changes nothing at scale one",
                cellsBal.totalSavings(),
                one.totalSavings() + two.totalSavings() + six.totalSavings() + old.totalSavings());

        System.out.println("\n--- the money follows the people ---");

        // Let them all save something first, so there is money to follow.
        for (int m = 0; m < 3; m++) {
            for (int r = 0; r < R; r++) bought[r] = 0;
            cellsBal.advanceMonth(who, pay, .50, noFees, bought, .20, .05, 1);
        }
        double cityBefore = cellsBal.totalSavings();
        double coupleEach = two.savings();

        /*
         * A CHILD AGES INTO A TEEN. Fifty couples with a child become fifty
         * couples with a teen: the same families, the same money, a different
         * cell. Set up as a fresh cell so the move is unmistakable.
         */
        city[withChild][U] = 50;
        cellsBal.advanceMonth(who, pay, .50, noFees, bought, .20, .05, 1);
        Household child = cellsBal.cell(FamilyStructure.COUPLE_CHILD, PayTier.UNSKILLED);
        Household teen  = cellsBal.cell(FamilyStructure.COUPLE_TEEN, PayTier.UNSKILLED);
        double familyEach = child.savings();
        assertTrue("fifty new families arrived with the buffer", familyEach > 0);
        double before = cellsBal.totalSavings();
        double writtenBefore = cellsBal.getWrittenOff();

        city[withChild][U] = 0;
        city[withTeen][U] = 50;
        bought[U] = cellsBal.getHouseholds(U) * cellsBal.getPlanned(U) * 0;   // nothing bought: the stock is what moves
        cellsBal.advanceMonth(who, pay, .50, noFees, bought, .20, .05, 1);
        check("the child's cell is empty", child.households(), 0);
        check("...the teen's cell holds them", teen.households(), 50);
        check("...WITH THEIR MONEY: the teen's family opened with what the child's had",
                teen.savings() - teen.banked(), familyEach);
        check("nothing was written off for a birthday", cellsBal.getWrittenOff(), 0);
        check("...and nothing left the city", cellsBal.getTakenAway(), 0);

        /*
         * FIVE SINGLES TAKE A FLATSHARE. Five households become one; weighed
         * by households, four of them would have "left" and the flatshare
         * would inherit a fifth of their money. Weighed by the adults in them
         * it is five for five.
         */
        double singleEach = one.savings();
        double singlesTotal = one.totalSavings();
        city[single][U] = 50;
        city[shared][U] = 10;
        cellsBal.advanceMonth(who, pay, .50, noFees, bought, .20, .05, 1);
        Household flatshare = cellsBal.cell(FamilyStructure.SHARED_ADULTS, PayTier.UNSKILLED);
        double flatMonth = flatshare.banked();   // what the flatshare put by this month
        assertTrue("five singles sharing carry FIVE wallets into the flatshare",
                Math.abs((flatshare.savings() - flatMonth) - 5 * singleEach) < 1e-6);
        assertTrue("...and the singles who stayed have what they had",
                one.savings() >= singleEach - 1e-9);
        check("nothing was written off for a lease", cellsBal.getWrittenOff(), 0);
        check("...and nothing left the city", cellsBal.getTakenAway(), 0);

        /*
         * A JOB CHANGE CROSSES A TIER. Forty unskilled couples become forty
         * skilled couples: the money crosses the row boundary with them,
         * because the pool runs within the tier first and then across the
         * city.
         */
        double coupleNow = two.savings();
        city[couple][U] = 60;
        city[couple][S] = 40;
        pay[S] = 80 * 3.0;
        pay[U] = 420 * 2.0;   // 50 + 120 + 100 + 100 + 50 earners still in the row
        cellsBal.advanceMonth(who, pay, .50, noFees, bought, .20, .05, 1);
        Household skilledCouple = cellsBal.cell(FamilyStructure.COUPLE, PayTier.SKILLED);
        check("a couple promoted to skilled brings its savings up the ladder",
                skilledCouple.savings() - skilledCouple.banked(), coupleNow);
        check("...and nothing left the city", cellsBal.getTakenAway(), 0);

        /*
         * DEPARTURES TAKE THEIR SAVINGS AND LEAVE THEIR DEBT ON THE BANK.
         * Nobody gains, so the loss is real: the savings are gone with them,
         * and the debt is the bank's loss - which is what the old per-row rule
         * did and the only part of it that was ever about leaving.
         */
        HouseholdBalance leaving = new HouseholdBalance();
        double[][] town = new double[FamilyStructure.values().length][PayTier.values().length];
        java.util.function.ToDoubleBiFunction<FamilyStructure, PayTier> townCensus =
                (s, t) -> town[s.ordinal()][t.ordinal()];
        Household broke = leaving.cell(FamilyStructure.COUPLE, PayTier.UNSKILLED);
        double[] thin = new double[R];
        double[] eat = new double[R];

        // Comfortable first, so there are savings to take.
        town[couple][U] = 100;
        for (int m = 0; m < 3; m++) {
            thin[U] = 100 * 3.0;
            eat[U] = 100 * 2 * .25;
            leaving.advanceMonth(townCensus, thin, 1.0, noFees, eat, .25, .05, 1);
        }
        double savingsEach = broke.savings();
        assertTrue("the fixture saved something - or the next line proves nothing", savingsEach > 0);
        town[couple][U] = 80;
        thin[U] = 80 * 3.0;
        eat[U] = 80 * 2 * .25;
        leaving.advanceMonth(townCensus, thin, 1.0, noFees, eat, .25, .05, 1);
        check("twenty households leaving take twenty households' savings with them",
                leaving.getTakenAway(), 20 * savingsEach);
        check("...and nobody wrote anything off, because they owed nothing",
                leaving.getWrittenOff(), 0);
        check("...and the ones who stayed opened the month with what they had",
                broke.savings() - broke.banked(), savingsEach);

        // Then a wage that does not cover the rent, until they owe.
        int months = 0;
        while (broke.debt() < 3.0 && months++ < 200) {
            thin[U] = 80 * 1.2;
            eat[U] = 80 * 2 * .25;
            leaving.advanceMonth(townCensus, thin, 1.0, noFees, eat, .25, .05, 1);
        }
        assertTrue("the fixture reached a debt - or the next line proves nothing", broke.debt() >= 3.0);
        double debtEach = broke.debt();
        town[couple][U] = 60;
        thin[U] = 60 * 1.2;
        eat[U] = 60 * 2 * .25;
        leaving.advanceMonth(townCensus, thin, 1.0, noFees, eat, .25, .05, 1);
        check("twenty households leaving in debt write it off against the bank",
                leaving.getWrittenOff(), 20 * debtEach);
        // ...plus the month: what they drew, and since 0.7.7 the bank's fee on
        // it, which is added to what they owe.
        check("...and the ones who stayed still owe what they owed, plus the month",
                broke.debt() - broke.borrowed() - broke.loanFee() + broke.repaid(), debtEach);

        /*
         * ARRIVALS NOBODY RELEASED BRING THE BUFFER, NOT THE NEIGHBOURS' MONEY.
         * The couples' cell grows by fifty with nothing lost anywhere: the
         * newcomers arrive with the opening buffer and no debt, so the
         * per-household debt is diluted and the savings are the old total plus
         * what they brought.
         */
        double owedTotal = broke.totalDebt();
        double savedTotal = broke.totalSavings();
        double buffer = 1.2 * HouseholdBalance.OPENING_BUFFER_MONTHS;
        town[couple][U] = 110;
        thin[U] = 110 * 1.2;
        eat[U] = 0;
        leaving.advanceMonth(townCensus, thin, 1.0, noFees, eat, .25, .05, 1);
        check("fifty arrivals owe nothing: the debt is the old total, less what the month repaid",
                broke.totalDebt() + broke.totalRepaid(), owedTotal);
        check("...and the per-household debt is diluted by them",
                broke.debt() + broke.repaid(), owedTotal / 110);
        check("...and they brought the buffer: the old savings plus fifty buffers",
                broke.totalSavings() - (broke.banked() - broke.drawn()) * 110,
                savedTotal + 50 * buffer);

        /*
         * AND THE BANKRUPTCY IS PER CELL. In one tier, a large family that
         * cannot cover its rent discharges while the single adult next door,
         * who can, keeps its line of credit - where a tier-wide lockout used
         * to punish the solvent for their neighbours.
         */
        HouseholdBalance street = new HouseholdBalance();
        double[][] block = new double[FamilyStructure.values().length][PayTier.values().length];
        java.util.function.ToDoubleBiFunction<FamilyStructure, PayTier> blockCensus =
                (s, t) -> block[s.ordinal()][t.ordinal()];
        block[single][U] = 100;      // 100 earners
        block[large][U]  = 100;      // 200 earners, six mouths
        double[] wage = new double[R];
        wage[U] = 300 * 1.0;         // $1.00 an earner: the single has $1, the family $2
        double[] shop = new double[R];
        Household solo = street.cell(FamilyStructure.SINGLE_ADULT, PayTier.UNSKILLED);
        Household big  = street.cell(FamilyStructure.LARGE_FAMILY, PayTier.UNSKILLED);
        boolean familyDischarged = false;
        boolean lockedWhenItDid = false;
        for (int m = 0; m < 120; m++) {
            // Rent .70: the single keeps .30 and needs .25 to eat; the family
            // keeps 1.30 and needs 1.50 for six. One of them is fine.
            shop[U] = solo.totalPlanned() + big.totalPlanned();
            street.advanceMonth(blockCensus, wage, .70, noFees, shop, .25, .05, 1);
            if (big.bankrupt() > 0) {
                familyDischarged = true;
                lockedWhenItDid = big.isLockedOut();
            }
        }
        assertTrue("the large family, short every month, discharges", familyDischarged);
        assertTrue("...and is locked out when it does", lockedWhenItDid);
        assertTrue("the single adult next door never borrowed", solo.debt() == 0);
        assertTrue("...and was never locked out", !solo.isLockedOut());
        assertTrue("the row reads the lockout because ONE cell has it",
                street.isLockedOut(U) == big.isLockedOut());

        /*
         * THE SAVE CARRIES THE CELLS, BY NAME, and a row-only save from the
         * build before them seeds every cell of the row.
         */
        /*
         * AND THE SHARES FOLLOW THE PEOPLE TOO - the same pool, the same
         * weights, since the register went in the same evening. Fifty large
         * families hold ten shares of Retail each and become fifty couples
         * with a teen: the shares move with them.
         */
        int retail = Equity.indexOf(Sectors.RETAIL);
        big.shares[retail] = 10;
        big.abroad = 3;   // ...and US$3k of the world's paper each, since the next day
        double sharesBefore = street.sharesHeld(retail);
        double abroadBefore = street.totalAbroadUsd();
        block[large][U] = 0;
        block[FamilyStructure.COUPLE_TEEN.ordinal()][U] = 100;
        shop[U] = 0;
        street.advanceMonth(blockCensus, wage, .70, noFees, shop, .25, .05, 1);
        check("the shares move with the people, like the savings",
                street.cell(FamilyStructure.COUPLE_TEEN, PayTier.UNSKILLED).shares(retail), 10);
        check("...and none left the city", street.sharesHeld(retail), sharesBefore);
        check("...nor were taken away", street.getSharesTakenAway(retail), 0);
        check("the dollars abroad move with them too",
                street.cell(FamilyStructure.COUPLE_TEEN, PayTier.UNSKILLED).abroad(), 3);
        check("...all of them", street.totalAbroadUsd(), abroadBefore);
        check("...and none left with anybody", street.getAbroadTakenAway(), 0);

        HouseholdBalance copy = new HouseholdBalance();
        assertTrue("the cells restore by name",
                copy.restoreCells(street.cellKeys(), street.toCellSaveArray(), Equity.COMPANIES));
        boolean everyCell = true;
        for (int i = 0; i < street.cellCount(); i++) {
            Household a = street.cells().get(i), b = copy.cells().get(i);
            if (Math.abs(a.savings() - b.savings()) > 1e-12 || Math.abs(a.debt() - b.debt()) > 1e-12
                    || a.lockout() != b.lockout() || Math.abs(a.households() - b.households()) > 1e-12
                    || Math.abs(a.planned() - b.planned()) > 1e-12
                    || Math.abs(a.shares(retail) - b.shares(retail)) > 1e-12
                    || Math.abs(a.abroad() - b.abroad()) > 1e-12) everyCell = false;
        }
        assertTrue("...every cell, to the cent, shares and dollars included", everyCell);
        // The evening's save, the eight and the shares but no dollars, restores too.
        double[] evening = new double[street.cellCount() * HouseholdBalance.CELL_SLOTS_BEFORE_ABROAD + 3];
        double[] whole = street.toCellSaveArray();
        for (int i = 0, j = 0; i < street.cellCount(); i++) {
            for (int k = 0; k < HouseholdBalance.CELL_SLOTS_BEFORE_ABROAD; k++) evening[j++] = whole[i * HouseholdBalance.CELL_SLOTS + k];
        }
        System.arraycopy(whole, whole.length - 3, evening, evening.length - 3, 3);
        HouseholdBalance lastNight = new HouseholdBalance();
        assertTrue("a save from before the dollars abroad restores", lastNight.restoreCells(street.cellKeys(), evening, Equity.COMPANIES));
        check("...with the shares", lastNight.sharesHeld(retail), street.sharesHeld(retail));
        check("...and no dollars", lastNight.totalAbroadUsd(), 0);
        // The morning's save, eight a cell and no shares, still restores.
        double[] morning = new double[street.cellCount() * HouseholdBalance.CELL_SLOTS_BEFORE_SHARES + 3];
        double[] full = street.toCellSaveArray();
        for (int i = 0, j = 0; i < street.cellCount(); i++) {
            for (int k = 0; k < HouseholdBalance.CELL_SLOTS_BEFORE_SHARES; k++) morning[j++] = full[i * HouseholdBalance.CELL_SLOTS + k];
        }
        System.arraycopy(full, full.length - 3, morning, morning.length - 3, 3);
        HouseholdBalance older = new HouseholdBalance();
        assertTrue("a save from before the shares restores", older.restoreCells(street.cellKeys(), morning, Equity.COMPANIES));
        check("...with the savings", older.totalSavings(), street.totalSavings());
        check("...and no shares", older.sharesHeld(retail), 0);
        check("...and the city's stock with them", copy.totalSavings(), street.totalSavings());
        assertTrue("a save with a key this build does not know is refused whole",
                !copy.restoreCells(new String[] {"NOBODY"}, new double[] {1, 2}, Equity.COMPANIES));

        HouseholdBalance seeded = new HouseholdBalance();
        seeded.restore(street.toSaveArray(), blockCensus);
        check("a row-only save seeds the row's cells with the row's position",
                seeded.cell(FamilyStructure.SINGLE_ADULT, PayTier.UNSKILLED).savings(),
                street.getSavings(U));
        check("...and the row totals survive the seeding", seeded.totalSavings(), street.totalSavings());

        /* ============ A CELL UNDER HALF A HOUSEHOLD IS EMPTY (0.7.2) ============

           The census can leave a cell 1e-15 of a household, and the payments
           used to ask "households > 0" - so the ghost was paid, and a reformed
           city parted from its twin on which cell happened to be one
           (DenominationCheck). A cell under HouseholdBalance.EMPTY_CELL is now
           emptied where its count is written, and what it held goes to the
           cells that are not empty - its own row first, then the city, pro
           rata to what each holds. The fixtures PUT a position in a
           cell and drop the cell under the line; the claim is that it then
           holds nothing and the city's households hold everything they held.
           ======================================================================== */
        System.out.println("\n--- a cell under half a household is empty, and what it held stays ---");

        HouseholdBalance folding = new HouseholdBalance();
        Household ghost  = folding.cell(FamilyStructure.SINGLE_ADULT, PayTier.UNSKILLED);
        Household poorer = folding.cell(FamilyStructure.COUPLE, PayTier.UNSKILLED);
        Household richer = folding.cell(FamilyStructure.COUPLE, PayTier.SKILLED);
        ghost.households = .3;
        ghost.savings = 10; ghost.debt = 2; ghost.shares[retail] = 10; ghost.abroad = 3;
        ghost.paper = 5; ghost.cars = 1; ghost.studentDebt = 4;
        poorer.households = 100;
        poorer.savings = 4; poorer.debt = 1; poorer.shares[retail] = 2; poorer.paper = 1;
        richer.households = 50;
        richer.savings = 6; richer.paper = 2;
        String[] stockNames = {"savings", "debt", "shares", "dollars abroad", "paper", "cars", "student loans"};
        java.util.List<java.util.function.ToDoubleFunction<Household>> stockOf = java.util.List.of(
                c -> c.savings, c -> c.debt, c -> c.shares[retail], c -> c.abroad,
                c -> c.paper, c -> c.cars, c -> c.studentDebt);
        double[] heldBefore = new double[stockNames.length];
        for (int k = 0; k < stockNames.length; k++) heldBefore[k] = across(folding, stockOf.get(k));
        assertTrue("fixture: a cell of .3 households holds a position",
                ghost.isEmpty() && folding.holdsAnything(ghost));
        int foldedCells = folding.foldEmptyCells();
        assertTrue("the cell under half a household holds nothing", !folding.holdsAnything(ghost));
        check("...and its count stands: the census's, not ours to round", ghost.households(), .3);
        check("one cell had something to fold", foldedCells, 1);
        for (int k = 0; k < stockNames.length; k++) {
            check("...and the households hold all their " + stockNames[k],
                    across(folding, stockOf.get(k)), heldBefore[k]);
        }
        check("into its own row first: the unskilled couples hold the single's savings",
                poorer.savings, 4 * (1 + 3.0 / 400));
        check("...and the skilled couples, a row away, none of it", richer.savings, 6);
        check("a stock nobody in the row held goes by the row's households",
                poorer.abroad, .3 * 3 / 100);
        check("...and none of it across the row's edge", richer.abroad, 0);
        /*
         * ...AND A ROW WITH NOBODY LEFT IN IT FOLDS INTO THE CITY: a senior
         * professional single at .2 of a household, alone in its row.
         */
        Household lone = folding.cell(FamilyStructure.SINGLE_ADULT, PayTier.SENIOR_PROFESSIONAL);
        lone.households = .2;
        lone.savings = 5;
        double savedBefore = across(folding, c -> c.savings);
        double poorerHad = poorer.savings;
        folding.foldEmptyCells();
        assertTrue("a cell alone in its row is emptied too", !folding.holdsAnything(lone));
        check("...into the city, every saver's savings up by 1 in 703",
                richer.savings, 6 * (1 + 1.0 / 703));
        check("...the unskilled couples' too", poorer.savings, poorerHad * (1 + 1.0 / 703));
        check("...and the households hold all their savings", across(folding, c -> c.savings), savedBefore);

        /*
         * ...AND THROUGH A MONTH, where it happens: a census that drops a cell
         * holding shares and dollars from a hundred households to .3. The 99.7
         * who went took their positions with them - nobody grew, so nobody
         * claimed them - and what the .3 still held is the couples' now.
         */
        HouseholdBalance monthly = new HouseholdBalance();
        double[][] folk = new double[FamilyStructure.values().length][PayTier.values().length];
        java.util.function.ToDoubleBiFunction<FamilyStructure, PayTier> folkCensus =
                (s, t) -> folk[s.ordinal()][t.ordinal()];
        folk[single][U] = 100;
        folk[couple][U] = 100;
        double[] wages = new double[R];
        wages[U] = 300 * 3.0;
        double[] noShopping = new double[R];
        for (int m = 0; m < 3; m++) monthly.advanceMonth(folkCensus, wages, .50, noFees, noShopping, .20, .05, 1);
        Household thinning = monthly.cell(FamilyStructure.SINGLE_ADULT, PayTier.UNSKILLED);
        Household couples  = monthly.cell(FamilyStructure.COUPLE, PayTier.UNSKILLED);
        thinning.shares[retail] = 10;
        thinning.abroad = 3;
        double sharesIn = monthly.sharesHeld(retail);
        double abroadIn = monthly.totalAbroadUsd();
        folk[single][U] = .3;
        wages[U] = 200.3 * 3.0;
        monthly.advanceMonth(folkCensus, wages, .50, noFees, noShopping, .20, .05, 1);
        assertTrue("a cell the census leaves at .3 of a household holds nothing after the month",
                !monthly.holdsAnything(thinning));
        check("...and the month counted it", monthly.getCellsFolded(), 1);
        check("the shares: the households' now, plus what left with the 99.7",
                monthly.sharesHeld(retail) + monthly.getSharesTakenAway(retail), sharesIn);
        check("...and the .3's are the couples'", couples.shares(retail) * 100, .3 * 10);
        check("the dollars abroad the same way",
                monthly.totalAbroadUsd() + monthly.getAbroadTakenAway(), abroadIn);

        /*
         * ...AND NOTHING PAYS ONE, which is the half that went wrong. The
         * theft's proceeds are split by a weight per cell and divided by the
         * count: handed to a cell of 1e-15, a whole share became savings of a
         * quadrillion times that a household. Weighted to the ghost and the
         * couples alike, all of it now goes to the couples.
         */
        thinning.households = 1e-15;
        double[] offenders = new double[monthly.cellCount()];
        offenders[monthly.cells().indexOf(thinning)] = 1;
        offenders[monthly.cells().indexOf(couples)] = 1;
        double couplesHad = couples.totalSavings();
        check("the proceeds are all credited", monthly.creditByWeight(10, offenders), 10);
        check("...all of them to the households who are there",
                couples.totalSavings() - couplesHad, 10);
        assertTrue("...and none to a cell of 1e-15 households", !monthly.holdsAnything(thinning));

        /* ============ AND WHEN THEY CANNOT AFFORD A HOME, THEY SHARE ============

           Jerus, 2026-09-07: "perhaps poor families start living together."
           FamilyModel already knew how - it only ever did it when the city ran
           out of HOMES. This is the other reason, and the commoner one.
           ==================================================================== */
        System.out.println("\n--- a tier priced out of living alone shares instead ---");

        FamilyModel homes2 = new FamilyModel();
        double[] noPressure = new double[PayTier.values().length];
        homes2.shareByAffordability(noPressure);
        check("nobody shares when everybody can afford a home",
                homes2.getPricedOutShares(), 0);

        double[] priced = new double[PayTier.values().length];
        priced[PayTier.UNSKILLED.ordinal()] = 1;   // cannot cover any of it
        homes2.shareByAffordability(priced);
        check("...and a model with no households still forms none",
                homes2.getPricedOutShares(), 0);

        assertTrue("somebody always holds out, however dear the rent",
                FamilyModel.MAX_SHARING < 1);

        /*
         * THE PRESSURE ITSELF, which is the number the whole mechanic turns on.
         * Asserted as a shape rather than a figure: zero when one wage covers a
         * home and a basket comfortably, one when it covers none of it, and in
         * between when it is in between.
         */
        int hhRows = HouseholdAccounts.RETIRED + 1;
        HouseholdAccounts priceTest = new HouseholdAccounts();
        double[] wagesRich = new double[PayTier.values().length];
        double[] taxNone   = new double[PayTier.values().length];
        double[] peopleRow = new double[hhRows];
        double[] homesRow  = new double[hhRows];
        peopleRow[PayTier.UNSKILLED.ordinal()] = 100;
        homesRow[PayTier.UNSKILLED.ordinal()]  = 100;

        // rent 100 over 100 homes, shopping 100 over 100 people: $2 to live alone.
        priceTest.refresh(1000, 0, 100, 100, 0, 0, 0, 0, 0, 100, 100, 100);
        priceTest.updateByTier(wagesRich, taxNone, peopleRow, homesRow);
        double[] flat = priceTest.livingAlonePressure(null);
        check("no household model, no pressure", flat[PayTier.UNSKILLED.ordinal()], 0);

        /*
         * AND THE WHOLE THING, IN A CITY. The unit checks above say the valve
         * opens; this says it is worth opening - a flatshare has to leave its
         * members BETTER OFF than living alone, or the mechanic is a costume.
         */
        java.io.PrintStream realOut = System.out;
        java.io.PrintStream hush = new java.io.PrintStream(new java.io.OutputStream() {
            @Override public void write(int b) { }
        });

        Game poor = new Game(GameFiles.scratch("householdcheck"));
        System.setOut(hush);
        try {
            poor.newGame();
            // THE TREASURY THIS FIXTURE WAS WRITTEN AGAINST (0.7.10): its build list
            // is bought out of cash, and a city founds on D$100M since 0.7.10, not the
            // D$2.5B it assumed - so it is given that, the Wealthy preset's, explicitly.
            poor.setCashForTest(Founding.WEALTHY_CASH);
            /*
             * CAUSED, since 2026-09-10. The block below records that this city
             * stopped being poor on 2026-09-09 and that flatshares were being
             * asserted "however they got there" - which on this build meant
             * whichever households happened to migrate in, and after the
             * material repricing none of them did. A fixture that depends on
             * who happens to arrive is not a fixture. The one lever that still
             * makes an unskilled adult unable to live alone is take-home pay,
             * so the income tax is set to its ceiling: a full-time wage at 40%
             * pays for a basket but not for a home of its own, and the valve
             * has a reason to open.
             */
            poor.getEconomyManager().getTaxPolicy().setIncomeTaxRate(.60);
            for (BuildingsTemplate t : poor.getBuildingManager().getTemplates()) {
                if (t.getName().equals("Low-Rise Apartments")) poor.buildStack(t, 60, true);
                if (t.getName().equals("Small Grocery Store"))  poor.buildStack(t, 8, true);
                if (t.getName().equals("Coal Power Plant"))     poor.buildStack(t, 2, true);
                if (t.getName().equals("Water Treatment Plant"))poor.buildStack(t, 2, true);
                if (t.getName().equals("Paved Road"))           poor.buildStack(t, 20, true);
                if (t.getName().equals("Industrial Bakery"))         poor.buildStack(t, 6, true);
            }
            poor.simulateMonths(120);
        } finally { System.setOut(realOut); }

        HouseholdAccounts books = poor.getHouseholds();
        FamilyModel mix = poor.getFamilies();
        double[] pressure = books.livingAlonePressure(mix);
        int un = PayTier.UNSKILLED.ordinal();

        HouseholdAccounts.Statement alone =
                books.statementFor(mix, FamilyStructure.SINGLE_ADULT, PayTier.UNSKILLED);
        HouseholdAccounts.Statement sharing =
                books.statementFor(mix, FamilyStructure.SHARED_ADULTS, PayTier.UNSKILLED);

        System.out.printf("   unskilled pressure %.0f%%, %,.0f flatshares priced out;"
                + " alone leaves %.3f a month, sharing %.3f%n",
                pressure[un] * 100, mix.getPricedOutShares(), alone.left(), sharing.left());

        /* ===================================================================
           THIS CITY IS NO LONGER POOR, AND THAT IS NOT A FAILURE (2026-09-09).

           This asserted pressure[un] > 0 - an unskilled single adult who cannot
           afford to live alone here - as the fixture for everything below it.
           The 2026-09-09 rebalance put the wage ladder on real Job Bank medians
           and the homes on real build costs, and the two together leave that
           adult $366 a month clear after rent and a basket. Squeezing the
           city's housing does not bring it back either: 22 Low-Rise instead of
           60 moved it to $317, because rent here is cost-anchored and the
           scarcity multiple is bounded.

           So a single unskilled adult CAN live alone in a balanced city, which
           is both correct - a full-time wage should house one person - and the
           end of this line as a fixture.

           What this block is actually for is the sentence above it: the unit
           checks say the valve opens, this says it is WORTH opening. That
           assertion does not need the city to be poor and is unchanged below.
           The priced-out state itself is still tested, and tested properly, in
           the unit checks further up, where the rent is set by hand rather than
           hoped for - which is where a claim about a threshold belongs.
           =================================================================== */
        System.out.printf("   living-alone pressure on the unskilled: %.0f%%%n",
                pressure[un] * 100);
        /*
         * Sharing, or nobody left to share. The fixture cannot guarantee single
         * adults exist - a city where every one of them has ALREADY paired off
         * is the mechanic having worked, not having failed - so the assertion
         * is that flatshares exist, however they got there.
         */
        assertTrue("...so some of them are sharing",
                mix.totalOf(FamilyStructure.SHARED_ADULTS) > 0);
        assertTrue("A FLATSHARE IS BETTER OFF THAN LIVING ALONE",
                sharing.left() > alone.left());
        assertTrue("...because five of them pay one rent, not five",
                sharing.rent() < alone.rent() * 5 - 1e-9);
        assertTrue("...and still five baskets",
                Math.abs(sharing.shopping() - alone.shopping() * 5) < 1e-6);

        /* ============ A HOME IS A SIZE, AND A HOUSEHOLD HAS TO FIT ============

           Jerus, 2026-09-07: "studio apartments... only single adults can
           occupy them, or well two people, so any other structure is not
           allowed." Homes were a pooled count before this, so a family of six
           could live in a studio as long as the city had eighty spare doors
           somewhere - which is most of why Studio Apartments were a building
           with no niche and lost to a House on price at every land price
           (backlog I1).
           ==================================================================== */
        System.out.println("\n--- a home is a size, and a household has to fit ---");

        BuildingsTemplate studio = new BuildingsTemplate("s", BuildingType.RESIDENTIAL);
        studio.setCapacity(160);
        studio.setDwellings(80);
        BuildingsTemplate houseT = new BuildingsTemplate("h", BuildingType.RESIDENTIAL);
        houseT.setCapacity(4);
        houseT.setDwellings(1);
        BuildingsTemplate lowRise = new BuildingsTemplate("l", BuildingType.RESIDENTIAL);
        lowRise.setCapacity(250);
        lowRise.setDwellings(100);

        check("a studio flat takes two", studio.homeSize(), 2);
        check("a house takes four", houseT.homeSize(), 4);
        check("a low-rise flat takes three", lowRise.homeSize(), 3);
        assertTrue("...and only the studio refuses children", studio.adultsOnly()
                && !houseT.adultsOnly() && !lowRise.adultsOnly());

        /*
         * A CITY OF NOTHING BUT STUDIOS CANNOT HOUSE A FAMILY, which is the one
         * hard no in the model. Everything else crowds.
         */
        FamilyModel onlyStudios = new FamilyModel();
        int[] studiosOnly = new int[]{0, 0, 500};      // 500 two-person flats
        double nowhere = onlyStudios.house(studiosOnly);
        check("an empty city needs no homes", nowhere, 0);

        /*
         * THE FLAT SETS THE PRICE, and the household in it does not come into
         * it. Jerus: "the building earns its rent regardless - if a couple is
         * living in a mansion it is paying a mansion's price." The first
         * version weighted the two together, which is a market story rather
         * than a lease and put a household's own size back into its rent.
         */
        check("a two-person flat bills two", FamilyModel.rentWeightOf(2), 2);
        check("a six-person house bills six", FamilyModel.rentWeightOf(6), 6);
        assertTrue("...so a bigger home is a dearer one",
                FamilyModel.rentWeightOf(6) > FamilyModel.rentWeightOf(2));

        FamilyModel priceTestModel = new FamilyModel();
        check("and a flat nobody in the city could live in bills nothing",
                priceTestModel.marginalRentWeight(2), 0);

        System.out.println("\n--- and the two pension dials are the player's ---");
        TaxPolicy pol = new TaxPolicy();
        check("the contribution starts at the real CPP rate",
                pol.getContributionRate(), SocialSecurity.DEFAULT_CONTRIBUTION_RATE);
        pol.setContributionRate(.09);
        check("...and moves", pol.getContributionRate(), .09);
        pol.setContributionRate(9);
        check("...but not past the ceiling", pol.getContributionRate(),
                TaxPolicy.MAX_CONTRIBUTION);
        pol.setPensionReplacement(.60);
        check("a richer pension is a bigger cheque", pol.pensionPerSenior(),
                .60 * PayTier.UNSKILLED.getMonthlyWage());
        double[] state = pol.getPolicyState();
        TaxPolicy back2 = new TaxPolicy();
        assertTrue("the dials survive a save", back2.restorePolicyState(state));
        check("...the contribution", back2.getContributionRate(), TaxPolicy.MAX_CONTRIBUTION);
        check("...and the pension", back2.getPensionReplacement(), .60);
        check("and never negative when contributions overshoot",
                SocialSecurity.shortfall(100_000, 1), 0);

        /* ---- and in the books ---- */
        HouseholdAccounts pens = new HouseholdAccounts();
        pens.update(1000, 150, 300, 400, 60, 200, 500, 250, 240);

        check("contributions come off take-home", pens.getDisposableIncome(),
                1000 - 150 - 60 + 200);
        check("...and the pension goes on", pens.getPensions(), 200);

        double[] pw = new double[PayTier.values().length];
        double[] pt = new double[PayTier.values().length];
        pw[PayTier.UNSKILLED.ordinal()] = 1000;
        pt[PayTier.UNSKILLED.ordinal()] = 150;
        double[] pp = new double[rows];
        double[] ph = new double[rows];
        pp[PayTier.UNSKILLED.ordinal()] = 400;
        pp[HouseholdAccounts.RETIRED]   = 100;
        ph[PayTier.UNSKILLED.ordinal()] = 200;
        ph[HouseholdAccounts.RETIRED]   = 80;
        pens.updateByTier(pw, pt, pp, ph);

        /*
         * Contributions follow WAGES and the pension goes entirely to the
         * retired row. Allocating contributions by headcount instead would
         * charge pensioners for their own pension, which is the one thing this
         * split must never do.
         */
        check("the workers pay all the contributions",
                pens.getRowContributions(PayTier.UNSKILLED.ordinal()), 60);
        check("...and the pensioners pay none",
                pens.getRowContributions(HouseholdAccounts.RETIRED), 0);
        check("the pension goes entirely to the retired",
                pens.getRowPensions(HouseholdAccounts.RETIRED), 200);
        check("...and nowhere else",
                pens.getRowPensions(PayTier.UNSKILLED.ordinal()), 0);
        assertTrue("the retired row now has an income at all",
                pens.getRowDisposable(HouseholdAccounts.RETIRED) > 0);

        whatItSpendsAnswersTheRealRate();

        System.out.println(fails == 0 ? "\nAll checks passed." : "\n" + fails + " FAILED");
        System.exit(fails == 0 ? 0 : 1);
    }

    /* =====================================================================
       AND WHAT IT SPENDS ANSWERS THE REAL RATE (0.7.3)

       Jerus's design, the-central-bank.md section 9: for the rate to bite at
       home, a household's saving must answer the real return. What is
       proved, every figure against the dials rather than a number:

         - at no real return the plan is the plan as it was, term by term;
         - at ten points of real return the part above subsistence is exactly
           1 - SAVING_RESPONSE x .10 of it and subsistence does not move; at
           ten points negative, exactly 1 + SAVING_RESPONSE x .10;
         - at eighty points either way the floor and the ceiling bind;
         - a household that can afford a basket and no more plans the same
           at any rate;
         - the counter and the table move with the surplus they spend out
           of, by the same factor;
         - the factor handed to the balance reaches every cell's plan, on the
           month's path and on the load path's re-strike;
         - and the monetary page's figure, read between presses, is the one
           the next month's plan is struck at.
       ===================================================================== */
    static void whatItSpendsAnswersTheRealRate() {
        System.out.println("\n--- what a household spends above subsistence answers the real deposit rate ---");

        int R = HouseholdBalance.ROWS;
        int U = PayTier.UNSKILLED.ordinal();
        double[][] mix = new double[FamilyStructure.values().length][PayTier.values().length];
        java.util.function.ToDoubleBiFunction<FamilyStructure, PayTier> census =
                (s, t) -> mix[s.ordinal()][t.ordinal()];
        mix[FamilyStructure.COUPLE.ordinal()][U] = 100;
        double[] income = new double[R], fees = new double[R], spent = new double[R];
        income[U] = 100 * 4.0;   // well past the rent and the basket: a surplus to spend
        double rentEach = .60, basket = .25;

        /*
         * A household with both terms: income past subsistence, and a net
         * worth - the opening buffer, and six months of banking the half of
         * its plan the shops did not sell it.
         */
        HouseholdBalance saver = new HouseholdBalance();
        for (int m = 0; m < 6; m++) {
            saver.advanceMonth(census, income, rentEach, fees, spent, basket, .05, 1);
            spent[U] = saver.getHouseholds(U) * saver.getPlanned(U) * .5;
        }
        Household c = saver.cell(FamilyStructure.COUPLE, PayTier.UNSKILLED);
        double subsistence = c.subsistence();
        double earned = c.afterFixed + Math.max(0, c.investmentIncome);
        double worth = Math.max(0, c.savings + c.abroad + c.paper - c.debt);
        // The plan as it was before 0.7.3, written out from the dials.
        double wantThen = subsistence + HouseholdBalance.MARGINAL_PROPENSITY
                * Math.max(0, earned - subsistence) + HouseholdBalance.WEALTH_SPENT_A_MONTH * worth;
        double surplusThen = Math.max(0, earned - wantThen);
        double luxuryThen = HouseholdBalance.WEALTH_SPENT_A_MONTH * worth
                + HouseholdBalance.LUXURY_SHARE_OF_SURPLUS * surplusThen;
        double mealsThen = HouseholdBalance.MEAL_SHARE_OF_SURPLUS * surplusThen
                + HouseholdBalance.MEAL_SHARE_OF_WEALTH * HouseholdBalance.WEALTH_SPENT_A_MONTH * worth;
        assertTrue("fixture: income past the basket, a net worth, and a surplus left over",
                earned > subsistence && worth > 0 && surplusThen > 0);

        double atZero = HouseholdBalance.spendFactor(0);
        check("at no real return the factor is one", atZero, 1);
        c.plan(1, 1, atZero);
        check("...and the plan is what it was: the grocer's", c.want(), wantThen);
        check("...the counter's", c.luxuryWant(), luxuryThen);
        check("...and the table's", c.mealWant, mealsThen);

        for (double real : new double[] { .10, -.10 }) {
            double f = HouseholdBalance.spendFactor(real);
            check(String.format("at %+.0f points real the factor is 1 %s SAVING_RESPONSE x .10",
                    real * 100, real > 0 ? "-" : "+"), f, 1 - HouseholdBalance.SAVING_RESPONSE * real);
            c.plan(1, 1, f);
            check("...the part above subsistence is exactly that share of it",
                    c.want() - c.subsistence(), f * (wantThen - subsistence));
            check("...and subsistence does not move", c.subsistence(), subsistence);
            check("...the counter moves with the surplus, by the same share", c.luxuryWant(), f * luxuryThen);
            check("...and so does the table", c.mealWant, f * mealsThen);
        }

        assertTrue("fixture: eighty points either way is past the floor and the ceiling",
                1 - HouseholdBalance.SAVING_RESPONSE * .80 < HouseholdBalance.SPEND_FLOOR
                        && 1 + HouseholdBalance.SAVING_RESPONSE * .80 > HouseholdBalance.SPEND_CEILING);
        check("at +80 points the floor binds", HouseholdBalance.spendFactor(.80), HouseholdBalance.SPEND_FLOOR);
        c.plan(1, 1, HouseholdBalance.spendFactor(.80));
        check("...and the plan keeps SPEND_FLOOR of what is above subsistence",
                c.want() - c.subsistence(), HouseholdBalance.SPEND_FLOOR * (wantThen - subsistence));
        check("at -80 points the ceiling binds", HouseholdBalance.spendFactor(-.80), HouseholdBalance.SPEND_CEILING);
        c.plan(1, 1, HouseholdBalance.spendFactor(-.80));
        check("...and the plan asks SPEND_CEILING of it",
                c.want() - c.subsistence(), HouseholdBalance.SPEND_CEILING * (wantThen - subsistence));
        check("a rate that is not a number is no return at all", HouseholdBalance.spendFactor(Double.NaN), 1);

        /*
         * A HOUSEHOLD AT SUBSISTENCE: the first section's couple on $1.00, whose
         * income after the rent is short of a basket, run until its savings
         * are gone. Nothing above a basket, so nothing for any rate to move.
         */
        HouseholdBalance poorBal = new HouseholdBalance();
        double[] low = new double[R], spentLow = new double[R];
        low[U] = 100 * 1.0;
        for (int m = 0; m < 80; m++) {
            poorBal.advanceMonth(census, low, rentEach, fees, spentLow, basket, .05, 1);
            spentLow[U] = poorBal.getHouseholds(U) * poorBal.getPlanned(U);
        }
        Household p = poorBal.cell(FamilyStructure.COUPLE, PayTier.UNSKILLED);
        assertTrue("fixture: short of a basket after the rent, with nothing saved",
                p.afterFixed() < p.subsistence() && p.netWorth() <= 0);
        p.plan(1, 1, HouseholdBalance.SPEND_FLOOR);
        double wantAtFloor = p.want(), plannedAtFloor = p.planned();
        p.plan(1, 1, HouseholdBalance.SPEND_CEILING);
        check("a household at subsistence plans the same at any rate", p.want(), wantAtFloor);
        check("...a basket and no more", p.want(), p.subsistence());
        check("...and can fund the same", p.planned(), plannedAtFloor);

        /*
         * THROUGH THE BALANCE: two of them in lockstep, one handed a factor.
         * The month they part settles the same shop - both planned the same
         * the month before - so everything that differs is the plan.
         */
        HouseholdBalance plain = new HouseholdBalance(), handed = new HouseholdBalance();
        double[] spentPlain = new double[R], spentHanded = new double[R];
        for (int m = 0; m < 6; m++) {
            plain.advanceMonth(census, income, rentEach, fees, spentPlain, basket, .05, 1);
            handed.advanceMonth(census, income, rentEach, fees, spentHanded, basket, .05, 1);
            spentPlain[U] = plain.getHouseholds(U) * plain.getPlanned(U) * .5;
            spentHanded[U] = handed.getHouseholds(U) * handed.getPlanned(U) * .5;
        }
        check("fixture: two balances in lockstep", handed.getWant(U), plain.getWant(U));
        double f = HouseholdBalance.spendFactor(.10);
        handed.setSpendFactor(f);
        plain.advanceMonth(census, income, rentEach, fees, spentPlain, basket, .05, 1);
        handed.advanceMonth(census, income, rentEach, fees, spentHanded, basket, .05, 1);
        check("a balance nobody hands a factor plans at one", plain.getSpendFactor(), 1);
        check("the one handed a factor plans at it", handed.getSpendFactor(), f);
        check("...every cell asking that share of what is above subsistence",
                handed.getWant(U) - handed.getSubsistence(U), f * (plain.getWant(U) - plain.getSubsistence(U)));
        assertTrue("...so the shops are told of less to sell",
                handed.getSpendingCapacity() < plain.getSpendingCapacity());
        plain.planOnly(census, income, rentEach, fees, basket, .05);
        handed.planOnly(census, income, rentEach, fees, basket, .05);
        check("...and the load path's re-strike plans at the same factor",
                handed.getWant(U) - handed.getSubsistence(U), f * (plain.getWant(U) - plain.getSubsistence(U)));

        /*
         * AND IN A CITY: the monetary page's figure, read between presses, is
         * the factor the next month's plan is struck at. The playtest's
         * founding with the dial held at 40% for a year, so that saving pays
         * and the factor is not one.
         */
        java.io.PrintStream loud = System.out;
        java.io.PrintStream hushed = new java.io.PrintStream(new java.io.OutputStream() {
            @Override public void write(int b) { }
        });
        Game city;
        double worstAudit = 0;
        try {
            java.nio.file.Path root = java.nio.file.Files.createTempDirectory("householdcheck-rate");
            System.setOut(hushed);
            city = MonetaryCheck.founding(root, "saving-pays");
            for (int m = 0; m < 12; m++) {
                MonetaryCheck.step(city, .40, 0);
                worstAudit = Math.max(worstAudit, city.getLastMoneyAudit().relative());
            }
        } catch (java.io.IOException ex) {
            System.setOut(loud);
            assertTrue("a temporary directory for the city: " + ex.getMessage(), false);
            return;
        } finally {
            System.setOut(loud);
        }
        double pageReal = city.realDepositRate(), pageFactor = city.spendFactor();
        System.out.printf("   a year at a dial of 40%%: savers are paid %.2f%%, inflation %+.2f%%,"
                        + " so %+.2f%% real and a factor of %.4f%n",
                city.getBank().depositRate() * 100, city.getPriceIndex().inflation() * 100,
                pageReal * 100, pageFactor);
        check("the page's real deposit rate is the deposit rate less the year's inflation",
                pageReal, city.getBank().depositRate() - city.getPriceIndex().inflation());
        check("...and its factor is the rule's on it", pageFactor, HouseholdBalance.spendFactor(pageReal));
        assertTrue("fixture: saving pays, so the factor is under one", pageFactor < 1 - 1e-6);
        System.setOut(hushed);
        try {
            MonetaryCheck.step(city, .40, 0);
        } finally {
            System.setOut(loud);
        }
        worstAudit = Math.max(worstAudit, city.getLastMoneyAudit().relative());
        check("...and it is the factor the next month's plan was struck at",
                city.getHouseholdBalance().getSpendFactor(), pageFactor);
        assertTrue("every month of it passed the money audit", worstAudit < 1e-6);
    }
}
