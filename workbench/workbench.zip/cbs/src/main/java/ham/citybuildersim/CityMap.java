package ham.citybuildersim;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;

/**
 * The city map's data: the city's buildings counted by type in each 7.68 km district of its land, placed month by month so nothing placed ever moves, dealt out over the tiles about each district, drawn as each tile's homes, workplaces and roads, summed up a pyramid for the far view, and written beside the save as a sidecar - what the tile painter paints the city from.
 *
 * WHY THIS EXISTS (0.7.60, batch J3; the project's spec-land.md 2.5). The
 * model counts buildings by type and nothing else: a city of ten billion has
 * 279 million of them and no places. Jerus's mockup placed every building on
 * a 30 m plot as it grew; stored that way a 10B city is gigabytes. So the map
 * keeps counts by type in districts of 256 x 256 plots - 29,929 of them at
 * 10B, 10.8 MB - and paints a tile from its district's counts when the screen
 * needs it (TilePainter), so its cost follows the screen, never the
 * population. NOTHING IN THE MODEL READS IT.
 *
 * A DISTRICT holds its owned dry plots (from 32 x 32 samples, recounted in
 * every district a purchase touches), the plots its buildings use (a type's
 * land / 9,687.5 sq ft a plot), its owned iron and oil sites, and its count
 * of every type.
 *
 * EACH MONTH, ONCE CONSTRUCTION COMPLETES (reconcile(), star 12): each type's
 * change is placed - new buildings into the first district with room,
 * districts tried nearest the founding site first, but farms, utilities,
 * mines and wells, the railway and the car plants farthest first; removals in
 * reverse - and nothing placed ever moves. Running totals and a cursor each
 * way keep a month's work to the districts it changes: measured 0.76 ms a
 * month at 10B in the design. Mines and wells are the exception the design
 * names: they stand on their resource's sites, the first in acquisition order
 * (the centre, then each purchase) not worked out, so they go to the
 * districts holding those sites.
 *
 * CANONICALLY (canonical()), for a save with no sidecar, a lost one or one
 * that does not match: each type in proportion in every district, inner
 * first, the remainders by largest remainder - exact. The picture shifts
 * once.
 *
 * THE DEAL (deal()) spreads a district over the tiles within half a
 * district of its middle (J3b): building j of type t goes where its own hash
 * says, through an alias table weighted by each tile's owned dry samples and
 * a tent that falls to nothing half a district out, so neighbouring
 * districts blend across their border; homes, shops, offices and services
 * lean toward the founding site, the city's middle. One more building
 * changes one tile by one. A tile's counts are then DRAWN (tileInput(),
 * BuildingVisual's visual counts): its homes from the people they house,
 * its shops, offices and plants from their jobs, the rest one for one, and
 * its road budget from the frontage its buildings need; the two world
 * highways of the mockup use none.
 *
 * THE PYRAMID sums ten classes, used plots and owned plots two by two up to
 * one node, built when the map is, each district's ancestors updated as it
 * changes: what the far view draws (batch J4).
 *
 * THE SIDECAR (slot-NN-map.bin, writeSidecar()/readSidecar()): one record a
 * district, deflated, its header the magic, the format, the world's seed, the
 * month, a stamp of the content (also the save's mapStamp), the land it was
 * drawn on and the type count. A map saved and read back writes the same
 * bytes.
 */
public final class CityMap {

    /* =====================================================================
       THE GEOMETRY
       ===================================================================== */

    /** Plots on a district's side: World.DISTRICT, 256 (7.68 km). */
    public static final int DISTRICT = World.DISTRICT;

    /** Tiles on a district's side: 8. */
    public static final int TILES_A_SIDE = DISTRICT / World.TILE;

    /** Tiles in a district: 64. */
    public static final int TILES = TILES_A_SIDE * TILES_A_SIDE;

    /** Samples across a district each way its owned dry plots are counted from: 32, so 1,024 a district (spec-land 2.5). */
    public static final int SAMPLES = 32;

    /** Plots between samples: 8. */
    public static final int SAMPLE_STRIDE = DISTRICT / SAMPLES;

    /** Plots a sample stands for: 64. */
    public static final int SAMPLE_PLOTS = SAMPLE_STRIDE * SAMPLE_STRIDE;

    /** Samples across a tile: 4, so a tile's owned dry ground is 0 to 16 samples. */
    public static final int TILE_SAMPLES = World.TILE / SAMPLE_STRIDE;

    /** Half square feet in a plot: 9,687.5 sq ft twice, so a district's room and use are whole numbers and a month's change is exact however it is added up. */
    static final long HALF_SQ_FT_PER_PLOT = Math.round(2 * BuildingVisual.SQ_FT_PER_PLOT);

    /** A district with less room than this many plots is passed by the cursors: half a plot (the design's). */
    static final double MIN_ROOM = 0.5;

    /** The resources a district counts its owned sites of, and mines and wells stand on: iron and oil (spec-land 2.5). */
    static final Resource[] SITED = { Resource.IRON, Resource.OIL };

    /** How many districts' lists of sites are kept: 64. */
    static final int SITE_LISTS_KEPT = 64;

    /** Above this many districts under the land's box, a canonical build looks at the ground coarsely first and measures only districts with land in or beside them: 1,024 (a box 246 km across). */
    static final int COARSE_ABOVE = 1024;

    /** The coarse look's stride, in plots: 32, a sample a tile. */
    static final int COARSE_STRIDE = 32;

    /** The sidecar's magic: "CMAP". */
    static final int MAGIC = 0x434D4150;

    /** The sidecar's format: 1. */
    static final int FORMAT = 1;

    /** Where the stamp sits in the sidecar's raw bytes: after the magic, the format, the seed and the month. */
    static final int STAMP_AT = 4 + 4 + 8 + 4;

    /* =====================================================================
       A DISTRICT
       ===================================================================== */

    /** One district: where it is, its owned dry plots, the plots used, its owned sites, its counts by type. */
    public static final class District {
        /** Its column and row, in districts from the founding site's. */
        public final int dx, dy;
        final long key;
        final double order;
        /** Its owned dry plots, from SAMPLES x SAMPLES samples. */
        int owned;
        /** The ground its buildings use, in half square feet: each type's count x its land, kept exactly. */
        long usedHalf;
        /** Its count of every type, by id. */
        final int[] counts;
        /** Its owned sites of each SITED resource. */
        final int[] sites = new int[SITED.length];
        /** Each tile's owned dry samples, 0 to 16, row by row; null until measured or asked for. */
        byte[] tileDry;
        /** How many of each site-bound type stand on its sites (the rest of its count has none); null when none. */
        int[] sited;
        /** For painting: per SITED resource, pairs of {holding, mines} - how many of each holding's sites here carry one. */
        int[][] holdingMines = new int[SITED.length][];
        /** Bumped whenever its counts change: what its deal is cached against. */
        long version;
        /** Its place in the map's order, nearest first. */
        int index;

        District(int dx, int dy, int types, double order) {
            this.dx = dx;
            this.dy = dy;
            this.key = key(dx, dy);
            this.order = order;
            this.counts = new int[types];
        }

        public int owned()       { return owned; }
        /** The plots its buildings use: each type's count x its land in plots. */
        public double used()     { return usedHalf / (double) HALF_SQ_FT_PER_PLOT; }
        public int count(int t)  { return t < counts.length ? counts[t] : 0; }
        public int sites(Resource r) {
            for (int k = 0; k < SITED.length; k++) if (SITED[k] == r) return sites[k];
            return 0;
        }
        double free()            { return (owned * HALF_SQ_FT_PER_PLOT - usedHalf) / (double) HALF_SQ_FT_PER_PLOT; }
        /** Its room in half square feet, never below nothing. */
        long freeHalf()          { return Math.max(0, owned * HALF_SQ_FT_PER_PLOT - usedHalf); }
    }

    static long key(int dx, int dy) { return ((long) dx << 32) | (dy & 0xffffffffL); }

    /* =====================================================================
       THE STATE
       ===================================================================== */

    private final long seed;
    private final long siteX, siteY;
    private final long baseDX, baseDY;
    private final BuildingVisual.Type[] types;
    private CityLand land;
    private Function<Resource, double[]> remaining;

    private final List<District> districts = new ArrayList<>();
    private final Map<Long, District> byKey = new HashMap<>();
    private final long[] have;
    private final int[] lo, hi;
    private int innerCursor, outerCursor;
    private int purchasesSeen;
    private double centreHalfSeen;
    private boolean measured = true;
    private Pyramid pyramid;
    private SiteIndex siteIndex;
    private boolean sitedPlaced;

    private CityMap(long seed, long siteX, long siteY, BuildingVisual.Type[] types) {
        this.seed = seed;
        this.siteX = siteX;
        this.siteY = siteY;
        this.baseDX = Math.floorDiv(siteX, DISTRICT);
        this.baseDY = Math.floorDiv(siteY, DISTRICT);
        this.types = types;
        this.have = new long[types.length];
        this.lo = new int[types.length];
        this.hi = new int[types.length];
    }

    /** The world's seed. */
    public long seed()                     { return seed; }

    /** The types it counts, by id. */
    public BuildingVisual.Type[] types()   { return types; }

    /** Its districts, nearest the founding site first. */
    public List<District> districts()      { return java.util.Collections.unmodifiableList(districts); }

    /** The district at (dx, dy) from the founding site's, or null. */
    public District district(int dx, int dy) { return byKey.get(key(dx, dy)); }

    /** The pyramid. */
    public Pyramid pyramid()               { return pyramid; }

    /** Whether its districts were measured on the ground (false for a harness's square city, whose capacities were given). */
    public boolean measured()              { return measured; }

    /** Every type's count over all districts. */
    public long[] totals() {
        long[] out = new long[types.length];
        for (District d : districts) for (int t = 0; t < types.length; t++) out[t] += d.counts[t];
        return out;
    }

    /** The land it was drawn on. */
    public CityLand land() { return land; }

    /** The founding site's district's column, absolute. */
    long baseDX() { return baseDX; }

    /** ...and row. */
    long baseDY() { return baseDY; }

    /* =====================================================================
       BUILDING ONE: CANONICALLY, FROM A SIDECAR, OR A HARNESS'S SQUARE
       ===================================================================== */

    /**
     * A map drawn canonically (spec-land 2.5): the land's districts measured,
     * then each type in proportion in every district, inner first, the
     * remainders by largest remainder; mines and wells on their sites.
     *
     * @param land       the city's land
     * @param remaining  what remains of a resource in each holding, in acquisition order (LandManager.remainingByHolding)
     * @param types      the types by id (BuildingVisual.table())
     * @param counts     the model's count of every type, by id
     */
    public static CityMap canonical(CityLand land, Function<Resource, double[]> remaining,
                                    BuildingVisual.Type[] types, long[] counts) {
        CityMap m = new CityMap(land.seed(), land.siteX(), land.siteY(), types);
        m.land = land;
        m.remaining = remaining;
        m.measureAll();
        m.allocate(counts);
        return m;
    }

    /**
     * A HARNESS'S SQUARE CITY (the design's scale case): side x side districts
     * round the founding site, every one owned and holding `capacity` plots,
     * its tiles alike - a city of any size at one density without measuring
     * its ground. Its land is a centre reaching the square's edge; its sites
     * are the world's under it; nothing in it worked.
     */
    static CityMap square(long seed, long siteX, long siteY, BuildingVisual.Type[] types, int side, int capacity,
                          long[] counts) {
        CityMap m = new CityMap(seed, siteX, siteY, types);
        int h = side / 2;
        double[] centre = new double[CityLand.CENTRE_FIELDS];
        long x0 = (m.baseDX - h) * DISTRICT, x1 = (m.baseDX - h + side) * DISTRICT;
        long y0 = (m.baseDY - h) * DISTRICT, y1 = (m.baseDY - h + side) * DISTRICT;
        double half = Math.min(Math.min(siteX - x0, x1 - 1 - siteX), Math.min(siteY - y0, y1 - 1 - siteY));
        centre[0] = half;
        centre[CityLand.CENTRE_FIELDS - 5] = -1;
        centre[CityLand.CENTRE_FIELDS - 4] = -1;
        centre[CityLand.CENTRE_FIELDS - 2] = siteX;
        centre[CityLand.CENTRE_FIELDS - 1] = siteY;
        m.land = CityLand.restore(seed, centre, null, null);
        m.remaining = r -> m.land.amountsInOrder(r);
        m.measured = false;
        byte[] full = new byte[TILES];
        Arrays.fill(full, (byte) (TILE_SAMPLES * TILE_SAMPLES));
        for (int dy = -h; dy < side - h; dy++) {
            for (int dx = -h; dx < side - h; dx++) {
                District d = m.newDistrict(dx, dy);
                d.owned = capacity;
                d.tileDry = full.clone();
            }
        }
        m.sortDistricts();
        m.purchasesSeen = 0;
        m.centreHalfSeen = half;
        m.siteIndex();
        m.allocate(counts);
        return m;
    }

    private District newDistrict(int dx, int dy) {
        long cx = (baseDX + dx) * DISTRICT + DISTRICT / 2, cy = (baseDY + dy) * DISTRICT + DISTRICT / 2;
        double ox = cx - siteX, oy = cy - siteY;
        District d = new District(dx, dy, types.length, ox * ox + oy * oy);
        districts.add(d);
        d.index = districts.size() - 1;
        byKey.put(d.key, d);
        return d;
    }

    private void sortDistricts() {
        districts.sort(DISTRICT_ORDER);
        for (int i = 0; i < districts.size(); i++) districts.get(i).index = i;
        rangeTypes();
        innerCursor = 0;
        outerCursor = districts.size() - 1;
        advanceCursors();
    }

    /** Each type's lowest and highest district index holding it. */
    private void rangeTypes() {
        Arrays.fill(lo, Integer.MAX_VALUE);
        Arrays.fill(hi, -1);
        for (int i = 0; i < districts.size(); i++) {
            int[] c = districts.get(i).counts;
            for (int t = 0; t < types.length; t++) {
                if (c[t] > 0) {
                    if (i < lo[t]) lo[t] = i;
                    hi[t] = i;
                }
            }
        }
    }

    private void advanceCursors() {
        while (innerCursor < districts.size() && districts.get(innerCursor).free() < MIN_ROOM) innerCursor++;
        while (outerCursor >= 0 && districts.get(outerCursor).free() < MIN_ROOM) outerCursor--;
    }

    /* =====================================================================
       MEASURING THE GROUND: OWNED DRY PLOTS
       ===================================================================== */

    /** Every district the land reaches, measured; the coarse look first when there are many. */
    private void measureAll() {
        double reach = outerReach();
        long dx0 = Math.floorDiv(siteX - (long) Math.ceil(reach), DISTRICT) - baseDX;
        long dx1 = Math.floorDiv(siteX + (long) Math.ceil(reach), DISTRICT) - baseDX;
        long dy0 = Math.floorDiv(siteY - (long) Math.ceil(reach), DISTRICT) - baseDY;
        long dy1 = Math.floorDiv(siteY + (long) Math.ceil(reach), DISTRICT) - baseDY;
        int nx = (int) (dx1 - dx0 + 1), ny = (int) (dy1 - dy0 + 1);
        boolean[] maybe = null;
        if ((long) nx * ny > COARSE_ABOVE) maybe = coarseLand((int) dx0, (int) dy0, nx, ny);
        for (int j = 0; j < ny; j++) {
            for (int i = 0; i < nx; i++) {
                int dx = (int) (dx0 + i), dy = (int) (dy0 + j);
                int own = ownership(dx, dy);
                if (own == NONE || (maybe != null && !maybe[j * nx + i])) continue;
                measureNew(dx, dy, own);
            }
        }
        if (byKey.get(key(0, 0)) == null) {
            District d = newDistrict(0, 0);
            measure(d, ownership(0, 0));
        }
        sortDistricts();
        purchasesSeen = land.purchases().size();
        centreHalfSeen = land.centreHalf();
        siteIndex();
    }

    /** Which districts have land in or beside them, by a sample a tile (COARSE_STRIDE): a district all sea there, with all-sea neighbours, is taken as sea and not measured. */
    private boolean[] coarseLand(int dx0, int dy0, int nx, int ny) {
        int per = DISTRICT / COARSE_STRIDE, block = 16;
        boolean[] land = new boolean[nx * ny];
        byte[] buf = new byte[block * per * block * per];
        World world = World.of(seed);
        for (int bj = 0; bj < ny; bj += block) {
            for (int bi = 0; bi < nx; bi += block) {
                int n = block * per;
                world.regionTerrain((baseDX + dx0 + bi) * DISTRICT, (baseDY + dy0 + bj) * DISTRICT, COARSE_STRIDE, n, buf);
                for (int p = 0; p < n * n; p++) {
                    if (buf[p] == World.SALT) continue;
                    int i = bi + (p % n) / per, j = bj + (p / n) / per;
                    if (i < nx && j < ny) land[j * nx + i] = true;
                }
            }
        }
        boolean[] out = land.clone();
        for (int j = 0; j < ny; j++) {
            for (int i = 0; i < nx; i++) {
                if (!land[j * nx + i]) continue;
                for (int b = -1; b <= 1; b++) for (int a = -1; a <= 1; a++) {
                    int x = i + a, y = j + b;
                    if (x >= 0 && y >= 0 && x < nx && y < ny) out[y * nx + x] = true;
                }
            }
        }
        return out;
    }

    static final int NONE = 0, SOME = 1, ALL = 2;

    /** Whether the city owns none, some or all of a district (or tile): by its radii from the site and the lanes its corners lie in. */
    int ownership(int dx, int dy) {
        long x0 = (baseDX + dx) * DISTRICT - siteX, y0 = (baseDY + dy) * DISTRICT - siteY;
        return boxOwnership(x0, y0, DISTRICT);
    }

    /** ...of a box of plots, its first plot (x0, y0) from the site, `size` plots a side. */
    private int boxOwnership(long x0, long y0, int size) {
        long x1 = x0 + size - 1, y1 = y0 + size - 1;
        double rMax = Math.max(Math.max(Math.abs(x0), Math.abs(x1)), Math.max(Math.abs(y0), Math.abs(y1)));
        double minX = x0 <= 0 && x1 >= 0 ? 0 : Math.min(Math.abs(x0), Math.abs(x1));
        double minY = y0 <= 0 && y1 >= 0 ? 0 : Math.min(Math.abs(y0), Math.abs(y1));
        double rMin = Math.max(minX, minY);
        double ch = land.centreHalf();
        if (rMax <= ch) return ALL;
        if (rMin > outerReach()) return NONE;
        int sl = CityLand.sideLane(x0, y0);
        if (sl == CityLand.sideLane(x1, y0) && sl == CityLand.sideLane(x0, y1) && sl == CityLand.sideLane(x1, y1)) {
            double f = Math.max(ch, land.frontier(sl / CityLand.LANES, sl % CityLand.LANES));
            if (rMax <= f) return ALL;
            if (rMin > f) return NONE;
        }
        return SOME;
    }

    /** The farthest the land reaches from the site, L-infinity: the centre's half-side or the farthest frontier. */
    double outerReach() {
        double r = land.centreHalf();
        for (int s = 0; s < CityLand.SIDES; s++) for (int l = 0; l < CityLand.LANES; l++) r = Math.max(r, land.frontier(s, l));
        return r;
    }

    /** Counts a district's owned dry plots from SAMPLES x SAMPLES samples - each tile's, and the whole's. */
    private void measure(District d, int own) {
        d.tileDry = new byte[TILES];
        d.owned = 0;
        if (own == NONE) return;
        long x0 = (baseDX + d.dx) * DISTRICT, y0 = (baseDY + d.dy) * DISTRICT;
        byte[] t = new byte[SAMPLES * SAMPLES];
        World.of(seed).regionTerrain(x0, y0, SAMPLE_STRIDE, SAMPLES, t);
        int total = 0;
        for (int j = 0; j < SAMPLES; j++) {
            for (int i = 0; i < SAMPLES; i++) {
                byte c = t[j * SAMPLES + i];
                if (c == World.SALT || c == World.FRESH) continue;
                if (own != ALL && !land.ownsPlot(x0 + (long) i * SAMPLE_STRIDE + SAMPLE_STRIDE / 2,
                        y0 + (long) j * SAMPLE_STRIDE + SAMPLE_STRIDE / 2)) continue;
                d.tileDry[(j / TILE_SAMPLES) * TILES_A_SIDE + i / TILE_SAMPLES]++;
                total++;
            }
        }
        d.owned = total * SAMPLE_PLOTS;
    }

    /** A district not on the map yet, measured, and kept only when it holds owned dry ground: a district of water joins the map only when a site in it needs one (tallySites()). */
    private District measureNew(int dx, int dy, int own) {
        District d = newDistrict(dx, dy);
        measure(d, own);
        if (d.owned > 0) return d;
        districts.remove(districts.size() - 1);
        byKey.remove(d.key);
        return null;
    }

    /** A district's tiles' owned dry samples, measured if they were not (after a sidecar is read). */
    byte[] tileDry(District d) {
        if (d.tileDry == null) {
            int owned = d.owned;
            measure(d, ownership(d.dx, d.dy));
            d.owned = owned;
        }
        return d.tileDry;
    }

    /* =====================================================================
       THE LAND CHANGED: A PURCHASE, OR THE LAND DRAWN AGAIN
       ===================================================================== */

    /**
     * Catches the map up with its land: every district a new purchase
     * touches recounted (new ones added); true when the land was drawn
     * again (a restatement, a conversion), which the caller answers with a
     * canonical map.
     */
    boolean syncLand() {
        if (!measured) return false;
        List<CityLand.Purchase> bought = land.purchases();
        if (land.centreHalf() != centreHalfSeen || bought.size() < purchasesSeen) return true;
        if (bought.size() == purchasesSeen) return false;
        // Every new purchase's band, as a box of plots from the site: the districts under it are recounted.
        java.util.Set<Long> touched = new java.util.LinkedHashSet<>();
        int firstNew = purchasesSeen + 1;
        double nbx0 = Double.MAX_VALUE, nby0 = Double.MAX_VALUE, nbx1 = -Double.MAX_VALUE, nby1 = -Double.MAX_VALUE;
        for (int k = purchasesSeen; k < bought.size(); k++) {
            LandParcel o = bought.get(k).offer();
            double t0 = -1 + o.getLane() * 2.0 / CityLand.LANES, t1 = t0 + 2.0 / CityLand.LANES;
            double bx0 = Double.MAX_VALUE, by0 = Double.MAX_VALUE, bx1 = -Double.MAX_VALUE, by1 = -Double.MAX_VALUE;
            for (double[] c : new double[][] { CityLand.point(o.getSide(), o.getR1(), t0), CityLand.point(o.getSide(), o.getR1(), t1),
                    CityLand.point(o.getSide(), o.getR2(), t0), CityLand.point(o.getSide(), o.getR2(), t1) }) {
                bx0 = Math.min(bx0, c[0]); bx1 = Math.max(bx1, c[0]);
                by0 = Math.min(by0, c[1]); by1 = Math.max(by1, c[1]);
            }
            long ax0 = Math.floorDiv(siteX + (long) Math.floor(bx0) - 1, DISTRICT) - baseDX;
            long ax1 = Math.floorDiv(siteX + (long) Math.ceil(bx1) + 1, DISTRICT) - baseDX;
            long ay0 = Math.floorDiv(siteY + (long) Math.floor(by0) - 1, DISTRICT) - baseDY;
            long ay1 = Math.floorDiv(siteY + (long) Math.ceil(by1) + 1, DISTRICT) - baseDY;
            for (long dy = ay0; dy <= ay1; dy++) for (long dx = ax0; dx <= ax1; dx++) touched.add(key((int) dx, (int) dy));
            nbx0 = Math.min(nbx0, bx0); nbx1 = Math.max(nbx1, bx1);
            nby0 = Math.min(nby0, by0); nby1 = Math.max(nby1, by1);
        }
        purchasesSeen = bought.size();
        landVersion++;
        changes++;
        for (long k : touched) {
            int dx = (int) (k >> 32), dy = (int) k;
            int own = ownership(dx, dy);
            District d = byKey.get(k);
            if (d == null) {
                if (own != NONE) measureNew(dx, dy, own);
                continue;
            }
            measure(d, own);
            d.version++;
        }
        sortDistricts();
        if (siteIndex != null) tallySites(siteIndex, firstNew, nbx0 - 1, nby0 - 1, nbx1 + 1, nby1 + 1);
        if (pyramid != null) pyramid = new Pyramid(this);
        return false;
    }

    /* =====================================================================
       PLACING: THE MONTH'S CHANGE, AND THE CANONICAL ALLOCATION
       ===================================================================== */

    /**
     * THE MONTH (spec-land 2.5, star 12): the land caught up, then each
     * type's change placed - new buildings into the first district with room
     * (nearest first; farms, utilities, mines and wells, the railway and the
     * car plants farthest first), removals in reverse - and the mines and
     * wells put on their sites. When the land was drawn again it answers
     * false and places nothing: the caller draws the map again canonically.
     * (How many district-types it touched is lastTouched.)
     */
    public boolean reconcile(long[] model) {
        if (syncLand()) return false;
        int touched = 0;
        for (int t = 0; t < types.length; t++) {
            if (types[t] == null || types[t].site() != null) continue;
            long want = t < model.length ? model[t] : 0;
            long delta = want - have[t];
            if (delta > 0) touched += place(t, delta);
            else if (delta < 0) touched += remove(t, -delta);
        }
        placeSited(model);
        advanceCursors();
        lastTouched = touched;
        // What is worked out moved: the sites drawn are drawn again (their states), the deals stand.
        int[][] states = new int[Resource.values().length][];
        for (Resource r : Resource.values()) if (r.inFields()) states[r.ordinal()] = holdingStates(r);
        if (!Arrays.deepEquals(states, lastStates)) {
            siteLists.clear();
            siteListVersion.clear();
            lastStates = states;
            changes++;
        }
        return true;
    }

    /** How many changes the map has taken since it was drawn - a district's count, a purchase measured, a site's state: what the view stamps its tiles again on (MapTiles). Only grows. */
    private long changes;

    /** How many changes the map has taken since it was drawn: when it moves, a view stamps the tiles it shows again (batch J4). */
    public long changes() { return changes; }

    /**
     * A map drawn away from the screen's thread, on a copy of the land
     * (Game.MapDraft, batch J4), bound to the city's own land and what
     * remains of its resources before it is kept: the copy was the land as
     * it stood, field for field, so every district, site and count drawn on
     * it stands; a purchase made since is the next reconcile()'s to measure.
     */
    void rebind(CityLand live, Function<Resource, double[]> liveRemaining) {
        this.land = live;
        this.remaining = liveRemaining;
        changes++;
    }

    /** Each resource's holdings' states at the last month: when they move, the sites are drawn again. */
    private int[][] lastStates;

    /** How many district-types the last month's change touched. */
    int lastTouched;

    /** Places n more of type t: into the first districts with room in its direction, the rest into the outermost. */
    private int place(int t, long n) {
        boolean out = types[t].outer();
        long each = 2 * types[t].sqFt();
        int touched = 0;
        int i = out ? outerCursor : innerCursor;
        while (n > 0 && i >= 0 && i < districts.size()) {
            District d = districts.get(i);
            long room = each > 0 ? d.freeHalf() / each : n;
            long k = Math.min(n, room);
            if (k > 0) {
                add(d, i, t, k);
                n -= k;
                touched++;
            }
            if (n > 0) i += out ? -1 : 1;
        }
        if (n > 0) {
            int last = districts.size() - 1;
            add(districts.get(last), last, t, n);
            touched++;
        }
        return touched;
    }

    /** Takes n of type t away: an inner type from the outermost district holding it in, an outer type from the innermost out. */
    private int remove(int t, long n) {
        boolean out = types[t].outer();
        int touched = 0;
        if (hi[t] < 0) return 0;
        int i = out ? lo[t] : hi[t];
        while (n > 0 && i >= 0 && i < districts.size()) {
            District d = districts.get(i);
            int k = (int) Math.min(n, d.counts[t]);
            if (k > 0) {
                add(d, i, t, -k);
                n -= k;
                touched++;
            }
            if (n > 0) i += out ? 1 : -1;
        }
        // The range shrinks to the districts still holding it.
        while (lo[t] <= hi[t] && lo[t] < districts.size() && districts.get(lo[t]).counts[t] == 0) lo[t]++;
        while (hi[t] >= lo[t] && hi[t] >= 0 && districts.get(hi[t]).counts[t] == 0) hi[t]--;
        if (lo[t] > hi[t]) { lo[t] = Integer.MAX_VALUE; hi[t] = -1; }
        return touched;
    }

    /** Adds k (negative to take away) of type t to the district at index i, keeping its plots used, the running total, the type's range, the cursors and the pyramid. */
    private void add(District d, int i, int t, long k) {
        d.counts[t] += (int) k;
        have[t] += k;
        d.usedHalf += k * 2 * types[t].sqFt();
        d.version++;
        changes++;
        if (k > 0) {
            if (i < lo[t]) lo[t] = i;
            if (i > hi[t]) hi[t] = i;
        } else {
            if (i < innerCursor) innerCursor = i;
            if (i > outerCursor) outerCursor = i;
        }
        if (pyramid != null) pyramid.add(d, t, k);
    }

    /** The ground a district's buildings use, in half square feet: each type's count x its land, twice. */
    long usedOf(District d) {
        long u = 0;
        for (int t = 0; t < types.length; t++) if (d.counts[t] != 0 && types[t] != null) u += d.counts[t] * 2 * types[t].sqFt();
        return u;
    }

    /**
     * THE CANONICAL ALLOCATION (spec-land 2.5): the city's footprint F shared
     * inner first - each district its share of F, min(its room, what is left)
     * / F - and each type in that proportion in every district, rounded down,
     * its remainder to the districts with the largest remainders (the nearer
     * on a tie). Exact. Mines and wells then go on their sites.
     */
    private void allocate(long[] counts) {
        int n = districts.size();
        double total = 0;
        for (int t = 0; t < types.length; t++) {
            if (types[t] == null || types[t].site() != null || t >= counts.length) continue;
            total += counts[t] * (double) types[t].sqFt() / BuildingVisual.SQ_FT_PER_PLOT;
        }
        double[] share = new double[n];
        double left = total;
        for (int i = 0; i < n && left > 0; i++) {
            double take = Math.min(Math.max(0, districts.get(i).owned), left);
            share[i] = total > 0 ? take / total : 0;
            left -= take;
        }
        if (n > 0 && total > 0 && left > 0) share[n - 1] += left / total;
        if (n > 0 && total <= 0) share[0] = 1;
        long[] keys = new long[n];
        for (int t = 0; t < types.length; t++) {
            if (types[t] == null || types[t].site() != null || t >= counts.length || counts[t] <= 0) continue;
            long c = counts[t], given = 0;
            int m = 0;
            for (int i = 0; i < n; i++) {
                if (share[i] <= 0) continue;
                double q = c * share[i];
                long whole = (long) Math.floor(q);
                double rem = q - whole;
                if (whole > 0) districts.get(i).counts[t] += (int) whole;
                given += whole;
                // Largest remainder first, then the nearer district: the remainder in the high bits.
                keys[m++] = ((long) ((1 - rem) * (1L << 30)) << 32) | i;
            }
            long extra = c - given;
            if (extra > 0) {
                Arrays.sort(keys, 0, m);
                for (int k = 0; k < extra && k < m; k++) districts.get((int) (keys[k] & 0xffffffffL)).counts[t]++;
                if (extra > m) districts.get(n - 1).counts[t] += (int) (extra - m);
            }
            have[t] = c;
        }
        for (District d : districts) {
            d.usedHalf = usedOf(d);
            d.version++;
        }
        rangeTypes();
        innerCursor = 0;
        outerCursor = districts.size() - 1;
        advanceCursors();
        placeSited(counts);
        pyramid = new Pyramid(this);
    }

    /* =====================================================================
       MINES AND WELLS ON THEIR SITES (spec-land 2.4, 2.5)

       Every owned site of a SITED resource, by holding - the centre, then
       each purchase - and by district. The mines and wells of a type go to
       the first sites in acquisition order whose holding is not worked out,
       then the worked-out ones in the same order; within a holding, the
       districts nearest first. More of them than sites are drawn in the
       founding site's district with no site under them.
       ===================================================================== */

    /** Every owned site of the SITED resources: per resource and holding, the districts holding them, nearest first, and how many in each. */
    static final class SiteIndex {
        /** [resource][holding]: the districts, and the sites in each. */
        District[][][] where;
        int[][][] how;
        /** The tallies they are read from: [resource] then holding, district to sites. */
        final List<List<Map<District, int[]>>> tally = new ArrayList<>();
    }

    /** The holding a point (dx, dy) from the site lies in: 0 the centre, k the k-th purchase, -1 none. */
    int holdingOf(double dx, double dy) {
        double r = CityLand.radius(dx, dy);
        if (r <= land.centreHalf()) return 0;
        int sl = CityLand.sideLane(dx, dy);
        double frontier = land.frontier(sl / CityLand.LANES, sl % CityLand.LANES);
        if (r > frontier) return -1;
        List<CityLand.Purchase> bought = land.purchases();
        for (int k : laneIndex()[sl]) {
            LandParcel o = bought.get(k).offer();
            if (r > o.getR1() && r <= o.getR2()) return k + 1;
        }
        return -1;
    }

    private int[][] laneIndex;
    private int laneIndexFor = -1;

    /** Each lane's purchases, in the order bought. */
    private int[][] laneIndex() {
        List<CityLand.Purchase> bought = land.purchases();
        if (laneIndex == null || laneIndexFor != bought.size()) {
            List<List<Integer>> lanes = new ArrayList<>();
            for (int k = 0; k < CityLand.SIDES * CityLand.LANES; k++) lanes.add(new ArrayList<>());
            for (int k = 0; k < bought.size(); k++) {
                LandParcel o = bought.get(k).offer();
                lanes.get(o.getSide() * CityLand.LANES + o.getLane()).add(k);
            }
            laneIndex = new int[lanes.size()][];
            for (int k = 0; k < lanes.size(); k++) laneIndex[k] = lanes.get(k).stream().mapToInt(Integer::intValue).toArray();
            laneIndexFor = bought.size();
        }
        return laneIndex;
    }

    /** The fields of a resource that reach into a box of plots: the world's, and a converted centre's legacy iron field. */
    private List<Deposit> fieldsNear(Resource r, double bx0, double by0, double bx1, double by1) {
        World world = World.of(seed);
        List<Deposit> out = new ArrayList<>();
        double reach = Deposit.mostReach(r);
        for (int cell : CityLand.cellsUnder(bx0 - reach, by0 - reach, bx1 + reach, by1 + reach)) {
            for (Deposit d : CityLand.fields(world, cell, r)) {
                double o = d.reach();
                if (d.x() + o < bx0 || d.x() - o > bx1 || d.y() + o < by0 || d.y() - o > by1) continue;
                out.add(d);
            }
        }
        if (r == Resource.IRON && land.legacySites() > 0 && land.legacyX() >= 0) {
            Deposit legacy = legacyField();
            double o = legacy.reach();
            if (!(legacy.x() + o < bx0 || legacy.x() - o > bx1 || legacy.y() + o < by0 || legacy.y() - o > by1)) out.add(legacy);
        }
        return out;
    }

    /** A converted centre's legacy iron field, as a field of its sites at its plot (cell -1). */
    Deposit legacyField() {
        int n = Math.min(World.MAX_SITES, land.legacySites());
        return new Deposit(Resource.IRON, -1, 0, land.legacyX(), land.legacyY(), n, land.centreAmount(Resource.IRON));
    }

    /**
     * The site index: every owned site of the SITED resources by holding and
     * district, built with the map and extended by each purchase (a new
     * holding's sites are its band's alone). A district holding sites but no
     * sample of dry ground is added, wet.
     */
    SiteIndex siteIndex() {
        if (siteIndex == null) {
            siteIndex = new SiteIndex();
            double reach = outerReach();
            for (District d : districts) Arrays.fill(d.sites, 0);
            tallySites(siteIndex, 0, -reach, -reach, reach, reach);
        }
        return siteIndex;
    }

    /**
     * Adds to the index the sites of holdings `from` on that lie in a box of
     * plots from the site, and lays its lists out again: a new index object,
     * so the walks lay themselves out again too.
     */
    private void tallySites(SiteIndex ix, int from, double bx0, double by0, double bx1, double by1) {
        int holdings = 1 + land.purchases().size();
        boolean added = false;
        for (int k = 0; k < SITED.length; k++) {
            if (ix.tally.size() <= k) ix.tally.add(new ArrayList<>());
            List<Map<District, int[]>> m = ix.tally.get(k);
            while (m.size() < holdings) m.add(new HashMap<>());
            Resource r = SITED[k];
            if (!r.inFields()) continue;
            for (Deposit f : fieldsNear(r, siteX + bx0, siteY + by0, siteX + bx1, siteY + by1)) {
                double fx = f.x() - siteX, fy = f.y() - siteY;
                boolean legacy = f.cell() < 0;
                if (legacy && from > 0) continue;
                for (int s = 0; s < f.sites(); s++) {
                    double[] at = f.siteAt(s);
                    double sx = fx + at[0], sy = fy + at[1];
                    int h = legacy ? 0 : holdingOf(sx, sy);
                    if (h < from) continue;
                    int ddx = (int) (Math.floorDiv(siteX + (long) Math.floor(sx), DISTRICT) - baseDX);
                    int ddy = (int) (Math.floorDiv(siteY + (long) Math.floor(sy), DISTRICT) - baseDY);
                    District d = byKey.get(key(ddx, ddy));
                    if (d == null) {
                        d = newDistrict(ddx, ddy);
                        d.tileDry = new byte[TILES];
                        added = true;
                    }
                    d.sites[k]++;
                    m.get(h).computeIfAbsent(d, x -> new int[1])[0]++;
                }
            }
        }
        if (added) {
            sortDistricts();
            if (pyramid != null) pyramid = new Pyramid(this);
        }
        SiteIndex out = new SiteIndex();
        out.tally.addAll(ix.tally);
        out.where = new District[SITED.length][holdings][];
        out.how = new int[SITED.length][holdings][];
        for (int k = 0; k < SITED.length; k++) {
            for (int h = 0; h < holdings; h++) {
                Map<District, int[]> m = out.tally.get(k).get(h);
                List<District> where = new ArrayList<>(m.keySet());
                where.sort(DISTRICT_ORDER);
                out.where[k][h] = where.toArray(new District[0]);
                out.how[k][h] = new int[where.size()];
                for (int i = 0; i < where.size(); i++) out.how[k][h][i] = m.get(where.get(i))[0];
            }
        }
        siteIndex = out;
    }

    /** The owned sites of a SITED resource on the map. */
    public long ownedSites(Resource r) {
        siteIndex();
        int k = siteSlot(r);
        long n = 0;
        if (k >= 0) for (District d : districts) n += d.sites[k];
        return n;
    }

    /** Nearest the founding site first, then north to south, west to east. */
    static final Comparator<District> DISTRICT_ORDER =
            Comparator.comparingDouble((District d) -> d.order).thenComparingInt(d -> d.dy).thenComparingInt(d -> d.dx);

    /** A holding's state for a resource from what remains in it: UNWORKED, WORKING or WORKED_OUT (one that listed none, unworked). */
    static int holdingState(double listed, double left) {
        if (listed <= 0) return TilePainter.UNWORKED;
        if (left <= 0) return TilePainter.WORKED_OUT;
        return left < listed ? TilePainter.WORKING : TilePainter.UNWORKED;
    }

    /** Each holding's state for a resource, the centre first. */
    int[] holdingStates(Resource r) {
        double[] listed = land.amountsInOrder(r);
        double[] left = remaining != null ? remaining.apply(r) : listed;
        int[] out = new int[listed.length];
        for (int h = 0; h < listed.length; h++) out[h] = holdingState(listed[h], h < left.length ? left[h] : listed[h]);
        return out;
    }

    /** One SITED resource's sites in the order mines and wells take them, and how far its type's count has filled them. */
    private static final class Walk {
        SiteIndex ix;
        int[] states;
        int type;
        District[] at = new District[0];
        int[] holding = new int[0], sites = new int[0];
        int length, pos, partial;
        long placed, overflow;
    }

    private final Walk[] walks = new Walk[SITED.length];

    /** The type standing on a SITED resource's sites: the first with it as its site, or -1. */
    private int typeOn(Resource r) {
        for (int t = 0; t < types.length; t++) if (types[t] != null && types[t].site() == r) return t;
        return -1;
    }

    /**
     * Puts each SITED resource's mines or wells on its sites (spec-land 2.4,
     * 2.5): the first sites in acquisition order whose holding is not worked
     * out, then the worked-out ones, a holding's districts nearest first;
     * more than there are sites stand in the founding site's district on
     * none. Incremental: a month's change fills or empties the walk from
     * where it stood; the land or a holding's state changing lays it out
     * again. A second type on the same resource stands on no site.
     */
    private void placeSited(long[] model) {
        for (int k = 0; k < SITED.length; k++) {
            Resource r = SITED[k];
            int t = typeOn(r);
            if (t < 0) continue;
            long n = t < model.length ? Math.max(0, model[t]) : 0;
            Walk w = walks[k];
            if (n == 0 && (w == null ? have[t] == 0 : w.placed + w.overflow == 0)) continue;
            SiteIndex ix = siteIndex();
            int[] states = holdingStates(r);
            if (w == null || w.ix != ix || !Arrays.equals(w.states, states) || w.type != t) {
                clearType(t, k);
                w = layWalk(ix, states, k, t);
                walks[k] = w;
            }
            fill(w, k, n);
        }
        // Any further type on a SITED resource: in the founding site's district, on no site, as any building.
        for (int t = 0; t < types.length; t++) {
            if (types[t] == null || types[t].site() == null || typeOn(types[t].site()) == t) continue;
            long delta = (t < model.length ? model[t] : 0) - have[t];
            if (delta != 0) add(home(), indexOf(home()), t, delta);
        }
        sitedPlaced = true;
    }

    private District home() {
        District d = byKey.get(key(0, 0));
        if (d == null) {
            d = newDistrict(0, 0);
            d.tileDry = new byte[TILES];
            sortDistricts();
            if (pyramid != null) pyramid = new Pyramid(this);
        }
        return d;
    }

    private static int indexOf(District d) { return d.index; }

    /** Where a resource sits among SITED, or -1. */
    static int siteSlot(Resource r) {
        for (int k = 0; k < SITED.length; k++) if (SITED[k] == r) return k;
        return -1;
    }

    /** Takes every one of type t off the map, its sites' marks with it. */
    private void clearType(int t, int k) {
        if (hi[t] < 0) return;
        for (int i = Math.max(0, lo[t]); i <= hi[t] && i < districts.size(); i++) {
            District d = districts.get(i);
            if (d.counts[t] != 0) add(d, i, t, -d.counts[t]);
            if (d.sited != null) d.sited[t] = 0;
            d.holdingMines[k] = null;
        }
        lo[t] = Integer.MAX_VALUE;
        hi[t] = -1;
    }

    /** The walk's order: holdings not worked out in acquisition order, then the worked-out; within each, its districts nearest first. */
    private Walk layWalk(SiteIndex ix, int[] states, int k, int t) {
        Walk w = new Walk();
        w.ix = ix;
        w.states = states;
        w.type = t;
        int holdings = ix.where[k].length, size = 0;
        for (int h = 0; h < holdings; h++) size += ix.where[k][h].length;
        w.at = new District[size];
        w.holding = new int[size];
        w.sites = new int[size];
        for (int pass = 0; pass < 2; pass++) {
            for (int h = 0; h < holdings; h++) {
                boolean out = h < states.length && states[h] == TilePainter.WORKED_OUT;
                if (out != (pass == 1)) continue;
                for (int i = 0; i < ix.where[k][h].length; i++) {
                    w.at[w.length] = ix.where[k][h][i];
                    w.holding[w.length] = h;
                    w.sites[w.length] = ix.how[k][h][i];
                    w.length++;
                }
            }
        }
        return w;
    }

    /** Fills or empties a walk to n: on sites from where it stood, past the last site in the founding site's district. */
    private void fill(Walk w, int k, long n) {
        int t = w.type;
        while (w.placed + w.overflow < n) {
            if (w.pos >= w.length) {
                long rest = n - w.placed - w.overflow;
                District h = home();
                add(h, indexOf(h), t, rest);
                w.overflow += rest;
                break;
            }
            District d = w.at[w.pos];
            int take = (int) Math.min(w.sites[w.pos] - w.partial, n - w.placed - w.overflow);
            mark(d, k, t, w.holding[w.pos], take);
            w.placed += take;
            w.partial += take;
            if (w.partial >= w.sites[w.pos]) { w.pos++; w.partial = 0; }
        }
        while (w.placed + w.overflow > n) {
            if (w.overflow > 0) {
                long off = Math.min(w.overflow, w.placed + w.overflow - n);
                District h = home();
                add(h, indexOf(h), t, -off);
                w.overflow -= off;
                continue;
            }
            if (w.partial == 0) { w.pos--; w.partial = w.sites[w.pos]; }
            District d = w.at[w.pos];
            int take = (int) Math.min(w.partial, w.placed - n);
            mark(d, k, t, w.holding[w.pos], -take);
            w.placed -= take;
            w.partial -= take;
        }
    }

    /** m more (or fewer) of type t on a district's sites of one holding. */
    private void mark(District d, int k, int t, int holding, int m) {
        if (m == 0) return;
        if (d.sited == null) d.sited = new int[types.length];
        d.sited[t] += m;
        int[] pairs = d.holdingMines[k];
        int at = -1;
        if (pairs != null) for (int a = 0; a < pairs.length; a += 2) if (pairs[a] == holding) at = a;
        if (at < 0) {
            pairs = pairs == null ? new int[2] : Arrays.copyOf(pairs, pairs.length + 2);
            at = pairs.length - 2;
            pairs[at] = holding;
        }
        pairs[at + 1] += m;
        d.holdingMines[k] = pairs;
        add(d, indexOf(d), t, m);
    }

    /* =====================================================================
       THE DEAL: EACH DISTRICT OVER THE TILES AROUND IT (J3b)

       J3 split a district into its own 64 tiles, flat: a full district
       beside an empty one met it in a straight line 7.68 km long, and a city
       of districts all 92% used came out the same density everywhere, with
       no middle. Now a district's buildings spread over the 16 x 16 tiles
       within half a district of its middle, by a tent that falls from 1 at
       its middle to nothing half a district out, times each tile's owned dry
       ground - so the tents of neighbouring districts add up to one on every
       tile, and the density between them is a smooth blend of theirs. The
       people-bearing types - homes, shops, offices and the services that
       follow them - lean toward the founding site too, by 1 + CORE_BOOST
       e^-(r / CORE_RADIUS)^2, which gives the city its middle out of what its
       districts hold, never more; the plants lean toward the two highways and
       out of that middle, as the mockup's industry did. Building j of type t
       still goes where its own hash says, so one more building changes one
       tile by one.
       ===================================================================== */

    /** Tiles on a side of the square a district's deal spreads over: 16 - its own 8 and half a district either way, as far as its tent reaches. */
    static final int SPREAD = 2 * TILES_A_SIDE;

    /** ...and that square's first tile, from the district's own first: -4. */
    static final int SPREAD_FROM = -TILES_A_SIDE / 2;

    /** The tiles in it: 256. */
    static final int SPREAD_TILES = SPREAD * SPREAD;

    /** How much more of the people-bearing types a tile at the founding site takes, before its district's share is shared out: 6 times more (star) - in Jerus's city, its districts all nearly full, the people within 64 plots of the site come out at about three times his average (13.9 a plot against 4.7), its middle built half full and its edges a fifth... */
    public static final double CORE_BOOST = 6;

    /** ...falling off over this many plots: 80 (2.4 km, star) - a middle a town's size; a wider one only spreads its district's people more evenly (at 128 plots, his middle came out 2.1 times his average). */
    public static final double CORE_RADIUS = 80;

    /** How much more of the plants a tile on one of the two world highways takes: twice more (star) - the mockup's industry by the highways and out of the middle (its weight 3 + 9 near a highway - 9 in the middle), so the plants gather into strips along them rather than sprinkle every street; they lean away from the core by its own lean... */
    public static final double HIGHWAY_BOOST = 2;

    /** ...falling off over this many plots from the highway: 48 (1.4 km, star). */
    public static final double HIGHWAY_RADIUS = 48;

    /** How many districts' tile counts are kept: 64 - about 1.2 MB, a screen's and its neighbours' many times over. */
    static final int TILE_COUNTS_KEPT = 64;

    /** How many districts' spreads (their two alias tables) are kept: 128. */
    static final int SPREADS_KEPT = 128;

    /** Bumped whenever owned ground is measured again: what the spreads are kept against. */
    private long landVersion;

    private final Map<District, long[]> countsStamp = new LinkedHashMap<>(TILE_COUNTS_KEPT * 2, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<District, long[]> e) { return size() > TILE_COUNTS_KEPT; }
    };
    private final Map<District, int[][]> tileCountsKept = new HashMap<>();

    /** A district's three alias tables over its spread - plain, leaning to the core, leaning to the highways and out of the core - and the land version they were made on. */
    private static final class Spread {
        long landVersion;
        double[] prob, probCore, probRoad;
        int[] alias, aliasCore, aliasRoad;
    }

    private final Map<District, Spread> spreads = new LinkedHashMap<>(SPREADS_KEPT * 2, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<District, Spread> e) { return size() > SPREADS_KEPT; }
    };

    /** Whether a type leans toward the founding site in the deal: homes, shops, offices, schools, health and safety - what follows people. */
    static boolean leansToCore(BuildingVisual.Type t) {
        if (t == null || t.road() != BuildingVisual.NOT_A_ROAD || t.outer()) return false;
        int c = t.cls();
        return c == BuildingVisual.HOME || c == BuildingVisual.SHOP || c == BuildingVisual.OFFICE || c == BuildingVisual.SCHOOL
                || c == BuildingVisual.HEALTH || c == BuildingVisual.SAFETY;
    }

    /** Whether a type leans toward the two world highways, and out of the core, in the deal: the plants (the mockup's industry by the highways and away from the middle). */
    static boolean leansToHighway(BuildingVisual.Type t) {
        return t != null && t.road() == BuildingVisual.NOT_A_ROAD && t.cls() == BuildingVisual.INDUSTRY;
    }

    /** The highways' lean at a tile: 1 + HIGHWAY_BOOST e^-(d / HIGHWAY_RADIUS)^2, d from the tile's middle to the nearer highway in plots - an arm only as far as it runs before the sea. */
    double highwayLean(long tx, long ty) {
        double cx = tx * World.TILE + World.TILE / 2.0, cy = ty * World.TILE + World.TILE / 2.0;
        double best = Double.MAX_VALUE;
        long alongY = Math.round(Math.abs(cy - siteY)), alongX = Math.round(Math.abs(cx - siteX));
        if (armReach(cy < siteY ? 0 : 2, alongY) >= alongY) best = Math.abs(cx - siteX);
        if (armReach(cx < siteX ? 3 : 1, alongX) >= alongX) best = Math.min(best, Math.abs(cy - siteY));
        if (best == Double.MAX_VALUE) return 1;
        double q = best * best / (HIGHWAY_RADIUS * HIGHWAY_RADIUS);
        return 1 + HIGHWAY_BOOST * Math.exp(-q);
    }

    /** The core's lean at a tile: 1 + CORE_BOOST e^-(r / CORE_RADIUS)^2, r from the founding site to the tile's middle in plots. */
    double coreLean(long tx, long ty) {
        double dx = tx * World.TILE + World.TILE / 2.0 - siteX, dy = ty * World.TILE + World.TILE / 2.0 - siteY;
        double q = (dx * dx + dy * dy) / (CORE_RADIUS * CORE_RADIUS);
        return 1 + CORE_BOOST * Math.exp(-q);
    }

    /** A district's spread: the weight of each tile within half a district of its middle - its owned dry samples, times the tent, times the core's lean for the second table - as two alias tables. */
    private Spread spread(District s) {
        Spread got = spreads.get(s);
        if (got != null && got.landVersion == landVersion) return got;
        double[] w = new double[SPREAD_TILES], wc = new double[SPREAD_TILES], wr = new double[SPREAD_TILES];
        long t0x = (baseDX + s.dx) * TILES_A_SIDE + SPREAD_FROM, t0y = (baseDY + s.dy) * TILES_A_SIDE + SPREAD_FROM;
        double sum = 0;
        for (int j = 0; j < SPREAD; j++) {
            double tentY = 1 - Math.abs(j - (SPREAD - 1) / 2.0) * World.TILE / DISTRICT;
            for (int i = 0; i < SPREAD; i++) {
                long tx = t0x + i, ty = t0y + j;
                District d = byKey.get(key((int) (Math.floorDiv(tx, TILES_A_SIDE) - baseDX), (int) (Math.floorDiv(ty, TILES_A_SIDE) - baseDY)));
                if (d == null) continue;
                int dry = tileDry(d)[(int) (Math.floorMod(ty, TILES_A_SIDE) * TILES_A_SIDE + Math.floorMod(tx, TILES_A_SIDE))];
                if (dry <= 0) continue;
                double tentX = 1 - Math.abs(i - (SPREAD - 1) / 2.0) * World.TILE / DISTRICT;
                w[j * SPREAD + i] = dry * tentX * tentY;
                wc[j * SPREAD + i] = w[j * SPREAD + i] * coreLean(tx, ty);
                wr[j * SPREAD + i] = w[j * SPREAD + i] * highwayLean(tx, ty) / coreLean(tx, ty);
                sum += w[j * SPREAD + i];
            }
        }
        if (sum <= 0) {
            // No owned dry ground within reach (a wet district holding sites): its own 64 tiles, alike.
            for (int j = -SPREAD_FROM; j < -SPREAD_FROM + TILES_A_SIDE; j++) {
                for (int i = -SPREAD_FROM; i < -SPREAD_FROM + TILES_A_SIDE; i++) w[j * SPREAD + i] = wc[j * SPREAD + i] = wr[j * SPREAD + i] = 1;
            }
        }
        Spread out = new Spread();
        out.landVersion = landVersion;
        out.prob = new double[SPREAD_TILES];
        out.alias = new int[SPREAD_TILES];
        aliasTable(w, out.prob, out.alias);
        out.probCore = new double[SPREAD_TILES];
        out.aliasCore = new int[SPREAD_TILES];
        aliasTable(wc, out.probCore, out.aliasCore);
        out.probRoad = new double[SPREAD_TILES];
        out.aliasRoad = new int[SPREAD_TILES];
        aliasTable(wr, out.probRoad, out.aliasRoad);
        spreads.put(s, out);
        return out;
    }

    /** Vose's alias table for weights w, into prob and alias. */
    static void aliasTable(double[] w, double[] prob, int[] alias) {
        int n = w.length;
        double sum = 0;
        for (double v : w) sum += v;
        double[] scaled = new double[n];
        int[] small = new int[n], large = new int[n];
        int ns = 0, nl = 0;
        for (int i = 0; i < n; i++) {
            scaled[i] = sum > 0 ? w[i] * n / sum : 1;
            if (scaled[i] < 1) small[ns++] = i; else large[nl++] = i;
        }
        while (ns > 0 && nl > 0) {
            int s = small[--ns], l = large[--nl];
            prob[s] = scaled[s];
            alias[s] = l;
            scaled[l] = scaled[l] + scaled[s] - 1;
            if (scaled[l] < 1) small[ns++] = l; else large[nl++] = l;
        }
        while (nl > 0) prob[large[--nl]] = 1;
        while (ns > 0) prob[small[--ns]] = 1;
    }

    /**
     * A district's tiles' counts, [tile][type] (tile = row x 8 + column):
     * what it and the eight districts around it deal onto them - building j
     * of type t of each goes to the tile its own hash picks through its
     * spread; a type on sites deals only its part on no site. One more
     * building changes one tile of the map by one. Kept for the last
     * TILE_COUNTS_KEPT districts asked.
     */
    public int[][] deal(District d) {
        long stamp = countsStampOf(d);
        long[] v = countsStamp.get(d);
        int[][] got = tileCountsKept.get(d);
        if (v != null && got != null && v[0] == stamp) return got;
        int[][] out = new int[TILES][types.length];
        for (int b = -1; b <= 1; b++) {
            for (int a = -1; a <= 1; a++) {
                District s = byKey.get(key(d.dx + a, d.dy + b));
                if (s != null) dealOnto(s, d, out);
            }
        }
        countsStamp.put(d, new long[] { stamp });
        tileCountsKept.put(d, out);
        tileCountsKept.keySet().retainAll(countsStamp.keySet());
        return out;
    }

    /** What a district's tile counts hang on: the land's version and its own and its eight neighbours' versions. */
    private long countsStampOf(District d) {
        long h = World.mix(landVersion ^ 0x5EEDL);
        for (int b = -1; b <= 1; b++) {
            for (int a = -1; a <= 1; a++) {
                District s = byKey.get(key(d.dx + a, d.dy + b));
                h = World.mix(h ^ (s == null ? 0 : s.version + 1) ^ ((long) (b * 3 + a + 4) << 56));
            }
        }
        return h;
    }

    /** District s's buildings that its spread puts on district d's tiles, added into out. */
    private void dealOnto(District s, District d, int[][] out) {
        Spread sp = spread(s);
        // d's tiles in s's spread: columns and rows from (d - s) x 8 - SPREAD_FROM.
        int ox = (d.dx - s.dx) * TILES_A_SIDE - SPREAD_FROM, oy = (d.dy - s.dy) * TILES_A_SIDE - SPREAD_FROM;
        long dseed = World.mix(seed ^ ((baseDX + s.dx) << 32) ^ ((baseDY + s.dy) & 0xffffffffL));
        for (int t = 0; t < types.length; t++) {
            int c = s.counts[t];
            if (types[t] != null && types[t].site() != null && s.sited != null) c -= s.sited[t];
            if (c <= 0) continue;
            boolean core = leansToCore(types[t]), road = leansToHighway(types[t]);
            double[] prob = core ? sp.probCore : road ? sp.probRoad : sp.prob;
            int[] alias = core ? sp.aliasCore : road ? sp.aliasRoad : sp.alias;
            long base = World.mix(dseed ^ ((long) t << 40));
            for (int j = 0; j < c; j++) {
                long h = World.mix(base + j);
                int i = (int) ((h >>> 32) % SPREAD_TILES);
                double u = (h & 0xffffffffL) * 0x1.0p-32;
                int k = u < prob[i] ? i : alias[i];
                int x = k % SPREAD - ox, y = k / SPREAD - oy;
                if (x >= 0 && y >= 0 && x < TILES_A_SIDE && y < TILES_A_SIDE) out[y * TILES_A_SIDE + x][t]++;
            }
        }
    }

    /* =====================================================================
       A TILE'S INPUTS FOR THE PAINTER
       ===================================================================== */

    /** The district holding tile (tx, ty), or null. */
    public District districtOfTile(long tx, long ty) {
        return byKey.get(key((int) (Math.floorDiv(tx, TILES_A_SIDE) - baseDX), (int) (Math.floorDiv(ty, TILES_A_SIDE) - baseDY)));
    }

    /** A tile's own counts of the model's types from the deal: a copy into out, zeros where no district is. */
    public void tileCounts(long tx, long ty, int[] out) {
        Arrays.fill(out, 0);
        District d = districtOfTile(tx, ty);
        if (d == null) return;
        int[] c = deal(d)[(int) (Math.floorMod(ty, TILES_A_SIDE) * TILES_A_SIDE + Math.floorMod(tx, TILES_A_SIDE))];
        System.arraycopy(c, 0, out, 0, Math.min(c.length, out.length));
    }

    /** Whether a tile has anything on it - so roads, since any building brings its tile at least a step of road. */
    boolean tileHasRoads(long tx, long ty) {
        District d = districtOfTile(tx, ty);
        if (d == null) return false;
        int[] c = deal(d)[(int) (Math.floorMod(ty, TILES_A_SIDE) * TILES_A_SIDE + Math.floorMod(tx, TILES_A_SIDE))];
        for (int t = 0; t < c.length; t++) if (c[t] > 0 && types[t] != null) return true;
        return false;
    }

    /** Which of a tile's plots the city owns: whole tiles inside or outside in one test, the rest a plot at a time. */
    public void tileOwnership(long tx, long ty, boolean[] out) {
        long x0 = tx * World.TILE - siteX, y0 = ty * World.TILE - siteY;
        int own = boxOwnership(x0, y0, World.TILE);
        if (own != SOME) {
            Arrays.fill(out, 0, TilePainter.PLOTS, own == ALL);
            return;
        }
        for (int i = 0; i < TilePainter.PLOTS; i++) out[i] = land.owns(x0 + i % World.TILE, y0 + i / World.TILE);
    }

    /** The painter's table: the map's types, then the four visual kinds (BuildingVisual.paintTable()). */
    private BuildingVisual.Type[] paintTypes;

    /** The painter's table of types, the map's then the visual kinds': what a tile's counts index. */
    public BuildingVisual.Type[] paintTypes() {
        if (paintTypes == null) paintTypes = BuildingVisual.paintTable(types);
        return paintTypes;
    }

    /** The share of the city's road the model has paved (Paved Road and Elevated Highway, by their plots): the floor under every tile's paved share, so a city that paves its roads sees them paved. */
    public double modelPavedShare() {
        double all = 0, paved = 0;
        for (int t = 0; t < types.length; t++) {
            if (types[t] == null || types[t].road() == BuildingVisual.NOT_A_ROAD || have[t] <= 0) continue;
            double p = have[t] * types[t].plots();
            all += p;
            if (types[t].road() >= BuildingVisual.PAVED) paved += p;
        }
        return all > 0 ? paved / all : 0;
    }

    /**
     * Everything the painter needs for tile (tx, ty), into in: its ground,
     * what the city owns of it, its counts drawn from the deal, its road
     * budget, which neighbours have roads, and the sites on it with their
     * states and the mines standing on them.
     *
     * THE COUNTS DRAWN (J3b, BuildingVisual's visual counts): the people
     * the tile's homes house become its homes, at peoplePerHome() of its
     * density - houses in a thin town, flats in a dense middle; the jobs its
     * shops, offices and plants hold become those, at so many jobs a
     * building; its schools, clinics, utilities, farms and the mines with no
     * site, one for one. THE ROAD BUDGET is the frontage its buildings need,
     * ROAD_PER_PLOT of their plots in whole steps, paved by its density
     * (never less than the model paves) and the rest gravel; the model's own
     * roads only steer that mix. The two world highways use none.
     */
    public void tileInput(long tx, long ty, TilePainter.Input in) {
        World.of(seed).tileTerrain(tx, ty, in.terrain);
        fillInput(tx, ty, in);
    }

    /** ...with the tile's ground given (a view keeps it: MapTiles.terrain(), batch J4) rather than read from the world. */
    public void tileInput(long tx, long ty, TilePainter.Input in, byte[] terrain) {
        System.arraycopy(terrain, 0, in.terrain, 0, TilePainter.PLOTS);
        fillInput(tx, ty, in);
    }

    /** Everything tileInput() fills but the ground, which is in `in` already. */
    private void fillInput(long tx, long ty, TilePainter.Input in) {
        BuildingVisual.Type[] paint = paintTypes();
        in.seed = seed;
        in.tx = tx;
        in.ty = ty;
        in.types = paint;
        tileOwnership(tx, ty, in.owned);
        if (in.counts.length != paint.length) in.counts = new int[paint.length];
        if (in.model.length != types.length) in.model = new int[types.length];
        tileCounts(tx, ty, in.model);
        in.neighbourRoads[0] = tileHasRoads(tx, ty - 1);
        in.neighbourRoads[1] = tileHasRoads(tx + 1, ty);
        in.neighbourRoads[2] = tileHasRoads(tx, ty + 1);
        in.neighbourRoads[3] = tileHasRoads(tx - 1, ty);
        highways(tx, ty, in);
        in.clearSites();
        long px0 = tx * World.TILE, py0 = ty * World.TILE;
        int ddx = (int) (Math.floorDiv(tx, TILES_A_SIDE) - baseDX), ddy = (int) (Math.floorDiv(ty, TILES_A_SIDE) - baseDY);
        for (int b = -1; b <= 1; b++) {
            for (int a = -1; a <= 1; a++) {
                for (DrawnSite s : siteList(ddx + a, ddy + b)) {
                    if (s.x1 < px0 || s.x0 >= px0 + World.TILE || s.y1 < py0 || s.y0 >= py0 + World.TILE) continue;
                    in.addSite((int) (s.x0 - px0), (int) (s.y0 - py0), (int) (s.x1 - px0), (int) (s.y1 - py0),
                            s.kind, s.state, s.mine);
                }
            }
        }
        drawCounts(in.model, buildable(in), modelPavedShare(), in);
    }

    /** A tile's plots a building can stand on: owned, dry, and in no resource's site (a site is its field, which no building covers) - the ground its counts are drawn for. */
    static int buildable(TilePainter.Input in) {
        boolean[] field = new boolean[TilePainter.PLOTS];
        for (int k = 0; k < in.sites; k++) {
            for (int y = in.siteY0[k]; y <= in.siteY1[k]; y++) {
                for (int x = in.siteX0[k]; x <= in.siteX1[k]; x++) field[y * TilePainter.TILE + x] = true;
            }
        }
        int plots = 0;
        for (int i = 0; i < TilePainter.PLOTS; i++) {
            byte g = in.terrain[i];
            if (in.owned[i] && g != World.SALT && g != World.FRESH && !field[i]) plots++;
        }
        return plots;
    }

    /**
     * A tile's counts as drawn, from its model counts and its owned dry
     * plots, into in: in.counts (by the painter's table), in.roadBudget and
     * in.peoplePerHome. Pure in its inputs, so a harness can draw a tile's
     * counts by hand.
     */
    public void drawCounts(int[] model, int plots, double pavedFloor, TilePainter.Input in) {
        BuildingVisual.Type[] paint = paintTypes();
        if (in.counts.length != paint.length) in.counts = new int[paint.length];
        Arrays.fill(in.counts, 0);
        Arrays.fill(in.roadBudget, 0);
        double people = 0;
        double[] jobs = new double[BuildingVisual.VISUAL_KINDS];
        double buildingPlots = 0;
        boolean any = false;
        for (int t = 0; t < types.length && t < model.length; t++) {
            int c = model[t];
            if (c <= 0 || types[t] == null) continue;
            any = true;
            BuildingVisual.Type ty = types[t];
            if (ty.road() != BuildingVisual.NOT_A_ROAD) continue;
            int k = BuildingVisual.visualKindOf(ty);
            if (k == 0) people += (double) c * ty.people();
            else if (k > 0) jobs[k] += (double) c * ty.jobs();
            else {
                in.counts[t] = c;
                buildingPlots += c * BuildingVisual.meanPlots(ty);
            }
        }
        int n = types.length;
        int homes = BuildingVisual.homes(people, plots);
        in.counts[n] = homes;
        buildingPlots += homes;
        double work = 0;
        for (int k = 1; k < BuildingVisual.VISUAL_KINDS; k++) {
            int w = BuildingVisual.workplaces(k, jobs[k], plots);
            in.counts[n + k] = w;
            buildingPlots += w * BuildingVisual.meanPlots(paint[n + k]);
            work += jobs[k];
        }
        in.peoplePerHome = plots > 0 ? BuildingVisual.peoplePerHome(people / plots) : BuildingVisual.HOUSE_PEOPLE;
        int budget = BuildingVisual.roadBudget(buildingPlots, any);
        double share = BuildingVisual.pavedShare(plots > 0 ? (people + work) / plots : 0, pavedFloor);
        int paved = (int) Math.round(budget * share);
        in.roadBudget[BuildingVisual.PAVED] = paved;
        in.roadBudget[BuildingVisual.GRAVEL] = budget - paved;
    }

    /* =====================================================================
       THE TWO HIGHWAYS (the mockup's star 5)

       Along the founding site's row and its column, an arm each way from
       the site to the first plot of sea, over fresh water whatever its width
       - the road to the next city. Each arm is walked a tile at a time, as
       far as a tile asks and no further, and kept. An exit every 7 to 13
       plots (EXIT_EVERY, give or take), off a dry plot, is a paved road's
       end once the city owns it.
       ===================================================================== */

    /** The arms' directions from the site: north, east, south, west. */
    static final int[] ARM_DX = { 0, 1, 0, -1 }, ARM_DY = { -1, 0, 1, 0 };

    /** An exit stands about this many plots past the one before: 10... */
    static final int EXIT_EVERY = 10;

    /** ...give or take: -1 to +2 of it, so 7 to 13 plots apart (the mockup's). */
    static final int EXIT_LESS = 1, EXIT_MORE = 2;

    /** An exit's road leaves on the left (facing out) when its draw is under 0.75, and on the right when it is over 0.4: one side or both, both a third of the time (the mockup's). */
    static final double EXIT_LEFT = 0.75, EXIT_RIGHT = 0.4;

    private final long[] armWalked = new long[4];
    private final boolean[] armEnded = new boolean[4];

    /** How far an arm runs from the site, in plots, walked at least to `upTo` unless it meets the sea first. */
    long armReach(int arm, long upTo) {
        byte[] t = null;
        while (!armEnded[arm] && armWalked[arm] < upTo) {
            long d = armWalked[arm] + 1;
            long x = siteX + ARM_DX[arm] * d, y = siteY + ARM_DY[arm] * d;
            if (x < 0 || y < 0 || x >= World.SIDE || y >= World.SIDE) { armEnded[arm] = true; break; }
            long tx = Math.floorDiv(x, World.TILE), ty = Math.floorDiv(y, World.TILE);
            if (t == null) t = new byte[TilePainter.PLOTS];
            World.of(seed).tileTerrain(tx, ty, t);
            while (Math.floorDiv(x, World.TILE) == tx && Math.floorDiv(y, World.TILE) == ty) {
                if (t[(int) ((y - ty * World.TILE) * World.TILE + (x - tx * World.TILE))] == World.SALT) { armEnded[arm] = true; break; }
                armWalked[arm] = d;
                d++;
                x += ARM_DX[arm];
                y += ARM_DY[arm];
            }
        }
        return armWalked[arm];
    }

    /** Whether the plot `d` along an arm is an exit: the k-th stands EXIT_EVERY x k plus its own -EXIT_LESS to +EXIT_MORE. */
    boolean isExit(int arm, long d) {
        long k = Math.floorDiv(d + EXIT_LESS, EXIT_EVERY);
        for (long j = k - 1; j <= k + 1; j++) {
            if (j < 1) continue;
            long at = EXIT_EVERY * j - EXIT_LESS + Math.floorMod(World.mix(seed ^ 0xE817L ^ ((long) arm << 56) ^ j), EXIT_LESS + EXIT_MORE + 1);
            if (at == d) return true;
        }
        return false;
    }

    /** The highways' plots and exits on tile (tx, ty), into in. */
    void highways(long tx, long ty, TilePainter.Input in) {
        Arrays.fill(in.highway, false);
        in.exits = 0;
        long x0 = tx * World.TILE, y0 = ty * World.TILE;
        for (int axis = 0; axis < 2; axis++) {
            // axis 0: the row through the site (west and east arms); 1: its column (north and south).
            long line = axis == 0 ? siteY : siteX, from = axis == 0 ? y0 : x0;
            if (line < from || line >= from + World.TILE) continue;
            for (int c = 0; c < World.TILE; c++) {
                long along = (axis == 0 ? x0 : y0) + c, off = along - (axis == 0 ? siteX : siteY);
                int arm = axis == 0 ? (off >= 0 ? 1 : 3) : (off >= 0 ? 2 : 0);
                long d = Math.abs(off);
                if (d > 0 && armReach(arm, d) < d) continue;
                int px = axis == 0 ? c : (int) (line - x0), py = axis == 0 ? (int) (line - y0) : c;
                int i = py * World.TILE + px;
                in.highway[i] = true;
                if (d == 0 || in.terrain[i] == World.FRESH || in.terrain[i] == World.SALT || !isExit(arm, d)) continue;
                double u = World.unit(World.mix(seed ^ 0xE817L ^ ((long) arm << 56) ^ (d << 8)));
                int lx = ARM_DY[arm], ly = -ARM_DX[arm];
                if (u < EXIT_LEFT) in.addExit(px, py, lx, ly);
                if (u > EXIT_RIGHT) in.addExit(px, py, -lx, -ly);
            }
        }
    }

    /** One site as the map draws it: its square of plots (inclusive), resource, state and the mine on it (-1 for none). */
    record DrawnSite(long x0, long y0, long x1, long y1, int kind, int state, int mine) { }

    private final Map<Long, List<DrawnSite>> siteLists = new LinkedHashMap<>(SITE_LISTS_KEPT * 2, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<Long, List<DrawnSite>> e) { return size() > SITE_LISTS_KEPT; }
    };
    private final Map<Long, Long> siteListVersion = new HashMap<>();

    /**
     * The sites whose centres lie in district (dx, dy) - every resource's,
     * owned or not - each with its holding's state and, for the SITED
     * resources, the mine on it: in each holding, the first of its sites here
     * (in field order) carry the mines the district holds from that holding.
     */
    List<DrawnSite> siteList(int dx, int dy) {
        long k = key(dx, dy);
        District d = byKey.get(k);
        long version = d == null ? -1 : d.version;
        List<DrawnSite> got = siteLists.get(k);
        Long seen = siteListVersion.get(k);
        if (got != null && seen != null && seen == version) return got;
        if (d != null && !sitedPlaced) placeSited(totals());
        long x0 = (baseDX + dx) * DISTRICT, y0 = (baseDY + dy) * DISTRICT;
        List<DrawnSite> out = new ArrayList<>();
        Map<Resource, int[]> states = new HashMap<>();
        for (Resource r : Resource.values()) {
            if (!r.inFields()) continue;
            int slot = siteSlot(r);
            int[][] pairs = d == null || slot < 0 ? null : new int[][] { d.holdingMines[slot] };
            int[] left = new int[1 + land.purchases().size()];
            if (pairs != null && pairs[0] != null) for (int a = 0; a + 1 < pairs[0].length; a += 2) left[pairs[0][a]] += pairs[0][a + 1];
            int mineType = -1;
            for (int t = 0; t < types.length; t++) if (types[t] != null && types[t].site() == r) { mineType = t; break; }
            double w = Deposit.siteWidth(r);
            for (Deposit f : fieldsNear(r, x0, y0, x0 + DISTRICT - 1, y0 + DISTRICT - 1)) {
                boolean legacy = f.cell() < 0;
                for (int s = 0; s < f.sites(); s++) {
                    double[] at = f.siteAt(s);
                    double cx = f.x() + at[0], cy = f.y() + at[1];
                    if (Math.floorDiv((long) Math.floor(cx), DISTRICT) != baseDX + dx
                            || Math.floorDiv((long) Math.floor(cy), DISTRICT) != baseDY + dy) continue;
                    int h = legacy ? 0 : holdingOf(cx - siteX, cy - siteY);
                    int state = TilePainter.UNOWNED;
                    if (h >= 0) {
                        int[] st = states.computeIfAbsent(r, this::holdingStates);
                        state = h < st.length ? st[h] : TilePainter.UNWORKED;
                    }
                    int mine = -1;
                    if (h >= 0 && h < left.length && left[h] > 0 && mineType >= 0) {
                        mine = mineType;
                        left[h]--;
                    }
                    long sx0 = Math.round(cx - w / 2), sy0 = Math.round(cy - w / 2);
                    long sx1 = Math.round(cx + w / 2) - 1, sy1 = Math.round(cy + w / 2) - 1;
                    out.add(new DrawnSite(sx0, sy0, Math.max(sx0, sx1), Math.max(sy0, sy1), r.ordinal(), state, mine));
                }
            }
        }
        siteLists.put(k, out);
        siteListVersion.put(k, version);
        siteListVersion.keySet().retainAll(siteLists.keySet());
        return out;
    }

    /** Forgets the painted state of every district - the deals, their spreads and the site lists - after the ground's states moved (what is worked out). */
    public void forgetPainted() {
        countsStamp.clear();
        tileCountsKept.clear();
        spreads.clear();
        siteLists.clear();
        siteListVersion.clear();
    }

    /* =====================================================================
       THE PYRAMID (spec-land 2.5): TEN CLASSES, USED AND OWNED, 2 x 2
       ===================================================================== */

    /** How many numbers a node sums: the ten classes, the ground used (in half square feet, exact) and the owned dry plots. */
    public static final int NODE_WIDTH = BuildingVisual.CLASSES + 2;

    /** Where a node keeps the ground used, in half square feet. */
    public static final int NODE_USED = BuildingVisual.CLASSES;

    /** ...and its owned dry plots. */
    public static final int NODE_OWNED = BuildingVisual.CLASSES + 1;

    /**
     * The districts summed two by two, level by level, to one node - level 0
     * is the districts themselves, each level above a grid of nodes over the
     * districts' box, a node NODE_WIDTH numbers. Built when the map is drawn
     * or its land changes; a district's change goes up its ancestors only.
     */
    public static final class Pyramid {
        private final CityMap map;
        private final int minX, minY;
        /** Each level's grid: its width, height and nodes (NODE_WIDTH numbers each, row by row). */
        private final int[] widths, heights;
        private final long[][] nodes;
        private final int count;

        Pyramid(CityMap map) {
            this.map = map;
            int mx = Integer.MAX_VALUE, my = Integer.MAX_VALUE, xx = Integer.MIN_VALUE, xy = Integer.MIN_VALUE;
            for (District d : map.districts) {
                mx = Math.min(mx, d.dx); my = Math.min(my, d.dy);
                xx = Math.max(xx, d.dx); xy = Math.max(xy, d.dy);
            }
            if (mx == Integer.MAX_VALUE) { mx = my = xx = xy = 0; }
            minX = mx;
            minY = my;
            int w = xx - mx + 1, h = xy - my + 1;
            List<int[]> sizes = new ArrayList<>();
            while (w > 1 || h > 1) {
                w = (w + 1) / 2;
                h = (h + 1) / 2;
                sizes.add(new int[] { w, h });
            }
            widths = new int[sizes.size()];
            heights = new int[sizes.size()];
            nodes = new long[sizes.size()][];
            for (int l = 0; l < sizes.size(); l++) {
                widths[l] = sizes.get(l)[0];
                heights[l] = sizes.get(l)[1];
                nodes[l] = new long[widths[l] * heights[l] * NODE_WIDTH];
            }
            for (District d : map.districts) {
                long[] v = vector(d);
                int x = d.dx - minX, y = d.dy - minY;
                for (int l = 0; l < nodes.length; l++) {
                    x >>= 1;
                    y >>= 1;
                    int at = (y * widths[l] + x) * NODE_WIDTH;
                    for (int c = 0; c < NODE_WIDTH; c++) nodes[l][at + c] += v[c];
                }
            }
            int n = 0;
            for (int l = 0; l < nodes.length; l++) {
                for (int at = 0; at < nodes[l].length; at += NODE_WIDTH) {
                    boolean any = false;
                    for (int c = 0; c < NODE_WIDTH && !any; c++) any = nodes[l][at + c] != 0;
                    if (any || l == nodes.length - 1) n++;
                }
            }
            count = n;
        }

        /** A district's numbers: its buildings by class, its ground used (half square feet) and its owned dry plots. */
        long[] vector(District d) {
            long[] v = new long[NODE_WIDTH];
            for (int t = 0; t < map.types.length; t++) {
                BuildingVisual.Type ty = map.types[t];
                if (d.counts[t] == 0 || ty == null || !ty.drawn()) continue;
                v[ty.cls()] += d.counts[t];
            }
            v[NODE_USED] = d.usedHalf;
            v[NODE_OWNED] = d.owned;
            return v;
        }

        /** k more (or fewer) of type t in a district: its ancestors take them. */
        void add(District d, int t, long k) {
            BuildingVisual.Type ty = map.types[t];
            int cls = ty != null && ty.drawn() ? ty.cls() : -1;
            long used = ty == null ? 0 : k * 2 * ty.sqFt();
            int x = d.dx - minX, y = d.dy - minY;
            if (x < 0 || y < 0) return;
            for (int l = 0; l < nodes.length; l++) {
                x >>= 1;
                y >>= 1;
                if (x >= widths[l] || y >= heights[l]) return;
                int at = (y * widths[l] + x) * NODE_WIDTH;
                if (cls >= 0) nodes[l][at + cls] += k;
                nodes[l][at + NODE_USED] += used;
            }
        }

        /** How many levels above the districts. */
        public int levels() { return nodes.length; }

        /** How many nodes above the districts hold anything (and the top). */
        public int nodes() { return count; }

        /** The top node: the whole city's numbers. */
        public long[] root() {
            if (nodes.length == 0) {
                long[] v = new long[NODE_WIDTH];
                for (District d : map.districts) {
                    long[] w = vector(d);
                    for (int c = 0; c < NODE_WIDTH; c++) v[c] += w[c];
                }
                return v;
            }
            return Arrays.copyOf(nodes[nodes.length - 1], NODE_WIDTH);
        }

        /** The node at a level (1 up) covering district (dx, dy), or null. */
        public long[] node(int level, int dx, int dy) {
            if (level <= 0 || level > nodes.length) return null;
            int x = (dx - minX) >> level, y = (dy - minY) >> level, l = level - 1;
            if (x < 0 || y < 0 || x >= widths[l] || y >= heights[l]) return null;
            int at = (y * widths[l] + x) * NODE_WIDTH;
            return Arrays.copyOfRange(nodes[l], at, at + NODE_WIDTH);
        }
    }

    /* =====================================================================
       THE SIDECAR (spec-land 2.5)
       ===================================================================== */

    /**
     * The map as its sidecar's bytes, deflated: the header (magic, format,
     * seed, month, stamp, the founding site, the centre's half-side and the
     * purchases it was drawn on, the type count, the district count), then a
     * record a district in its order - dx and dy (int16), owned dry plots,
     * plots used (double), owned iron and oil sites, a count a type (int32).
     * The stamp is a hash of every other byte, so the same map always writes
     * the same file.
     */
    public byte[] writeSidecar(int month) {
        try {
            ByteArrayOutputStream raw = new ByteArrayOutputStream();
            DataOutputStream out = new DataOutputStream(raw);
            out.writeInt(MAGIC);
            out.writeInt(FORMAT);
            out.writeLong(seed);
            out.writeInt(month);
            out.writeLong(0);                       // the stamp, below
            out.writeLong(siteX);
            out.writeLong(siteY);
            out.writeDouble(centreHalfSeen);
            out.writeInt(purchasesSeen);
            out.writeInt(types.length);
            out.writeInt(districts.size());
            for (District d : districts) {
                out.writeShort(d.dx);
                out.writeShort(d.dy);
                out.writeInt(d.owned);
                out.writeDouble(d.used());
                for (int k = 0; k < SITED.length; k++) out.writeInt(d.sites[k]);
                for (int t = 0; t < types.length; t++) out.writeInt(d.counts[t]);
            }
            out.flush();
            byte[] bytes = raw.toByteArray();
            long stamp = stampOf(bytes);
            lastStamp = stamp;
            for (int b = 0; b < 8; b++) bytes[STAMP_AT + b] = (byte) (stamp >>> (56 - 8 * b));
            ByteArrayOutputStream z = new ByteArrayOutputStream();
            Deflater deflater = new Deflater(Deflater.DEFAULT_COMPRESSION);
            try (DeflaterOutputStream d = new DeflaterOutputStream(z, deflater)) {
                d.write(bytes);
            } finally {
                deflater.end();
            }
            return z.toByteArray();
        } catch (IOException e) {
            throw new IllegalStateException("the map would not write", e);
        }
    }

    private long lastStamp;

    /** The stamp of the sidecar last written: what the save carries as mapStamp. */
    public long lastStamp() { return lastStamp; }

    /** The stamp of a sidecar's raw bytes: SplitMix64 folded over them, the stamp's own eight bytes read as zero. */
    static long stampOf(byte[] raw) {
        long h = World.mix(MAGIC);
        for (int i = 0; i < raw.length; i += 8) {
            long w = 0;
            for (int b = 0; b < 8; b++) {
                int at = i + b;
                long v = at < raw.length && (at < STAMP_AT || at >= STAMP_AT + 8) ? raw[at] & 0xffL : 0;
                w = (w << 8) | v;
            }
            h = World.mix(h ^ w);
        }
        return h;
    }

    /** The stamp a sidecar carries, or 0 when it is not one. */
    public static long stampIn(byte[] deflated) {
        byte[] raw = inflate(deflated);
        if (raw == null || raw.length < STAMP_AT + 8) return 0;
        long s = 0;
        for (int b = 0; b < 8; b++) s = (s << 8) | (raw[STAMP_AT + b] & 0xffL);
        return s;
    }

    private static byte[] inflate(byte[] deflated) {
        try (InflaterInputStream in = new InflaterInputStream(new ByteArrayInputStream(deflated))) {
            return in.readAllBytes();
        } catch (IOException | RuntimeException e) {
            return null;
        }
    }

    /**
     * A map read back from its sidecar, or null when it is not one, is not
     * this city's (another seed, month or stamp, or land drawn otherwise), or
     * does not add up. Its mines are put back on their sites, which gives the
     * counts the file holds when the ground's states are those it was saved
     * with.
     */
    public static CityMap readSidecar(byte[] deflated, CityLand land, Function<Resource, double[]> remaining,
                                      BuildingVisual.Type[] types, int month, long stamp) {
        byte[] raw = inflate(deflated);
        if (raw == null || raw.length < STAMP_AT + 8) return null;
        try {
            DataInputStream in = new DataInputStream(new ByteArrayInputStream(raw));
            if (in.readInt() != MAGIC || in.readInt() != FORMAT) return null;
            long seed = in.readLong();
            int savedMonth = in.readInt();
            long savedStamp = in.readLong();
            if (seed != land.seed() || savedMonth != month || savedStamp != stamp || stampOf(raw) != stamp) return null;
            long sx = in.readLong(), sy = in.readLong();
            double half = in.readDouble();
            int bought = in.readInt();
            if (sx != land.siteX() || sy != land.siteY() || half != land.centreHalf() || bought != land.purchases().size()) return null;
            int nTypes = in.readInt(), n = in.readInt();
            if (nTypes > types.length || n < 0) return null;
            CityMap m = new CityMap(seed, sx, sy, types);
            m.land = land;
            m.remaining = remaining;
            for (int i = 0; i < n; i++) {
                int dx = in.readShort(), dy = in.readShort();
                District d = m.newDistrict(dx, dy);
                d.owned = in.readInt();
                double used = in.readDouble();
                d.tileDry = null;
                for (int k = 0; k < SITED.length; k++) d.sites[k] = in.readInt();
                for (int t = 0; t < nTypes; t++) {
                    d.counts[t] = in.readInt();
                    m.have[t] += d.counts[t];
                }
                d.usedHalf = m.usedOf(d);
                if (used != d.used()) return null;
            }
            m.purchasesSeen = bought;
            m.centreHalfSeen = half;
            m.sortDistricts();
            m.pyramid = new Pyramid(m);
            return m;
        } catch (IOException | RuntimeException e) {
            return null;
        }
    }

    /** Whether two maps hold the same districts with the same figures, in the same order. */
    public boolean same(CityMap o) {
        if (o == null || o.seed != seed || o.districts.size() != districts.size() || o.types.length != types.length) return false;
        for (int i = 0; i < districts.size(); i++) {
            District a = districts.get(i), b = o.districts.get(i);
            if (a.dx != b.dx || a.dy != b.dy || a.owned != b.owned || a.usedHalf != b.usedHalf || !Arrays.equals(a.counts, b.counts)) return false;
        }
        return true;
    }
}
