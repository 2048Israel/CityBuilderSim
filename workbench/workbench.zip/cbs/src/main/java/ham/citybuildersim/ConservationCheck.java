package ham.citybuildersim;

import java.io.OutputStream;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Nothing is created and nothing is destroyed.
 *
 * ==================== WHY THIS FILE EXISTS ====================
 *
 * A deliberate audit in September 2026 turned up three bugs that all twenty-two
 * existing harnesses and four thousand months of `LongPlaytest` had missed:
 *
 *   1. Loading a save into a running game DOUBLED every building. loadGameSave()
 *      called only initialize(), which is guarded and therefore a no-op once a
 *      game is running, and the reset inside loadGame() was commented out.
 *      Measured: house capacity 2,720 -> 2,720 -> 5,340.
 *
 *   2. The food warehouse never drained. updateFinalIndustrialHandler()
 *      subtracted two fields that only a dead method ever wrote, so stock sat at
 *      capacity while the mills booked revenue on it every month and the shops
 *      added inventory the mills never lost.
 *
 *   3. 73% of the city's electricity was billed to nobody. The utility collected
 *      on every building's draw; only four sector categories were ever charged.
 *
 * Every one of them is the same KIND of bug and none of them is a broken
 * mechanism. The existing harnesses assert a great deal about mechanisms - that
 * a bond amortises, that a streak survives a save, that households fit their
 * homes - and almost nothing about whether the books balance. A mechanism can be
 * perfectly correct while quietly manufacturing food.
 *
 * So this file asserts conservation laws and nothing else. One per commodity,
 * one per money flow, plus the one that says a city is the same city after you
 * load it. They are cheap, they are unglamorous, and they are the only thing
 * that would have caught any of the three.
 *
 * THE BLIND QUADRANT. Bug 1 was invisible BY CONSTRUCTION: every other harness
 * builds a fresh Game per case, so the same Game object is never loaded into
 * twice. Section 4 deliberately reuses one. Any future bug that only appears
 * when state survives across a load or a new game lives in that quadrant too.
 *
 * ==============================================================
 */
public class ConservationCheck {

    static int fails = 0;
    static PrintStream out;
    static PrintStream quiet = new PrintStream(new OutputStream() {
        @Override public void write(int b) { }
        @Override public void write(byte[] b, int off, int len) { }
    });

    static void check(String label, double actual, double expected, double tol) {
        boolean ok = Math.abs(actual - expected) <= tol;
        if (!ok) fails++;
        System.out.printf("%-56s %14.4f  expected %14.4f  %s%n",
                label, actual, expected, ok ? "OK" : "FAIL");
    }

    static void assertTrue(String label, boolean ok) {
        if (!ok) fails++;
        System.out.printf("%-56s %s%n", label, ok ? "OK" : "FAIL");
    }

    /** A city with something of everything in it, so every law has something to test. */
    static Game city(Path root, String name, int months) throws Exception {
        GameFiles files = new GameFiles(root.resolve(name), root.resolve("no-legacy"));
        Game g = new Game(files);
        System.setOut(quiet);
        try {
            g.run();
            BuildingManager b = g.getBuildingManager();
            b.addStack(b.getTemplateByName("House"), 300, true);
            b.addStack(b.getTemplateByName("Convenience Store"), 12, true);
            b.addStack(b.getTemplateByName("Bakery"), 3, true);
            b.addStack(b.getTemplateByName("Construction Depot"), 3, true);
            b.addStack(b.getTemplateByName("Coal Power Plant"), 2, true);
            b.addStack(b.getTemplateByName("Water Treatment Plant"), 1, true);
            /*
             * THE FIXTURE HAS TO KEEP THE PLANTS IT IS MEASURING. Three food
             * plants for twelve hundred people is a sector losing money on
             * every unit, and since 2026-09-10 a sector that does so sells its
             * capacity: at a buildable plant size the spare-capacity rule
             * thins three plants to one, and the distress rule takes the last
             * one two years later - so a 36-month conservation law measured
             * at month 120 read "made 0, sold 0" against a warehouse that no
             * longer existed. Twentieth sighting. The city protects the
             * sector, as a player can from the Policy tab, so the loss the
             * fixture's own shape creates is covered rather than acted on and
             * the law is measured against a warehouse that is still there.
             */
            g.setAutoSubsidised(Sectors.INDUSTRY, true);
            /*
             * AND THE TREASURY THAT PAYS FOR ALL OF IT, SAID OUT LOUD (0.7.10).
             * The subsidy above, two coal plants' unbilled draw and a hundred
             * and fifty-six months of a city's running costs come out of the
             * treasury, and this fixture was written against the D$2.5B every
             * city opened with until 0.7.10. On the D$100M a city founds with
             * now it ran dry, simulateMonths() stopped running months, and the
             * food law was measured on a warehouse nothing moved through. The
             * fixture is given the treasury it always spent - the Wealthy
             * preset's - explicitly.
             */
            g.setCashForTest(Founding.WEALTHY_CASH);
            g.simulateMonths(months);
        } finally { System.setOut(out); }
        return g;
    }

    public static void main(String[] args) throws Exception {

        out = System.out;
        Path root = Files.createTempDirectory("conservation");

        Game g = city(root, "main", 120);
        EconomyManager em = g.getEconomyManager();
        Sector ih = g.getSectors().industry();
        UtilitiesHandler uh = g.getServicesManager().getUtilitiesHandler();

        /* ============ 1. FOOD ============ */
        System.out.println("--- food: what came in equals what went out ---");

        /*
         * THE LAW: opening stock + what was made - what spoiled - what was sold
         * - what was shipped abroad = closing stock. Exactly, every month, for
         * as long as you care to run it.
         *
         * Run over many months rather than one because the failure that
         * motivated it was a STEADY leak: stock pinned at capacity while sales
         * were booked against it, which one month in isolation looks like a
         * warehouse that happens to be full.
         */
        boolean conserved = true;
        int worstMonth = 0;
        double worstGap = 0;
        double totalMade = 0, totalSold = 0, totalExported = 0, totalSpoiled = 0;
        int lowStock = Integer.MAX_VALUE, highStock = Integer.MIN_VALUE;

        for (int m = 0; m < 36; m++) {
            /*
              * THE WAREHOUSE HOLDS BREAD NOW. This read Good.FOOD, and the
              * ovens stopped making it on 2026-09-15 - so every term in the
              * law was zero, the law held perfectly, and the two assertions
              * below (which exist precisely to catch a law satisfied by an
              * empty warehouse) went red. They were right to: the warehouse
              * was not conserving, it was absent.
              */
            double opening = ih.getStock(Good.BREAD);
            System.setOut(quiet);
            try { g.simulateMonths(1); } finally { System.setOut(out); }

            /*
             * What went INTO the warehouse, not what the income statement said
             * was made. The two differ whenever a ratio moved during the month -
             * which is the entire reason the report carries a basis - and this
             * line used to read the report, so the law could only ever be
             * asserted to within a unit. Sickness moves every month and pushed
             * the gap to 1.06, which read as a leak and was a mis-measurement.
             *
             * Since the sector template (2026-09-11) the month's figures are
             * the sector's own Output record for the good. The export-bound
             * share leaves FROM THE LINE and never passes through the shed -
             * see Sector.produceStock - so it is counted but is not a term in
             * the warehouse's law.
             */
            Sector.Output o = ih.output(Good.BREAD);
            double made = o.produced;
            double spoiled = o.writtenOff;
            double sold = o.soldLocal;
            double exported = o.exported;

            totalMade += made;
            totalSpoiled += spoiled;
            totalSold += sold;
            totalExported += exported;

            lowStock = Math.min(lowStock, (int) Math.round(ih.getStock(Good.BREAD)));
            highStock = Math.max(highStock, (int) Math.round(ih.getStock(Good.BREAD)));

            double expected = opening + made - spoiled - sold;
            double gap = Math.abs(expected - ih.getStock(Good.BREAD));
            if (gap > worstGap) { worstGap = gap; worstMonth = m; }
            // Doubles now, so a few ulps of slack on a five-figure stock.
            if (gap > 1e-6) conserved = false;
        }

        System.out.printf("   over 36 months: made %,.0f  sold %,.0f  exported %,.0f"
                + "  spoiled %,.0f%n", totalMade, totalSold, totalExported, totalSpoiled);
        System.out.printf("   worst monthly discrepancy: %.4f units (month %d)%n",
                worstGap, worstMonth);
        assertTrue("every month, food in equals food out plus the change in stock",
                conserved);

        /*
         * AND IT ACTUALLY MOVES. The conservation law above is satisfied
         * trivially by a warehouse where nothing ever happens - which is exactly
         * the state the bug produced, since 0 in and 0 out balances perfectly.
         * A law that a broken system also passes is not a test.
         */
        /*
         * AND THE STOCK ACTUALLY MOVES, measured as the range it covered rather
         * than as first-versus-last. A settled city cycles - it ends a run where
         * it began - so comparing the two endpoints of a periodic series proves
         * nothing and fails on a perfectly healthy warehouse. What the broken
         * version looked like was a FLAT line, so flatness is the thing to test.
         */
        System.out.printf("   stock ranged %,d to %,d over the run%n", lowStock, highStock);
        assertTrue("...and the warehouse is not simply frozen", totalSold > 0);
        assertTrue("...and the stock level actually moves", highStock > lowStock);

        /* ============ 2. ELECTRICITY ============ */
        System.out.println("\n--- electricity: the utility books what the sectors pay ---");

        double billedDraw = uh.getBilledElectricityDraw();
        System.out.printf("   city draws %,.0f W, of which %,.0f W is invoiced to somebody%n",
                uh.getConsumption(), billedDraw);

        double charged = 0;
        for (Sector s : g.getSectors().all()) charged += s.statement().electricity;

        check("the utility's revenue is exactly what the sectors were charged",
                uh.getElectricityRevenue(), charged, .0001);

        /*
         * The unbilled draw is real and deliberate - houses, roads, the water
         * plant and the city's own yards all use power and nobody invoices them.
         * What must never happen again is the utility BOOKING that draw as
         * revenue, which is what made 73% of a city's power bill money from
         * nowhere.
         */
        assertTrue("there is unbilled draw, and it is not booked as revenue",
                uh.getUnbilledElectricityDraw() > 0);

        /* ============ 3. WATER ============ */
        System.out.println("\n--- water: the same law, which it already obeyed ---");

        double waterCharged = 0;
        for (Sector s : g.getSectors().all()) waterCharged += s.statement().water;

        check("the water utility's revenue is what the sectors were charged",
                uh.getWaterRevenue(), waterCharged, .0001);

        /* ============ 4. A CITY IS THE SAME CITY AFTER YOU LOAD IT ============ */
        System.out.println("\n--- loading: the blind quadrant ---");

        /*
         * THE ONE NO OTHER HARNESS CAN SEE. Every other file builds a fresh Game
         * per case, so a Game object is never loaded into twice - and the bug
         * this catches only exists on the second load. Reusing one object here
         * is the entire point of the section, not a shortcut.
         */
        Game source = city(root, "saved", 60);
        System.setOut(quiet);
        try { source.saveGame(1, "conservation"); } finally { System.setOut(out); }

        GameFiles files = new GameFiles(root.resolve("saved"), root.resolve("no-legacy"));
        Game reused = new Game(files);

        System.setOut(quiet);
        try { reused.loadGameSave(1); } finally { System.setOut(out); }
        double[] first = snapshot(reused);

        System.setOut(quiet);
        try {
            reused.loadGameSave(1);
            reused.loadGameSave(1);
        } finally { System.setOut(out); }
        double[] third = snapshot(reused);

        String[] names = {"house capacity", "total jobs", "population", "cash",
                          "land allocated", "monthly GDP", "city debt"};
        System.out.printf("   after 1 load: %,.0f house capacity;  after 3: %,.0f%n",
                first[0], third[0]);
        for (int i = 0; i < names.length; i++) {
            check("  " + names[i] + " survives three loads unchanged",
                    third[i], first[i], .0001);
        }

        // And it agrees with the city it came from, not merely with itself.
        double[] original = snapshot(source);
        check("...and matches the city that was saved", first[0], original[0], .0001);

        /*
         * NEW GAME AFTER A PLAYED GAME, the other half of the quadrant. Same
         * object, and it must come back to a founding city rather than
         * inheriting one - buildWorld() exists for exactly this and is asserted
         * here rather than assumed.
         */
        /*
         * Compared against a GENUINELY FRESH Game rather than against zero. A new
         * city is not empty - it is founded with a starter block of housing - so
         * asserting zero tests the founding grant, not the reset. The property
         * buildWorld() actually promises is that a new game on a used object is
         * indistinguishable from one in a fresh process, and that is what this
         * says.
         */
        Game virgin = new Game(new GameFiles(root.resolve("virgin"), root.resolve("no-legacy")));
        System.setOut(quiet);
        try {
            virgin.run();
            reused.newGame();
        } finally { System.setOut(out); }

        double[] afterNew = snapshot(reused);
        double[] neverUsed = snapshot(virgin);
        for (int i = 0; i < names.length; i++) {
            check("  " + names[i] + ": a new game on a used object matches a fresh one",
                    afterNew[i], neverUsed[i], .0001);
        }
        check("...and it is back at month one", reused.getMonth(), 1, 0);

        /* ============ 5. WHAT A RELOAD MUST NOT FORGET ============ */
        System.out.println("\n--- history a reload cannot rebuild ---");

        /*
         * Four setters and five fields were found in the same audit, all the
         * same shape: something the monthly path maintains that the load path
         * never touched. None is a wrong calculation; each is a missing call or
         * a missing field, and every one of them is invisible until you compare
         * a played city against a reloaded one.
         *
         * The sharpest was MINING'S PAYROLL. updateMiningWages() had exactly one
         * call site, on the month loop, and startOfMonthUpdate() writes the
         * mine's statement BEFORE simulateMonth() would have filled the wage
         * array in - so the first month after any reload the mine booked full
         * revenue against a payroll of zero and the city taxed the profit.
         */
        Game mined = city(root, "mined", 40);
        System.setOut(quiet);
        try {
            BuildingManager b = mined.getBuildingManager();
            // ...over ore. A mine over a worked-out deposit is spare plant and
            // is sold within the year since 2026-09-11 (sectors.Mining), and
            // a sold mine has no payroll to survive a load. The fixture wants
            // a WORKING mine, so it gets a deposit to work.
            mined.getLandManager().restoreIron(3, 50_000_000);
            b.addStack(b.getTemplateByName("Iron Mine"), 3, true);
            mined.simulateMonths(30);
            mined.saveGame(1, "mined");
        } finally { System.setOut(out); }

        GameFiles minedFiles = new GameFiles(root.resolve("mined"), root.resolve("no-legacy"));
        Game minedBack = new Game(minedFiles);
        System.setOut(quiet);
        try { minedBack.loadGameSave(1); } finally { System.setOut(out); }

        double livePayroll = mined.getSectors().mining().getPayroll();
        double backPayroll = minedBack.getSectors().mining().getPayroll();
        System.out.printf("   mining payroll: live $%.4f, reloaded $%.4f%n",
                livePayroll, backPayroll);
        assertTrue("the mine has a payroll at all after a load", backPayroll > 0);
        check("...and it is the payroll it was working", backPayroll, livePayroll, .0001);

        // The utility's net income, the residents' statement and the whole
        // government block were all set on the monthly path only.
        assertTrue("utility income survives a load",
                minedBack.getEconomyManager().getUtilityIncome() != 0);
        assertTrue("the residents' statement is not blank after a load",
                minedBack.getHouseholds().getWages() > 0);
        assertTrue("...and the government's revenue block is not either",
                minedBack.getEconomyManager().getNationalAccounts().getTotalRevenue() > 0);

        /*
         * And the running total the residents' books carry must NOT gain a month
         * from being rebuilt - the reason the load path calls refresh() rather
         * than update().
         */
        check("...and rebuilding it does not book the month twice",
                minedBack.getHouseholds().getCumulativeSaving(),
                mined.getHouseholds().getCumulativeSaving(), .01);

        /* ---- the private sector's memory ---- */
        BusinessInvestment liveBi = mined.getBusinessInvestment();
        BusinessInvestment backBi = minedBack.getBusinessInvestment();

        check("the population trend survives, so forecasts are not flat",
                backBi.getPopulationGrowth(), liveBi.getPopulationGrowth(), .0001);

        boolean streaksMatch = true;
        for (java.util.Map.Entry<String, Integer> e : liveBi.getLossMonthsState().entrySet()) {
            if (!e.getValue().equals(backBi.getLossMonths(e.getKey()))) streaksMatch = false;
        }
        System.out.printf("   loss streaks carried: %s%n", liveBi.getLossMonthsState());
        assertTrue("every sector's losing streak survives a load", streaksMatch);

        cleanUp(root);

        System.out.println(fails == 0 ? "\nAll checks passed." : "\n" + fails + " FAILED");
        if (fails > 0) System.exit(1);
    }

    /** The figures a load must not move. */
    static double[] snapshot(Game g) {
        return new double[]{
            g.getBuildingManager().getTotalHouseCapacity(),
            g.getPopulationManager().getTotalJobs(),
            g.getPopulationManager().getPopulation(),
            Math.round(g.getCash() * 10000) / 10000.0,
            g.getLandManager().getAllocatedSqFt(),
            Math.round(g.getEconomyManager().getMonthGdp() * 10000) / 10000.0,
            Math.round(g.getDebtManager().getTotalMarketValue() * 10000) / 10000.0
        };
    }

    static void cleanUp(Path root) {
        try (var walk = Files.walk(root)) {
            walk.sorted(java.util.Comparator.reverseOrder()).forEach(p -> {
                try { Files.deleteIfExists(p); } catch (java.io.IOException ignored) { }
            });
        } catch (java.io.IOException ignored) { }
    }
}
