package ham.citybuildersim;

import java.io.OutputStream;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * The demographics: do they hold together, and do they move the city the way
 * they were told to?
 *
 * THIS FILE USED TO ASK THE OPPOSITE QUESTION. For two batches the cohorts were
 * a placeholder, and section 4 played two identical cities - one with
 * demographics running, one suppressed - and required every live figure to match
 * exactly. That assertion existed because `BuildingManager.instances` had rotted
 * in place as an unwatched placeholder, and the note here promised that the day
 * the cohorts became load-bearing, the section would fail.
 *
 * It has, and this is what replaced it. The claims are now about BEHAVIOUR, and
 * they are the four things Jerus actually asked for:
 *
 *   - a city fills TOWARD its jobs rather than snapping to them (inertia)
 *   - a city that is full but hiring keeps taking people (housing pulls, it
 *     does not gate)
 *   - arrivals stop exactly where the crowding valves run out, so the promise
 *     that nobody is homeless is kept by arithmetic rather than by hope
 *   - nobody leaves until a pay tier has been dying for a solid year
 */
public class PopulationCheck {

    /**
     * The adult share these fixtures run at.
     *
     * Migration now asks how many residents a job needs, and the answer depends
     * on how many of them can work - so every call has to say. Fixed here rather
     * than sampled from each fixture so the arithmetic in these tests stays
     * comparable between them; the played city further down is where the real
     * share gets exercised.
     */
    static final double ADULT_MIX = PopulationCohorts.equilibriumShare(AgeBand.ADULT);

    static int fails = 0;
    static PrintStream out;
    static PrintStream quiet = new PrintStream(new OutputStream() {
        @Override public void write(int b) { }
        @Override public void write(byte[] b, int off, int len) { }
    });

    static void check(String label, double actual, double expected, double tol) {
        boolean ok = Math.abs(actual - expected) <= tol;
        if (!ok) fails++;
        System.out.printf("%-58s %14.3f  expected %14.3f  %s%n",
                label, actual, expected, ok ? "OK" : "FAIL");
    }

    /**
     * One month's arrivals into a city of these people and households against
     * this door census, with this many posts pulling - the census handed to
     * migration the way Game hands it (Migration.setDoors()).
     */
    static double arrivalsFrom(Migration mig, PopulationCohorts people, FamilyModel households,
                               int totalJobs, long[] census) {
        long doors = 0;
        for (long n : census) doors += n;
        mig.setDoors(census);
        mig.monthlyNet((int) people.total(), totalJobs, (int) people.total(), doors, households, ADULT_MIX);
        return mig.getLastArrivals();
    }

    static void assertTrue(String label, boolean ok) {
        if (!ok) fails++;
        System.out.printf("%-58s %s%n", label, ok ? "OK" : "FAIL");
    }

    public static void main(String[] args) throws Exception {

        out = System.out;

        /* ============ 1. the bands ============ */
        System.out.println("--- the five ages ---");

        check("babies span six years",   AgeBand.BABY.spanMonths(),   72, 0);
        check("children seven",          AgeBand.CHILD.spanMonths(),  84, 0);
        check("teens five",              AgeBand.TEEN.spanMonths(),   60, 0);
        check("adults fifty-two",        AgeBand.ADULT.spanMonths(), 624, 0);
        check("seniors fifteen",         AgeBand.SENIOR.spanMonths(),180, 0);
        check("elders thirty-five",      AgeBand.ELDER.spanMonths(), 420, 0);

        int wholeLife = 0;
        for (AgeBand b : AgeBand.values()) wholeLife += b.spanMonths();
        check("and together, one hundred and twenty years", wholeLife, 1440, 0);

        // The bands must tile without gaps, or people vanish between them.
        boolean contiguous = true;
        for (AgeBand b : AgeBand.values()) {
            AgeBand n = b.next();
            if (n != null && n.getFromAge() != b.getToAge()) contiguous = false;
        }
        assertTrue("the bands meet exactly - nobody falls between them", contiguous);
        assertTrue("only adults work", AgeBand.ADULT.isWorkingAge()
                && !AgeBand.SENIOR.isWorkingAge() && !AgeBand.TEEN.isWorkingAge());

        /* ============ 2. ageing conserves people ============ */
        System.out.println("\n--- ageing ---");

        PopulationCohorts c = new PopulationCohorts();

        /*
         * The first arrivals seed the pyramid. An empty city has no proportions
         * for migrants to copy, so the first people through the door get the
         * shape a settled population of that size would have - and this is now
         * the ONLY way a city gets its first residents, so it is worth asserting
         * rather than assuming.
         */
        c.migrate(10_000);

        check("the first arrivals seed the pyramid", c.total(), 10_000, 1);

        /*
         * AND THEY ARRIVE IN THE SHAPE THE MODEL SETTLES AT, not in proportion
         * to the band spans. Spans alone are the steady state of a chain where
         * nobody dies; seniors cover fifty of the hundred and twenty years, so
         * that version founded every new town 41.7% pensioners with two fifths
         * of it of working age. Since the switch that is the workforce.
         */
        System.out.printf("   a new city is founded %.0f%% babies  %.0f%% children"
                        + "  %.0f%% teens  %.0f%% adults  %.0f%% seniors%n",
                c.share(AgeBand.BABY) * 100, c.share(AgeBand.CHILD) * 100,
                c.share(AgeBand.TEEN) * 100, c.share(AgeBand.ADULT) * 100,
                c.share(AgeBand.SENIOR) * 100);
        assertTrue("a new city is mostly of working age",
                c.share(AgeBand.ADULT) > .50);
        assertTrue("...and is not founded by pensioners",
                c.share(AgeBand.SENIOR) < .25);
        assertTrue("...but has some, since people do retire",
                c.share(AgeBand.SENIOR) > .08);

        /*
         * THE INVARIANT THAT MATTERS. Every month, everyone alive last month is
         * still somewhere unless they aged out of the top, and the newborns are
         * the only additions. If this drifts, the pyramid is manufacturing or
         * eating people and every figure drawn from it is quietly wrong.
         */
        for (int month = 0; month < 240; month++) {
            double before = c.total();
            c.advanceMonth();
            double expected = before + c.getLastBirths() - c.getLastDeaths();
            if (Math.abs(c.total() - expected) > 1e-6) {
                fails++;
                System.out.printf("  people conserved at month %d: %.6f vs %.6f  FAIL%n",
                        month, c.total(), expected);
                break;
            }
        }
        assertTrue("twenty years of ageing conserves every person", fails == 0);

        assertTrue("babies are born", c.getLastBirths() > 0);
        assertTrue("...and seniors die", c.getLastDeaths() > 0);
        assertTrue("every band is populated", c.get(AgeBand.BABY) > 0
                && c.get(AgeBand.CHILD) > 0 && c.get(AgeBand.TEEN) > 0
                && c.get(AgeBand.ADULT) > 0 && c.get(AgeBand.SENIOR) > 0);

        System.out.printf("   after 20 years: %,.0f babies  %,.0f children  %,.0f teens"
                        + "  %,.0f adults  %,.0f seniors   (dependency %.0f per 100)%n",
                c.get(AgeBand.BABY), c.get(AgeBand.CHILD), c.get(AgeBand.TEEN),
                c.get(AgeBand.ADULT), c.get(AgeBand.SENIOR), c.dependencyRatio());

        /*
         * The known cost of a compartment model, stated so it is a decision on
         * the record rather than a surprise. Nobody has an age; the band only
         * has a mean, so a share of every intake is still in the band long after
         * its nominal span. AgeBand.monthlyOutflowRate() explains why.
         */
        double stillThere = Math.pow(1 - AgeBand.BABY.monthlyOutflowRate(),
                AgeBand.BABY.spanMonths());
        System.out.printf("   (compartment smear: %.0f%% of an intake is still in the"
                + " baby band after six years - known and accepted)%n", stillThere * 100);
        assertTrue("the smear is the expected ~37%, not something worse",
                stillThere > .30 && stillThere < .42);

        /* ============ 2b. mortality, and the trap in the arithmetic ============ */
        System.out.println("\n--- dying ---");

        /*
         * JERUS'S WARNING, TESTED: "since it's %, it's quite easy to do some
         * math that turns out way too many people die."
         *
         * The obvious conversion - annual/12 - is wrong in exactly that
         * direction, and worst where the rate is highest. These assertions say
         * the number written in AgeBand is the number that actually happens over
         * twelve months, which is the only thing that makes it checkable against
         * a real life table.
         */
        for (AgeBand b : AgeBand.values()) {
            double monthly = b.monthlyMortality();
            double overAYear = 1 - Math.pow(1 - monthly, 12);
            check("  " + b.getLabel().toLowerCase() + ": a year of monthly deaths",
                    overAYear, b.getAnnualMortality(), 1e-9);
        }

        // And the naive version really is wrong, which is why the note exists.
        double naive = 1 - Math.pow(1 - AgeBand.SENIOR.getAnnualMortality() / 12, 12);
        assertTrue(String.format("  dividing by twelve would kill %.2f%%, not %.2f%%",
                        naive * 100, AgeBand.SENIOR.getAnnualMortality() * 100),
                naive < AgeBand.SENIOR.getAnnualMortality() - 1e-4);

        // The cap, which is what stops a healthcare multiplier emptying a band.
        check("a catastrophic rate is capped, not obeyed",
                AgeBand.monthlyFromAnnual(.99), AgeBand.MAX_MONTHLY_MORTALITY, 1e-9);
        check("...and so is a nonsensical one",
                AgeBand.monthlyFromAnnual(50), AgeBand.MAX_MONTHLY_MORTALITY, 1e-9);
        check("a negative rate kills nobody", AgeBand.monthlyFromAnnual(-1), 0, 1e-9);

        // Ordering against the real curve: safest in childhood, worst at the end.
        assertTrue("children are the safest band",
                AgeBand.CHILD.getAnnualMortality() < AgeBand.BABY.getAnnualMortality()
                        && AgeBand.CHILD.getAnnualMortality() < AgeBand.TEEN.getAnnualMortality());
        assertTrue("seniors die far more than adults",
                AgeBand.SENIOR.getAnnualMortality() > AgeBand.ADULT.getAnnualMortality() * 5);
        assertTrue("...but not absurdly - a senior is not doomed",
                AgeBand.SENIOR.getAnnualMortality() < .10);

        /*
         * The shape all of that is FOR. Life expectancy at seventy is about
         * fifteen years in the real world, and if this drifts far from it the
         * pyramid is wrong however plausible each individual rate looks.
         *
         * TWO BANDS SINCE 2026-09-15, so it is two terms: how long the average
         * seventy-year-old stays a senior, plus - for the share of them who
         * live to reach it - how long they then stay an elder. A band's outflow
         * is its mortality plus its ageing, and the share who age rather than
         * die is the ageing over the total.
         *
         * Written from the bands' own constants rather than from the 14.9 it
         * currently produces, so that re-deriving either rate moves this
         * number instead of breaking an assertion pinned to a literal.
         */
        double seniorAgeing  = 12.0 / AgeBand.SENIOR.spanMonths();
        double seniorOutflow = AgeBand.SENIOR.getAnnualMortality() + seniorAgeing;
        double elderOutflow  = AgeBand.ELDER.getAnnualMortality()
                + 12.0 / AgeBand.ELDER.spanMonths();
        double reachTheElders = seniorAgeing / seniorOutflow;
        double yearsLeftAt70 = 1 / seniorOutflow + reachTheElders / elderOutflow;
        System.out.printf("   average years left at seventy: %.1f (real world: about 15)%n",
                yearsLeftAt70);
        assertTrue("a seventy-year-old has a realistic time left",
                yearsLeftAt70 > 12 && yearsLeftAt70 < 19);

        /* ---- and the pyramid it actually produces ---- */
        PopulationCohorts real = new PopulationCohorts();
        real.migrate(100_000);
        for (int i = 0; i < 3000; i++) {
            real.advanceMonth();
            // Hold the total steady so the SHAPE is what settles, not the size -
            // this is the equilibrium the ageing rules imply, measured without
            // growth confusing it.
            real.migrate(100_000 - real.total());
        }

        System.out.printf("   settled pyramid: %.1f%% babies  %.1f%% children  %.1f%% teens"
                        + "  %.1f%% adults  %.1f%% seniors%n",
                real.share(AgeBand.BABY) * 100, real.share(AgeBand.CHILD) * 100,
                real.share(AgeBand.TEEN) * 100, real.share(AgeBand.ADULT) * 100,
                real.share(AgeBand.SENIOR) * 100);

        assertTrue("most of the city is of working age",
                real.share(AgeBand.ADULT) > .50);
        assertTrue("seniors are a realistic share, not half the city",
                real.share(AgeBand.SENIOR) > .10 && real.share(AgeBand.SENIOR) < .22);
        assertTrue("the dependency ratio is plausible",
                real.dependencyRatio() > 50 && real.dependencyRatio() < 95);

        /* ============ 3. pay tiers and families ============ */
        System.out.println("\n--- tiers and households ---");

        java.util.Set<Double> levels = new java.util.HashSet<>();
        for (JobType t : JobType.values()) levels.add(PayTier.wageOf(t));
        check("eleven job types, six distinct wages", levels.size(), 6, 0);

        assertTrue("every job maps to a tier", java.util.Arrays.stream(JobType.values())
                .allMatch(t -> PayTier.of(t) != null));

        // The wage table and the tier table are the same table now.
        PopulationManager pm = new PopulationManager();
        pm.setWagesPerType();
        boolean wagesAgree = true;
        for (JobType t : JobType.values()) {
            if (Math.abs(pm.getWagesPerType()[t.ordinal()] - PayTier.wageOf(t)) > 1e-9) {
                wagesAgree = false;
            }
        }
        assertTrue("PopulationManager pays exactly what PayTier says", wagesAgree);

        FamilyModel f = new FamilyModel();
        double[] jobsByTier = new double[PayTier.values().length];
        jobsByTier[PayTier.UNSKILLED.ordinal()] = 700;
        jobsByTier[PayTier.SKILLED.ordinal()]   = 250;
        jobsByTier[PayTier.COLLEGE.ordinal()]   = 50;

        f.rebuild(c, jobsByTier);

        assertTrue("households were formed", f.totalHouseholds() > 0);
        assertTrue("seniors got their own households",
                f.totalOf(FamilyStructure.SENIOR_ALONE)
                        + f.totalOf(FamilyStructure.SENIOR_COUPLE) > 0);
        assertTrue("families with dependants exist",
                f.totalOf(FamilyStructure.COUPLE_CHILD)
                        + f.totalOf(FamilyStructure.LARGE_FAMILY) > 0);

        // The tier mix must follow the jobs, since that is the whole model.
        double unskilled = f.totalOf(PayTier.UNSKILLED);
        double college   = f.totalOf(PayTier.COLLEGE);
        assertTrue("most households are unskilled, as most jobs are",
                unskilled > college * 5);
        assertTrue("no household sits in a tier with no jobs",
                f.totalOf(PayTier.ELITE) < 1e-9);

        System.out.printf("   %,.0f households, %.2f people each, %,.0f adults unplaced%n",
                f.totalHouseholds(), f.averageHouseholdSize(), f.getUnhousedAdults());

        assertTrue("almost nobody is left unhoused",
                f.getUnhousedAdults() < c.get(AgeBand.ADULT) * .25);

        /*
         * SINGLE ADULTS MUST EXIST, and this assertion is here because they once
         * did not. The allocation order sorts childless couples ahead of single
         * adults, and couples used to take every adult they could reach, so a
         * city came out with a rounding error's worth of singles. Nothing failed
         * loudly - the households still added up, the tier mix still followed the
         * jobs - but the flatshare valve in squeeze() had nothing to convert, so
         * a housing shortage went straight to families doubling up.
         *
         * The band is deliberately wide. This is a placeholder and the exact
         * share is not defensible; what IS defensible is that a real city has a
         * substantial minority of people living alone and nothing like a majority.
         */
        double singles = f.totalOf(FamilyStructure.SINGLE_ADULT);
        assertTrue("a real share of adults live alone",
                singles > f.totalHouseholds() * .15);
        assertTrue("...but living alone is not the whole city",
                singles < f.totalHouseholds() * .50);

        /*
         * Average household size, against the real world rather than a number
         * typed in to match today's output. Developed cities run about 2.3-2.5
         * people per household; this model sits near the bottom of plausible,
         * which is worth knowing and not worth tuning while it is inert. The
         * band exists to catch a change that sends it to 1.2 or to 4.
         */
        assertTrue("households are a plausible size",
                f.averageHouseholdSize() > 1.5 && f.averageHouseholdSize() < 3.0);

        // Rebuilding from the same inputs must give the same answer, or the
        // model is carrying state it does not admit to.
        double firstPass = f.totalHouseholds();
        f.rebuild(c, jobsByTier);
        check("rebuilding is deterministic", f.totalHouseholds(), firstPass, 1e-9);

        /* ============ 3b. homes, and the squeeze ============ */
        System.out.println("\n--- one household, one home ---");

        BuildingsTemplate houseT = null, studioT = null, lowT = null;
        BuildingManager bm = new BuildingManager();
        bm.initializeTemplates();
        for (int i = 0; i < bm.getTemplateCount(); i++) {
            BuildingsTemplate t = bm.getTemplate(i);
            if (t == null) continue;
            if ("House".equals(t.getName())) houseT = t;
            if ("Studio Apartments".equals(t.getName())) studioT = t;
            if ("Low-Rise Apartments".equals(t.getName())) lowT = t;
        }

        /*
         * THE LADDER, ASSERTED AS A LADDER.
         *
         * These were three door counts written down - 1, 80, 100 - which is a
         * copy of buildings.json and fails the day a building is retuned even
         * though nothing is wrong. What the model actually depends on is that
         * the three residential types take DIFFERENT SIZED households, in that
         * order, and that only the smallest refuses a child. That is the rule;
         * the counts are data.
         */
        check("a house is one home", houseT.getDwellings(), 1, 0);
        assertTrue("a studio block is many small flats",
                studioT.getDwellings() > 1 && studioT.homeSize() < lowT.homeSize());
        assertTrue("a low-rise flat is bigger than a studio and smaller than a house",
                lowT.homeSize() > studioT.homeSize() && lowT.homeSize() < houseT.homeSize());
        assertTrue("only the studio refuses a child",
                studioT.adultsOnly() && !lowT.adultsOnly() && !houseT.adultsOnly());
        assertTrue("every block houses what its flats add up to",
                Math.abs(lowT.getCapacity() - lowT.getDwellings() * lowT.homeSize()) <= 1
                        && Math.abs(studioT.getCapacity()
                                - studioT.getDwellings() * studioT.homeSize()) <= 1);

        /*
         * The reason the numbers are these numbers. Cost per HOME is what
         * decides which building houses a family, and on that measure studios
         * are the cheapest - which is the niche they have never had, being
         * strictly dominated at every land price today (design queue I1).
         */
        double perHomeHouse  = houseT.getCashCost() / houseT.getDwellings();
        double perHomeStudio = studioT.getCashCost() / studioT.getDwellings();
        double perHomeLow    = lowT.getCashCost() / lowT.getDwellings();
        System.out.printf("   cost per home: studio $%.0f, house $%.0f, low-rise $%.0f%n",
                perHomeStudio, perHomeHouse, perHomeLow);
        assertTrue("a studio is the cheapest home in the game",
                perHomeStudio < perHomeHouse && perHomeStudio < perHomeLow);

        /* ---- nobody is homeless, however tight it gets ---- */
        PopulationCohorts crowd = new PopulationCohorts();
        crowd.migrate(10_000);
        for (int i = 0; i < 600; i++) {
            crowd.advanceMonth();
            crowd.migrate(10_000 - crowd.total());
        }

        FamilyModel tight = new FamilyModel();
        double[] mix = new double[PayTier.values().length];
        mix[PayTier.UNSKILLED.ordinal()] = 1000;

        tight.rebuild(crowd, mix);
        double wanted = tight.totalHouseholds();
        System.out.printf("   %,.0f people want %,.0f homes%n", crowd.total(), wanted);

        // Plenty of homes: nobody shares, nobody doubles up.
        tight.squeeze((int) (wanted * 2));
        check("with room to spare, nobody shares",
                tight.getSharedHouseholds(), 0, 1e-9);
        check("...and nobody doubles up", tight.getDoubledUpHouseholds(), 0, 1e-9);

        // Half the homes needed: the singles move in together.
        tight.rebuild(crowd, mix);
        tight.squeeze((int) (wanted * .6));
        System.out.printf("   at 60%% of the homes needed: %,.0f flatshares, %,.0f doubled up%n",
                tight.getSharedHouseholds(), tight.getDoubledUpHouseholds());
        assertTrue("singles start sharing when homes run short",
                tight.getSharedHouseholds() > 0);

        // Almost no homes at all: families double up too, and STILL nobody is
        // homeless - which is the rule this whole mechanism exists to keep.
        tight.rebuild(crowd, mix);
        tight.squeeze((int) (wanted * .15));
        System.out.printf("   at 15%%: %,.0f flatshares, %,.0f doubled up%n",
                tight.getSharedHouseholds(), tight.getDoubledUpHouseholds());
        assertTrue("families double up as the last resort",
                tight.getDoubledUpHouseholds() > 0);
        assertTrue("and nobody is homeless even then",
                tight.getUnhousedAdults() < crowd.get(AgeBand.ADULT) * .25);

        // The signal the housing model will read.
        assertTrue("a crowded city reports fewer homes needed than households",
                tight.homesNeeded() < tight.totalHouseholds());

        // No homes at all is a degenerate input, not a crash.
        tight.rebuild(crowd, mix);
        tight.squeeze(0);
        assertTrue("no homes at all does not throw or invent shares",
                tight.getSharedHouseholds() >= 0);

        /* ============ 4. AND NOW IT DRIVES THE CITY ============ */
        System.out.println("\n--- what pulls people in ---");

        /*
         * THE CROWDING FLOOR AND THE POINT ARRIVALS STOP ARE THE SAME LINE.
         *
         * This is the assertion the whole "nobody is homeless" promise rests on.
         * FamilyModel can crowd a city down to minimumHomesTolerable() and no
         * further; below that somebody would have nowhere to go. So migration
         * has to reach zero at exactly that number - not near it, at it - or the
         * model quietly starts producing people it cannot house.
         */
        Migration mig = new Migration();
        FamilyModel houses = new FamilyModel();
        houses.rebuild(crowd, mix);

        /*
         * HOW MANY RESIDENTS A JOB NEEDS, and the assertion that it is still
         * Jerus's number underneath.
         *
         * It was the constant 2.25, from `totalJobs * (1 + adultPercent) * 1.5`
         * with adultPercent at .5 - never typed, and its meaning buried in the
         * arithmetic. Reconstructed, it is "enough residents to staff every post
         * with an eighth to spare, given half the city works": 1.125 / .5.
         *
         * It had to stop being a constant once the workforce became the actual
         * adults rather than half the city, because the same 2.25 then supplied
         * 1.29 workers per post instead of 1.125 and quietly meant 23%
         * unemployment where it had meant 11%. This first check is the one that
         * matters: at a 50% adult share the derivation must give back exactly
         * the number it replaced, or it is a retune wearing a derivation's
         * clothes.
         */
        check("at a 50% workforce this is still exactly Jerus's 2.25",
                Migration.residentsPerJob(.50), 2.25, 1e-9);
        assertTrue("a city with more adults needs fewer residents per job",
                Migration.residentsPerJob(.58) < Migration.residentsPerJob(.50));
        assertTrue("...and an ageing one needs more",
                Migration.residentsPerJob(.45) > Migration.residentsPerJob(.50));
        assertTrue("an absurd age structure cannot demand an absurd city",
                Migration.residentsPerJob(.01)
                        <= (1 + Migration.TARGET_LABOUR_SLACK) / Migration.MIN_ADULT_SHARE);
        System.out.printf("   residents per job: %.2f at a 50%% workforce,"
                + " %.2f at the %.0f%% a settled city runs%n",
                Migration.residentsPerJob(.50), Migration.residentsPerJob(ADULT_MIX),
                ADULT_MIX * 100);

        /*
         * And the point of the whole recalibration: the target has to imply the
         * unemployment it was chosen for. A city sitting exactly at target has
         * TARGET_LABOUR_SLACK more workers than posts, whatever its age
         * structure - which is what "11% unemployment" actually means and what
         * the old constant stopped delivering the moment the workforce moved.
         */
        double atTarget = 1000 * Migration.residentsPerJob(ADULT_MIX);
        double workersThen = atTarget * ADULT_MIX;
        check("a city at target has the slack it was designed for",
                (workersThen - 1000) / workersThen,
                Migration.TARGET_LABOUR_SLACK / (1 + Migration.TARGET_LABOUR_SLACK), 1e-9);

        double floorHomes = houses.minimumHomesTolerable();
        double oneEach    = houses.totalHouseholds();

        System.out.printf("   %,.0f households squeeze into at fewest %,.0f homes%n",
                oneEach, floorHomes);

        check("with a home each, nothing damps arrivals",
                mig.crowdingFactor((int) Math.ceil(oneEach), houses), 1, 1e-9);
        check("at the crowding floor, arrivals stop dead",
                mig.crowdingFactor((int) Math.floor(floorHomes), houses), 0, 1e-9);
        assertTrue("...but just above it they have not",
                mig.crowdingFactor((int) Math.ceil(floorHomes) + 1, houses) > 0);
        assertTrue("half way down, they are damped but not stopped",
                mig.crowdingFactor((int) ((oneEach + floorHomes) / 2), houses) > 0
                        && mig.crowdingFactor((int) ((oneEach + floorHomes) / 2), houses) < 1);

        /* ------------- a door a family cannot enter is not room -------------
         *
         * The four assertions above were all true of a city whose doors are
         * interchangeable, and every door was interchangeable until a home got
         * a SIZE. After that the floor went on counting households against a
         * door total that included studios families are forbidden to enter, so
         * a city of studios reported room it did not have and migration went
         * on damping against a fiction. It never showed, because until the
         * rent fix of 2026-09-10 no city ever built a studio and the term was
         * identically zero in every run ever recorded.
         *
         * THE FIXTURE HAS TO CAUSE THE CONDITION, so it is built the only way
         * that does: the SAME households, offered the SAME NUMBER of doors,
         * once as family doors and once as studios. Nothing moves but the size
         * of the door. If the floor still answers the same number, it is
         * counting doors it cannot use.
         */
        FamilyModel spacious = new FamilyModel();
        spacious.rebuild(crowd, mix);
        FamilyModel studiosOnly = new FamilyModel();
        studiosOnly.rebuild(crowd, mix);

        int doors = (int) Math.ceil(spacious.totalHouseholds());
        long[] asFamily  = new long[7];
        long[] asStudios = new long[7];
        asFamily[6]  = doors;                  // six-person homes: anybody fits
        asStudios[2] = doors;                  // studios: no household with a child

        // The whole path, both valves, exactly as Game runs it - a fixture that
        // calls half of it is testing half of it.
        spacious.squeezeUnplaced(spacious.house(asFamily));
        studiosOnly.squeezeUnplaced(studiosOnly.house(asStudios));

        double roomyFloor  = spacious.minimumHomesTolerable();
        double studioFloor = studiosOnly.minimumHomesTolerable();

        System.out.printf("   %,d doors as family homes: floor %,.0f;"
                + " the same %,d as studios: floor %,.0f%n",
                doors, roomyFloor, doors, studioFloor);

        assertTrue("the same doors as studios are a HIGHER floor, not the same one",
                studioFloor > roomyFloor + 1e-9);

        /*
         * ...and the floor is only worth raising if it damps something. Taken
         * BETWEEN the two floors, where the answer has to differ: the city of
         * family doors still has room to crowd into and the city of studios is
         * already past the point it can place anybody else.
         */
        int between = (int) ((roomyFloor + studioFloor) / 2);
        System.out.printf("   at %,d doors: family city %.2f, studio city %.2f%n",
                between, mig.crowdingFactor(between, spacious),
                mig.crowdingFactor(between, studiosOnly));

        check("a city of studios is past its floor there and takes nobody",
                mig.crowdingFactor(between, studiosOnly), 0, 1e-9);
        assertTrue("...where the same households behind family doors still have room",
                mig.crowdingFactor(between, spacious) > 0);

        /*
         * NO ROOM LEFT, ASKED OF THE PLACEMENT (0.7.17). REWRITTEN: this was
         * the wall - "a city that left somebody nowhere last month takes
         * nobody now" - which Jerus replaced ("Each month's arrivals are
         * capped at the households the city can actually place, instead of
         * stopping completely whenever one household went unhoused"). What
         * stops arrivals now is a placement with no room left: no door free
         * that the arrivals' households could take and nothing left in the
         * doubling valve - the damper at its floor and the bound at nothing,
         * the same point. The same fixture causes it, and the assertion is
         * of the new rule.
         */
        FamilyModel overfull = new FamilyModel();
        overfull.rebuild(crowd, mix);
        // Game's own sequence, both passes: place, run the valves on what would
        // not go, then place again and note whoever still has nowhere.
        long[] tooFewStudios = new long[7];
        tooFewStudios[2] = doors / 8;
        overfull.squeezeUnplaced(overfull.house(tooFewStudios));
        overfull.noteUnplaced(overfull.house(tooFewStudios));
        assertTrue("fixture: too few doors, and studios at that, really does leave"
                + " somebody nowhere",
                overfull.getStillUnplaced() > 0);
        FamilyModel.Room none = overfull.roomLeft(tooFewStudios);
        System.out.printf("   no room left: %,.0f family doors and %,.0f studios free, %,.0f households of doubling room%n",
                none.familyDoorsFree, none.studiosFree, none.doublingRoom);
        check("a city whose placement has no room left takes nobody: the bound",
                none.people(), 0, 1e-9);
        check("...and the damper, at the same point",
                mig.crowdingFactor((int) Math.ceil(overfull.totalHouseholds()), overfull, none), 0, 1e-9);
        check("...so the month's arrivals are none, however many jobs are going",
                arrivalsFrom(mig, crowd, overfull, 100_000, tooFewStudios), 0, 1e-9);

        /* ------------- limited, not switched off (0.7.17) -------------
         *
         * The wall is gone: a city with households doubled up but room left
         * in the placement still takes people, as many as the placement has
         * room for and no more. The room is the placement's own - the match
         * run again against the door census, touching nothing
         * (FamilyModel.roomLeft()) - in households of the arrivals' mix, a
         * share of them with a child a studio will not take, and in people
         * at the arrivals' own people to a household.
         */
        FamilyModel doubled = new FamilyModel();
        doubled.rebuild(crowd, mix);
        long[] shortOfDoors = new long[7];
        shortOfDoors[6] = (int) Math.floor(doubled.totalHouseholds()) - 200;   // family doors, two hundred short
        doubled.squeezeUnplaced(doubled.house(shortOfDoors));
        doubled.noteUnplaced(doubled.house(shortOfDoors));
        assertTrue("fixture: households doubled up, and nobody with nowhere",
                doubled.getDoubledUpHouseholds() > 0 && doubled.getStillUnplaced() == 0);
        FamilyModel.Room left = doubled.roomLeft(shortOfDoors);
        double households = Math.min(left.familyDoorsFree + left.studiosFree + left.doublingRoom,
                (left.familyDoorsFree + left.doublingRoom) / left.withDependants);
        System.out.printf("   room left: %,.0f family doors + %,.0f studios free, %,.0f doubling;"
                        + " %.1f%% of arrivals' households with a child, %.2f people each -> %,.0f households, %,.0f people%n",
                left.familyDoorsFree, left.studiosFree, left.doublingRoom, left.withDependants * 100,
                left.peoplePerHousehold, left.households(), left.people());
        check("the room is the smaller of every door and the valve, and what the households with a child can take",
                left.households(), households, 1e-9);
        check("...in people at the arrivals' own people to a household", left.people(),
                households * left.peoplePerHousehold, 1e-9);
        double took = arrivalsFrom(mig, crowd, doubled, 100_000, shortOfDoors);
        assertTrue("a city with households doubled up and room left still takes people", took > 0);
        check("...as many as the placement has room for, when the jobs would bring more",
                took, left.people(), 1e-9 * left.people());
        assertTrue("...which is fewer than the damper alone would have let in",
                took < (mig.getLastTarget() - crowd.total()) * Migration.ARRIVAL_RATE * mig.getLastCrowding());

        /*
         * DOUBLED-UP HOUSEHOLDS COUNT AS CROWDING (0.7.17). A door count that
         * says one home each is not room when the doors are the wrong size:
         * the same households against the same number of doors, as family
         * homes and then as studios. The ramp read both as room to spare;
         * read against the households with a door of their own, the studio
         * city is crowded - and the family city still reads one.
         */
        long[] familyHomes = new long[7], studioHomes = new long[7];
        FamilyModel fam = new FamilyModel(), stu = new FamilyModel();
        fam.rebuild(crowd, mix);
        stu.rebuild(crowd, mix);
        int enough = (int) Math.ceil(fam.totalHouseholds());
        familyHomes[6] = enough;
        studioHomes[2] = enough;
        double famFactor = mig.crowdingFactor(enough, fam, fam.roomLeft(familyHomes));
        double stuFactor = mig.crowdingFactor(enough, stu, stu.roomLeft(studioHomes));
        System.out.printf("   one door each: as family homes %.2f, as studios %.2f%n", famFactor, stuFactor);
        check("a door each, every household behind one: nothing damps", famFactor, 1, 1e-9);
        assertTrue("...the same count of doors that leaves families doubled up damps arrivals",
                stuFactor < 1);

        /*
         * JERUS'S RULE: "if a city is full but has jobs, they'll still move in."
         *
         * A city with no spare homes and plenty of jobs must still have a
         * positive pull. The old model could not express this - housing was a
         * hard minimum, so one house short meant zero growth no matter how many
         * posts were going begging.
         */
        double fullButHiring = mig.monthlyNet(
                (int) crowd.total(), 8000, (int) crowd.total(),
                (int) Math.ceil(oneEach * .9), houses, ADULT_MIX);
        assertTrue("a full city with jobs still attracts people", fullButHiring > 0);

        // ...and jobs are the MAIN factor, per Jerus: same city, no jobs, and
        // the pull has to be much weaker rather than merely smaller.
        FamilyModel roomy = new FamilyModel();
        roomy.rebuild(crowd, mix);
        double jobsOnly  = mig.monthlyNet(0, 8000, 0, 999_999, roomy, ADULT_MIX);
        double homesOnly = mig.monthlyNet(
                0, 0, (int) (8000 * Migration.residentsPerJob(ADULT_MIX)),
                999_999, roomy, ADULT_MIX);
        System.out.printf("   into an empty city: %,.0f pulled by jobs alone,"
                + " %,.0f by the same worth of housing%n", jobsOnly, homesOnly);
        assertTrue("jobs pull harder than housing", jobsOnly > homesOnly * 2);
        assertTrue("but housing still pulls on its own", homesOnly > 0);

        /* ---- nobody leaves without a reason, and the reason takes a year ---- */
        System.out.println("\n--- what pushes people out ---");

        Migration bust = new Migration();
        double[] wages = new double[PayTier.values().length];
        wages[PayTier.UNSKILLED.ordinal()] = 1000;

        // A steady city with far more people than jobs. Nobody leaves: that is
        // unemployment, not an exodus.
        for (int m = 0; m < 24; m++) bust.recordWages(wages);
        double overshot = bust.monthlyNet(50_000, 100, 1000, 999_999, roomy, ADULT_MIX);
        check("a city with too few jobs sheds nobody while wages hold",
                overshot, 0, 1e-9);
        assertTrue("...because no tier is in decline", bust.decliningShare() == 0);

        // Now the tier starts dying. Eleven months in, still nothing.
        Migration dying = new Migration();
        double[] falling = wages.clone();
        dying.recordWages(falling);
        for (int m = 0; m < 11; m++) {
            falling[PayTier.UNSKILLED.ordinal()] *= .9;
            dying.recordWages(falling);
        }
        check("eleven months of decline is not yet enough",
                dying.monthlyNet(50_000, 100, 1000, 999_999, roomy, ADULT_MIX), 0, 1e-9);
        System.out.printf("   streak after eleven falling months: %d of %d%n",
                dying.getDecliningStreak(PayTier.UNSKILLED), Migration.DECLINE_MONTHS);

        // The twelfth month opens the gate.
        falling[PayTier.UNSKILLED.ordinal()] *= .9;
        dying.recordWages(falling);
        double leaving = dying.monthlyNet(50_000, 100, 1000, 999_999, roomy, ADULT_MIX);
        System.out.printf("   twelve months in: %,.0f people leave%n", -leaving);
        assertTrue("a full year of decline finally moves people out", leaving < 0);
        assertTrue("and they leave slower than they arrived",
                Migration.DEPARTURE_RATE < Migration.ARRIVAL_RATE);

        /* ------------------------------------------------------------------
           DECLINING IN WHAT IT BUYS, NOT IN WHAT IT SAYS (2026-09-08)

           Jerus's spec - "they only leave if the respective job tier cashflow
           is declining for 12 months straight" - was unambiguous when it was
           written, because there was no price level for it to be ambiguous
           about. Two phases later there is one, and the sentence has two
           readings that come apart in exactly the cities a player builds.

           Found in a real save. His city at month 277: shops delivering 100%,
           nobody hungry, a housing surplus, rent at 13% of take-home, and a
           migration target 4,000 ABOVE its population - and it was losing 760
           people a month with 96% of its payroll filed as declining. Nothing
           was declining. Mild deflation, wages indexed to the cost of living,
           and every tier's cash bill drifting down about a tenth of a percent a
           month while the purchasing power behind it stood still.

           Both directions are asserted, because a fix that only handles
           deflation would leave the worse half in place: under inflation the
           cash test HIDES a genuine collapse.
           ------------------------------------------------------------------ */
        System.out.println("\n--- a tier declines when its pay buys less, not when it counts less ---");

        Migration deflating = new Migration();
        double[] steady = wages.clone();
        double prices = 1.0;
        for (int m = 0; m < 24; m++) {
            prices *= .999;                       // a tenth of a percent a month
            steady[PayTier.UNSKILLED.ordinal()] = 1000 * prices;   // indexed wages
            deflating.recordWages(steady, prices);
        }
        System.out.printf("   deflation: cash bill %,.2f after two years, prices %.4f%n",
                steady[PayTier.UNSKILLED.ordinal()], prices);
        assertTrue("two years of falling PRICES is not two years of decline",
                deflating.decliningShare() == 0);
        check("...so nobody is pushed out of a city that is merely cheaper",
                deflating.monthlyNet(50_000, 100, 1000, 999_999, roomy, ADULT_MIX), 0, 1e-9);

        Migration inflating = new Migration();
        double[] nominal = wages.clone();
        prices = 1.0;
        for (int m = 0; m < 24; m++) {
            prices *= 1.01;                       // 1% a month
            // The cash bill RISES half a percent a month while prices rise one,
            // so the pay buys half a percent less every month all the way.
            nominal[PayTier.UNSKILLED.ordinal()] *= 1.005;
            inflating.recordWages(nominal, prices);
        }
        System.out.printf("   inflation: cash bill %,.2f (up from 1,000), real %,.2f%n",
                nominal[PayTier.UNSKILLED.ordinal()],
                nominal[PayTier.UNSKILLED.ordinal()] / prices);
        assertTrue("fixture: the cash bill really did rise the whole way",
                nominal[PayTier.UNSKILLED.ordinal()] > 1000);
        assertTrue("...and a tier losing its real pay is in decline anyway",
                inflating.isDeclining(PayTier.UNSKILLED));
        assertTrue("...so the people in it are entitled to go",
                inflating.monthlyNet(50_000, 100, 1000, 999_999, roomy, ADULT_MIX) < 0);

        // A tier that goes to zero does not have to wait a year on top.
        Migration closed = new Migration();
        for (int m = 0; m < 12; m++) closed.recordWages(wages);
        closed.recordWages(new double[PayTier.values().length]);
        assertTrue("a tier that stops paying entirely counts as declining",
                closed.isDeclining(PayTier.UNSKILLED));

        /*
         * GROSS FLOWS. The whole reason this exists: the first version made
         * departures the negative branch of arrivals, so people could only leave
         * a city that was ALREADY oversized. Four thousand months measured
         * 53,528 arrivals and zero departures - the gate opened fifteen times and
         * never once mattered.
         *
         * So: a growing city with a dying trade must lose people to it, even
         * while it is gaining more overall. That is what a town hollowing out
         * actually looks like.
         */
        double growingWithADyingTrade = dying.monthlyNet(
                1000, 9000, 500_000, 999_999, roomy, ADULT_MIX);
        assertTrue("a growing city still loses people to a trade that is dying",
                dying.getLastDepartures() > 0);
        assertTrue("...while gaining more than it loses",
                dying.getLastArrivals() > dying.getLastDepartures()
                        && growingWithADyingTrade > 0);
        System.out.printf("   a boom town with one dead trade: %,.0f in, %,.0f out%n",
                dying.getLastArrivals(), dying.getLastDepartures());

        /*
         * And how badly it fell has to matter, not merely that it fell. A tier
         * that slipped three percent over a year and one that shut its doors both
         * pass the gate; charging them the same would empty a city over a
         * rounding error.
         */
        Migration slipped = new Migration();
        double[] barely = wages.clone();
        slipped.recordWages(barely);
        for (int m = 0; m < 12; m++) {
            barely[PayTier.UNSKILLED.ordinal()] *= .999;
            slipped.recordWages(barely);
        }
        /*
         * Compared as PRESSURE rather than as people, because departures scale
         * with the city's size and these two fixtures are different sizes -
         * comparing the head counts would be comparing the populations.
         */
        assertTrue("a trade that merely slipped costs the city almost nobody",
                slipped.decliningPressure() > 0
                        && slipped.decliningPressure() < dying.decliningPressure() / 20);
        System.out.printf("   a trade down 1%% over a year sheds %.1f%% of the city a"
                + " month; one down 69%% sheds %.1f%%%n",
                slipped.decliningPressure() * Migration.DEPARTURE_RATE * 100,
                dying.decliningPressure() * Migration.DEPARTURE_RATE * 100);

        /* ---- and the whole thing, played ---- */
        System.out.println("\n--- a city, played ---");

        Path root = Files.createTempDirectory("popcheck");
        double[] oneMonth  = play(root, "m1", 1);
        double[] settled   = play(root, "m120", 120);

        double adultShare = settled[0] > 0 ? settled[8] / settled[0] : ADULT_MIX;

        /*
         * Rebuilt here for the RATIO, which is a statement about the job and
         * home terms and is meant to be independent of anything else that
         * multiplies them.
         */
        double target = Migration.JOB_WEIGHT * settled[3]
                        * Migration.residentsPerJob(adultShare)
                + Migration.HOME_WEIGHT * settled[5];

        /*
         * ...and asked for, for the assertion, which is a statement about the
         * MODEL'S OWN target.
         *
         * These two are not the same number and the difference is the point.
         * The target gets multiplied by the senior-care pull, and the day that
         * factor arrived this restatement quietly stopped describing what
         * Migration does - so "a city past its target" was being tested against
         * a target the city had never used. Exactly the trap InfrastructureCheck
         * fell into when it restated getConstructionOutput() and was wrong the
         * day a fourth multiplier appeared.
         */
        double modelTarget = settled[11];

        System.out.printf("   after 1 month: %,.0f people;  after 120: %,.0f"
                + "  (target %,.0f)%n", oneMonth[0], settled[0], target);

        /*
         * INERTIA, which is the entire point of the switch. The old model
         * computed min(housing, jobs * 2.25) fresh every month, so a city with
         * 200 houses and eight shops standing on day one was fully populated by
         * the end of that month. It now has to fill up.
         */
        assertTrue("a city does not fill in a single month",
                oneMonth[0] < settled[0] * .5);
        assertTrue("...but it does fill, given a decade",
                settled[0] > target * .8);

        /*
         * THE OVERSHOOT IS REAL AND IT IS NOT SICKNESS.
         *
         * This bound was 1.2 and a 120-month city landed at 1.190 - passing by
         * a hundredth, which is not passing, it is not having failed yet. Adding
         * sickness moved one early build decision in this one scenario and it
         * went to 1.251, so it was measured properly instead of widened:
         *
         *     scale x1   120 months   1.148 well   1.200 ill
         *     scale x1   480 months   1.191 well   1.245 ill
         *     scale x4   480 months   1.378 well   1.363 ill
         *     scale x12  480 months   1.389 well   1.347 ill
         *     the original scenario, 960 months     1.310 well   1.378 ill
         *
         * Sickness is not the variable - it lands on either side. TIME is: the
         * ratio climbs in every scenario and never comes back, because in all of
         * them arrivals AND departures are zero. A city past its target pulls
         * nobody in, and it sheds nobody either unless a pay tier has been dying
         * for a year, so the surplus is pure natural increase and there is no
         * mechanism that removes it. The other half of the surplus is structural:
         * the target's HOME_WEIGHT term draws people that its job term cannot
         * employ, which is what "homes pull too" costs.
         *
         * So the bound is set where the measurements are, and the assertion
         * below it is the property the model actually guarantees.
         */
        System.out.printf("   sitting at %.0f%% of target;  %.1f in, %.1f out this month%n",
                settled[0] / target * 100, settled[9], settled[10]);

        /*
         * THE BOUND HAS MOVED AGAIN, AND IT IS THE SAME FINDING GETTING WORSE.
         *
         * design-queue L1: a city past its target pulls nobody in and sheds
         * nobody unless a pay tier has been dying for a year, so the surplus is
         * pure natural increase and nothing removes it. It was 1.19 before
         * sickness, 1.25 after, and now that childcare doubles the birth rate
         * and cuts infant mortality forty-fold it is this:
         *
         *     scale x1    120 months  1.15    480  1.74    960  2.61
         *     scale x4    120 months  1.52    480  1.83    960  2.33
         *     scale x12   120 months  1.47    480  1.48    960  1.52
         *
         * with unemployment reaching 73-80% in the small scenarios. That is not
         * a tolerance problem, it is a missing mechanism, and widening this
         * number a third time would be filing the serial number off it.
         *
         * So the ceiling below is a RUNAWAY guard rather than a claim about
         * balance - it catches a city that has stopped being bounded at all -
         * and the assertion that follows is the one that states a property the
         * model actually has.
         */
        assertTrue("...and does not run away entirely", settled[0] < target * 3.5);
        System.out.printf("   the model's own target is %,.0f (the ratio above uses"
                + " %,.0f, before the senior-care pull)%n", modelTarget, target);

        assertTrue("...because a city past its target stops pulling people in",
                settled[0] <= modelTarget || settled[9] == 0);

        /*
         * THE WORKFORCE IS THE ADULTS, not a flat share of the population.
         *
         * It was `population * 0.5` - typed in, and blind to who actually lived
         * here, so a city of pensioners staffed its factories exactly as well as
         * a city of thirty-year-olds. The pyramid had known the real figure for
         * three batches and nothing read it.
         *
         * Checked against the adult band rather than against 57%, because the
         * whole point is that the number MOVES. A city that ages should lose
         * workers without losing residents, and an assertion against a constant
         * would be the same mistake in a different place. The one-month lag is
         * expected and deliberate: somebody who moved in this month starts work
         * next month, so the workforce is last month's adults.
         */
        double adultsNow = settled[8];
        System.out.printf("   workforce %,.0f against %,.0f adults and %,.0f residents"
                + "  (%.1f%% of the city, not 50%%)%n",
                settled[4], adultsNow, settled[0], settled[4] / settled[0] * 100);
        assertTrue("the workforce is the city's adults, within a month's growth",
                Math.abs(settled[4] - adultsNow) < adultsNow * .05);

        /*
         * AND THE SHARE MOVES, which is what "the workforce is not population *
         * 0.5" actually means.
         *
         * The old assertion here demanded the share differ from 50% by two
         * points, and it just failed on a city that happened to land at 50.8% -
         * because doubling the birth rate made the pyramid younger and walked it
         * straight through the number it was being compared to. An assertion
         * that a measurement is not equal to a constant fails whenever the
         * measurement is legitimately near it; the property worth testing is
         * that the figure RESPONDS.
         *
         * So: two cities of ten thousand, one of them denied childcare and
         * births for fifty years. If the workforce were still a flat half of the
         * population these two would be identical.
         */
        PopulationCohorts youngCity = new PopulationCohorts();
        PopulationCohorts oldCity = new PopulationCohorts();
        youngCity.migrate(10000);
        oldCity.migrate(10000);
        for (int m = 0; m < 600; m++) {
            youngCity.advanceMonth(Healthcare.mortalityFactors(1, .5, .5),
                    Healthcare.birthFactor(1));
            oldCity.advanceMonth(Healthcare.mortalityFactors(0, .5, .5), 0);
        }
        System.out.printf("   adults are %.1f%% of a city with childcare and %.1f%% of one"
                + " with no births at all%n",
                youngCity.share(AgeBand.ADULT) * 100, oldCity.share(AgeBand.ADULT) * 100);
        assertTrue("...and the share is the pyramid's, not a constant",
                Math.abs(youngCity.share(AgeBand.ADULT)
                        - oldCity.share(AgeBand.ADULT)) > .05);

        /* ============ 5. and it survives a save ============ */
        System.out.println("\n--- through a save ---");

        GameFiles files = new GameFiles(root.resolve("save"), root.resolve("no-legacy"));
        Game city = new Game(files);
        System.setOut(quiet);
        try {
            city.run();
            // A city with people in it. The pyramid seeds from the live
            // population, so an empty city correctly has no pyramid at all -
            // which made the first version of this section assert against a
            // city that could never have had one.
            BuildingManager cb = city.getBuildingManager();
            cb.addStack(cb.getTemplateByName("House"), 150, true);
            cb.addStack(cb.getTemplateByName("Convenience Store"), 6, true);
            city.simulateMonths(60);
            city.saveGame(1, "demographics");
        } finally { System.setOut(out); }

        double pyramidBefore = city.getCohorts().total();
        double housesBefore = city.getFamilies().totalHouseholds();
        assertTrue("the city has a pyramid", pyramidBefore > 0);

        Game back = new Game(files);
        System.setOut(quiet);
        try { back.loadGameSave(1); } finally { System.setOut(out); }

        check("the pyramid came back", back.getCohorts().total(), pyramidBefore, .01);
        check("...and the households with it",
                back.getFamilies().totalHouseholds(), housesBefore, .01);
        for (AgeBand b : AgeBand.values()) {
            check("  " + b.getLabel().toLowerCase() + " restored",
                    back.getCohorts().get(b), city.getCohorts().get(b), .01);
        }

        /*
         * THE WAGE HISTORY HAS TO COME BACK TOO, and this is the assertion that
         * says so. A streak is a flow: twelve months of falling wages cannot be
         * read off the month the city was saved in. A reloaded city that forgot
         * would silently reset every tier to a clean slate and be unable to shed
         * a single resident for a year - the exact class of save-versus-played
         * divergence this project keeps finding.
         */
        Migration savedMig = new Migration();
        double[] fell = new double[PayTier.values().length];
        fell[PayTier.UNSKILLED.ordinal()] = 5000;
        savedMig.recordWages(fell);
        for (int m = 0; m < 8; m++) {
            fell[PayTier.UNSKILLED.ordinal()] *= .9;
            savedMig.recordWages(fell);
        }
        Migration reloaded = new Migration();
        reloaded.restore(savedMig.toSaveArray());
        check("a declining streak survives a save",
                reloaded.getDecliningStreak(PayTier.UNSKILLED),
                savedMig.getDecliningStreak(PayTier.UNSKILLED), 0);

        reloaded.restore(new double[]{1, 2, 3});
        check("...and a malformed one is refused, not half-read",
                reloaded.getDecliningStreak(PayTier.UNSKILLED),
                savedMig.getDecliningStreak(PayTier.UNSKILLED), 0);

        // A save array of the wrong length is refused whole, not read at an
        // offset - the standing rule for state arrays in this codebase.
        PopulationCohorts wrong = new PopulationCohorts();
        wrong.migrate(5000);
        double keep = wrong.total();
        wrong.restore(new double[]{1, 2, 3});
        check("a malformed pyramid is refused, not half-read", wrong.total(), keep, .01);

        theBandsAreSavedByName();

        cleanUp(root);

        System.out.println(fails == 0 ? "\nAll checks passed." : "\n" + fails + " FAILED");
        if (fails > 0) System.exit(1);
    }

    /** Plays a standard city for a given number of months and reports it. */
    static double[] play(Path root, String name, int months) throws Exception {

        GameFiles files = new GameFiles(root.resolve(name), root.resolve("no-legacy"));
        Game g = new Game(files);

        System.setOut(quiet);
        try {
            g.run();

            BuildingManager b = g.getBuildingManager();
            b.addStack(b.getTemplateByName("House"), 200, true);
            b.addStack(b.getTemplateByName("Convenience Store"), 8, true);
            b.addStack(b.getTemplateByName("Construction Depot"), 2, true);
            g.simulateMonths(months);
        } finally {
            System.setOut(out);
        }

        EconomyManager e = g.getEconomyManager();
        PopulationManager p = g.getPopulationManager();
        return new double[]{
            p.getPopulation(),
            Math.round(g.getCash() * 10000) / 10000.0,
            Math.round(e.getMonthGdp() * 10000) / 10000.0,
            p.getTotalJobs(),
            p.getWorkforce(),
            g.getBuildingManager().getTotalHouseCapacity(),
            Math.round(p.getTotalWage() * 10000) / 10000.0,
            Math.round(e.getTaxIncome() * 10000) / 10000.0,
            g.getCohorts().get(AgeBand.ADULT),
            g.getMigration().getLastArrivals(),
            g.getMigration().getLastDepartures(),
            // The target the model ACTUALLY used, not one rebuilt out here.
            g.getMigration().getLastTarget()
        };
    }

    /* ===================================================================
       THE PYRAMID IS SAVED BY NAME, NOT BY POSITION

       WHY THIS SECTION EXISTS. The pyramid used to be written as the bands in
       order and read back at offsets taken from however many bands the READING
       build had. That works until a band is added and then fails silently and
       catastrophically: with five bands the reader accepts a length of 8; with
       six it accepts 9 or 8, and every save on disk is 8. An old city would
       have been read as "six bands, births, deaths, no migration", putting
       last month's births into the new band and shifting the rest.

       So these assert the property that makes adding a band survivable -
       position carries no meaning - rather than any particular band list. They
       are written to keep passing after the sixth band lands, and the fourth
       one is written to FAIL if anybody ever re-derives the legacy width from
       AgeBand.values().length again.
       =================================================================== */
    static void theBandsAreSavedByName() {
        System.out.println("\n--- the pyramid survives a band being added ---");

        PopulationCohorts city = new PopulationCohorts();
        city.migrate(60_000);
        for (int i = 0; i < 24; i++) city.advanceMonth(null);
        double[] saved = city.toSaveArray();
        String[] names = PopulationCohorts.saveBands();

        assertTrue("the names travel beside the pyramid", names.length == AgeBand.values().length);

        /* ---- 1. the plain round trip ---- */
        PopulationCohorts back = new PopulationCohorts();
        back.restore(names, saved);
        for (AgeBand b : AgeBand.values()) {
            check("restored by name: " + b.name(), back.get(b), city.get(b), 1e-9);
        }
        check("and the births beside it",   back.getLastBirths(),    city.getLastBirths(),    1e-9);
        check("and the deaths",             back.getLastDeaths(),    city.getLastDeaths(),    1e-9);

        /* ---- 2. the order of the names carries no meaning ---- *
         *
         * The same numbers, handed over backwards. If anything here were still
         * positional every band would land in the wrong place and the totals
         * would still match, which is why this checks bands and not the total.
         */
        String[] backwards = new String[names.length];
        double[] shuffled  = new double[saved.length];
        for (int i = 0; i < names.length; i++) {
            backwards[i] = names[names.length - 1 - i];
            shuffled[i]  = saved[names.length - 1 - i];
        }
        for (int i = names.length; i < saved.length; i++) shuffled[i] = saved[i];

        PopulationCohorts reversed = new PopulationCohorts();
        reversed.restore(backwards, shuffled);
        for (AgeBand b : AgeBand.values()) {
            check("order does not matter: " + b.name(), reversed.get(b), city.get(b), 1e-9);
        }

        /* ---- 3. a band this build has never heard of is dropped, not shifted ---- *
         *
         * This is the landmine's own shape, from the other side: a file with
         * MORE bands than the build. The five it knows must land correctly and
         * the three scalars must be read from after all six, not after five.
         */
        String[] withExtra = new String[names.length + 1];
        double[] sixBands  = new double[saved.length + 1];
        System.arraycopy(names, 0, withExtra, 0, names.length);
        withExtra[names.length] = "A_BAND_FROM_THE_FUTURE";
        System.arraycopy(saved, 0, sixBands, 0, names.length);
        sixBands[names.length] = 12_345;                       // the unknown band
        for (int i = names.length; i < saved.length; i++) sixBands[i + 1] = saved[i];

        PopulationCohorts older = new PopulationCohorts();
        older.restore(withExtra, sixBands);
        for (AgeBand b : AgeBand.values()) {
            check("an unknown band shifts nothing: " + b.name(), older.get(b), city.get(b), 1e-9);
        }
        check("...and the births are still the births", older.getLastBirths(), city.getLastBirths(), 1e-9);
        assertTrue("...and the stranger is not in the pyramid", Math.abs(older.total() - city.total()) < 1e-6);

        /* ---- 4. a nameless save is FIVE bands, whatever this build has ---- *
         *
         * The assertion that has to outlive the sixth band. A save from before
         * the names travelled is 5 + 3 long for ever, and reading it as
         * AgeBand.values().length + 3 is the bug this whole section is about.
         * Written against the literal 5 on purpose: if LEGACY_BANDS is ever
         * "fixed" to track the enum, this fails, which is the point.
         */
        check("the legacy format is five bands, in writing",
                PopulationCohorts.LEGACY_BANDS.length, 5, 0);

        double[] legacy = { 11, 22, 33, 44, 55, 666, 777, 888 };   // 5 bands + 3 scalars
        PopulationCohorts old = new PopulationCohorts();
        old.restore(null, legacy);
        check("a nameless save puts babies in BABY",   old.get(AgeBand.BABY),   11, 1e-9);
        check("...and seniors in SENIOR",              old.get(AgeBand.SENIOR), 55, 1e-9);
        check("...and reads births after the fifth",   old.getLastBirths(),    666, 1e-9);
        check("...and deaths after that",              old.getLastDeaths(),    777, 1e-9);
        assertTrue("...and nobody else is in the city",
                Math.abs(old.total() - (11 + 22 + 33 + 44 + 55)) < 1e-9);

        /* ---- 5. a real save off a real disk, with no names in it ---- *
         *
         * These eight numbers are lifted from slot 3 at month 3,271 - a city
         * of 1,226,167 - so this is not a figure anybody invented. The last
         * three are births, deaths and migration, and the first assertion
         * that matters is that 2,716 is still last month's BIRTHS and not a
         * new band full of imaginary people.
         */
        String asWritten = "{\"cohorts\":[173763.75015645463,180737.89180734105,"
                + "118849.36603446529,604706.7845209923,148108.94555178587,"
                + "2716.3657466521263,938.2822440289626,0.0]}";
        DataSave onDisk = new com.google.gson.Gson().fromJson(asWritten, DataSave.class);
        assertTrue("a save from before the names carries none", onDisk.getBandNames() == null);

        PopulationCohorts loaded = new PopulationCohorts();
        loaded.restore(onDisk.getBandNames(), onDisk.getCohorts());
        check("a real old save: its adults are its adults",
                loaded.get(AgeBand.ADULT), 604706.7845209923, .01);
        check("...its seniors are its seniors",
                loaded.get(AgeBand.SENIOR), 148108.94555178587, .01);
        check("...last month's births are births, not a band",
                loaded.getLastBirths(), 2716.3657466521263, .01);
        check("...and the city is the size it was saved at",
                loaded.total(), 1226166.7380806038, .01);

        /* ---- 6. and a malformed one is still refused whole ---- */
        PopulationCohorts guard = new PopulationCohorts();
        guard.migrate(5000);
        double kept = guard.total();
        guard.restore(names, new double[]{1, 2, 3});
        check("a malformed named pyramid is refused too", guard.total(), kept, .01);

        theOtherTwoBandArraysSurviveItToo();
    }

    /* ===================================================================
       THE FAMILIES AND THE RING OF THE LONG SICK, SAME PROPERTY

       Three arrays in the save are band-indexed and all three used to take
       their width from the READING build. The pyramid was the one that would
       have been misread; these two would have failed differently and just as
       quietly:

         - FamilyModel writes the orphans in the MIDDLE of its array with the
           seekers and the unhoused-by-shape behind them, so one more band
           moves every offset after it. Every save on disk would have been one
           slot short of all five accepted lengths, and restore() would have
           returned at the guard having restored nothing at all - not the
           orphans, not the household matrix, not the formed-household memory.

         - Sickness checks its length with an exact !=, so every existing ring
           would have been refused and silently reseeded: a city that forgets
           who has been ill for eleven months, on the frame it loads.

       Both are asserted by round-tripping the array itself rather than by
       naming getters, because the array IS the contract and a getter-by-getter
       check tests whichever ones somebody remembered.
       =================================================================== */
    static void theOtherTwoBandArraysSurviveItToo() {
        System.out.println("\n--- the families and the sick ring survive it too ---");

        Game game = new Game(GameFiles.scratch("band-array-check"));
        game.newGame();
        for (int i = 0; i < 18; i++) game.toggleNextMonth();

        String[] names = PopulationCohorts.saveBands();
        int bands = names.length;

        /* ------------------------------ families ------------------------------ */
        double[] savedFamilies = game.getFamilies().toSaveArray();
        assertTrue("the fixture actually has families to save", savedFamilies.length > bands);

        String[] shapes = FamilyModel.saveShapes();
        FamilyModel back = new FamilyModel();
        back.restore(names, shapes, savedFamilies);
        sameArray("the families round-trip by name", back.toSaveArray(), savedFamilies);

        /*
         * A save written by THIS build read with the legacy lists must be
         * REFUSED, not half-read: thirteen shapes cannot describe a fifteen
         * shape array, and the thing that makes that safe is that no two
         * accepted lengths collide.
         */
        FamilyModel legacy = new FamilyModel();
        legacy.restore(null, null, savedFamilies);
        check("a today-save read as five bands and thirteen shapes is refused whole",
                legacy.getOrphansTotal(), 0, 1e-9);

        /*
         * A save carrying a band this build has never heard of. The orphan
         * block widens by one and EVERYTHING BEHIND IT SHIFTS - which is the
         * whole point: if the offsets were still taken from this build, the
         * seekers would be read as orphans and the household memory would be
         * lost, and the round-trip below would not match.
         *
         * TWO BLOCKS ARE BAND-INDEXED SINCE 2026-09-15, not one: the orphans,
         * and the children who went out of work with their parent at the very
         * end. So a band added is TWO slots, not one, and this fixture spliced
         * one and was refused - correctly, and it is a better test for having
         * had to learn it. The tail is spliced from the BACK first so the
         * orphan block's offset is still the one measured on the original.
         */
        String[] withExtra = java.util.Arrays.copyOf(names, bands + 1);
        withExtra[bands] = "A_BAND_FROM_THE_FUTURE";
        double[] widened = spliceOneSlot(savedFamilies, savedFamilies.length, 8_888);
        widened = spliceOneSlot(widened, orphanBlockEnd(bands, shapes.length), 7_777);

        FamilyModel wider = new FamilyModel();
        wider.restore(withExtra, shapes, widened);
        sameArray("...and a band from the future shifts nothing behind it",
                wider.toSaveArray(), savedFamilies);

        FamilyModel refused = new FamilyModel();
        refused.restore(names, shapes, new double[]{1, 2, 3});
        check("a malformed family array is refused whole", refused.getOrphansTotal(), 0, 1e-9);

        /* ------------------------------ the ring ------------------------------ */
        double[] savedRing = game.getSickness().getState();
        Sickness ring = new Sickness();
        assertTrue("the ring restores by name", ring.restore(names, savedRing));
        sameArray("...and round-trips", ring.getState(), savedRing);

        /*
         * A ring written by THIS build read with the legacy list must be
         * refused, not half-read - the same property the families have. Five
         * band names cannot describe a six-band ring, and the exact length
         * check is what makes that safe.
         */
        Sickness old = new Sickness();
        assertTrue("a today-ring read as five bands is refused whole", !old.restore(null, savedRing));

        /*
         * ...and a genuinely old ring, five bands wide, still loads. Built at
         * the legacy width on purpose rather than from this build's, because
         * that is the file sitting on somebody's disk.
         */
        int legacyBands = PopulationCohorts.LEGACY_BANDS.length;
        double[] legacyRing = new double[legacyBands * Sickness.RING + legacyBands + 2];
        for (int k = 0; k < legacyRing.length; k++) legacyRing[k] = k + 1;
        legacyRing[legacyRing.length - 1] = 1;          // seeded
        Sickness fromDisk = new Sickness();
        assertTrue("a five-band ring from before the names still loads", fromDisk.restore(null, legacyRing));
        assertTrue("...and it put somebody in the ring", fromDisk.getState().length > 0);

        Sickness stranger = new Sickness();
        assertTrue("a ring is refused whole when the width does not match its names",
                !stranger.restore(withExtra, savedRing));
    }

    /** Where FamilyModel's orphan block ends, counting from the front of its array. */
    static int orphanBlockEnd(int bands, int shapes) {
        int base = shapes * PayTier.values().length + 2;
        return base + 3 + 1 + bands;     // ...the matrix, the counts, outsideAdults, the orphans
    }

    /** The same array with one extra slot pushed in at `at`, everything behind it moved along. */
    static double[] spliceOneSlot(double[] source, int at, double value) {
        double[] out = new double[source.length + 1];
        System.arraycopy(source, 0, out, 0, at);
        out[at] = value;
        System.arraycopy(source, at, out, at + 1, source.length - at);
        return out;
    }

    static void sameArray(String label, double[] got, double[] wanted) {
        if (got.length != wanted.length) {
            System.out.printf("  FAIL  %s: %d slots, wanted %d%n", label, got.length, wanted.length);
            fails++;
            return;
        }
        for (int i = 0; i < got.length; i++) {
            if (Math.abs(got[i] - wanted[i]) > 1e-9) {
                System.out.printf("  FAIL  %s: slot %d is %s, wanted %s%n", label, i, got[i], wanted[i]);
                fails++;
                return;
            }
        }
        System.out.printf("%-58s %d slots  OK%n", label, got.length);
    }

    static void cleanUp(Path root) {
        try (var walk = Files.walk(root)) {
            walk.sorted(java.util.Comparator.reverseOrder()).forEach(p -> {
                try { Files.deleteIfExists(p); } catch (java.io.IOException ignored) { }
            });
        } catch (java.io.IOException ignored) { }
    }
}
