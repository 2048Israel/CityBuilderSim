package ham.citybuildersim;

/**
 * The city's tax rates - the revenue half of what the player actually decides.
 *
 * Both rates used to be one hardcoded field on EconomyManager. They live here
 * together because they are the same kind of thing, they are both set by the
 * player, they both have to survive a save, and because the two of them are
 * only interesting relative to each other: an income tax takes a share of what
 * a business earned, a property tax takes a share of what it owns whether it
 * earned anything or not. Which one the city leans on decides who actually pays
 * for it.
 *
 * ANNUAL IN, MONTHLY OUT
 *
 * Property tax is quoted annually, because that is how anyone who has ever paid
 * one thinks about it, and charged monthly, because that is the game's tick.
 * The conversion lives here and nowhere else - getting a 1.5%/year rate charged
 * as 1.5%/month would be an eighteen-fold error that still looks like a
 * plausible number on screen, so there is exactly one place it can be got wrong.
 *
 * Income tax is not converted: it is a share of a month's income, so the rate
 * applies to the month directly.
 *
 * ======================================================================
 * CITY RATES, AND OFFSETS FROM THEM
 * ======================================================================
 *
 * There are four base rates - one per tax: profit, sales, wage and property -
 * and then every band and every sector carries an OFFSET in rate points from
 * its own tax's base. Industry at -0.03 on profit pays three points under
 * whatever the profit rate is.
 *
 * Jerus's call, and it is the right one for a game where a base is a lever the
 * player pulls often: raise it and every sector you have customised keeps its
 * relative treatment instead of being silently left behind. The cost is that a
 * rate on screen is arithmetic rather than a number, so every screen shows the
 * offset AND what it resolves to.
 *
 * THREE BASES WHERE THERE WAS ONE (0.7.4). Until 0.7.4 profit, sales and wage
 * all moved off ONE city income rate, so raising sales tax for every sector
 * meant fifteen offsets or the city rate, and the city rate dragged profit and
 * wage with it. Jerus: "what about just increasing sale tax for all at the same
 * time? currently that's a hassle, i want to be able to do that for every type
 * of tax, even wage tax". Each of the three has its own base now, and
 * setIncomeTaxRate() is what his old city rate became: every income tax at
 * once, all three bases set to one number.
 *
 * RESOLUTION HAPPENS HERE, ONCE. effective*() clamps to [0, max]. No caller
 * adds an offset itself: an offset that escapes clamping is a negative tax rate,
 * which is the city paying businesses to trade, and it would show up as revenue
 * appearing from nowhere three layers away from the line that caused it.
 *
 * DEFAULTS ARE ALL ZERO, and the three bases open equal, which makes every
 * effective rate the one income rate and reproduces the single-rate behaviour
 * this replaced, exactly.
 */
public class TaxPolicy {

    /* =====================================================================
       THE DECISION LOG (0.7.23)

       Every dial on this class is the player's, and this is the one place
       each is applied - so a change is written here, as it is made, to the
       city's DecisionLog: "Taxes to 17%", "Pensions to 25% of a wage". A
       setter called with the value the dial already reads writes nothing.
       The city wires it (Game.buildWorld()) and holds it while it is built
       or loaded, which is when these setters run without anybody deciding.
       ===================================================================== */

    /** Where a change to a dial here is written; null for a policy no city holds. Never saved: the city wires it. */
    private transient DecisionLog decisions;

    /** Wires this policy to its city's decision log (Game.buildWorld()). */
    public void recordTo(DecisionLog log) { decisions = log; }

    private void decided(String kind, String label) {
        if (decisions != null) decisions.record(kind, label);
    }

    /** Where income tax started before it was a dial. */
    public static final double DEFAULT_INCOME_TAX = .15;

    /**
     * 1.5% a year, near the real-world average.
     *
     * Worth being conservative with. Property tax is charged on capital whether
     * or not it earned anything, so it is the one rate that can push a business
     * under while it is doing nothing wrong - and the city's biggest owner of
     * idle capital is its construction sector.
     */
    public static final double DEFAULT_PROPERTY_TAX = .015;

    /** Nobody has ever paid 100% property tax and the game should not model it. */
    public static final double MAX_PROPERTY_TAX = .10;

    /** Above this, income tax stops being a policy and starts being confiscation. */
    public static final double MAX_INCOME_TAX = .60;

    /**
     * How far a band or sector may be moved from its tax's base rate, either way.
     *
     * Bounded so a single offset cannot express a policy the base rate could not
     * express on its own - an offset is a discount or a surcharge, not a
     * separate tax system. A property offset is held tighter, at
     * MAX_PROPERTY_TAX (clampPropertyOffset(), B5).
     */
    public static final double MAX_OFFSET = .30;

    /*
     * THE THREE INCOME BASES (0.7.4), one per tax, where there was one income
     * rate - see CITY RATES, AND OFFSETS FROM THEM above. Each opens
     * at DEFAULT_INCOME_TAX, so a new city is the single-rate city it was.
     */
    private double profitTaxRate = DEFAULT_INCOME_TAX;
    private double salesTaxRate = DEFAULT_INCOME_TAX;
    private double wageTaxRate = DEFAULT_INCOME_TAX;
    private double propertyTaxRate = DEFAULT_PROPERTY_TAX;

    /* ==================================================================
       FARMLAND, AND WHAT IT IS ASSESSED AT (2026-09-13)

       A farm is the only building in this game whose cost is the GROUND
       rather than the structure. A Mixed Farm's shed and machinery come to
       $1.19m; the twenty-four city blocks under it are $3.1m in a young city
       and $144m in a grown one, and the property tax is struck on what the
       ground would FETCH. At a grown city's land price that bill is more than
       the field can grow on it, several times over, long before the city
       actually reaches the fence.

       THAT IS NOT A BUG, IT IS WHAT HAPPENS, and it is why almost every
       province and state assesses farmland at USE value rather than at
       development value - Ontario's Farm Property Class, Nova Scotia's
       resource-property rate, California's Williamson Act, and farm-use
       assessment in most of the United States all exist to stop a growing
       town taxing the market gardens off its own edge.

       So the player gets the same lever, with the same cost. At 0 the fields
       are assessed like anything else, the tax exceeds the harvest, and the
       city buys its dinner from strangers - which is a real outcome and a
       defensible one. At 1 the ground under a farm is assessed at nothing and
       only the barn is taxed, the fields survive the city growing round them,
       and the city forgoes the tax on what by then is a large share of its
       whole assessment. Jerus's call, 2026-09-13, taken against the
       alternative of simply making an acre of wheat out-earn an acre of
       houses, which is the opposite of the reason cities exist.

       IT TOUCHES THE LAND HALF ONLY. A barn is a building and is taxed like
       one; the relief is on the difference between what the ground is worth to
       a developer and what it is worth to a farmer, which is exactly what the
       real programmes relieve.

       Defaults to full relief because that is what the real default is almost
       everywhere, and because a player who never finds the dial should get the
       behaviour a real jurisdiction has rather than the one nobody chose.
       ================================================================== */
    public static final double DEFAULT_FARMLAND_RELIEF = 1.0;

    /** The sector whose ground the relief applies to. */
    public static final String FARM_SECTOR = Sectors.AGRICULTURE;

    private double farmlandRelief = DEFAULT_FARMLAND_RELIEF;

    /** 0 assesses a field like a building lot; 1 assesses only what stands on it. */
    public double getFarmlandRelief() { return farmlandRelief; }

    public void setFarmlandRelief(double share) {
        double was = farmlandRelief;
        this.farmlandRelief = share < 0 ? 0 : Math.min(share, 1);
        if (DecisionLog.moved(was, farmlandRelief)) {
            decided(DecisionLog.TAX, "Farmland relief to " + DecisionLog.pct(farmlandRelief));
        }
    }

    /**
     * The share of a sector's LAND that is on the assessment roll. One for
     * everybody; less for the fields, by however much the player has relieved
     * them. See EconomyManager.getAssessedValue().
     */
    public double assessedLandShare(String sector) {
        return FARM_SECTOR.equals(sector) ? 1 - farmlandRelief : 1;
    }

    /* =====================================================================
       THE PENSION PROMISE, AS TWO DIALS

       They were constants on SocialSecurity, and constants are the wrong shape
       for the only two numbers in the game that are a POLICY CHOICE about the
       age structure. A city whose pyramid is greying has exactly two levers -
       charge the workers more, or pay the pensioners less - and until now it
       had neither.

       They live here rather than on SocialSecurity because this is the class
       that is saved, has a screen, and already holds every other rate the
       player sets. SocialSecurity keeps the arithmetic and now takes the rate
       as an argument, which also makes it testable at rates nobody has set.
       ===================================================================== */

    private double contributionRate  = SocialSecurity.DEFAULT_CONTRIBUTION_RATE;
    private double pensionReplacement = SocialSecurity.DEFAULT_PENSION_REPLACEMENT;

    /** Nobody hands over more than a fifth of a wage, whatever the deficit. */
    public static final double MAX_CONTRIBUTION = .20;

    /** A pension of more than one unskilled wage is a wage, not a pension. */
    public static final double MAX_REPLACEMENT = 1.00;

    public double getContributionRate()   { return contributionRate; }
    public double getPensionReplacement() { return pensionReplacement; }

    public void setContributionRate(double rate) {
        double was = contributionRate;
        contributionRate = Math.max(0, Math.min(MAX_CONTRIBUTION, rate));
        if (DecisionLog.moved(was, contributionRate)) {
            decided(DecisionLog.PROMISE, "CPP contributions to " + DecisionLog.pct(contributionRate));
        }
    }

    public void setPensionReplacement(double share) {
        double was = pensionReplacement;
        pensionReplacement = Math.max(0, Math.min(MAX_REPLACEMENT, share));
        if (DecisionLog.moved(was, pensionReplacement)) {
            decided(DecisionLog.PROMISE, "Pensions to " + DecisionLog.pct(pensionReplacement) + " of a wage");
        }
    }

    /* =====================================================================
       EMPLOYMENT INSURANCE AND THE STUDENT GRANT, AS THREE MORE DIALS
       (2026-09-11)

       Jerus: EI "like CPP" - a premium off every wage into the treasury,
       pay-as-you-go, and a policy dial. The same shape as the pension's two:
       what the workers pay, and what the out of work draw. And the grant a
       full-time student is paid, beside them, because it is the same kind of
       promise. Defaults are the real 2026 figures; see Unemployment and
       StudentHousehold.
       ===================================================================== */

    private double eiPremiumRate = Unemployment.DEFAULT_PREMIUM_RATE;
    private double eiBenefitRate = Unemployment.DEFAULT_BENEFIT_RATE;

    /**
     * The Canada Student Grant, $525 a month of study (2026-27), as a share of
     * the $3,460 unskilled median the ladder is anchored on - so it moves with
     * the wage it was measured against and with a currency reform. The
     * WAGE_SHARE basis's own default share, and the founding rule until 0.7.19.
     */
    public static final double DEFAULT_STUDENT_GRANT_SHARE = 525.0 / 3_460;

    /**
     * THE GRANT FOLLOWS PRICES (0.7.19): the default grant as a FIXED amount,
     * in founding thousands - $525 a month, the Canada Student Grant (2026-27)
     * this basis's share was read off, so at founding, when the price index
     * is one and the unskilled wage is PayTier's $3,460, it pays exactly what
     * DEFAULT_STUDENT_GRANT_SHARE of that wage did. Kept up with prices by
     * the expected price level since 0.7.42 (grantBill(); the price index
     * from 0.7.19), the way Canada's
     * grants are fixed dollar amounts reviewed against the cost of living
     * rather than a share of any wage (the full-time grant was $3,000 a year
     * to 2021 and $4,200 from 2023-24, set by budget, not by a wage - see
     * the banner at DEFAULT_GRANT_BASIS).
     */
    public static final double DEFAULT_FIXED_GRANT = DEFAULT_STUDENT_GRANT_SHARE * PayTier.UNSKILLED.getMonthlyWage();

    /** A premium past a tenth of a wage is a second income tax. */
    public static final double MAX_EI_PREMIUM = .10;

    /** EI that replaces more than the wage pays people to stay out of work. */
    public static final double MAX_EI_BENEFIT = 1.00;

    /** A grant of more than an unskilled wage is a wage: the ceiling on the WAGE_SHARE basis's share. */
    public static final double MAX_STUDENT_GRANT = 1.00;

    public double getEiPremiumRate()     { return eiPremiumRate; }
    public double getEiBenefitRate()     { return eiBenefitRate; }

    /* ------------------------- FOOD ASSISTANCE (0.7.43) -------------------------

       Jerus's dial, the project's spec-inflation.md 2.9: groceries are priced
       now, and a price rations - the poorest are priced out first. The city
       can answer with a voucher: the treasury pays this share of an eligible
       household's baskets at the shelf price (HouseholdBalance
       .foodAssistanceFor(), FOOD_ASSISTANCE_MEANS_SHARE says who is
       eligible), on the baskets it actually got, as a promise
       (TreasuryLine.FOOD_ASSISTANCE). A share of a basket, so it is real
       whatever prices do. 0 by default: a city without it is the city it was.
       Measured on the founding at 50%: hunger at year ten 4.1% to 2.9%, the
       clearing price 3-4% dearer, the same food sold - to the poor.
       --------------------------------------------------------------------------- */

    /** No voucher: the city it was. */
    public static final double DEFAULT_FOOD_ASSISTANCE = 0;

    /** A voucher for every basket an eligible household eats is the most there is. */
    public static final double MAX_FOOD_ASSISTANCE = 1.00;

    private double foodAssistance = DEFAULT_FOOD_ASSISTANCE;

    /** The share of an eligible household's baskets, at the shelf price, the treasury's voucher covers. */
    public double getFoodAssistance() { return foodAssistance; }

    public void setFoodAssistance(double share) {
        double was = foodAssistance;
        foodAssistance = clamp(share, MAX_FOOD_ASSISTANCE);
        if (DecisionLog.moved(was, foodAssistance)) {
            decided(DecisionLog.PROMISE, "Food assistance to " + DecisionLog.pct(foodAssistance));
        }
    }

    /**
     * The share of the unskilled wage a student is granted a month: the
     * amount under the WAGE_SHARE basis, and nothing under any other, because
     * under any other there is no such share. See getGrantBasis().
     */
    public double getStudentGrantShare() {
        return grantBasis == GrantBasis.WAGE_SHARE ? grantAmount : 0;
    }

    public void setEiPremiumRate(double rate) {
        double was = eiPremiumRate;
        eiPremiumRate = clamp(rate, MAX_EI_PREMIUM);
        if (DecisionLog.moved(was, eiPremiumRate)) {
            decided(DecisionLog.PROMISE, "EI premium to " + DecisionLog.pct(eiPremiumRate));
        }
    }

    public void setEiBenefitRate(double share) {
        double was = eiBenefitRate;
        eiBenefitRate = clamp(share, MAX_EI_BENEFIT);
        if (DecisionLog.moved(was, eiBenefitRate)) {
            decided(DecisionLog.PROMISE, "EI to " + DecisionLog.pct(eiBenefitRate) + " of a wage");
        }
    }

    /** The grant as a share of the unskilled wage - the founding basis until 0.7.19, at this share. */
    public void setStudentGrantShare(double share) {
        GrantBasis wasBasis = grantBasis;
        double was = grantAmount;
        grantBasis = GrantBasis.WAGE_SHARE;
        grantAmount = clamp(share, MAX_STUDENT_GRANT);
        grantDecided(wasBasis, was);
    }

    /* =====================================================================
       THE PRICE OF A PLACE - THE GRANT'S BASIS, THE LOAN'S RATE AND THE
       TUITION SCALE (2026-09-21)

       Jerus: "yes grants and government tuition are in the game, but what
       about more granularity, so perhaps, grants its just a menu where you
       can choose between a fixed amount, or a percentage of last month's
       surplus, or a % as it is now of living costs, or a % of tuition. and
       then another slider which is the interest rate for the student loans,
       and idk if real life is like that but have it so that the money is
       withdrawn from the treasury and then later when they pay it back it's
       added back, and you get the interest if there is any. ... and also
       make it so that you can tweak the price of tuition as well."

       Three more dials in the EI premium's shape, and the grant's one share
       becomes a MENU:

         grantBasis, grantAmount   what the grant is a share of, or is, and
                                   the one number that goes with it. The
                                   founding rule - a share of the unskilled
                                   wage, per student per month ("as it is
                                   now"; Jerus said living costs, and the
                                   wage is what that has always been struck
                                   against) - is one of four. The others: a
                                   fixed amount a month; a share of LAST
                                   month's budget surplus as one pool split
                                   over this month's students, nothing in a
                                   deficit month; a share of each student's
                                   own course tuition at today's price. The
                                   amount is in the basis's own unit and has
                                   a ceiling per basis, below. TaxPolicy
                                   strikes the bill (grantBill) and Game
                                   hands it the four figures it needs
                                   (Game.studentGrantBillUnder); every
                                   reader - the treasury's bill, the
                                   save's re-strike, the students' income,
                                   the Schools page - goes through that one
                                   method.
         studentLoanRate           annual, on the treasury's student loans.
                                   Interest is charged on a GRADUATE's
                                   balance during repayment only - the
                                   Canadian shape, the government carrying
                                   the interest while the student studies -
                                   and it lands in the treasury as its own
                                   revenue line, beside the premiums; the
                                   principal keeps coming back through the
                                   journal's line as it did. Zero by default,
                                   as Canada's loans have been since April
                                   2023. See Household's THE LOAN'S RATE.
         tuitionScale              a multiplier on the founding tuition table,
                                   Healthcare's fee scale for the schools. 1
                                   is the founding price; 0 is free; the
                                   poverty trap the Education header describes
                                   returns around x3 against today's wages.
                                   Education.foundingTuition() stays the
                                   founding table; what a seat is charged at,
                                   what a household measures against its wage,
                                   what the treasury collects and forgoes, and
                                   the TUITION_SHARE grant all read the scaled
                                   fee.

       The loan rate and the scale are RATIOS and a currency reform leaves
       them alone; a FIXED grant is money and is scaled with it. All four
       ride this class's save array on the end: an old save reads WAGE_SHARE
       at the share its old slot already carried, no interest and the
       founding price, which is the game it was.

       A SCALE PER SCHOOL WHERE THERE WAS ONE (0.7.6). Jerus: "have it so
       that not only can you raise prices but also raise the price for a
       specific university". The one tuition scale is nine now, one per
       EducationType bar NONE - tuitionScaleOf() and setTuitionScaleOf() -
       each opening at DEFAULT_TUITION_SCALE and held to MAX_TUITION_SCALE,
       which is the shape 0.7.4 gave the income taxes (THREE BASES WHERE
       THERE WAS ONE, under THE CITY RATES): setTuitionScale() is what the
       one scale became, every school at once, all nine set to one number;
       getTuitionScale() reads the first of the nine, ELEMENTARY's, and
       tuitionScalesSplit() says whether they have parted. The old slot in
       the save array carries getTuitionScale(), and the nine ride the end;
       an older, shorter array reads all nine as the one scale it carried.
       ===================================================================== */

    /** How the student grant is struck: what the one amount is a share of, or is. */
    public enum GrantBasis {
        /** A share of the unskilled wage, per student per month - the founding rule until 0.7.19, and what an older save that chose nothing keeps. */
        WAGE_SHARE,
        /** A fixed REAL amount per student per month, in founding thousands, kept up with prices - by the expected price level since 0.7.42, the price index from 0.7.19 (a nominal amount until then) - the default since 0.7.19. Money, so a currency reform scales it. */
        FIXED,
        /** A share of last month's budget surplus as ONE POOL, split evenly over this month's students; a deficit month pays nothing. */
        SURPLUS_SHARE,
        /** A share of each student's own course tuition at today's price - after the tuition scale, before the subsidy. */
        TUITION_SHARE
    }

    /*
     * THE GRANT FOLLOWS PRICES (0.7.19). Jerus, on "Money and prices: which of
     * these?", chose "Grant follows prices": "The student grant follows the
     * cost of living (or the median wage) instead of the unskilled wage."
     *
     * WHAT IT REPLACED. The default was WAGE_SHARE: a share of the unskilled
     * wage, which tracks the SCARCEST wage in a city short of labourers. In
     * Jerus's 0.7.14 city the grant was 0.1517 x 146,615 students x a $68.30k
     * unskilled wage - $1,519.4M a month, of which $1,092.0M (72%) was the
     * wage's scarcity multiple, not the cost of living (the trace's Q2).
     *
     * THE BASIS ALREADY EXISTED: FIXED, a fixed amount a month. It is now a
     * REAL amount - in founding thousands, times the price index the city
     * already keeps (PriceIndex, what a month costs a household against
     * founding; the expected price level since 0.7.42, the anchor's, like
     * every money constant) - so it keeps what it buys, and it is the default, at
     * DEFAULT_FIXED_GRANT: at founding, the old default's bill to the cent.
     * The source is the grant's own shape. Canada Student Grants are fixed
     * dollar amounts per year of study set in the federal budget and
     * reviewed against costs (the full-time grant: $3,000 a year to 2021,
     * $4,200 from 2023-24 - ESDC, Canada Student Financial Assistance
     * Program), not a share of any wage.
     *
     * OLD SAVES KEEP THE BASIS THEY CHOSE. A save carries its basis, so a
     * city on WAGE_SHARE - chosen or left at the old default, which the save
     * cannot tell apart - stays on it; only a new game starts on FIXED. A
     * save from before the basis existed (2026-09-21) carries no choice at
     * all and reads WAGE_SHARE at the share its slot carried, as it always
     * did: the rule it was played under. A FIXED grant in a save from before
     * 0.7.19 was a NOMINAL amount; it is read as the real amount that pays
     * the same the month it is loaded (realiseFixedGrant()), so the grant
     * does not jump on the load and keeps up with prices from there.
     */

    /** Where the grant starts: a fixed real amount, kept up with prices - the expected price level since 0.7.42, the price index from 0.7.19 (the founding rule, a share of the unskilled wage, until then). */
    public static final GrantBasis DEFAULT_GRANT_BASIS = GrantBasis.FIXED;

    /** A fixed grant of more than one unskilled wage a month is a wage: the FIXED ceiling, in founding unskilled wages, struck against that wage in today's money. */
    public static final double MAX_FIXED_GRANT_WAGES = 1.00;

    /** The whole of last month's surplus, and no more: the SURPLUS_SHARE ceiling. */
    public static final double MAX_SURPLUS_GRANT_SHARE = 1.00;

    /** Twice the course's tuition: the TUITION_SHARE ceiling, so a grant can cover the fee and living costs on top. */
    public static final double MAX_TUITION_GRANT_SHARE = 2.00;

    /** Where the loan rate starts: no interest, as Canada's loans have been since April 2023. */
    public static final double DEFAULT_STUDENT_LOAN_RATE = 0;

    /** Fifteen per cent a year: past any rate a government has charged a student, and the dial's ceiling. */
    public static final double MAX_STUDENT_LOAN_RATE = .15;

    /** Where the tuition scale starts: the founding table, unscaled. */
    public static final double DEFAULT_TUITION_SCALE = 1.0;

    /** Five times the founding table: the trap the Education header describes returns around x3 against today's wages (university 3.60 against a diploma wage of 4.500 is past MAX_BURDEN unsubsidised), so x5 leaves room past it; a ceiling, not a default. */
    public static final double MAX_TUITION_SCALE = 5.0;

    /**
     * What the grant is a share of, or is. An old save reads WAGE_SHARE - the
     * only basis there was.
     */
    private GrantBasis grantBasis = DEFAULT_GRANT_BASIS;

    /**
     * The grant's one number, in the basis's own unit: a share of the wage, a
     * fixed real amount in founding thousands, a share of the surplus, or a
     * share of the tuition. An old save reads its wage share into this, from
     * the slot that always carried it.
     */
    private double grantAmount = DEFAULT_FIXED_GRANT;

    /** True while a FIXED amount read from a save before 0.7.19 is still nominal, until realiseFixedGrant() reads it at the load month's level (the expected price level since 0.7.42; the price index before). Never saved. */
    private boolean fixedGrantNominal;

    /** Annual interest on the treasury's student loans. An old save reads none. */
    private double studentLoanRate = DEFAULT_STUDENT_LOAN_RATE;

    /**
     * The multiplier on the founding tuition table, one per school kind by
     * EducationType ordinal (0.7.6). NONE's slot is never read, set or saved:
     * a building that teaches nothing has no price. An old save reads 1 on
     * every kind.
     */
    private final double[] tuitionScales = new double[EducationType.values().length];
    { java.util.Arrays.fill(tuitionScales, DEFAULT_TUITION_SCALE); }

    /** The nine kinds a school can be, in EducationType order: everything bar NONE (0.7.6). */
    private static final EducationType[] SCHOOL_KINDS = schoolKinds();

    private static EducationType[] schoolKinds() {
        java.util.List<EducationType> kinds = new java.util.ArrayList<>();
        for (EducationType type : EducationType.values()) {
            if (type != EducationType.NONE) kinds.add(type);
        }
        return kinds.toArray(new EducationType[0]);
    }

    public GrantBasis getGrantBasis() { return grantBasis; }

    /** The amount that goes with getGrantBasis(), in that basis's unit. */
    public double getGrantAmount()    { return grantAmount; }

    /** The annual rate a graduate is charged on the student loan while repaying it. */
    public double getStudentLoanRate(){ return studentLoanRate; }

    /**
     * The multiplier on the founding tuition table; 1 is the founding price,
     * 0 is free at the point of use. EVERY SCHOOL AT ONCE (0.7.6): while the
     * nine kinds are equal, which they are in any city that has only ever
     * moved them together, that one scale; once they have parted, the first
     * kind's, ELEMENTARY's - what the old slot of the save carries for a
     * reader that knows only one. A caller that means one kind asks
     * tuitionScaleOf(); a screen that prints "the scale" asks
     * tuitionScalesSplit() first.
     */
    public double getTuitionScale()   { return tuitionScales[SCHOOL_KINDS[0].ordinal()]; }

    /** One school kind's own multiplier (0.7.6); NONE, or null, reads the every-school one. */
    public double tuitionScaleOf(EducationType type) {
        return type == null || type == EducationType.NONE ? getTuitionScale()
                : tuitionScales[type.ordinal()];
    }

    /** Whether the nine kinds' scales have parted - no longer one number (0.7.6). */
    public boolean tuitionScalesSplit() {
        double first = getTuitionScale();
        for (EducationType type : SCHOOL_KINDS) {
            if (Math.abs(tuitionScales[type.ordinal()] - first) > 1e-12) return true;
        }
        return false;
    }

    /**
     * The ceiling on the amount under a basis: a share of a wage up to one
     * wage, a fixed amount up to an unskilled wage (the founding wage in
     * today's unit - a real amount against a real one since 0.7.19), the
     * whole surplus, twice the tuition. pensionWageBase carries that wage at
     * the expected price level since 0.7.42 (seedConstants()), so the
     * ceiling takes the level back out: the amount is in founding money.
     */
    public double maxGrantAmount(GrantBasis basis) {
        if (basis == null) return MAX_STUDENT_GRANT;
        switch (basis) {
            case FIXED:         return MAX_FIXED_GRANT_WAGES * pensionWageBase / expectedLevel;
            case SURPLUS_SHARE: return MAX_SURPLUS_GRANT_SHARE;
            case TUITION_SHARE: return MAX_TUITION_GRANT_SHARE;
            default:            return MAX_STUDENT_GRANT;
        }
    }

    /** Picks the basis; the amount is clamped to the new basis's ceiling and otherwise left where it was. */
    public void setGrantBasis(GrantBasis basis) {
        GrantBasis wasBasis = grantBasis;
        double was = grantAmount;
        grantBasis = basis == null ? DEFAULT_GRANT_BASIS : basis;
        grantAmount = clamp(grantAmount, maxGrantAmount(grantBasis));
        grantDecided(wasBasis, was);
    }

    /** Sets the amount, in the current basis's unit, clamped to its ceiling. */
    public void setGrantAmount(double amount) {
        double was = grantAmount;
        grantAmount = clamp(amount, maxGrantAmount(grantBasis));
        grantDecided(grantBasis, was);
    }

    /** Both at once, so a screen can stage them together - and one line in the log for the two. */
    public void setGrant(GrantBasis basis, double amount) {
        GrantBasis wasBasis = grantBasis;
        double was = grantAmount;
        grantBasis = basis == null ? DEFAULT_GRANT_BASIS : basis;
        grantAmount = clamp(amount, maxGrantAmount(grantBasis));
        grantDecided(wasBasis, was);
    }

    /** The grant's line in the decision log, when its basis or its amount moved (0.7.23). */
    private void grantDecided(GrantBasis wasBasis, double wasAmount) {
        if (wasBasis == grantBasis && !DecisionLog.moved(wasAmount, grantAmount)) return;
        String amount = switch (grantBasis) {
            case FIXED         -> DecisionLog.money(grantAmount) + " a month at founding prices";
            case SURPLUS_SHARE -> DecisionLog.pct(grantAmount) + " of the surplus";
            case TUITION_SHARE -> DecisionLog.pct(grantAmount) + " of tuition";
            default            -> DecisionLog.pct(grantAmount) + " of a wage";
        };
        decided(DecisionLog.PROMISE, "Student grant to " + amount);
    }

    public void setStudentLoanRate(double annual) {
        double was = studentLoanRate;
        studentLoanRate = clamp(annual, MAX_STUDENT_LOAN_RATE);
        if (DecisionLog.moved(was, studentLoanRate)) {
            decided(DecisionLog.PROMISE, "Student loan rate to " + DecisionLog.pct(studentLoanRate));
        }
    }

    /**
     * Every school at once: all nine kinds set to this scale (0.7.6), which
     * is what the one scale did. The Schools page's top lever, the
     * playtest's switch and a save from before the split all come through
     * here, so a city that never parts them is the city it was.
     */
    public void setTuitionScale(double scale) {
        double s = clamp(scale, MAX_TUITION_SCALE);
        boolean moved = false;
        for (EducationType type : SCHOOL_KINDS) {
            moved |= DecisionLog.moved(tuitionScales[type.ordinal()], s);
            tuitionScales[type.ordinal()] = s;
        }
        if (moved) decided(DecisionLog.PROMISE, "Tuition, every school, to " + DecisionLog.times(s));
    }

    /** One school kind's own scale, held to MAX_TUITION_SCALE (0.7.6); NONE, or null, is ignored. */
    public void setTuitionScaleOf(EducationType type, double scale) {
        if (type == null || type == EducationType.NONE) return;
        double was = tuitionScales[type.ordinal()];
        tuitionScales[type.ordinal()] = clamp(scale, MAX_TUITION_SCALE);
        if (DecisionLog.moved(was, tuitionScales[type.ordinal()])) {
            decided(DecisionLog.PROMISE, "Tuition, " + type.getLabel() + ", to "
                    + DecisionLog.times(tuitionScales[type.ordinal()]));
        }
    }

    /**
     * The month's grant bill under any basis and amount - the one place the
     * four rules are written, so the treasury's bill, the save's re-strike,
     * the students' income and the Schools page's preview cannot disagree.
     *
     *   WAGE_SHARE     students x amount x the unskilled wage, in that order:
     *                  the founding expression until 0.7.19, and at the
     *                  founding share it is bit for bit the bill it always was.
     *   FIXED          students x amount x the expected price level: a real
     *                  amount (0.7.19), kept up with what prices are expected
     *                  to be since 0.7.42 (the price index until then).
     *   SURPLUS_SHARE  amount x last month's surplus, as ONE pool - a deficit
     *                  is a pool of nothing - and nothing at all with nobody
     *                  to split it over. Per student it is the pool over the
     *                  students.
     *   TUITION_SHARE  amount x what the whole student body is charged at
     *                  today's price, before the subsidy: each student's own
     *                  course fee, so a medical student is granted more than
     *                  a college one.
     *
     * @param students           full-time students this month
     * @param unskilledWage      what an unskilled post pays a month, today
     * @param priceIndex         the expected price level against founding
     *                           (Expectations.getExpectedLevel(), since 0.7.42;
     *                           PriceIndex.getIndex() before), for the FIXED basis
     * @param lastSurplus        last month's budget balance, as the Government
     *                           tab shows it; negative in a deficit month
     * @param studentBodyTuition the whole adult student body's tuition a month
     *                           at today's price, before the subsidy
     */
    public static double grantBill(GrantBasis basis, double amount, double students,
                                   double unskilledWage, double priceIndex, double lastSurplus,
                                   double studentBodyTuition) {
        if (basis == null) basis = DEFAULT_GRANT_BASIS;
        switch (basis) {
            case FIXED:         return students * amount * Math.max(0, priceIndex);
            case SURPLUS_SHARE: return students > 0 ? amount * Math.max(0, lastSurplus) : 0;
            case TUITION_SHARE: return amount * Math.max(0, studentBodyTuition);
            default:            return students * amount * unskilledWage;
        }
    }

    /* =====================================================================
       HEALTHCARE HAS A PRICE, AND A PREMIUM (2026-09-19)

       Jerus: "healthcare should be an adjustable price, all the way to even
       make it a profitable business or the option to make it an obligatory
       insurance payment system." Two dials in the EI premium's shape:

         healthFeeScale    a multiplier on the three care fees. 0 is care free
                           at the point of use; the scale that recovers the
                           service's cost is the city's own (Healthcare
                           .breakEvenScale(), x7 to x13 in the played cities,
                           because wages have risen against the founding
                           fees, and the dial runs to 15 so it is reachable);
                           past it, a business. FUNERAL FEES ARE NOT
                           SCALED - the cemetery-against-crematorium design is
                           its own thing and keeps its own prices.
         healthPremiumRate a share of every wage, employee side, into the
                           treasury as revenue. No employer share and no
                           automatic balancing, per Jerus: what it raises goes
                           against the service's cost, and the gap either way
                           is the treasury's.

       Fees 0 and premium 0 is tax-funded care; fees up is fee-funded;
       fees 0 and a premium is insurance; anything between is a mix. AND A
       FEE CAN PRICE PEOPLE OUT: a household that cannot pay its care bill
       after its savings, its shares and its credit goes without care rather
       than without food - see Household.affordCare() - so a high fee is a
       sicker city. That is what makes the dial a decision.

       Both are RATIOS, not money, so a currency reform leaves them alone;
       both ride this class's save array, on the end, and an old save reads
       1 and 0, which is the game it was.
       ===================================================================== */

    /** Where the fee scale starts: the founding fees, unscaled. */
    public static final double DEFAULT_HEALTH_FEE_SCALE = 1.0;

    /** Fifteen times the founding fees: past every played city's break-even (x7 to x13 at today's wages), so the business corner is reachable; a ceiling, not a default. */
    public static final double MAX_HEALTH_FEE_SCALE = 15.0;

    /** Where the health premium starts: nobody pays one until the player says so. */
    public static final double DEFAULT_HEALTH_PREMIUM = 0;

    /** A health premium past a tenth of a wage is a second income tax, as the EI premium's ceiling says. */
    public static final double MAX_HEALTH_PREMIUM = .10;

    private double healthFeeScale = DEFAULT_HEALTH_FEE_SCALE;
    private double healthPremiumRate = DEFAULT_HEALTH_PREMIUM;

    /** The multiplier on the three care fees; 1 is the founding fee, 0 is free at the point of use. */
    public double getHealthFeeScale()   { return healthFeeScale; }

    /** The share of every wage the health premium takes, employee side. */
    public double getHealthPremiumRate(){ return healthPremiumRate; }

    public void setHealthFeeScale(double scale) {
        double was = healthFeeScale;
        healthFeeScale = clamp(scale, MAX_HEALTH_FEE_SCALE);
        if (DecisionLog.moved(was, healthFeeScale)) {
            decided(DecisionLog.PROMISE, "Clinic fees to " + DecisionLog.times(healthFeeScale));
        }
    }

    public void setHealthPremiumRate(double rate) {
        double was = healthPremiumRate;
        healthPremiumRate = clamp(rate, MAX_HEALTH_PREMIUM);
        if (DecisionLog.moved(was, healthPremiumRate)) {
            decided(DecisionLog.PROMISE, "Health premium to " + DecisionLog.pct(healthPremiumRate));
        }
    }

    /**
     * A pension, in TODAY's money.
     *
     * SocialSecurity computes this as `replacement x PayTier.UNSKILLED`, which
     * is a compile-time money constant read every month - so a reformed city
     * went on paying its pensioners the FOUNDING cheque out of the new,
     * hundred-times-smaller money. Measured at a factor of two: seniors
     * received 110.65 where 55.32 was due, and they were the last row in the
     * household matrix that would not come into line.
     *
     * (The wage this is struck against does not move with the labour market
     * either. Until 0.7.42 it did not move with prices, so a pension was
     * frozen in nominal terms for three centuries; since then its base is
     * struck at the expected price level every month (seedConstants()), so a
     * pension keeps up with what prices are expected to be while wages pull
     * ahead of it. The labour-market half is a separate design question -
     * filed, not fixed.)
     */
    public double pensionPerSenior() {
        return pensionReplacement * pensionWageBase;
    }

    /**
     * ...at another replacement rate, in today's money (0.7.36): what each
     * senior would be paid if the dial read `replacement`, on the same wage
     * base - the Policy tab's pension preview, which scaled today's bill by
     * the ratio of the two rates and so read nothing from a dial at zero.
     * SocialSecurity.pensionsFor() strikes the founding constant and is wrong
     * after a reform; this is not. Pure.
     */
    public double pensionPerSeniorAt(double replacement) {
        return Math.max(0, Math.min(MAX_REPLACEMENT, replacement)) * pensionWageBase;
    }

    /** The founding unskilled wage the pension is a share of, in today's unit at founding prices: the wage base over the level it is struck at (0.7.45, for the Policy tab's (i)). Pure. */
    public double foundingPensionWage() { return pensionWageBase / expectedLevel; }

    /** The wage a pension is a share of, carried in today's money - struck at the expected price level since 0.7.42 (seedConstants()). */
    private double pensionWageBase = PayTier.UNSKILLED.getMonthlyWage();

    public void redenominate(double scale) {
        pensionWageBase *= scale;
        /*
         * AND THE FARE, because it is a price and not a rate. Every other dial
         * on this class (bar a FIXED grant, since 2026-09-21 - below) is a
         * fraction and survives a reform untouched; a fare is dollars a
         * journey and a reform that left it alone would multiply the real
         * price of a bus ride by a hundred overnight. Twenty-third of
         * a family this codebase has been finding since September 8th, and the
         * first one caught in the same edit that created the field.
         */
        transitFare *= scale;
        /*
         * AND A FIXED GRANT (2026-09-21), for the fare's reason: it is dollars
         * a student a month, not a share of anything, and a reform that left
         * it alone would hand every student a hundred times the grant. Real
         * since 0.7.19 - founding dollars, in today's unit - and the level
         * it is multiplied by (the expected price level since 0.7.42, the
         * price index before) is a ratio a reform does not move, so the
         * amount alone scales. The grant's other three bases are shares and
         * do not move; nor do the loan rate and the tuition scale, which are
         * ratios.
         */
        if (grantBasis == GrantBasis.FIXED) grantAmount *= scale;
    }

    /* =======================================================================
       WHAT A RIDE COSTS (2026-09-16)

       The first price the city charges that a person can refuse to pay.

       Nobody chooses to be policed and a patient in a clinic is not shopping,
       so healthcare and safety are charges. A fare is a PRICE: set it high and
       people drive instead, and every one of them is back on the road the
       transit was built to empty. Jerus: "yes riders pay, yes its adjustable,
       to the point you can even make it profitable by alot" - and it can be,
       at a ridership the city may not want.

       A PRICE TO THE CAR OWNERS ONLY, SINCE 0.7.49. A commuter with no car of
       their own rides whatever the fare if a line reaches them, so a fare set
       high takes more of their money and puts only the owners back on the
       road (InfrastructureManager, WHO RIDES, BY WHAT THEY PAY).

       ZERO IS A LEGITIMATE SETTING and the default is not it. Free transit is
       a real policy with a real bill attached; the default is a fare that
       covers a decent share of the wages, because a city that has not thought
       about it should not be quietly running the buses for nothing.
       ======================================================================= */

    /** What a single journey costs a rider, in thousands. $2.50 a ride. */
    public static final double DEFAULT_TRANSIT_FARE = .0025;

    /** The dial's cap, $50 a ride, twenty times the default, in founding money: past it no car owner rides while a journey's fuel costs under half of it, and the commuters with no car of their own still do (0.7.49, InfrastructureManager, WHO RIDES, BY WHAT THEY PAY). */
    public static final double MAX_TRANSIT_FARE = .05;

    /* =======================================================================
       A RIDE IS NOT A MONTH (2026-09-17)

       Jerus: "the bus fares you got it right? the fact that you were charging
       2.5 for a month when in fact 2.50 for a month is way way way way too
       good of a deal lol" - and he is exactly right, and it had been wrong
       from the hour the fare was written.

       THE CONSTANT SAYS A JOURNEY AND THE ARITHMETIC SAID A MONTH. The city
       collected getTransitRiders() x getTransitFare(), and a rider is a
       PERSON: InfrastructureManager documents the figure as "commuters
       actually carried off the road this month", and the commuter load it is
       capped against is a headcount - jobs, plus 1.2 per home, straight out
       of BuildingsTemplate.loadOf(). So a city with fifty thousand people on
       its trams took a hundred and twenty-five thousand dollars a month for
       carrying them, every day, all month, and wondered why the buses lost
       money.

       AND THAT IS THE TRANSIT LOSS. The $5.4M a month the todo list has been
       carrying as a balance problem was never a balance problem. The wages
       were priced per month, because a driver is paid per month; the fare was
       priced per ride and then charged once. One of the two numbers was in
       the wrong unit and it was not the payroll.

       WHY FORTY. Two journeys a day - out and back, which is what a commuter
       is - times twenty working days. A monthly pass at the default fare is
       $100 against an unskilled wage of $3,460, or 2.9% of it, which is about
       what a real one costs a real low earner. Nothing here is tuned to a
       target; it is two trips a day and a working month.

       THE DIAL STAYS PER RIDE and that is deliberate. The player sets what a
       BUS TICKET costs, because that is the number a person on a platform
       recognises and the number the ridership curve is about - MAX_TRANSIT_FARE
       is $50 a ride, which is obviously absurd, and is meant to be. The
       multiplication into a month happens once, here, so that every place
       that needs the monthly figure asks for it rather than each deriving it.
       ======================================================================= */

    /** Journeys one commuter makes in a month: out and back, twenty days. */
    public static final double JOURNEYS_A_MONTH = 40;

    /**
     * What a month of riding costs one commuter, in thousands.
     *
     * The ONE source of the monthly figure. Game bills the households with it
     * and the national accounts collect it; anything that multiplies a rider
     * headcount by a fare wants this and not getTransitFare().
     */
    public double monthlyFare() { return monthlyFareAt(chargedFare()); }

    /** ...at a fare the city has not set (0.7.38): the fare dial's preview, the same one multiplication. */
    public static double monthlyFareAt(double fare) { return fare * JOURNEYS_A_MONTH; }

    private double transitFare = DEFAULT_TRANSIT_FARE;

    /* ------------------- THE FARE IS REAL (0.7.42, the anchor; star 9) -------------------

       The dial is a ride's price IN FOUNDING MONEY, like the minimum wage and
       a FIXED grant: what the player set keeps the worth they gave it. A
       rider is charged the dial times the level the month's money constants
       are struck at (Expectations.getStruckLevel(), the expected price level
       the last month ended on - told here by Game with every re-strike,
       setExpectedLevel()), so a $2.50
       fare in a city expecting prices 20% over founding charges $3.00. The
       ridership curve (InfrastructureManager.ridershipAt()) reads the dial
       against MAX_TRANSIT_FARE, both in founding money, so a fare's real
       price, not its nominal one, walks the riders down. Since 0.7.49 that
       curve walks down only the owners the jam puts on the bus: the owners
       choose by the charged fare against a journey's fuel at today's
       exchange rate, and the car-less ride at any fare (InfrastructureManager,
       WHO RIDES, BY WHAT THEY PAY). Until 0.7.42 the fare
       was a nominal price and inflation ate it. A save from before carries a
       nominal fare and is read as the real one that charges the same the
       month it loads (realiseFare()) - the same fare, because such a save
       loads at a level of 1.0.
       ---------------------------------------------------------------------- */

    /** The expected price level the fare is charged at; 1.0 until Game tells it. Derived, never saved. */
    private double expectedLevel = 1.0;

    /** True while a fare read from a save before 0.7.42 is still nominal, until realiseFare() reads it at the load month's level. Never saved. */
    private boolean fareNominal;

    /** The fare dial: a ride's price in founding money, in today's unit. What a rider pays is chargedFare(). */
    public double getTransitFare() { return transitFare; }

    /** What a ride is charged today: the dial at the expected price level (THE FARE IS REAL). */
    public double chargedFare() { return transitFare * expectedLevel; }

    /** Told by Game with every re-strike of the money constants; anything not positive is ignored. */
    public void setExpectedLevel(double level) {
        if (level > 0 && Double.isFinite(level)) expectedLevel = level;
    }

    /** The level the fare is charged at. */
    public double getExpectedLevel() { return expectedLevel; }

    /**
     * The currency's unit (Denomination.getUnit(), B6, 0.7.47): the dial is
     * founding money in today's unit and MAX_TRANSIT_FARE is founding money,
     * so the dial stops at the cap over the unit (maxTransitFare()). Told by
     * Game with every re-strike and at a reform's end; 1 until it is, and on a
     * restore, which runs before the load's re-strike - so a unit left from the
     * city loaded before cannot cut a saved fare. Derived, never saved.
     */
    private double moneyUnit = 1.0;

    /** Told by Game.restrikeMoneyConstants() and Game.reformCurrency(); anything not positive is ignored. */
    public void setMoneyUnit(double unit) {
        if (unit > 0 && Double.isFinite(unit)) moneyUnit = unit;
    }

    /** The most the fare dial takes in today's unit: MAX_TRANSIT_FARE over the unit, where no car owner rides. */
    public double maxTransitFare() { return MAX_TRANSIT_FARE / moneyUnit; }

    public void setTransitFare(double fare) {
        double was = transitFare;
        this.transitFare = Math.max(0, Math.min(maxTransitFare(), fare));
        if (DecisionLog.moved(was, transitFare)) {
            decided(DecisionLog.PROMISE, "Transit fare to " + DecisionLog.money(transitFare) + " at founding prices");
        }
    }

    /**
     * An older save's fare, read as the real fare that charges the same at
     * the load month's expected level (0.7.42): the nominal fare over the
     * level. Nothing for a save from 0.7.42 on, or a second call. Game's load
     * path calls it once the anchor is restored.
     */
    public void realiseFare(double level) {
        if (!fareNominal) return;
        fareNominal = false;
        if (level > 0) transitFare = transitFare / level;
    }

    /** Re-seeds the money CONSTANTS at a given unit. See Denomination. Since 0.7.42 Game calls it every month at the unit over the expected price level (Game.restrikeMoneyConstants()), so the pension's wage base keeps up with what prices are expected to be. */
    public void seedConstants(double unit) {
        pensionWageBase = PayTier.UNSKILLED.getMonthlyWage() / unit;
    }

    private final double[] wageOffset     = new double[WageBand.values().length];

    /*
     * THE SECTOR OFFSETS, KEYED BY THE SECTOR'S NAME (2026-09-11, the sector
     * template). They were three arrays indexed by PolicySector.ordinal(),
     * which was the cleanest registry-conversion candidate in the codebase
     * and the one that would have re-keyed every player's policy the day a
     * seventh sector was inserted anywhere but the end. A name is a name.
     * An unset sector reads zero, which is its tax's base rate - the same
     * default the arrays had.
     */
    private final java.util.Map<String, Double> profitOffset   = new java.util.LinkedHashMap<>();
    private final java.util.Map<String, Double> salesOffset    = new java.util.LinkedHashMap<>();
    private final java.util.Map<String, Double> propertyOffset = new java.util.LinkedHashMap<>();

    /* ==================================================================
       THE CITY RATES

       Four bases: profit, sales and wage since 0.7.4 (one income rate
       before), and property. "The income rate" survives as the three
       together - getIncomeTaxRate() and setIncomeTaxRate() below.
       ================================================================== */

    /**
     * The three income taxes TOGETHER - what "the city rate" was until 0.7.4.
     *
     * While the three bases are equal, which they are in any city that has
     * only ever moved them together, that one rate. Once they have parted,
     * the PROFIT rate: the first of the three, and what slot 0 of the save
     * carries for a reader that knows only one. A caller that means one tax
     * asks for it by name; a screen that prints "the income rate" asks
     * incomeRatesSplit() first and prints each when they have parted.
     */
    public double getIncomeTaxRate() {
        return profitTaxRate;
    }

    /** Whether the three income bases have parted - profit, sales and wage no longer one number. */
    public boolean incomeRatesSplit() {
        return Math.abs(profitTaxRate - salesTaxRate) > 1e-12
                || Math.abs(profitTaxRate - wageTaxRate) > 1e-12;
    }

    /** What every sector's profit tax moves off (0.7.4). */
    public double getProfitTaxRate() { return profitTaxRate; }

    /** What every sector's sales tax moves off (0.7.4). */
    public double getSalesTaxRate()  { return salesTaxRate; }

    /** What every band's wage tax moves off (0.7.4). */
    public double getWageTaxRate()   { return wageTaxRate; }

    public void setProfitTaxRate(double rate) {
        double was = profitTaxRate;
        profitTaxRate = clamp(rate, MAX_INCOME_TAX);
        if (DecisionLog.moved(was, profitTaxRate)) {
            decided(DecisionLog.TAX, "Profit tax to " + DecisionLog.pct(profitTaxRate));
        }
    }

    public void setSalesTaxRate(double rate) {
        double was = salesTaxRate;
        salesTaxRate = clamp(rate, MAX_INCOME_TAX);
        if (DecisionLog.moved(was, salesTaxRate)) {
            decided(DecisionLog.TAX, "Sales tax to " + DecisionLog.pct(salesTaxRate));
        }
    }

    public void setWageTaxRate(double rate) {
        double was = wageTaxRate;
        wageTaxRate = clamp(rate, MAX_INCOME_TAX);
        if (DecisionLog.moved(was, wageTaxRate)) {
            decided(DecisionLog.TAX, "Wage tax to " + DecisionLog.pct(wageTaxRate));
        }
    }

    /** The annual rate - what the player sets and what the screens show. */
    public double getPropertyTaxRate() {
        return propertyTaxRate;
    }

    /** The annual rate divided by twelve. What is actually charged each month. */
    public double getMonthlyPropertyTaxRate() {
        return propertyTaxRate / 12;
    }

    /**
     * Every income tax at once: the profit, sales and wage bases all set to
     * this rate (0.7.4), which is what the one city rate did. The Everything
     * page's lever, the playtest's advisor and a save from before the split
     * all come through here, so a city that never parts them is the city it
     * was.
     */
    public void setIncomeTaxRate(double rate) {
        double r = clamp(rate, MAX_INCOME_TAX);
        boolean moved = DecisionLog.moved(profitTaxRate, r) || DecisionLog.moved(salesTaxRate, r)
                || DecisionLog.moved(wageTaxRate, r);
        profitTaxRate = r;
        salesTaxRate = r;
        wageTaxRate = r;
        if (moved) decided(DecisionLog.TAX, "Taxes to " + DecisionLog.pct(r));
    }

    /** Takes the ANNUAL rate. */
    public void setPropertyTaxRate(double annualRate) {
        double was = propertyTaxRate;
        this.propertyTaxRate = clamp(annualRate, MAX_PROPERTY_TAX);
        if (DecisionLog.moved(was, propertyTaxRate)) {
            decided(DecisionLog.TAX, "Property tax to " + DecisionLog.pct(propertyTaxRate) + " a year");
        }
    }

    /* ==================================================================
       OFFSETS
       ================================================================== */

    public double getWageOffset(WageBand band)     { return wageOffset[band.ordinal()]; }
    public double getProfitOffset(String sector)   { return profitOffset.getOrDefault(sector, 0.0); }
    public double getSalesOffset(String sector)    { return salesOffset.getOrDefault(sector, 0.0); }
    public double getPropertyOffset(String sector) { return propertyOffset.getOrDefault(sector, 0.0); }

    public double getProfitOffset(Sector s)   { return getProfitOffset(s.key()); }
    public double getSalesOffset(Sector s)    { return getSalesOffset(s.key()); }
    public double getPropertyOffset(Sector s) { return getPropertyOffset(s.key()); }

    public void setWageOffset(WageBand band, double points) {
        double was = wageOffset[band.ordinal()];
        wageOffset[band.ordinal()] = clampOffset(points);
        offsetDecided("Wage tax", band.label(), was, wageOffset[band.ordinal()]);
    }

    public void setProfitOffset(String sector, double points) {
        if (sector == null) return;
        double was = getProfitOffset(sector);
        profitOffset.put(sector, clampOffset(points));
        offsetDecided("Profit tax", sector, was, getProfitOffset(sector));
    }

    public void setSalesOffset(String sector, double points) {
        if (sector == null) return;
        double was = getSalesOffset(sector);
        salesOffset.put(sector, clampOffset(points));
        offsetDecided("Sales tax", sector, was, getSalesOffset(sector));
    }

    /** In ANNUAL points, matching the rate it offsets; held at MAX_PROPERTY_TAX either way (clampPropertyOffset()), on a load too. */
    public void setPropertyOffset(String sector, double points) {
        if (sector == null) return;
        double was = getPropertyOffset(sector);
        propertyOffset.put(sector, clampPropertyOffset(points));
        offsetDecided("Property tax", sector, was, getPropertyOffset(sector));
    }

    /** An offset's line in the decision log, when it moved (0.7.23): "Profit tax, Retail, to -2 pts". */
    private void offsetDecided(String tax, String who, double was, double now) {
        if (DecisionLog.moved(was, now)) decided(DecisionLog.TAX, tax + ", " + who + ", to " + DecisionLog.points(now));
    }

    public void setProfitOffset(Sector s, double points)   { setProfitOffset(s.key(), points); }
    public void setSalesOffset(Sector s, double points)    { setSalesOffset(s.key(), points); }
    public void setPropertyOffset(Sector s, double points) { setPropertyOffset(s.key(), points); }

    /* ==================================================================
       EFFECTIVE RATES - the only numbers anything is ever charged at
       ================================================================== */

    /** What wages in this band are taxed at: the wage base and the band's offset. */
    public double effectiveWageRate(WageBand band) {
        return clamp(wageTaxRate + wageOffset[band.ordinal()], MAX_INCOME_TAX);
    }

    /** What this sector's profit is taxed at: the profit base and the sector's offset. */
    public double effectiveProfitRate(String sector) {
        return clamp(profitTaxRate + getProfitOffset(sector), MAX_INCOME_TAX);
    }

    /** What this sector charges on the value it adds: the sales base and its offset. See SalesTaxLedger. */
    public double effectiveSalesRate(String sector) {
        return clamp(salesTaxRate + getSalesOffset(sector), MAX_INCOME_TAX);
    }

    /** ANNUAL property tax rate for this sector. */
    public double effectivePropertyRate(String sector) {
        return clamp(propertyTaxRate + getPropertyOffset(sector), MAX_PROPERTY_TAX);
    }

    /** ...and the monthly one, which is what is actually billed. */
    public double effectiveMonthlyPropertyRate(String sector) {
        return effectivePropertyRate(sector) / 12;
    }

    public double effectiveProfitRate(Sector s)          { return effectiveProfitRate(s.key()); }
    public double effectiveSalesRate(Sector s)           { return effectiveSalesRate(s.key()); }
    public double effectivePropertyRate(Sector s)        { return effectivePropertyRate(s.key()); }
    public double effectiveMonthlyPropertyRate(Sector s) { return effectiveMonthlyPropertyRate(s.key()); }

    /**
     * What one month's property tax comes to on a given assessed value.
     *
     * The sector-blind version, kept for the one caller that has a value but no
     * sector - and for old tests. Prefer propertyTaxOn(value, sector).
     */
    public double propertyTaxOn(double assessedValue) {
        if (assessedValue <= 0) {
            return 0;   // a business that owns nothing owes nothing
        }
        return assessedValue * getMonthlyPropertyTaxRate();
    }

    /** One month's property tax at this sector's own rate. */
    public double propertyTaxOn(double assessedValue, String sector) {
        if (assessedValue <= 0 || sector == null) {
            return propertyTaxOn(assessedValue);
        }
        return assessedValue * effectiveMonthlyPropertyRate(sector);
    }

    /* ==================================================================
       WAGES
       ================================================================== */

    /**
     * What a payslip loses in this band (0.7.36): its wage tax at its own
     * rate, the pension contribution and the EI and health premiums - the
     * three promises are charged on the same payroll, flat across every
     * band. The Policy tab's payslip card, which totalled the four itself
     * at the base rate and called it "a wage in the middle band" (the
     * spec's B15). Null for a band reads the wage rate itself. Pure.
     */
    public double payslipShare(WageBand band) {
        double tax = band == null ? wageTaxRate : effectiveWageRate(band);
        return tax + contributionRate + eiPremiumRate + healthPremiumRate;
    }

    /**
     * The month's wage tax, summed job type by job type at its band's rate.
     *
     * NOT the total wage bill times an average rate. The bands exist so the
     * player can tax a doctor differently from a labourer, and averaging would
     * throw away exactly the distinction they just set - while still LOOKING
     * right, because the total is in the same neighbourhood either way.
     *
     * @param wagePerType the monthly wage bill per JobType, before fill
     * @param fillRate    what share of each type's posts are actually staffed
     */
    public double wageTaxOn(double[] wagePerType, double[] fillRate) {
        double tax = 0;
        for (double t : wageTaxPerTier(wagePerType, fillRate)) tax += t;
        return Math.max(0, tax);
    }

    /**
     * The same wage tax, split across the six pay tiers.
     *
     * The residents' books needed the split so each tier could have its own
     * cash-flow statement, and this is the ONLY place either figure is worked
     * out - wageTaxOn() is now a sum over this array rather than a second loop
     * that does the same thing. That is deliberate and it is not tidiness.
     *
     * The last time this codebase kept a second copy of the wage tax it cost
     * 23%. Game.updateHouseholdAccounts() computed the residents' tax as
     * `wages * incomeTaxRate` under a comment claiming it was "the identical
     * formula EconomyManager uses". It was, the day it was written - and then
     * the Policy tab added per-band offsets in this file only, so the moment a
     * player used the wage bands at all, the households were shown paying a
     * different tax from the one the city collected. With every offset at zero
     * the two agreed exactly, which is precisely why nothing noticed.
     *
     * Banded, and summed job type by job type rather than as one total times an
     * average - averaging would throw away exactly the distinction the bands
     * exist to express while still looking about right.
     */
    public double[] wageTaxPerTier(double[] wagePerType, double[] fillRate) {

        double[] byTier = new double[PayTier.values().length];
        if (wagePerType == null) return byTier;

        for (int i = 0; i < wagePerType.length && i < JobType.values().length; i++) {

            double paid = wagePerType[i];
            if (fillRate != null && i < fillRate.length) {
                paid *= fillRate[i];
            }
            if (paid <= 0) continue;

            JobType type = JobType.values()[i];
            byTier[PayTier.of(type).ordinal()] +=
                    paid * effectiveWageRate(WageBand.of(type));
        }
        return byTier;
    }

    /* =====================================================================
       A COPY TO PREVIEW ON (0.7.36)

       The Policy tab shows what a staged set of dials would do before it is
       applied. Until 0.7.36 the screen worked each "after" out itself - a
       clamp copied from this class, the sales tax by a ratio, the pension by
       scaling the bill - and a rule changed here would not have changed
       there. Now the staged set is put through a COPY of this policy, its
       own setters and clamps, and the model's own reads are asked about the
       copy (PolicyPreview). The copy is DETACHED: every dial, the sector
       offsets and the wage base a pension is struck on, and no decision log
       - a dial moved on it records nothing, because nobody decided anything.
       ===================================================================== */

    /** A detached copy of every dial (0.7.36): setters on it clamp as here and record nothing. See PolicyPreview. */
    public TaxPolicy copy() {
        TaxPolicy c = new TaxPolicy();
        c.profitTaxRate = profitTaxRate;
        c.salesTaxRate = salesTaxRate;
        c.wageTaxRate = wageTaxRate;
        c.propertyTaxRate = propertyTaxRate;
        c.farmlandRelief = farmlandRelief;
        c.contributionRate = contributionRate;
        c.pensionReplacement = pensionReplacement;
        c.eiPremiumRate = eiPremiumRate;
        c.eiBenefitRate = eiBenefitRate;
        c.grantBasis = grantBasis;
        c.grantAmount = grantAmount;
        c.fixedGrantNominal = fixedGrantNominal;
        c.studentLoanRate = studentLoanRate;
        System.arraycopy(tuitionScales, 0, c.tuitionScales, 0, tuitionScales.length);
        c.healthFeeScale = healthFeeScale;
        c.healthPremiumRate = healthPremiumRate;
        c.pensionWageBase = pensionWageBase;
        c.transitFare = transitFare;
        c.foodAssistance = foodAssistance;
        c.expectedLevel = expectedLevel;
        c.moneyUnit = moneyUnit;
        c.fareNominal = fareNominal;
        System.arraycopy(wageOffset, 0, c.wageOffset, 0, wageOffset.length);
        c.profitOffset.putAll(profitOffset);
        c.salesOffset.putAll(salesOffset);
        c.propertyOffset.putAll(propertyOffset);
        return c;
    }

    /* ==================================================================
       SAVE AND RESTORE
       ================================================================== */

    /** The slots a save from before the EI and grant dials carried: the four rates and the wage-band offsets. */
    public static final int STATE_BEFORE_EI = 4 + WageBand.values().length;

    /** ...and one from before the health dials of 2026-09-19: EI's three, the farmland relief and the fare on top. */
    public static final int STATE_BEFORE_HEALTH = STATE_BEFORE_EI + 3 + 1 + 1;

    /** ...and one from before the education dials of 2026-09-21: the two health dials on top. */
    public static final int STATE_BEFORE_EDUCATION = STATE_BEFORE_HEALTH + 2;

    /** ...and one from before the income rate split in three (0.7.4): the grant's basis and amount, the loan rate and the tuition scale on top. */
    public static final int STATE_BEFORE_SPLIT = STATE_BEFORE_EDUCATION + 4;

    /** ...and one from before the tuition scale split by school (0.7.6): the profit, sales and wage bases on top, each its own slot since 0.7.4. */
    public static final int STATE_BEFORE_SCHOOLS = STATE_BEFORE_SPLIT + 3;

    /** ...and one from before the real FIXED grant (0.7.19): a tuition scale per school kind on top, the nine in EducationType order bar NONE, since 0.7.6. */
    public static final int STATE_BEFORE_REAL_GRANT = STATE_BEFORE_SCHOOLS + EducationType.values().length - 1;

    /** ...and one from before the real fare (0.7.42): one slot on top saying the FIXED amount is real, in founding money (0.7.19) - see realiseFixedGrant(). */
    public static final int STATE_BEFORE_REAL_FARE = STATE_BEFORE_REAL_GRANT + 1;

    /** ...and one from before food assistance (0.7.43): one slot on top saying the fare is real, in founding money (0.7.42) - see realiseFare(). */
    public static final int STATE_BEFORE_FOOD_ASSISTANCE = STATE_BEFORE_REAL_FARE + 1;

    /** This build's array: the food assistance dial on top (0.7.43). */
    public static final int STATE_SLOTS = STATE_BEFORE_FOOD_ASSISTANCE + 1;

    /**
     * The city rates and the wage-band offsets as one array, city rates
     * first - bar the three income bases of 0.7.4, which ride the end like
     * every field added since. ORDER IS THE FORMAT and new fields go on the
     * END. The sector offsets are NOT in here any more: they are keyed by
     * name and saved as their own list - see getSectorOffsets().
     */
    public double[] getPolicyState() {

        int bands = WageBand.values().length;

        // 4 rates, one per wage band, the three dials of 2026-09-11, the
        // farmland relief of 09-13, the transit fare of 09-16, the two
        // health dials of 09-19, the four education dials of 09-21, the
        // three income bases of 0.7.4 and the nine school kinds' tuition
        // scales of 0.7.6. GROW THIS WITH EVERY SLOT ADDED
        // BELOW: the first version of the fare wrote to state[12] of a
        // twelve-long array and took forty-three harnesses down with it in
        // nineteen seconds, which is the good outcome.
        double[] state = new double[STATE_SLOTS];
        int i = 0;
        // The one income rate, as every older reader knows it: the three
        // together while they are equal, the profit rate once they have
        // parted (getIncomeTaxRate()). The three themselves ride the end.
        state[i++] = getIncomeTaxRate();
        state[i++] = propertyTaxRate;
        state[i++] = contributionRate;
        state[i++] = pensionReplacement;
        for (int b = 0; b < bands; b++) state[i++] = wageOffset[b];
        // The three dials of 2026-09-11, on the end. The grant's slot has
        // always meant "the share of the unskilled wage", and still does: it
        // carries the amount under WAGE_SHARE and nothing under any other
        // basis, so a build that reads only this slot reads a grant it can
        // strike and this build reads the basis and its amount from the end.
        state[i++] = eiPremiumRate;
        state[i++] = eiBenefitRate;
        state[i++] = getStudentGrantShare();
        // The farmland dial of 2026-09-13, on the end, for the same reason the
        // three above are on the end: an older save has one fewer slot and
        // keeps the default, which is the behaviour that city had.
        state[i++] = farmlandRelief;
        // The fare of 2026-09-16, on the end, for the reason the four above it
        // are on the end: an older save is one slot shorter and keeps the
        // default, which is the city it was.
        state[i++] = transitFare;
        // The two health dials of 2026-09-19, on the end again: an older save
        // is two slots shorter and reads the founding fee at 1x and no
        // premium, which is the game it was.
        state[i++] = healthFeeScale;
        state[i++] = healthPremiumRate;
        // The four education dials of 2026-09-21, on the end: the basis as
        // its ordinal, its amount, the loan rate and the tuition scale. An
        // older save is four slots shorter and reads WAGE_SHARE at the share
        // its grant slot above carries, no interest and the founding price,
        // which is the game it was.
        state[i++] = grantBasis.ordinal();
        state[i++] = grantAmount;
        state[i++] = studentLoanRate;
        // The one scale, as every older reader knows it: the nine together
        // while they are equal, the first kind's once they have parted
        // (getTuitionScale()). The nine themselves ride the end.
        state[i++] = getTuitionScale();
        // The three income bases of 0.7.4, on the end: an older save is three
        // slots shorter and reads all three as its one income rate in slot 0,
        // which is the city it was.
        state[i++] = profitTaxRate;
        state[i++] = salesTaxRate;
        state[i++] = wageTaxRate;
        // The nine school kinds' tuition scales of 0.7.6, on the end in
        // EducationType order: an older save is nine slots shorter and reads
        // all nine as the one scale its slot above carries, which is the
        // city it was.
        for (EducationType type : SCHOOL_KINDS) state[i++] = tuitionScales[type.ordinal()];
        // The real FIXED grant of 0.7.19, on the end: 1 says the amount above
        // is in founding money. An older save is one slot shorter, and a FIXED
        // amount in it was nominal - see realiseFixedGrant().
        state[i++] = 1;
        // The real fare of 0.7.42, on the end: 1 says the fare above is in
        // founding money. An older save is one slot shorter, and its fare
        // was nominal - see realiseFare().
        state[i++] = 1;
        // The food assistance dial of 0.7.43, on the end: an older save is one
        // slot shorter and reads none, which is the city it was.
        state[i++] = foodAssistance;
        return state;
    }

    /**
     * @return false if the array is shorter than the oldest shape
     *         (STATE_BEFORE_EI) or longer than this build's (STATE_SLOTS);
     *         nothing is changed. Every append has gone on the end, so any
     *         older save is a PREFIX of this build's array: what is there is
     *         read in order and every slot past its end keeps its default,
     *         which is the city that save was.
     */
    public boolean restorePolicyState(double[] state) {

        if (state == null || state.length < STATE_BEFORE_EI || state.length > STATE_SLOTS) return false;

        // The fare is clamped at the cap over the unit, and the load re-strikes
        // the unit after this (Game.restrikeMoneyConstants()): founding's until then.
        moneyUnit = 1.0;
        int i = 0;
        // All three income bases at the one rate slot 0 carries; a save from
        // 0.7.4 on overrides each from the end of the array below.
        setIncomeTaxRate(state[i++]);
        setPropertyTaxRate(state[i++]);
        setContributionRate(state[i++]);
        setPensionReplacement(state[i++]);
        for (WageBand b : WageBand.values()) setWageOffset(b, state[i++]);
        eiPremiumRate = Unemployment.DEFAULT_PREMIUM_RATE;
        eiBenefitRate = Unemployment.DEFAULT_BENEFIT_RATE;
        // THE RULE AN OLDER SAVE WAS PLAYED UNDER, not the new default
        // (0.7.19): every save carried a wage share, and one from before the
        // grant's dials carries no choice at all - it keeps the founding
        // rule it had. A save with a basis overrides this below.
        grantBasis = GrantBasis.WAGE_SHARE;
        grantAmount = DEFAULT_STUDENT_GRANT_SHARE;
        fixedGrantNominal = false;
        farmlandRelief = DEFAULT_FARMLAND_RELIEF;
        transitFare = DEFAULT_TRANSIT_FARE;
        healthFeeScale = DEFAULT_HEALTH_FEE_SCALE;
        healthPremiumRate = DEFAULT_HEALTH_PREMIUM;
        studentLoanRate = DEFAULT_STUDENT_LOAN_RATE;
        foodAssistance = DEFAULT_FOOD_ASSISTANCE;
        setTuitionScale(DEFAULT_TUITION_SCALE);
        if (i < state.length) setEiPremiumRate(state[i++]);
        if (i < state.length) setEiBenefitRate(state[i++]);
        // The wage share, as the slot always carried it: WAGE_SHARE at that
        // share, and the basis and amount four slots on override it when
        // the save has them.
        if (i < state.length) setStudentGrantShare(state[i++]);
        if (i < state.length) setFarmlandRelief(state[i++]);
        if (i < state.length) setTransitFare(state[i++]);
        if (i < state.length) setHealthFeeScale(state[i++]);
        if (i < state.length) setHealthPremiumRate(state[i++]);
        if (i < state.length) {
            int ordinal = (int) Math.round(state[i++]);
            GrantBasis[] bases = GrantBasis.values();
            grantBasis = ordinal >= 0 && ordinal < bases.length ? bases[ordinal] : DEFAULT_GRANT_BASIS;
        }
        if (i < state.length) setGrantAmount(state[i++]);
        if (i < state.length) setStudentLoanRate(state[i++]);
        // Every school at the one scale this slot carries; a save from 0.7.6
        // on overrides each kind from the end of the array below.
        if (i < state.length) setTuitionScale(state[i++]);
        if (i < state.length) setProfitTaxRate(state[i++]);
        if (i < state.length) setSalesTaxRate(state[i++]);
        if (i < state.length) setWageTaxRate(state[i++]);
        for (EducationType type : SCHOOL_KINDS) {
            if (i < state.length) setTuitionScaleOf(type, state[i++]);
        }
        // A FIXED amount is real only in an array that says so (0.7.19).
        boolean real = i < state.length && state[i++] > 0;
        fixedGrantNominal = grantBasis == GrantBasis.FIXED && !real;
        // ...and the fare is real only in an array that says so (0.7.42).
        boolean fareReal = i < state.length && state[i++] > 0;
        fareNominal = !fareReal;
        if (i < state.length) setFoodAssistance(state[i++]);
        return true;
    }

    /**
     * An older save's FIXED grant, read as the real amount that pays the same
     * at the load month's level (0.7.19): its nominal amount over the level,
     * so the bill the month after the load is the bill the save was paying,
     * and it keeps up with prices from there. The level is the expected price
     * level since 0.7.42 - 1.0 on any save this reaches - and was the price
     * index until then. Nothing for any other basis, a save from 0.7.19 on,
     * or a second call. Game's load path calls it once the anchor is
     * restored.
     */
    public void realiseFixedGrant(double priceIndex) {
        if (!fixedGrantNominal) return;
        fixedGrantNominal = false;
        if (priceIndex > 0) grantAmount = grantAmount / priceIndex;
    }

    /** One sector's three offsets, as the save carries them. */
    public static final class SectorOffsets {
        public String sector;
        public double profit, sales, property;
    }

    public java.util.List<SectorOffsets> getSectorOffsets() {
        java.util.Set<String> keys = new java.util.LinkedHashSet<>();
        keys.addAll(profitOffset.keySet());
        keys.addAll(salesOffset.keySet());
        keys.addAll(propertyOffset.keySet());
        java.util.List<SectorOffsets> out = new java.util.ArrayList<>();
        for (String k : keys) {
            SectorOffsets o = new SectorOffsets();
            o.sector = k;
            o.profit = getProfitOffset(k);
            o.sales = getSalesOffset(k);
            o.property = getPropertyOffset(k);
            out.add(o);
        }
        return out;
    }

    /** A sector the build does not have keeps its row - harmless, and it comes back if the sector does. */
    public void restoreSectorOffsets(java.util.List<SectorOffsets> saved) {
        profitOffset.clear();
        salesOffset.clear();
        propertyOffset.clear();
        if (saved == null) return;
        for (SectorOffsets o : saved) {
            if (o == null || o.sector == null) continue;
            setProfitOffset(o.sector, o.profit);
            setSalesOffset(o.sector, o.sales);
            setPropertyOffset(o.sector, o.property);
        }
    }

    public void reset() {
        setIncomeTaxRate(DEFAULT_INCOME_TAX);
        propertyTaxRate = DEFAULT_PROPERTY_TAX;
        transitFare = DEFAULT_TRANSIT_FARE;
        contributionRate = SocialSecurity.DEFAULT_CONTRIBUTION_RATE;
        pensionReplacement = SocialSecurity.DEFAULT_PENSION_REPLACEMENT;
        eiPremiumRate = Unemployment.DEFAULT_PREMIUM_RATE;
        eiBenefitRate = Unemployment.DEFAULT_BENEFIT_RATE;
        grantBasis = DEFAULT_GRANT_BASIS;
        grantAmount = DEFAULT_FIXED_GRANT;
        fixedGrantNominal = false;
        fareNominal = false;
        expectedLevel = 1.0;
        moneyUnit = 1.0;
        studentLoanRate = DEFAULT_STUDENT_LOAN_RATE;
        setTuitionScale(DEFAULT_TUITION_SCALE);
        farmlandRelief = DEFAULT_FARMLAND_RELIEF;
        healthFeeScale = DEFAULT_HEALTH_FEE_SCALE;
        healthPremiumRate = DEFAULT_HEALTH_PREMIUM;
        foodAssistance = DEFAULT_FOOD_ASSISTANCE;
        java.util.Arrays.fill(wageOffset, 0);
        profitOffset.clear();
        salesOffset.clear();
        propertyOffset.clear();
    }

    private double clamp(double rate, double max) {
        if (rate < 0) {
            return 0;
        }
        return Math.min(rate, max);
    }

    private double clampOffset(double points) {
        if (Double.isNaN(points)) return 0;
        return Math.max(-MAX_OFFSET, Math.min(points, MAX_OFFSET));
    }

    /**
     * A property offset is held at MAX_PROPERTY_TAX either way (B5, 0.7.47),
     * not MAX_OFFSET: the rate is the base plus the offset held within 0 and
     * MAX_PROPERTY_TAX, and the base itself is within them, so no offset past
     * them can give a rate one at them does not - the dial always stopped
     * there. An older save's offset past it loads at it, and rates the same.
     */
    private double clampPropertyOffset(double points) {
        if (Double.isNaN(points)) return 0;
        return Math.max(-MAX_PROPERTY_TAX, Math.min(points, MAX_PROPERTY_TAX));
    }
}
