package ham.citybuildersim;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The private economy: every sector, every market, the credit desk, the
 * tax policy and the national accounts, and the month they run in.
 *
 * SINCE THE SECTOR TEMPLATE (2026-09-11) this class holds a REGISTRY and
 * loops it. It used to hold five handlers by name and loop them by hand in
 * eleven places - pricing credit, charging property tax, pushing balance
 * sheets, settling loans, striking VAT, banking the month, restoring a save
 * - and each of those was a place a seventh sector would have been
 * forgotten. See Sectors, Sector and claude/the-sector-template.md.
 *
 * WHAT IS STILL HERE BY NAME: the two housing figures the landlords need
 * from the family model and the land office (see updateHousing()), and
 * the shops' budget constraint, which Game hands in from the households.
 * Both are inputs to a sector that is not a factory, and they arrive here
 * because this class already talks to everything that produces them.
 *
 * @author Jerus
 */
public class EconomyManager {

    /* ===================================================================
       THE CITY'S PARTS
       =================================================================== */

    private final BuildingManager buildingManager;
    private final Markets markets = new Markets();
    private final Sectors sectors;
    private final BusinessDebtManager businessDebtManager;
    private final TaxPolicy taxPolicy = new TaxPolicy();
    private final SalesTaxLedger salesTaxLedger = new SalesTaxLedger();
    private final NationalAccounts nationalAccounts = new NationalAccounts();

    public EconomyManager(BuildingManager buildingManager) {
        this.buildingManager = buildingManager;
        this.sectors = new Sectors(buildingManager, markets);
        this.businessDebtManager = new BusinessDebtManager();
        businessDebtManager.setSectors(sectors.keys());
    }

    public Sectors getSectors()                          { return sectors; }
    public Markets getMarkets()                          { return markets; }
    public GoodsMarket getMarket(Good g)                 { return markets.get(g); }
    public BusinessDebtManager getBusinessDebtManager()  { return businessDebtManager; }
    public TaxPolicy getTaxPolicy()                      { return taxPolicy; }
    public SalesTaxLedger getSalesTaxLedger()            { return salesTaxLedger; }
    public NationalAccounts getNationalAccounts()        { return nationalAccounts; }
    public BuildingManager getBuildingManager()          { return buildingManager; }

    /** A sector by its saved name, or null. */
    public Sector sector(String key) { return sectors.byKey(key); }

    /* ===================================================================
       WHAT THE CITY TELLS THE ECONOMY EACH MONTH
       =================================================================== */

    private double cash;
    private long totalJobs;
    private long population;
    private long households;
    private double totalWage;
    private final double[] fillRate = new double[11];

    /** What ONE job of each tier costs a month, as PopulationManager last set it. */
    private final double[] wageRates = new double[11];

    /** The wage bill per job type, staffed, for the banded wage tax. */
    private double[] staffedWagePerType = new double[JobType.values().length];

    /** The bank's posts, so its tellers can be charged to the bank and not to the shops. */
    private long[] bankJobs;

    public void setTotalJobs(long jobs)       { totalJobs = jobs; }
    public void setPopulation(long pop)       { population = pop; }
    public void setHouseholds(long houseCap)  { households = houseCap; }
    public void setCash(int money)            { cash = money; }
    public void setTotalWage(double wage)     { totalWage = wage; }
    public void setWageDetail(double[] staffedPerType) {
        if (staffedPerType != null) this.staffedWagePerType = staffedPerType.clone();
    }
    public double[] getStaffedWagePerType()   { return staffedWagePerType.clone(); }
    public long getPopulation()               { return population; }

    public void updateJobFillRate(double[] fill) {
        if (fill == null) return;
        System.arraycopy(fill, 0, fillRate, 0, Math.min(fill.length, fillRate.length));
        for (Sector s : sectors.all()) s.updateJobFillRate(fillRate);
    }

    /**
     * The wage schedule, handed to every sector with its own posts.
     *
     * @param wagePerType what one post of each tier costs a month
     * @param bankPosts   the bank's posts, which belong to no sector
     */
    public void updateWages(double[] wagePerType, long[] bankPosts) {
        if (wagePerType == null) return;
        System.arraycopy(wagePerType, 0, wageRates, 0, Math.min(wagePerType.length, wageRates.length));
        this.bankJobs = bankPosts;
        for (Sector s : sectors.all()) {
            s.updateJobFillRate(fillRate);
            s.updateWages(wageRates, s.postsPerTier());
        }
    }

    /** A copy, so nothing downstream can quietly rewrite the schedule. */
    public double[] getWageRates() { return wageRates.clone(); }

    /**
     * What the bank's own staff cost this month. A Commercial Bank is a
     * COMMERCIAL building with no sector, so its posts are in nobody's
     * payroll but the bank's - charged by Game through Bank.payRunning().
     */
    public double getBankPayroll() {
        if (bankJobs == null) return 0;
        double total = 0;
        int n = Math.min(bankJobs.length, wageRates.length);
        for (int i = 0; i < n; i++) total += bankJobs[i] * wageRates[i] * fillRate[i];
        return total;
    }

    /* ----------------------------- utilities ----------------------------- */

    private double pricePerWatt;
    private double pricePerWaterUnit;

    public double getPricePerWatt()      { return pricePerWatt; }
    public double getPricePerWaterUnit() { return pricePerWaterUnit; }

    public void setPricePerWatt(double price) {
        pricePerWatt = price;
        for (Sector s : sectors.all()) s.setPricePerWatt(price);
    }

    public void setPricePerWaterUnit(double price) {
        pricePerWaterUnit = price;
        for (Sector s : sectors.all()) s.setPricePerWaterUnit(price);
    }

    public void setEnergyRatio(double ratio) { for (Sector s : sectors.all()) s.setEnergyRatio(ratio); }
    public void setWaterRatio(double ratio)  { for (Sector s : sectors.all()) s.setWaterRatio(ratio); }
    /** The road network's throughput, handed to everyone whose goods move on it. */
    public void setRoadRatio(double ratio)   { for (Sector s : sectors.all()) s.setRoadRatio(ratio); }

    /**
     * ...and the same thing done properly, once the streams exist: each sector
     * feels the congestion IT generates.
     *
     * A contact centre is three hundred people and nothing shipped. A steel
     * mill is 83% ore. They stand in the same city on the same roads and they
     * do not have the same problem - the office's people can be on a tram
     * while the mill's lorries sit in the same jam they always did - and a
     * single city-wide ratio could not say so. The mix is the sector's own
     * buildings, which is the only honest measure of what it puts on the road.
     *
     * A SECTOR WITH NOTHING STANDING READS ONE, not zero: it is not being held
     * up by traffic, it simply is not there.
     */
    public void setRoadRatio(InfrastructureManager roads, BuildingManager buildings) {
        if (roads == null || buildings == null) return;
        for (Sector s : sectors.all()) {
            double[] mix = new double[Traffic.values().length];
            for (Traffic stream : Traffic.values()) {
                final Traffic t = stream;
                mix[t.ordinal()] = buildings.totalBySector(s.key(), b -> b.loadOf(t));
            }
            s.setRoadRatio(roads.throughputFor(mix));
        }
    }
    /** What is left of the workforce once this month's illness is taken off. Never touches payroll. See Health. */
    public void setHealthRatio(double ratio) { for (Sector s : sectors.all()) s.setHealthRatio(ratio); }

    /** What the sectors are currently running at, for the harnesses. */
    public double getHealthRatio() { return sectors.retail().getHealthRatio(); }

    /**
     * Every sector's draw, off its own buildings. Billed to the sectors that
     * draw it, water exactly as power is.
     *
     * EXCEPT THE HOMES. A house draws power and water and nobody is billed
     * for it - the tenants are not charged for utilities in this model, and
     * the landlords never were either (the old billing list was four
     * categories, and RESIDENTIAL was not one of them). Charging the
     * landlords for 40,000 houses' worth of water would be a rent rise
     * dressed as a utility bill. A household utility bill is a change to the
     * household model, not to the sectors, and it is on the list.
     */
    public void setElectricityConsumption() {
        for (Sector s : sectors.all()) {
            s.setElectricityConsumption(buildingManager.totalBySector(s.key(),
                    t -> BuildingsTemplate.isBilledForUtilities(t) ? t.getElectricityConsumption() : 0));
            s.setWaterConsumption(buildingManager.totalBySector(s.key(),
                    t -> BuildingsTemplate.isBilledForUtilities(t) ? t.getWaterConsumption() : 0));
        }
    }

    /** The month's power bills, as the sectors' statements booked them. */
    public double getSectorElectricityCharges() {
        double total = 0;
        for (Sector s : sectors.all()) total += s.statement().electricity;
        return total;
    }

    /** The month's water bills, likewise. */
    public double getSectorWaterCharges() {
        double total = 0;
        for (Sector s : sectors.all()) total += s.statement().water;
        return total;
    }

    /* ----------------------------- the world ----------------------------- */

    /**
     * Every world price in the game is quoted by the world in ITS money and
     * converted at this rate - times the world's own price level, which is
     * how world inflation rides in. Pushed in by Game.startOfMonthUpdate()
     * before anything is priced.
     */
    private double exchangeRate = 1.0;

    public void setExchangeRate(double rate) {
        this.exchangeRate = rate > 0 ? rate : 1.0;
        markets.setExchangeRate(this.exchangeRate);
        buildingManager.setExchangeRate(this.exchangeRate);
    }

    public double getExchangeRate() { return exchangeRate; }

    /* ------------------------------ the land ------------------------------ */

    /**
     * What the city currently charges for a square foot, so assessed values
     * track the price the player sets. A real reassessment with teeth both
     * ways: raising the land price raises what every landowner owes.
     */
    private double landPricePerSqFt;

    public void setLandPricePerSqFt(double price) { this.landPricePerSqFt = price; }
    public double getLandPricePerSqFt()           { return landPricePerSqFt; }

    /** What a sector's land is worth at the city's current price. */
    public double landValueOf(Sector s) {
        return buildingManager.getLandSqFtBySector(s.key()) * landPricePerSqFt;
    }

    /** What a city-owned category's land is worth. */
    public double landValueOf(BuildingType category) {
        return buildingManager.getLandSqFtByCategory(category) * landPricePerSqFt;
    }

    /* ===================================================================
       HOUSING - what the landlords need from the family model and the land office
       =================================================================== */

    private double householdCount;
    private double marginalHousingCost;
    private double occupiedHomes;
    private double studioSeekers, familySeekers, studioSeekerHeads, familySeekerHeads;

    public void setHouseholdCount(double count)       { this.householdCount = count; }
    public void setMarginalHousingCost(double perCap) { this.marginalHousingCost = perCap; }
    public double getMarginalHousingCost()            { return marginalHousingCost; }
    public void setOccupiedHomes(double occupied)     { this.occupiedHomes = occupied; }
    public void setHousingSeekers(double studio, double family, double studioHeads, double familyHeads) {
        this.studioSeekers = Math.max(0, studio);
        this.familySeekers = Math.max(0, family);
        this.studioSeekerHeads = Math.max(0, studioHeads);
        this.familySeekerHeads = Math.max(0, familyHeads);
    }
    public double getStudioSeekers() { return studioSeekers; }
    public double getFamilySeekers() { return familySeekers; }

    /**
     * Hands the landlords and the shops what the month looks like: how many
     * people there are, how many doors, who is chasing them and what a new
     * home costs. SET here; the rent WALKS at the bottom of the month, in
     * the sector's own endOfMonth() - setting state is not advancing it.
     */
    public void updateHousing() {
        var re = sectors.realEstate();
        re.setPopulation(population);
        re.setHousehold(households);
        re.setHomes(buildingManager.getTotalHomes());
        re.setOccupiedHomes(occupiedHomes);
        re.setHouseholdCount(householdCount);
        re.setMarginalHousingCost(marginalHousingCost);
        repriceHousingCosts();

        long[] bySize = buildingManager.homesBySize();
        long studioDoors = 0, familyDoors = 0;
        for (int size = 1; size < bySize.length; size++) {
            if (size <= FamilyModel.STUDIO_MAX_SIZE) studioDoors += bySize[size];
            else                                     familyDoors += bySize[size];
        }
        re.setSegments(studioDoors, familyDoors, studioSeekers, familySeekers,
                studioSeekerHeads, familySeekerHeads);

        sectors.retail().setPopulation(population);
    }

    /**
     * What one of these has to earn a month before it is worth putting up.
     *
     * ZERO PROFIT, PLUS A MARGIN. Jerus: "theyll rent at zero profit, but
     * they wont build more if new rent is zero profit." Maintenance on the
     * structure, property tax on the whole asset with its plot, and then a
     * margin. NO INTEREST IN THIS NUMBER: whether the building pays is this
     * question; whether the company can carry the loan is the lender's -
     * servicesItsOwnDebt()'s for a loan, and for a landlord's mortgage since
     * 0.7.11 the debt coverage on housingCarry() - and asking it twice
     * answered no both times.
     */
    public double housingBuildHurdle(BuildingsTemplate t) {
        return housingCarry(t) * (1 + ham.citybuildersim.sectors.RealEstate.BUILD_MARGIN);
    }

    /**
     * WHAT ONE OF THESE COSTS TO HOLD A MONTH, before any interest: its
     * maintenance, RealEstate.MAINTENANCE_PER_YEAR on the structure, and its
     * property tax, the property rate on the structure and its plot. The
     * carry housingBuildHurdle() puts a margin on, and the one a mortgage
     * lender takes off the rent to find the building's net operating income
     * (Game.consider(), 0.7.11) - one piece of arithmetic for both.
     */
    public double housingCarry(BuildingsTemplate t) {
        if (t == null || buildingManager == null) return 0;
        double materials = t.getConstructionMaterials() * Math.max(0, buildingManager.getConstructionMaterialPrice());
        double structure = t.getCashCost() + materials;
        double land = t.getLandSqFt() * Math.max(0, landPricePerSqFt);
        double full = structure + land;
        if (full <= 0) return 0;
        double monthlyPropertyRate = taxPolicy.effectiveMonthlyPropertyRate(sectors.realEstate());
        // The repairs as the builders bill them (0.7.19): the labour at
        // today's wages and the tax a landlord cannot claim back - see
        // maintenanceBillFor(). The property tax on the roll's value, which
        // is the structure's book value (BuildingManager) and its plot.
        double repairBase = ownersRepairCost(t, sectors.realEstate().key(),
                buildingManager.nonMaterialCost(t) + materials);
        return repairBase * ham.citybuildersim.sectors.RealEstate.MAINTENANCE_PER_YEAR / 12
                + full * monthlyPropertyRate;
    }

    /** The cheapest way to house one more person, land included, per segment. */
    public void repriceHousingCosts() {
        var re = sectors.realEstate();
        double materialPrice = Math.max(0, buildingManager.getConstructionMaterialPrice());
        double bestFull = 0, bestStructure = 0, bestLand = 0, bestStudio = 0, bestFamily = 0;
        for (BuildingsTemplate t : buildingManager.getTemplates()) {
            if (t == null || !re.key().equals(t.getSector()) || t.getCapacity() <= 0) continue;
            // ...at what the landlord pays the builders for it (0.7.19), less
            // the rebate on a new rental home (THE REBATES ON A NEW HOME).
            double structure = ownersBuildCost(t, re.key(),
                    buildingManager.nonMaterialCost(t) + t.getConstructionMaterials() * materialPrice) / t.getCapacity();
            double land = t.getLandSqFt() * Math.max(0, landPricePerSqFt) / t.getCapacity();
            double full = structure + land;
            if (full <= 0) continue;
            if (bestFull <= 0 || full < bestFull) {
                bestFull = full; bestStructure = structure; bestLand = land;
            }
            if (t.homeSize() <= FamilyModel.STUDIO_MAX_SIZE) {
                if (bestStudio <= 0 || full < bestStudio) bestStudio = full;
            } else {
                if (bestFamily <= 0 || full < bestFamily) bestFamily = full;
            }
        }
        re.setHousingCosts(bestStructure, bestLand);
        re.setSegmentHousingCosts(bestStudio, bestFamily);
        re.setOwnedHousingCapacity(buildingManager.getCapacityInPortfolioBySector(re.key()));
    }

    /* ===================================================================
       CASH BY NAME - the seam almost everything routes through
       =================================================================== */

    public double getSectorCash(String key) {
        Sector s = sectors.byKey(key);
        return s == null ? 0 : s.getCash();
    }

    public void setSectorCash(String key, double cash) {
        Sector s = sectors.byKey(key);
        if (s != null) s.setCash(cash);
    }

    /* ===================================================================
       THE MONTH, AT THE TOP
       =================================================================== */

    /**
     * Prices this month's business credit and hands every sector its
     * interest bill BEFORE the statements run, so the figures they bank are
     * net of it.
     *
     * @param primeRate the bank's prime this month (Bank.prime(), 0.7.7) -
     *                  every sector's own spread sits on it; the city's
     *                  rate until 0.7.7
     */
    public void updateBusinessCredit(double primeRate) {
        updateBusinessCredit(primeRate, businessDebtManager.getInsuredMortgageRate());
    }

    /**
     * ...and the insured mortgage's rate beside prime (0.7.11,
     * Bank.insuredMortgageRate()): what a landlord's new mortgage is written
     * at and a term that ends renews at.
     */
    public void updateBusinessCredit(double primeRate, double insuredMortgageRate) {
        businessDebtManager.setInsuredMortgageRate(insuredMortgageRate);
        businessDebtManager.setPrimeRate(primeRate);
        /*
         * THE LENDER READS THE SHEETS VALUED THIS MONTH (0.7.12 round 8; Jerus,
         * "Fix it in round 8"). They were valued at the END of this call, after
         * the refresh, so all month the lender read them as the last
         * insolvency check had left them: last month's land price and
         * materials, and none of the plant handed over since - the building a
         * sector bought after that check, a site the player laid between
         * months. Round 4 valued them first only in a city's first month
         * (Real Estate, Retail and Industry had defaulted in the first month
         * of HealthCheck's city for want of a sheet). Round 7 found the same
         * thing every month: a sector whose first plant arrived between months
         * read as owning nothing at its first settle and defaulted on its
         * first bill - RailCheck's railway $930, RestaurantsCheck's kitchens
         * $8.70 - and a sector that had just borrowed for a building was read
         * at the ceiling with the loan and without the building. So the
         * sheets are valued first, every month, the way the insolvency check
         * values them (settleInsolvency()), and the lender, its prices, its
         * ceiling and its default point read them. The push that closed this
         * call went with it: nothing below moves what it values.
         */
        pushBalanceSheetInputs();
        refreshCreditAssets();
        businessDebtManager.updateRates();
        for (Sector s : sectors.all()) {
            s.setInterestExpense(businessDebtManager.getMonthlyInterest(s.key()));
        }
    }

    /**
     * Tells the credit manager what each sector is worth right now - its
     * own sheet plus what it holds abroad, which a lender that ignored
     * would call a rich sector broke. And since 0.7.44 net of what it owes
     * its suppliers, with what its buyers owe it: the lender reads each side
     * of the grocers' trade credit as if it were not there, so cash a
     * supplier is still owed is not lent against twice (SupplierCredit).
     */
    public void refreshCreditAssets() {
        for (Sector s : sectors.all()) {
            BalanceSheet sheet = s.getBalanceSheet();
            businessDebtManager.setAssets(s.key(),
                    sheet.getTotalAssets() - sheet.getTradePayables() + getForeignAssets(s.key())
                            + getBondAssets(s.key()));
            businessDebtManager.setCash(s.key(), s.getCash());
        }
    }

    /** Book values and outstanding debt, refreshed onto each set of books. Buildings finished AND on site. */
    public void pushBalanceSheetInputs() {
        for (Sector s : sectors.all()) {
            s.setBalanceSheetInputs(landValueOf(s),
                    buildingManager.getBuildingsValueBySector(s.key()),
                    businessDebtManager.getPrincipal(s.key()));
        }
    }

    /* ------------------------------ property tax ------------------------------ */

    private double totalPropertyTax;
    private final Map<String, Double> propertyTaxBySector = new LinkedHashMap<>();

    /**
     * Land at today's price plus FINISHED buildings at replacement cost. Sites
     * are not assessed.
     *
     * THE LAND HALF IS SCALED BY WHAT THE ROLL ACTUALLY CARRIES (2026-09-13),
     * which is one for every sector but the fields. A farm's ground is worth
     * what a developer would pay for it and grows what a farmer can grow on it,
     * and taxing the first drives out the second long before the city reaches
     * the fence - so the player has a dial. See TaxPolicy.assessedLandShare.
     */
    public double getAssessedValue(Sector s) {
        return landValueOf(s) * taxPolicy.assessedLandShare(s.key())
                + buildingManager.getBookValueBySector(s.key());
    }

    /** The same for a city-owned category, which the city does not tax but a screen may want to show. */
    public double getAssessedValue(BuildingType category) {
        return landValueOf(category) + buildingManager.getBookValueByCategory(category);
    }

    /** One month's property tax on a sector, at its own rate. */
    public double getPropertyTaxFor(Sector s) {
        return taxPolicy.propertyTaxOn(getAssessedValue(s), s.key());
    }

    /**
     * Hands each sector its property tax bill for the month. Runs with the
     * interest bill, before the statements, for the same reason: what a
     * sector banks has to already be net of what it owes.
     */
    public void chargePropertyTax() {
        totalPropertyTax = 0;
        propertyTaxBySector.clear();
        for (Sector s : sectors.all()) {
            double bill = getPropertyTaxFor(s);
            s.setPropertyTaxExpense(bill);
            propertyTaxBySector.put(s.key(), bill);
            totalPropertyTax += bill;
        }
    }

    public double getTotalPropertyTax()            { return totalPropertyTax; }
    public void setTotalPropertyTax(double value)  { this.totalPropertyTax = value; }
    public double getPropertyTaxCharged(String key){ return propertyTaxBySector.getOrDefault(key, 0.0); }

    /* ------------------------------ maintenance ------------------------------ */

    /**
     * EVERY BUILDING IN THE CITY, BILLED FOR STANDING THERE. Jerus: "all
     * buildings need maintenance, and make sure they get billed." A real
     * order with the builders - money, materials and points - priced in the
     * building's own inputs at today's material price, one percent a year of
     * what it cost to put up. The sectors bear their own; the city bears
     * the buildings nobody else owns; the bank bears its branches.
     */
    private static final BuildingType[] CITY_MAINTAINED = {
        BuildingType.ELECTRICITY, BuildingType.WATER, BuildingType.INFRASTRUCTURE,
        BuildingType.HEALTHCARE,  BuildingType.EDUCATION, BuildingType.SAFETY
    };

    private double maintenanceBillTotal;
    private double maintenanceMaterialsTotal;
    private double maintenancePointsTotal;
    private double cityMaintenanceBill;
    private double bankMaintenanceBill;
    private final Map<String, Double> maintenanceBySector = new LinkedHashMap<>();

    private static final double MAINTENANCE_RATE = ham.citybuildersim.sectors.RealEstate.MAINTENANCE_PER_YEAR / 12;

    /*
     * THE REPAIR BILL KEEPS UP TOO (0.7.19; Game, THE BUILDERS' PRICE). Its
     * non-material part is the buildings' cash cost with its labour at
     * today's builders' wages (BuildingManager.nonMaterialCost()) - it was
     * the founding cash cost, and in Jerus's city the $119.5M a month of it
     * was 13.5 times short of the crews' wages by month 1793 - and the bill
     * carries the sales tax the builders remit on it (withBuildersTax()). A
     * business that makes taxable supplies claims that tax back, as an input
     * (settleSalesTax()); the city, the bank and the landlords bear it - the
     * landlords' rebates are on new homes, not on repairs to them (see THE
     * REBATES ON A NEW HOME, AND THE CITY'S).
     */

    /** The month's repair bill for one sector, in money - materials priced in, and the builders' sales tax. */
    public double maintenanceBillFor(Sector s, double materialPrice) {
        double cash = buildingManager.totalBySector(s.key(), buildingManager::nonMaterialCost) * MAINTENANCE_RATE;
        double mats = buildingManager.totalBySector(s.key(), BuildingsTemplate::getConstructionMaterials) * MAINTENANCE_RATE;
        double bill = withBuildersTax(cash + mats * Math.max(0, materialPrice));
        return Double.isFinite(bill) && bill > 0 ? bill : 0;
    }

    /** The same for a city-owned category. */
    public double maintenanceBillFor(BuildingType category, double materialPrice) {
        double cash = buildingManager.getTotalByCategoryDouble(category, t -> t.isOwnedBySector() ? 0 : buildingManager.nonMaterialCost(t)) * MAINTENANCE_RATE;
        double mats = buildingManager.getTotalByCategoryDouble(category, t -> t.isOwnedBySector() ? 0 : t.getConstructionMaterials()) * MAINTENANCE_RATE;
        double bill = withBuildersTax(cash + mats * Math.max(0, materialPrice));
        return Double.isFinite(bill) && bill > 0 ? bill : 0;
    }

    /* ------------------------ the builders' sales tax ------------------------ */

    /** What the builders charge their sales tax at. */
    public double buildersSalesRate() {
        return Math.max(0, Math.min(TaxPolicy.MAX_INCOME_TAX, taxPolicy.effectiveSalesRate(sectors.construction())));
    }

    /**
     * A price before the builders' sales tax, with it passed on (0.7.19): the
     * builders remit their rate on what they bill, so what they bill for a
     * price p that is theirs to keep is p / (1 - rate). See Game, THE
     * BUILDERS' PRICE.
     */
    public double withBuildersTax(double beforeTax) {
        return beforeTax / (1 - buildersSalesRate());
    }

    /**
     * WHETHER AN OWNER CLAIMS THE TAX ON ITS BUILDINGS BACK (0.7.19). Jerus:
     * "Businesses claim it back: input tax credits on buildings and repairs
     * for businesses; the city and households bear the tax." The GST/HST
     * rule: a registrant claims an input tax credit for the tax paid on
     * capital real property it uses primarily in its commercial activities
     * (CRA, Guide RC4022, "Claiming ITCs for capital real property"; Excise
     * Tax Act s. 169(1)), and a "commercial activity" excludes the making of
     * exempt supplies (ETA s. 123(1)), so property used to make them earns
     * no credit. Repairs are an input, credited the same way. Here: a sector that makes a taxable
     * good claims; the landlords, whose residential rent is an exempt supply
     * (Good.taxExempt(); ETA Schedule V, Part I), do not; nor the bank's
     * branch, which retail pays for but the bank uses to supply financial
     * services, exempt too (ETA Schedule V, Part VII); nor the city. (The
     * landlords' rebates on a new home, since the revision, are not a
     * credit and are apart: THE REBATES ON A NEW HOME, AND THE CITY'S.)
     */
    public boolean claimsTaxOnBuildings(String owner, BuildingsTemplate t) {
        if (t != null && "Commercial Bank".equals(t.getName())) return false;
        Sector s = owner == null ? null : sectors.byKey(owner);
        return s != null && makesTaxableSupplies(s);
    }

    /** A sector with a good the sales tax touches. */
    private static boolean makesTaxableSupplies(Sector s) {
        for (Good g : s.goodsMade()) if (!g.taxExempt()) return true;
        return false;
    }

    /**
     * What a building's price before the builders' tax costs this owner in
     * the end: the price, and whatever of the tax on it the owner does not
     * get back - none of it for a business that claims it, none for a
     * landlord's purpose-built rental, the tax less a new rental's rebate
     * for any other home, all of it for everyone else. See
     * taxRecoveredShare().
     */
    public double ownersBuildCost(BuildingsTemplate t, String owner, double beforeTax) {
        double gross = withBuildersTax(beforeTax);
        double share = taxRecoveredShare(owner, t, gross - beforeTax);
        if (share <= 0) return gross;
        if (share >= 1) return beforeTax;
        return beforeTax + (gross - beforeTax) * (1 - share);
    }

    /**
     * ...and a REPAIR bill's (0.7.19, revised): the bill itself when the
     * owner claims the tax on it back as an input, the bill with the tax
     * when it cannot. No rebate reaches a repair: a landlord's rent is an
     * exempt supply, so the tax on keeping a rental up is the landlord's to
     * bear (CRA RC4231 counts only a substantial renovation - "generally,
     * 90% or more of the interior ... removed or replaced" - as new housing).
     */
    public double ownersRepairCost(BuildingsTemplate t, String owner, double beforeTax) {
        return claimsTaxOnBuildings(owner, t) ? beforeTax : withBuildersTax(beforeTax);
    }

    /* =====================================================================
       THE REBATES ON A NEW HOME, AND THE CITY'S (0.7.19, revised)

       Jerus, 2026-09-30: "Both rebates (Recommended)". The builders' tax on
       a new home, and on the city's own works, is given back as Canada gives
       it back.

       THE LANDLORDS. A new rental building that is PURPOSE-BUILT RENTAL
       HOUSING gets 100% of the GST (or the federal part of the HST) back:
       "at least 4 residential units each with a private kitchen, a private
       bathroom, and a private living area", or "at least 10 residential
       units", "at least 90%" of them held for long-term rental (CRA, "GST/HST
       purpose-built rental housing rebate", 2026-06-21; Excise Tax Act
       s. 256.2(3.1)-(3.2); RC4231). A home here is a household's own
       dwelling - it cooks, washes and lives in it - and every home the
       landlords own is let, so the test is the template's dwellings: a
       building of PBRH_MIN_UNITS or more qualifies (Studio Apartments, 80;
       Low-Rise Apartments, 63) and a House, one, does not. The rebate's
       window - construction begun after September 13, 2023 and before 2031 -
       is not read off the calendar, which is presentation only (CityCalendar):
       the rebate is the city's law for as long as the game runs.

       A home that is not purpose-built rental gets the NEW RESIDENTIAL RENTAL
       PROPERTY rebate, where its value allows (RC4231; ETA s. 256.2(3)(a)):
       A x ($450,000 - B) / $100,000 a unit, A the lesser of $6,300 and 36% of
       the tax on the unit, B the greater of $350,000 and the unit's fair
       market value - "the value of the building, the applicable land, and
       all other structures", without the tax. The dollar figures are
       founding money at the month's price index in today's unit, as every
       sourced figure here is (the law has held them since 2000, but a
       figure that inflation erodes to nothing over a game's centuries would
       be a date, not a rule). A House's structure and plot are about $454k
       at founding, past the $450k where the rebate is gone, so a House
       mostly bears its tax, as a single house does.

       Either is claimed AFTER THE TAX IS PAID, on what was paid: the source
       gives the landlord two years from the month the tax becomes payable,
       and here it is claimed at the first strike after each part of the work
       is billed - the capital credit's path (settleSalesTax()), the earliest
       the source allows. The treasury pays it out of the sales tax it
       collects, so it is declared where the tax is. No rebate reaches the
       landlords' repairs (ownersRepairCost()).

       THE CITY. A municipality gets 100% of the GST back on what it buys
       (CRA RC4034, "GST/HST public service bodies' rebate", 2025-05-29:
       municipalities, 100% of the GST or the federal part of the HST - 57.14%
       of the provincial part in Nova Scotia, 78% in Ontario), claimed after
       the claim period in which the tax was paid. Here the city IS the
       taxing authority: the builders remit the tax on the city's own work,
       its escalation and its repairs to the treasury, at the strike after
       the work is billed - the same money at the same time a rebate claimed
       after paying would bring back. So the city's rebate is already how the
       money moves, and no line is added for it: one would be the treasury
       paying itself. What the city does carry is the tax on an order it has
       paid for and the builders have not yet billed, as every owner carries
       it (the order pays its whole quote up front).
       ===================================================================== */

    /** A building with this many dwellings or more is purpose-built rental housing (CRA: "at least 4 residential units each with a private kitchen, a private bathroom, and a private living area"). */
    public static final int PBRH_MIN_UNITS = 4;
    /** The new residential rental property rebate's share of the tax on a unit: 36% (Excise Tax Act section 256.2(3)(a); CRA RC4231). */
    public static final double NRRP_SHARE = .36;
    /** ...and its most a unit, in founding thousands: $6,300. */
    public static final double NRRP_CAP = 6.3;
    /** ...in full for a unit worth up to this, in founding thousands: $350,000. */
    public static final double NRRP_FULL_BELOW = 350;
    /** ...and none for a unit worth this or more: $450,000. */
    public static final double NRRP_NONE_FROM = 450;

    /** Today's money for a founding dollar: the month's price index over the unit. Supplied by Game; one without it. */
    private java.util.function.DoubleSupplier foundingToToday = () -> 1;
    public void setFoundingToToday(java.util.function.DoubleSupplier s) { if (s != null) foundingToToday = s; }

    /** Whether this building is one of the landlords' homes. */
    public boolean isLandlordsHome(String owner, BuildingsTemplate t) {
        return t != null && t.getDwellings() > 0 && owner != null && owner.equals(sectors.realEstate().key());
    }

    /** Whether a home of this template is purpose-built rental housing. See THE REBATES ON A NEW HOME. */
    public static boolean isPurposeBuiltRental(BuildingsTemplate t) {
        return t != null && t.getDwellings() >= PBRH_MIN_UNITS;
    }

    /**
     * The new residential rental property rebate on one building of this
     * template, on this much tax paid on it, in today's money: A x ($450,000
     * - B) / $100,000 a unit (THE REBATES ON A NEW HOME). The unit's value is
     * its structure at today's price before the tax, and its plot.
     */
    public double rentalPropertyRebate(BuildingsTemplate t, double taxPerBuilding) {
        int units = t == null ? 0 : t.getDwellings();
        if (units <= 0 || !(taxPerBuilding > 0)) return 0;
        double scale = Math.max(0, foundingToToday.getAsDouble());
        if (!(scale > 0)) return 0;
        double structure = buildingManager.nonMaterialCost(t)
                + t.getConstructionMaterials() * Math.max(0, buildingManager.getConstructionMaterialPrice());
        double value = (structure + t.getLandSqFt() * Math.max(0, landPricePerSqFt)) / units;
        double a = Math.min(NRRP_CAP * scale, NRRP_SHARE * taxPerBuilding / units);
        double b = Math.max(NRRP_FULL_BELOW * scale, value);
        double rebate = a * (NRRP_NONE_FROM * scale - b) / ((NRRP_NONE_FROM - NRRP_FULL_BELOW) * scale);
        return Double.isFinite(rebate) && rebate > 0 ? rebate * units : 0;
    }

    /**
     * The share of the builders' tax on a new building that its owner gets
     * back (0.7.19, revised): all of it for a business that claims it as a
     * credit (claimsTaxOnBuildings()) and for a landlord's purpose-built
     * rental; the new rental property rebate's share of it for any other
     * home the landlords build; none for the bank's branch, and none for the
     * city, whose rebate is the tax coming home (THE REBATES ON A NEW HOME,
     * AND THE CITY'S).
     *
     * @param taxPerBuilding the builders' tax paid on one building
     */
    public double taxRecoveredShare(String owner, BuildingsTemplate t, double taxPerBuilding) {
        if (claimsTaxOnBuildings(owner, t)) return 1;
        if (!isLandlordsHome(owner, t)) return 0;
        if (isPurposeBuiltRental(t)) return 1;
        if (!(taxPerBuilding > 0)) return 0;
        return Math.max(0, Math.min(1, rentalPropertyRebate(t, taxPerBuilding) / taxPerBuilding));
    }

    /** The material UNITS the whole city's repairs consume this month. */
    public double maintenanceMaterialsTotal() {
        double mats = buildingManager.getTotalDouble(BuildingsTemplate::getConstructionMaterials) * MAINTENANCE_RATE;
        return Double.isFinite(mats) && mats > 0 ? mats : 0;
    }

    /** The builders' time the whole city's repairs consume this month. */
    public double maintenancePointsTotal() {
        double pts = buildingManager.getTotalDouble(BuildingsTemplate::getConstructionPoints) * MAINTENANCE_RATE;
        return Double.isFinite(pts) && pts > 0 ? pts : 0;
    }

    /**
     * Hands every owner its repair bill for the month. No money moves here:
     * the figure is assigned, each income statement subtracts it, and what
     * a sector banks is already net of it. Game.chargeBuildingMaintenance()
     * owns the other half - the materials really consumed, the builders
     * really paid.
     *
     * @param materialPrice what a unit of construction material costs today
     */
    public void chargeMaintenance(double materialPrice) {
        maintenanceBySector.clear();
        maintenanceBillTotal = 0;
        cityMaintenanceBill = 0;
        bankMaintenanceBill = 0;

        for (Sector s : sectors.all()) {
            double bill = maintenanceBillFor(s, materialPrice);
            s.setMaintenanceExpense(bill);
            maintenanceBySector.put(s.key(), bill);
            maintenanceBillTotal += bill;
        }
        for (BuildingType category : CITY_MAINTAINED) {
            double bill = maintenanceBillFor(category, materialPrice);
            cityMaintenanceBill += bill;
            maintenanceBillTotal += bill;
        }
        // ...and the bank's branches, which are commercial buildings nobody in the private sector owns.
        BuildingsTemplate branch = buildingManager.getTemplateByName("Commercial Bank");
        if (branch != null) {
            int n = buildingManager.getQuantity(branch.getId());
            double bill = withBuildersTax(n * (buildingManager.nonMaterialCost(branch)
                    + branch.getConstructionMaterials() * Math.max(0, materialPrice)) * MAINTENANCE_RATE);
            if (Double.isFinite(bill) && bill > 0) {
                bankMaintenanceBill = bill;
                maintenanceBillTotal += bill;
            }
        }
        maintenanceMaterialsTotal = maintenanceMaterialsTotal();
        maintenancePointsTotal = maintenancePointsTotal();
    }

    /** Every owner's repair bill added up - what the builders are owed. */
    public double getMaintenanceBillTotal()      { return maintenanceBillTotal; }
    /** The share of it the treasury pays, because the city owns those buildings. */
    public double getCityMaintenanceBill()       { return cityMaintenanceBill; }
    /** The share the bank pays, for its branches. */
    public double getBankMaintenanceBill()       { return bankMaintenanceBill; }
    /**
     * ...AND WHAT THESE BRANCHES COST TO RUN (0.7.19): the template's upkeep,
     * a branch's rent, systems and supplies, which was charged to nobody
     * until then. Not a repair, so not the builders': the bank pays it with
     * its staff at the settle (Bank.payRunning()), on the branches standing
     * THEN - so a branch the fee rule closed this month (Game.closeBranches())
     * is not paid for, as its staff are not. The repairs were billed at the
     * top of the month, on the buildings that stood for the builders to
     * repair.
     *
     * THE CHARTER PAYS NONE OF IT (revised; Jerus, 2026-09-30, "Exempt first
     * branch"): of the branches standing, one is the charter - they are a
     * count, not named buildings - and the operating cost is the rest's. See
     * Bank, THE BRANCHES, BY THEIR CUSTOMERS.
     */
    public double bankOperatingCost(int branches) {
        if (branches <= 1) return 0;
        double running = (branches - 1) * bankOperatingCostPerLaterBranch();
        return Double.isFinite(running) && running > 0 ? running : 0;
    }

    /** ...what one branch past the charter carries of it: the template's upkeep. */
    public double bankOperatingCostPerLaterBranch() {
        BuildingsTemplate branch = buildingManager.getTemplateByName("Commercial Bank");
        if (branch == null) return 0;
        double upkeep = branch.getUpkeep();
        return Double.isFinite(upkeep) && upkeep > 0 ? upkeep : 0;
    }
    /** Material UNITS, not money - the yard has to find these. */
    public double getMaintenanceMaterialsTotal() { return maintenanceMaterialsTotal; }
    /** Builders' time, which comes straight off what the city can put up. */
    public double getMaintenancePointsTotal()    { return maintenancePointsTotal; }
    /** One sector's bill, for the screens. */
    public double getMaintenanceCharge(String key){ return maintenanceBySector.getOrDefault(key, 0.0); }

    /* ------------------------------ the strike ------------------------------ */

    /**
     * Strikes every sector's statement, settles the VAT from the same
     * figures, and banks the month. Once, at the top of the month, after
     * the bills are set. See Sector.strike() and bank(). Then the grocers'
     * suppliers' credit, both sides (0.7.44; settleSupplierCredit()).
     */
    public void strikeSectors() {
        for (Sector s : sectors.all()) {
            s.setTaxRate(taxPolicy.effectiveProfitRate(s));
            s.strike();
        }
        settleSalesTax();
        settleSupplierCredit();
    }

    /**
     * THE SUPPLIERS' CREDIT, SETTLED AT THE STRIKE (0.7.44; SupplierCredit).
     * The month just banked charged each buyer the whole of its stock bill
     * and paid each supplier the whole of its sale. For a buyer whose
     * suppliers waited, this hands back to its till what it bought on their
     * credit at the clearing the strike banked, and takes from it what it
     * owed from the clearing before - the stock that has since been sold -
     * and does the opposite to each local supplier, by its share: so the
     * cash a supplier is not yet paid stays in the buyer's till, and both
     * pools move at once, inside the money audit's window. The world's share
     * has no pool here; MoneyAudit declares it, a financial flow in when it
     * is taken and out when it is repaid ("SupplierCredit").
     */
    void settleSupplierCredit() {
        for (Sector s : sectors.all()) {
            SupplierCredit credit = s.supplierCredit();
            if (credit == null) continue;
            credit.strike();
            double moved = 0;
            for (String supplier : credit.suppliers()) {
                double net = credit.owedTo(supplier) - credit.repaidTo(supplier);
                if (net == 0) continue;
                moved += net;
                Sector seller = sectors.byKey(supplier);
                if (seller != null) seller.addCash(-net);
            }
            if (moved != 0) s.addCash(moved);
        }
    }

    /**
     * The month's sales tax, STRUCK FROM THE TRADES. A sale to a local
     * buyer at the seller's rate; an export zero-rated; a purchase from a
     * local supplier credited at THE SUPPLIER's rate, which is what it
     * actually remitted; an import charged at the buyer's own. Housing is
     * an exempt supply, so the landlords' sales are neither charged nor
     * credited (Good.taxExempt()). This was eleven hand-written lines with
     * three known asymmetries; it is one loop now.
     */
    public double settleSalesTax() {

        salesTaxLedger.startMonth();
        Map<String, Double> capitalCredit = new LinkedHashMap<>();

        for (Sector s : sectors.all()) {
            Sector.Statement st = s.statement();
            double taxable = st.localSales - exemptSales(s);
            salesTaxLedger.recordSales(s.key(), taxable + st.otherRevenue);
            salesTaxLedger.recordExport(s.key(), st.exports);
            for (Map.Entry<String, Double> e : st.purchasesBySupplier.entrySet()) {
                Sector supplier = sectors.byKey(e.getKey());
                double rate = supplier == null ? 0 : taxPolicy.effectiveSalesRate(supplier);
                salesTaxLedger.recordInputTax(s.key(), e.getValue() * rate);
            }
            salesTaxLedger.chargeImport(s.key(), st.imports, taxPolicy);
            /*
             * THE TAX ON A BUILDING IS CLAIMED BACK (0.7.19), by a business
             * that makes taxable supplies (claimsTaxOnBuildings()): on the
             * builders' work on its premises and the escalation on it, as the
             * work is billed, at the builders' rate - a capital credit, handed
             * to the till apart (Sector.bank()) - and on its repair bill, an
             * input like any other. A landlord's rebate on a new rental home
             * (revised) comes the same way, without the repairs: the share of
             * the work the rebate reaches is recorded as its capital purchase
             * (Game.settleSiteContracts()) and credited here at the builders'
             * rate.
             */
            double capital = 0;
            for (Map.Entry<String, Double> e : st.capitalBySupplier.entrySet()) {
                Sector supplier = sectors.byKey(e.getKey());
                double rate = supplier == null ? 0 : taxPolicy.effectiveSalesRate(supplier);
                capital += e.getValue() * rate;
            }
            if (capital != 0) {
                salesTaxLedger.recordCapitalInputTax(s.key(), capital);
                capitalCredit.put(s.key(), capital);
            }
            if (makesTaxableSupplies(s)) {
                salesTaxLedger.recordInputTax(s.key(), st.maintenance * buildersSalesRate());
            }
        }

        salesTax = salesTaxLedger.settle(taxPolicy);

        // AND THE SECTORS PAY IT, ON THEIR OWN INCOME STATEMENTS, and bank
        // the month net of both taxes - one movement, one place, one set of
        // numbers.
        for (Sector s : sectors.all()) {
            s.bank(salesTaxLedger.getNet(s.key()), capitalCredit.getOrDefault(s.key(), 0.0));
        }

        return salesTax;
    }

    /** The exempt part of a sector's local sales: what it sold of goods the tax never touches. */
    private double exemptSales(Sector s) {
        return exemptOf(s, s.statement().localSales);
    }

    /** ...of these local sales: all of them for a sector making only exempt goods, none otherwise. */
    private static double exemptOf(Sector s, double localSales) {
        boolean anyExempt = false;
        for (Good g : s.goodsMade()) if (g.taxExempt()) anyExempt = true;
        if (!anyExempt) return 0;
        // A sector making only exempt goods sold nothing taxable; one making
        // both would need the split by good, which no sector does today.
        for (Good g : s.goodsMade()) if (!g.taxExempt()) return 0;
        return localSales;
    }

    /**
     * The sales tax a sector's month owes SO FAR, off its ledger as it stands
     * (0.7.12 round 6): settleSalesTax()'s arithmetic for one sector - its
     * taxable sales at its own rate, less the credit on what it bought at
     * each supplier's; an import's tax is charged and credited, and nets to
     * nothing. Read by what it can pay for as the markets clear
     * (purchaseBudget()), where every purchase still to come can only add a
     * credit.
     */
    private double salesTaxSoFar(Sector s, Sector.Ledger p) {
        double taxable = p.localSales - exemptOf(s, p.localSales) + p.otherRevenue;
        double due = Math.max(0, taxable) * taxPolicy.effectiveSalesRate(s);
        for (Map.Entry<String, Double> e : p.purchasesBySupplier.entrySet()) {
            Sector supplier = sectors.byKey(e.getKey());
            double rate = supplier == null ? 0 : taxPolicy.effectiveSalesRate(supplier);
            if (e.getValue() > 0) due -= e.getValue() * rate;
        }
        // ...and the credits on its buildings and its repairs (0.7.19), which
        // settleSalesTax() nets inside the same remittance.
        for (Map.Entry<String, Double> e : p.capitalBySupplier.entrySet()) {
            Sector supplier = sectors.byKey(e.getKey());
            double rate = supplier == null ? 0 : taxPolicy.effectiveSalesRate(supplier);
            due -= e.getValue() * rate;
        }
        if (makesTaxableSupplies(s)) due -= s.getMaintenanceExpense() * buildersSalesRate();
        return due;
    }

    /** Whoever the city owes this month, or null. See SalesTaxLedger. */
    public String getDeepestRefundSector()        { return salesTaxLedger.deepestRefund(); }
    public double getSectorSalesTax(String key)   { return salesTaxLedger.getNet(key); }
    public double getSectorSalesTax(Sector s)     { return salesTaxLedger.getNet(s.key()); }

    /* ===================================================================
       INSOLVENCY, at the bottom of the investment step
       =================================================================== */

    private double overdraftForgivenThisMonth;
    private final Map<String, Double> overdraftForgivenBySector = new LinkedHashMap<>();
    private final Map<String, Double> overdraftForgivenThisMonthBySector = new LinkedHashMap<>();

    /**
     * End of the month: work out who is beyond saving and write their debt
     * down to what their assets support - since 0.7.8 each sector's slice of
     * defaulted firms, since 0.7.12 round 4 the part that could not pay its
     * month where that is more, and the whole-sector restructure for a
     * sector with nothing left or, since round 5, one nobody would make an
     * interim loan to (BusinessDebtManager.restructureInsolventSectors()).
     * THE INTERIM LOAN'S CASH is handed to the till here (round 5), and
     * THE OVERDRAFT A RESTRUCTURE FORGAVE is put back into the sector's
     * balance here - it arrives from the creditors who ate it, and
     * MoneyAudit declares it as such.
     *
     * @return total written off this month
     */
    public double settleInsolvency() {
        pushBalanceSheetInputs();
        refreshCreditAssets();
        businessDebtManager.advanceBlocks();
        double writtenOff = businessDebtManager.restructureInsolventSectors();

        overdraftForgivenThisMonth = 0;
        overdraftForgivenThisMonthBySector.clear();
        for (Sector s : sectors.all()) {
            /*
             * INTERIM FINANCING (0.7.12, round 5): what the month's bills left
             * unpaid after its default, lent to the sector ranked first - the
             * loan written with the month's lending, which the bank pays out
             * at the settle, its fee kept back; the till is handed the rest,
             * which is the overdraft it closes. Nothing forgiven.
             */
            double interim = businessDebtManager.takeInterimHanded(s.key());
            if (interim > 0) {
                s.addCash(interim);
                GameLog.note(String.format(
                        "%s could not pay its bills: its creditors took a loss, and the bank lent the $%,.0fk still unpaid as interim financing, ranked ahead of its other debt.",
                        s.key(), interim));
            }
            double forgiven = businessDebtManager.takeOverdraftForgiven(s.key());
            overdraftForgivenThisMonthBySector.put(s.key(), forgiven);
            if (forgiven > 0) {
                s.addCash(forgiven);
                overdraftForgivenThisMonth += forgiven;
                overdraftForgivenBySector.merge(s.key(), forgiven, Double::sum);
                GameLog.note(String.format(
                        "%s went bankrupt: $%,.0fk of bills it could not pay were written off.",
                        s.key(), forgiven));
            }
        }
        return writtenOff;
    }

    public double getOverdraftForgiven() { return overdraftForgivenThisMonth; }
    public double getOverdraftForgivenThisMonth(String key) { return overdraftForgivenThisMonthBySector.getOrDefault(key, 0.0); }
    public double getOverdraftForgivenTotal(String key)     { return overdraftForgivenBySector.getOrDefault(key, 0.0); }

    /**
     * Repay what matured - and since 0.7.11 the principal a mortgage's
     * payment took - then borrow if that left the sector short. A maturing
     * loan is usually rolled; a mortgage renews.
     *
     * A SHORT SECTOR SELLS WHAT IT HOLDS FIRST (0.7.12 round 4, CAN'T PAY
     * MEANS DEFAULT - see BusinessDebtManager): by the households' waterfall
     * (Household.settle()), its dollars abroad, then the other sectors' bonds
     * at the price that yields its own borrowing rate
     * (BondMarket.sellForCompany()) - a company holds no shares but its own,
     * which it retires. Then the lender. What is still short is the month's
     * defaults' (settleInsolvency()), and what the month asked it to pay is
     * struck here for them.
     */
    public void settleBusinessCredit(int month) {
        businessDebtManager.processMonth();
        // ...and since 0.7.12 every bond that falls due is paid from its
        // issuer's till to its holders first, so what the till could not pay
        // is the shortfall desk's below - a loan, or a new bond.
        if (bondMarket != null) bondMarket.redeemMaturing(month);
        for (Sector s : sectors.all()) {
            double matured = businessDebtManager.takeMaturedPrincipal(s.key());
            businessDebtManager.setMonthObligations(s.key(), monthObligations(s, matured));
            double cash = s.getCash() - matured;
            if (cash < 0) {
                double need = -cash;
                if (outward != null) need -= outward.recall(s.key(), need, this);
                if (need > 0 && bondMarket != null) {
                    bondMarket.sellForCompany(s.key(), need, businessDebtManager.getRate(s.key()));
                }
                cash = s.getCash() - matured;
            }
            double loss = Math.max(-s.getNetIncome(), 0);
            double lent = businessDebtManager.coverShortfall(s.key(), cash, loss, month);
            // ...less the loan's fee, which the bank keeps back (0.7.7);
            // and a bond's proceeds, net of its costs, where the desk found
            // one cheaper or the bank would not lend (0.7.12). A company
            // that bought the issue paid from its own till, which the market
            // debited: an earlier sector's after its turn, a later one's
            // before it is read.
            cash += lent - BusinessDebtManager.feeOn(lent) + businessDebtManager.takeBondProceeds(s.key());
            s.setCash(cash);
        }
        pushBalanceSheetInputs();
    }

    /**
     * What the month asked a sector to pay (round 4): the costs on this
     * month's statement - the goods it paid for this month, its payroll,
     * utilities and repairs - its interest and its taxes, and the principal
     * that fell due, its loans' and mortgages' and its bonds'. The cash-flow
     * test's denominator (BusinessDebtManager.cannotPayShare()).
     */
    double monthObligations(Sector s, double matured) {
        Sector.Statement st = s.statement();
        // ...the stock its suppliers are waiting for is not paid this month,
        // and what it owed them from the month before is (0.7.44; SupplierCredit).
        double stock = st.inputs - st.paidEarlier - s.getTradeCreditTaken() + s.getTradeCreditRepaid();
        double costs = Math.max(0, stock) + Math.max(0, st.payroll)
                + Math.max(0, st.electricity) + Math.max(0, st.water) + Math.max(0, st.maintenance)
                + Math.max(0, st.interest) + Math.max(0, st.propertyTax) + Math.max(0, st.salesTax)
                + Math.max(0, st.profitTax);
        double bonds = bondMarket == null ? 0 : bondMarket.getRepaid(s.key());
        return costs + Math.max(0, matured) + Math.max(0, bonds);
    }

    /* ===================================================================
       WHAT THE BANK PAID THE SECTORS FOR THE MONEY IN THEIR TILLS
       =================================================================== */

    private final Map<String, Double> depositInterestPaid = new LinkedHashMap<>();

    public void clearDepositInterest() { depositInterestPaid.clear(); }

    public void recordDepositInterest(String sector, double amount) {
        if (sector == null || !(amount > 0)) return;
        depositInterestPaid.merge(sector, amount, Double::sum);
    }

    public double getDepositInterestPaid(String sector) {
        return depositInterestPaid.getOrDefault(sector, 0.0);
    }

    /* ===================================================================
       THE OWNERS AND THE MONEY ABROAD
       =================================================================== */

    private OutwardInvestment outward;
    public void setOutwardInvestment(OutwardInvestment outward) { this.outward = outward; }
    public OutwardInvestment getOutwardInvestment() { return outward; }

    /**
     * WHAT A SECTOR CAN PAY FOR AS THE MARKETS CLEAR (0.7.12 round 6) - see
     * Sector, BUY ONLY WHAT IT CAN PAY FOR.
     *
     * THE TILL THE NEXT STRIKE WILL FIND, before anything bought now: its
     * cash, plus what the month has booked in and less what it has booked
     * out so far, since the ledger banks both at the strike - and less what
     * it owes its suppliers, plus what its buyers owe it, which the strike
     * settles too (0.7.44).
     *
     * LESS WHAT IT CANNOT AVOID, which the strike and the settle take before
     * any purchase's bill is read: this month's payroll, power and water, at
     * what the strike will charge; the repairs, the property tax and the
     * services it is billed for, at the month last struck, since each is
     * charged again at the top of the next; its interest, at today's rates;
     * its sales tax on the month so far (salesTaxSoFar()) and its profit tax
     * on the month so far with all of that taken off - both the most they can
     * come to, since a purchase still to come adds a credit and a cost; the
     * principal that falls due at the settle, its loans' and its bonds'; and
     * the dividend its owners are paid out of the till after the markets
     * clear (Game.payDividends()), which the month pays before the
     * purchase's bill arrives.
     *
     * PLUS WHAT THE SETTLE COULD RAISE, in its own order: its dollars
     * abroad, the other sectors' bonds it holds (at face, as its lender reads
     * them), and the working-capital line
     * (BusinessDebtManager.workingCapitalLine()).
     *
     * AND, FOR A BUYER WITH A SUPPLIER CREDIT (the grocers, 0.7.44), WHAT ITS
     * SUPPLIERS WILL WAIT FOR, on top of all that once it is floored at
     * nothing: the stock it buys is paid for by its own sale (SupplierCredit).
     *
     * AN ESTIMATE, AND NOTHING NEW IN IT: every figure is one a statement, a
     * lender or a market already computes. Infinite - nobody is limited -
     * when the books do not come to a finite figure.
     *
     * @param dividend what its owners are due this month (Game.dividendDueFor())
     * @param month    the month the markets are clearing in
     */
    public double purchaseBudget(Sector s, double dividend, int month) {
        String k = s.key();
        Sector.Statement st = s.statement();
        Sector.Ledger p = s.pending();
        double services = 0;
        for (double v : st.otherInputs.values()) services += v;
        services = Math.max(0, services - st.paidEarlier);
        double costs = Math.max(0, p.purchases()) + Math.max(0, s.getPayroll())
                + Math.max(0, s.getElectricityCost()) + Math.max(0, s.getWaterCost())
                + Math.max(0, st.maintenance) + services
                + Math.max(0, businessDebtManager.getMonthlyInterest(k)) + Math.max(0, st.propertyTax);
        double salesTax = Math.max(0, salesTaxSoFar(s, p));
        double preTax = p.revenue() - costs - salesTax;
        double profitTax = Math.max(0, preTax * taxPolicy.effectiveProfitRate(s));
        // ...less what it owes its suppliers and plus what its buyers owe it,
        // which the next strike settles (0.7.44; SupplierCredit).
        double till = s.getCash() + preTax - profitTax - s.getTradePayable() + s.getTradeReceivable();
        double due = businessDebtManager.principalDueNextMonth(k)
                + (bondMarket == null ? 0 : bondMarket.maturingFace(k, month + 1));
        double atSettle = till - due - Math.max(0, dividend);
        double raised = Math.max(0, getForeignAssets(k)) + Math.max(0, getBondAssets(k))
                + businessDebtManager.workingCapitalLine(k, atSettle, due);
        double budget = atSettle + raised;
        if (!Double.isFinite(budget)) return Double.POSITIVE_INFINITY;
        /*
         * ...AND WHAT ITS SUPPLIERS WILL WAIT FOR (0.7.44), a buyer with a
         * supplier credit's - opened here for the clearing, beside the till it
         * will have at the settle - on top of what its till and its lender
         * cover, and not netted against the bills those could not: it buys
         * stock and nothing else, and the sale of that stock repays it. See
         * SupplierCredit, THE CREDIT IS THE STOCK'S.
         */
        SupplierCredit credit = s.supplierCredit();
        return credit == null ? Math.max(0, budget)
                : Math.max(0, budget) + credit.open(supplierCreditLimit(s), atSettle);
    }

    /** What a buyer's suppliers will wait for this clearing: the grocers' (Retail.supplierCreditLimit()); nothing for anybody else. */
    private static double supplierCreditLimit(Sector s) {
        return s instanceof ham.citybuildersim.sectors.Retail r ? r.supplierCreditLimit() : 0;
    }

    /** What one sector holds abroad, in the city's money at the rate it was last valued at. */
    public double getForeignAssets(String sector) {
        return outward == null ? 0 : outward.localValue(sector);
    }

    /* The bond market (0.7.12), wired by Game: its maturities are paid at the credit settle, and the other sectors' bonds a company holds are among its assets. */
    private BondMarket bondMarket;
    public void setBondMarket(BondMarket market) { this.bondMarket = market; }
    public BondMarket getBondMarket() { return bondMarket; }

    /** What one sector holds of the other sectors' bonds, at face - an asset beside its cash and what it holds abroad (0.7.12). */
    public double getBondAssets(String sector) {
        return bondMarket == null ? 0 : bondMarket.faceHeldBy(sector);
    }

    private Equity equity;
    public void setEquity(Equity equity) { this.equity = equity; }
    public Equity getEquity() { return equity; }

    private final Map<String, Double> equityRaised = new LinkedHashMap<>();
    private final Map<String, Double> dividendsPaid = new LinkedHashMap<>();
    private final Map<String, Double> sharesBoughtBack = new LinkedHashMap<>();

    public void clearEquityFlows() { equityRaised.clear(); dividendsPaid.clear(); sharesBoughtBack.clear(); stolen.clear(); }

    /** Taken from each sector's till by thieves this month. See Crime. Cleared with the equity flows, at the top of the month. */
    private final Map<String, Double> stolen = new LinkedHashMap<>();
    public void recordStolen(String sector, double amount) {
        if (sector == null || !(amount > 0)) return;
        stolen.merge(sector, amount, Double::sum);
    }
    public double getStolen(String sector) { return stolen.getOrDefault(sector, 0.0); }
    public void recordSharesBoughtBack(String sector, double amount) {
        if (sector == null || !(amount > 0)) return;
        sharesBoughtBack.merge(sector, amount, Double::sum);
    }
    public double getSharesBoughtBack(String sector) { return sharesBoughtBack.getOrDefault(sector, 0.0); }
    public void recordEquityRaised(String sector, double amount) {
        if (sector == null || !(amount > 0)) return;
        equityRaised.merge(sector, amount, Double::sum);
    }
    public void recordDividendPaid(String sector, double amount) {
        if (sector == null || !(amount > 0)) return;
        dividendsPaid.merge(sector, amount, Double::sum);
    }
    public double getEquityRaised(String sector)  { return equityRaised.getOrDefault(sector, 0.0); }
    public double getDividendsPaid(String sector) { return dividendsPaid.getOrDefault(sector, 0.0); }

    /* ===================================================================
       THE MONTH, IN THE MIDDLE AND AT THE BOTTOM
       =================================================================== */

    /** The economy's inputs for the month, set from the simulation. Capacities are read live off the buildings. */
    public void updateEcon() {
        updateHousing();
    }

    /**
     * The bottom of the month: every market clears, every maker produces.
     * See Markets.clearMonth(). NOT on the load path - a market clearing IS
     * a month passing, which is the trap the old refreshEconPrices() existed
     * to avoid.
     */
    public void finalEconUpdate(Game game) {
        markets.clearMonth(sectors, game);
        this.interest = 0;
        setElectricityConsumption();
    }

    /** What the load path needs of the bottom of the month, and nothing else: the draw the expense lines need. */
    public void refreshEconPrices() {
        setElectricityConsumption();
    }

    /* ===================================================================
       THE CITY'S BOOKS
       =================================================================== */

    private double salesTax;
    private double totalWageTax;
    private double totalBankTax;
    private double totalContributions;
    private double interest;
    private double utilityIncome = 0;
    private double debt = 0;
    private double GDP;
    private double yearGDP;

    public void setBankTax(double amount) { this.totalBankTax = Math.max(0, amount); }
    public double getBankTax()            { return totalBankTax; }

    /** The profit tax one sector paid this month, as its statement carries it. */
    public double getProfitTax(Sector s) { return s.getProfitTax(); }

    /** Every sector's profit tax but the food industry's, plus the bank's - the "business tax" line. */
    public double getBusinessTax() {
        double total = totalBankTax;
        for (Sector s : sectors.all()) if (s != sectors.industry()) total += s.getProfitTax();
        return total;
    }

    /** The food industry's, on its own line, as the screens have always shown it. */
    public double getIndustrialTax() { return sectors.industry().getProfitTax(); }
    public double getHeavyIndustryTax() { return sectors.heavyIndustry().getProfitTax() + sectors.mining().getProfitTax(); }
    public double getConstructionTax()  { return sectors.construction().getProfitTax(); }
    public double getSalesTax()   { return salesTax; }
    public double getWageTax()    { return totalWageTax; }
    public double getUtilityIncome() { return utilityIncome; }

    /** The banded wage tax on one sector's payroll, asked of the policy rather than multiplied out in the UI. */
    public double wageTaxOnPayroll(double[] payrollPerType) {
        return taxPolicy.wageTaxOn(payrollPerType, null);
    }

    public double getTaxIncome() { return taxTake(true); }

    /**
     * The same take at today's rates, WRITING NOTHING (0.7.31, the Government
     * spec's B8): what Game.getIncome() - the header's EARNED - reads every
     * time the header draws. getTaxIncome() strikes the month's wage tax,
     * contributions and premiums into their fields as it sums them, which the
     * month needs and a getter must not do; read from a screen it rewrote four
     * of the budget's lines at whatever the dials said that moment. The sum
     * is the same arithmetic, so the figure is the same to the bit.
     */
    public double getTaxIncomeNow() { return taxTake(false); }

    /** The tax take, summed; struck into the month's fields only when `strike`. */
    private double taxTake(boolean strike) {
        double profit = 0;
        for (Sector s : sectors.all()) profit += s.getProfitTax();
        // Banded, and summed job type by job type rather than as one total
        // times an average - averaging throws away the distinction the
        // bands exist to express.
        double wageTax = taxPolicy.wageTaxOn(staffedWagePerType, null);
        // Pension contributions, taken off the same staffed wage bill. Revenue, and NOT a tax.
        double contributions = SocialSecurity.contributionsOn(totalWage, taxPolicy.getContributionRate());
        // ...and the EI premium, off the same bill, the same way (2026-09-11).
        double eiPremiums = Math.max(0, totalWage) * taxPolicy.getEiPremiumRate();
        /*
         * ...AND THE HEALTH PREMIUM (2026-09-19), off the same bill again:
         * every wage, employee side, no cap - the EI premium's own base (the
         * insurable cap is on EI's BENEFIT, not its premium). Revenue against
         * the health service's cost, with no automatic balancing: a surplus
         * or a shortfall is the treasury's, per Jerus. Zero at the default,
         * and x + 0.0 is x, so a city that charges none is the city it was.
         */
        double healthPremiums = Math.max(0, totalWage) * taxPolicy.getHealthPremiumRate();
        if (strike) {
            totalWageTax = wageTax;
            totalContributions = contributions;
            totalEiPremiums = eiPremiums;
            totalHealthPremiums = healthPremiums;
        }
        // Property tax and sales tax are NOT recomputed here: the sectors
        // were billed them and bore them, and the city collects the figure
        // the businesses paid.
        return profit + wageTax + salesTax + totalPropertyTax
                + contributions + eiPremiums + healthcareFees + educationFees
                + transitFares + totalBankTax + healthPremiums;
    }

    /* ------------------- WHAT THE POLICY TAB ASKS (0.7.36) -------------------
     *
     * The tax take, the three payroll lines and the pensions under ANOTHER
     * policy - a detached copy the Policy tab has put a staged set of dials
     * through (TaxPolicy.copy(), PolicyPreview) - struck on this month's
     * books by the month's own rules, so the tab's "before -> after" is the
     * model's arithmetic and not the screen's. Pure: nothing here writes a
     * field. At this city's own policy each line is the figure the month
     * booked - property's struck on the roll as it stands, which land changing
     * hands since the charge can move: PolicyPreviewCheck holds every one of
     * them to it.
     */

    /** One sector's profit tax under a policy (M2): its last struck pre-tax income at that policy's rate, nothing on a loss - Sector.strike()'s rule. */
    public double profitTaxUnder(Sector s, TaxPolicy p) {
        return Math.max(s.statement().preTaxIncome * p.effectiveProfitRate(s), 0);
    }

    /**
     * One sector's sales tax under a policy (M2): its net remittance scaled by
     * the ratio of the two rates, or its taxable sales at the rate when it was
     * charged nothing. SCALED, NOT RECOMPUTED (the Policy spec's D11): the
     * credits in the net are what its suppliers charged it, at their own
     * rates, so the ratio is exact while every sector's sales rate moves by
     * the same factor - a base move with no offsets - and an estimate when
     * only some move. The Policy tab's (i) says so.
     */
    public double salesTaxUnder(Sector s, TaxPolicy p) {
        double now = taxPolicy.effectiveSalesRate(s);
        double at = p.effectiveSalesRate(s);
        return now > 1e-9 ? salesTaxLedger.getNet(s.key()) * at / now
                          : salesTaxLedger.getTaxableSales(s.key()) * at;
    }

    /** One sector's property tax under a policy (M2): its land at today's price on that policy's roll share, and its finished buildings, at that policy's monthly rate - getPropertyTaxFor()'s rule. */
    public double propertyTaxUnder(Sector s, TaxPolicy p) {
        double roll = landValueOf(s) * p.assessedLandShare(s.key())
                + buildingManager.getBookValueBySector(s.key());
        return p.propertyTaxOn(roll, s.key());
    }

    /** One wage band's wage tax under a policy (M2): every job type in it, staffed, at that policy's rate for the band - TaxPolicy.wageTaxPerTier()'s rule. */
    public double wageTaxUnder(WageBand band, TaxPolicy p) {
        return Math.max(0, payrollIn(band)) * p.effectiveWageRate(band);
    }

    /** The staffed payroll one wage band carries this month: what its wage tax is struck on. */
    public double payrollIn(WageBand band) {
        double total = 0;
        for (int i = 0; i < staffedWagePerType.length && i < JobType.values().length; i++) {
            if (staffedWagePerType[i] > 0 && WageBand.of(JobType.values()[i]) == band) total += staffedWagePerType[i];
        }
        return total;
    }

    /** The wage bill the pension contribution and both premiums are struck on (M3): the month's total wage, as getTaxIncome() reads it. */
    public double getWageBill() { return Math.max(0, totalWage); }

    /** A premium at this rate off that bill (M3): the EI and health premiums' own rule. */
    public double premiumAt(double rate) { return Math.max(0, totalWage) * rate; }

    /** Pension contributions at this rate off that bill (M3): SocialSecurity's own rule. */
    public double contributionsAt(double rate) { return SocialSecurity.contributionsOn(totalWage, rate); }

    /** What the pensions would come to under a policy (M4): today's seniors at its pension. */
    public double pensionsPaidUnder(TaxPolicy p) { return Math.max(0, seniors) * p.pensionPerSenior(); }

    /* ------------------- EI and the student grant (2026-09-11) ------------------- */

    private double totalEiPremiums;
    private double eiBenefits;
    private double studentGrants;

    /** The month's health premium off every wage, struck in getTaxIncome() beside the EI premium (2026-09-19). */
    private double totalHealthPremiums;

    /** What the health premium raised this month, employee side, off the whole wage bill. */
    public double getHealthPremiums() { return totalHealthPremiums; }

    /**
     * The interest the graduates paid the treasury on their student loans
     * this month (2026-09-21): a revenue line beside the premiums, set by
     * Game off the household ledger the month it is struck. NOT in
     * getTaxIncome(), because Game moves the cash for it where it moves the
     * principal - see syncHouseholdAccounts - and a line in both would arrive
     * twice; the budget carries it through NationalAccounts.
     */
    private double studentLoanInterest;

    /**
     * THE CENTRAL BANK'S TWO BUDGET LINES (0.7.0), set by Game where the
     * central bank settles with the treasury at the top of the month: the
     * remittance in, the interest on the advances out. NOT in getTaxIncome()
     * or getExpenses(), for the student-loan interest's reason: Game moves
     * the cash for both there, and a line in both places would arrive twice.
     */
    private double centralBankRemittance, centralBankInterest;

    public void setCentralBankLines(double remittance, double interest) {
        this.centralBankRemittance = Math.max(0, remittance);
        this.centralBankInterest = Math.max(0, interest);
    }

    public double getCentralBankRemittance() { return centralBankRemittance; }
    public double getCentralBankInterest()   { return centralBankInterest; }

    /** THE TRANSFER FROM THE CITY'S FUND (0.7.14), set by Game where the treasury settles, for the central bank's lines' reason: Game moves the cash there. See NationalAccounts.setFundTransfer(). */
    private double fundTransfer;

    public void setFundTransfer(double transfer) { this.fundTransfer = Math.max(0, transfer); }
    public double getFundTransfer()              { return fundTransfer; }

    /** FOOD ASSISTANCE (0.7.43), set by Game where the treasury pays it, after the month's sale - for the central bank's lines' reason: Game moves the cash there. See NationalAccounts.setFoodAssistance(). */
    private double foodAssistance;

    public void setFoodAssistance(double paid) { this.foodAssistance = Math.max(0, paid); }
    public double getFoodAssistance()          { return foodAssistance; }

    /** Sets the month's student-loan interest, the treasury's. See Game.getStudentLoanInterest(). */
    public void setStudentLoanInterest(double interest) { this.studentLoanInterest = Math.max(0, interest); }

    /** What the graduates paid in interest on their student loans this month. */
    public double getStudentLoanInterest() { return studentLoanInterest; }

    /** The month's EI bill and grant bill as the treasury paid them: set by Game where it pays them, at the top of the month (payEiBenefits() since 0.7.3, payStudentGrants() since 0.7.1), and on the load path. */
    public void setOutsidePayments(double eiBenefits, double studentGrants) {
        this.eiBenefits = Math.max(0, eiBenefits);
        this.studentGrants = Math.max(0, studentGrants);
    }

    public double getEiPremiums()    { return totalEiPremiums; }
    public double getEiBenefits()    { return eiBenefits; }
    public double getStudentGrants() { return studentGrants; }

    /** What the premiums cover of the EI bill. 1 when nobody is drawing it. */
    public double getEiCoverage() {
        return eiBenefits > 0 ? totalEiPremiums / eiBenefits : 1;
    }

    /* ----------------------------- the services ----------------------------- */

    private double healthcareBill, healthcareFees;
    public void setHealthcare(double grossCost, double fees) {
        this.healthcareBill = Math.max(0, grossCost);
        this.healthcareFees = fees;
    }
    public double getHealthcareBill() { return healthcareBill; }
    public double getHealthcareFees() { return healthcareFees; }
    public double getHealthcareNet()  { return healthcareBill - healthcareFees; }

    private double educationBill, educationFees;
    public void setEducation(double grossCost, double fees) {
        this.educationBill = Math.max(0, grossCost);
        this.educationFees = fees;
    }
    public double getEducationBill() { return educationBill; }
    public double getEducationFees() { return educationFees; }
    public double getEducationNet()  { return educationBill - educationFees; }

    /**
     * What the police and the prisons cost this month: payroll and upkeep, no
     * fees - nobody pays to be policed or jailed. See Crime.
     */
    private double safetyBill;
    public void setSafety(double grossCost) { this.safetyBill = Math.max(0, grossCost); }
    public double getSafetyBill() { return safetyBill; }

    /* =======================================================================
       THE TRANSIT BOOKS (2026-09-16)

       The fourth thing the city builds for itself, and the FIRST ONE THAT CAN
       PAY FOR ITSELF. Jerus: "yes riders pay, yes its adjustable, to the point
       you can even make it profitable by alot."

       That is deliberately unlike the other three. Nobody pays to be policed;
       a patient pays something and never enough; a school charges a fee that
       is a rounding error against its wage bill. A tram is different because
       the person on it chose to be, so a fare is a price rather than a charge,
       and a city that sets it high enough is running a business. (To a car
       owner, since 0.7.49: a commuter with no car of their own has no choice,
       and to them it is a charge - see below.)

       AND THE PRICE HAS A COST, which is what stops it being free money: a
       fare high enough to turn a profit is a fare people will not pay, and
       everybody who will not pay it is back in a car on the road the transit
       was built to relieve. The revenue line and the congestion line move
       against each other, and that is the whole decision. See
       InfrastructureManager.ridershipAt() and TaxPolicy.getTransitFare().
       Since 0.7.49 only the owners have a car to go back to: the commuters
       with no car of their own ride at any fare, so a dearer fare takes more
       of their money instead (InfrastructureManager, WHO RIDES, BY WHAT THEY
       PAY).

       PAID SINCE 0.7.49 (B9). The bill below was struck every month and read
       by the national accounts alone: nobody paid it, so the crews' wages
       reached the households from nowhere, and the fares reached the cash
       outside the budget. The treasury pays it now as a promise
       (TreasuryLine.TRANSIT), getExpenses() carries it, and the budget
       carries both the bill and the fares (NationalAccounts' transit pair).
       ======================================================================= */

    private double transitBill, transitFares;
    public void setTransit(double grossCost, double fares) {
        this.transitBill = Math.max(0, grossCost);
        this.transitFares = Math.max(0, fares);
    }
    public double getTransitBill()  { return transitBill; }
    public double getTransitFares() { return transitFares; }

    /** Negative when the fare more than covers the wages, which a player can arrange. */
    public double getTransitNet()   { return transitBill - transitFares; }

    /** ...with another month of fares against this month's bill (0.7.38): the fare dial card's net, its fares InfrastructureManager.faresAt(). Pure. */
    public double transitNetAt(double fares) { return transitBill - Math.max(0, fares); }

    /** What the city paid this month to hold protected sectors at break-even. Reporting only; the cash already left. */
    private double subsidiesPaid;
    public void setSubsidiesPaid(double v) { this.subsidiesPaid = Math.max(0, v); }
    public double getSubsidiesPaid()       { return subsidiesPaid; }

    /* ------------------------------ pensions ------------------------------ */

    private double seniors;
    public void setSeniors(double seniors)   { this.seniors = Math.max(0, seniors); }
    public double getSeniors()               { return seniors; }
    public double getContributions()         { return totalContributions; }
    public double getPensionsPaid()          { return Math.max(0, seniors) * taxPolicy.pensionPerSenior(); }
    public double getPensionShortfall()      { return Math.max(0, getPensionsPaid() - totalContributions); }
    public double getPensionCoverage() {
        double owed = getPensionsPaid();
        if (owed <= 0) return 1;
        return totalContributions / owed;
    }

    /** What the city pays out this month. */
    public double getExpenses() {
        return interest + getPensionsPaid() + eiBenefits + studentGrants + healthcareBill + educationBill
                + safetyBill
                // ...and transit's wages and upkeep (0.7.49, B9), paid by the treasury since.
                + transitBill;
    }

    /** The interest alone, which is the only part of getExpenses() that is CARRIED. */
    public double getInterestAccrued() { return interest; }
    public void setInterest(double value) { this.interest = value; }
    public void updateInterestExpense(double interest) { this.interest += interest; }

    public double getTotalIncome() { return getTaxIncome() - getExpenses(); }

    public void setUtilityIncome(double income) { this.utilityIncome = income; }
    public void setDebt(double debt)            { this.debt = debt; }

    /* ===================================================================
       THE NATIONAL ACCOUNTS
       =================================================================== */

    /**
     * Measures the month's output and the government's books, from the
     * statements the sectors have just struck.
     *
     * Only FINAL sales count: what the shops and the landlords sold to
     * households is C; a mill's sale to a shop is intermediate. Exports are
     * every sector's sales to the world; imports are every sector's
     * purchases from it, split into the three lines the screen has always
     * shown - food (the shops'), materials (the builders'), raw material
     * (everyone else's).
     */
    public void updateNationalAccounts(double constructionWorkDone,
                                       double governmentServices,
                                       double interest,
                                       double capitalSpending,
                                       double landSales,
                                       double landPurchases,
                                       double propertyTax) {

        var retail = sectors.retail();
        var construction = sectors.construction();
        /*
         * CONSUMPTION IS WHAT HOUSEHOLDS BOUGHT, AND THAT IS MORE THAN ONE
         * SECTOR NOW (2026-09-17).
         *
         * This read Retail alone, which was true for as long as Retail was the
         * only thing a household could buy from. The luxury shops broke it in
         * the worst possible way: their IMPORTS land in net exports, which is
         * in GDP, and their SALES landed nowhere - so a city that took up
         * shopping reported NEGATIVE GDP sixty times over a run, worst at
         * -4,193 with raw imports of 8,636 against exports of 1. The goods
         * arrived and nobody had bought them.
         *
         * Named rather than summed over every sector, because two of the
         * others sell to households and are not goods consumption: Real Estate
         * is the housing line right below, and Automotive's cars go through
         * the market rather than a shop. Anything new that sells over a
         * counter belongs here the day it is written.
         */
        double retailSales = retail.statement().salesToHouseholds
                + sectors.luxuryRetail().statement().salesToHouseholds
                // ...and a dinner, which is consumption bought over a counter
                // like the other two. See the note above.
                + sectors.restaurants().statement().salesToHouseholds
                // ...and the drivers' fuel off the refiners' shelf (0.7.62), over
                // the pump's counter: without it a refinery's crude imports would
                // land in net exports with the fuel they became bought by nobody.
                // The world's part of their fuel is in neither C nor the imports.
                + sectors.refining().statement().salesToHouseholds;
        double rentPaid = sectors.realEstate().statement().salesToHouseholds;

        /*
         * THIRTEEN GOODS, AND STILL A VOLUME - WHICH IS THE WHOLE POINT.
         *
         * Kilograms of grain do not add to kilograms of fish, so the obvious
         * move is to value each good's stock at its own price and hand the
         * accounts the money. THAT IS THE BUG NationalAccounts.update() WARNS
         * AGAINST IN THE LINES THAT RECEIVE THIS: "a change in PRICE is neither
         * production nor consumption, and measuring the change in value rather
         * than in volume booked every price move as production". Done that way,
         * every wobble in the food market becomes output.
         *
         * So the thirteen are aggregated at FIXED WEIGHTS - each good's world
         * import price, which is a constant of the model and cannot move - to
         * make one volume index that behaves exactly as a count of loaves did.
         * The deflator beside it is what that volume costs in this city today,
         * so the accounts still multiply a change in volume by a price, which
         * is the shape the comment asks for.
         *
         * MATERIALS IS STILL ONE GOOD and is still counted in bricks.
         */
        double foodUnits = 0, foodWrittenOff = 0, foodAtLocal = 0;
        double materialUnits = 0;
        for (Sector s : sectors.all()) {
            for (Good fg : ham.citybuildersim.sectors.Retail.SHELF) {
                double held = s.getStock(fg) + s.getPantry(fg);
                foodUnits      += held * fg.worldImportPrice();
                foodWrittenOff += s.output(fg).writtenOff * fg.worldImportPrice();
                foodAtLocal    += held * Math.max(0, markets.get(fg).getLocalPrice());
            }
            materialUnits += s.getStock(Good.MATERIALS);
        }
        double foodPrice = foodUnits > 0 ? foodAtLocal / foodUnits : 0;
        double materialPrice = markets.get(Good.MATERIALS).getLocalPrice();

        /*
         * AND THE LUXURY SHELF, which is one good counted in pieces and needs
         * no weighting. Summed over every sector rather than off the boutiques
         * for the same reason the two above are: the accounts want the city's
         * stock, not one sector's, and a loop cannot forget a sector that
         * starts holding the good later. See the note in NationalAccounts for
         * why a month of imports read as negative output without this.
         */
        double luxuryUnits = 0;
        for (Sector s : sectors.all()) {
            luxuryUnits += s.getStock(Good.LUXURIES) + s.getPantry(Good.LUXURIES);
        }
        // At what a piece costs to bring in, not at the local price: a month
        // nobody bid struck "the middle" of a band with no maker in it, and
        // valued the shelf at half of anything anybody paid. See
        // LuxuryRetail.landedCost().
        double luxuryPrice = ham.citybuildersim.sectors.LuxuryRetail.landedCost(
                markets.get(Good.LUXURIES));

        /*
         * ...AND EVERY OTHER GOOD A SECTOR HOLDS (0.7.58): the farms' crops,
         * every sector's vans and the railway's rolling stock, each good's
         * units summed over every sector's stock and pantry, at what one
         * costs to bring in today - see NationalAccounts, EVERY OTHER GOOD A
         * SECTOR HOLDS IS THE FIFTH TERM, for the month it read as -16,056.
         */
        double[] heldUnits = new double[NationalAccounts.HELD.length];
        double[] heldPrices = new double[NationalAccounts.HELD.length];
        for (int i = 0; i < NationalAccounts.HELD.length; i++) {
            Good g = NationalAccounts.HELD[i];
            for (Sector s : sectors.all()) heldUnits[i] += s.getStock(g) + s.getPantry(g);
            heldPrices[i] = heldPrice(markets.get(g));
        }

        double exports = 0, rawImports = 0;
        for (Sector s : sectors.all()) {
            exports += s.statement().exports;
            if (s != retail && s != construction) rawImports += s.statement().imports;
        }
        double foodImports = retail.statement().imports;
        double materialImports = construction.statement().imports;

        nationalAccounts.update(retailSales, rentPaid,
                constructionWorkDone,
                foodUnits, foodWrittenOff, foodPrice,
                materialUnits, materialPrice,
                luxuryUnits, luxuryPrice,
                governmentServices,
                foodImports, materialImports,
                rawImports, exports,
                heldUnits, heldPrices);

        nationalAccounts.updateGovernment(
                getBusinessTax(), getIndustrialTax(), salesTax, totalWageTax,
                utilityIncome, landSales, propertyTax,
                interest, capitalSpending, landPurchases,
                totalContributions, getPensionsPaid(),
                healthcareFees, healthcareBill,
                educationFees, educationBill,
                subsidiesPaid);
        nationalAccounts.setOutsideLines(totalEiPremiums, eiBenefits, studentGrants,
                totalHealthPremiums, studentLoanInterest);
        nationalAccounts.setSafetySpending(safetyBill);
        nationalAccounts.setTransitLines(transitBill, transitFares);
        nationalAccounts.setCentralBankLines(centralBankRemittance, centralBankInterest);
        nationalAccounts.setFundTransfer(fundTransfer);
        nationalAccounts.setFoodAssistance(foodAssistance);
        setMortgageInsuranceLines();

        GDP = nationalAccounts.getGdp();
    }

    /**
     * What one unit of a held good is counted at (0.7.58): what one costs to
     * bring in this month (GoodsMarket.landedPrice()) - the local price while
     * somebody in the city has it on offer, the import price while nobody
     * does - and the import price, then the local price, when that reads no
     * price at all: a good with no market yet is counted at nothing.
     */
    static double heldPrice(GoodsMarket m) {
        if (m == null) return 0;
        double p = m.landedPrice();
        if (!(p > 0) || !Double.isFinite(p)) p = m.importPrice();
        if (!(p > 0) || !Double.isFinite(p)) p = m.getLocalPrice();
        return p > 0 && Double.isFinite(p) ? p : 0;
    }

    /**
     * Repopulates the government's revenue and expenditure block after a
     * load, and nothing else - running the whole measure would be running
     * a month of the economy with the calendar standing still.
     */
    public void refreshGovernmentAccounts(double landSales, double capitalSpending,
                                          double landPurchases, double interestPaid) {
        getTaxIncome();
        nationalAccounts.updateGovernment(
                getBusinessTax(), getIndustrialTax(), salesTax, totalWageTax,
                utilityIncome, landSales, getTotalPropertyTax(),
                interestPaid, capitalSpending, landPurchases,
                totalContributions, getPensionsPaid(),
                healthcareFees, healthcareBill,
                educationFees, educationBill,
                subsidiesPaid);
        nationalAccounts.setOutsideLines(totalEiPremiums, eiBenefits, studentGrants,
                totalHealthPremiums, studentLoanInterest);
        nationalAccounts.setSafetySpending(safetyBill);
        nationalAccounts.setTransitLines(transitBill, transitFares);
        nationalAccounts.setCentralBankLines(centralBankRemittance, centralBankInterest);
        nationalAccounts.setFundTransfer(fundTransfer);
        nationalAccounts.setFoodAssistance(foodAssistance);
        setMortgageInsuranceLines();
    }

    /**
     * THE MORTGAGE INSURANCE'S TWO BUDGET LINES (0.7.11), off the lender's
     * month: the premiums on the mortgages written, which the treasury took
     * as each was written, and the claims - what the month's write-downs took
     * off insured mortgages, which the treasury paid the bank whole, a claim
     * being a promise (TreasuryLine.MORTGAGE_INSURANCE_CLAIMS). Not in
     * getTaxIncome() or getExpenses(), for the central bank's lines' reason:
     * Game moves the cash where they happen.
     */
    private void setMortgageInsuranceLines() {
        nationalAccounts.setMortgageInsuranceLines(businessDebtManager.getPremiumsThisMonth(),
                businessDebtManager.getInsuredWrittenOffThisMonth());
    }

    public double getLastFoodVolume() { return nationalAccounts.getLastFoodVolume(); }

    /**
     * A NEW SLOT RATHER THAN A CHANGED ONE, because slot 11 changed SCALE.
     *
     * It counted units of FOOD until 2026-09-15 and holds a thirteen-good
     * volume index after it - still a volume, but weighted, so an old file's
     * loaf count read into it would put one month's inventory investment out
     * by the weighting. The index goes in a new slot at the tail and a file
     * without it reads zero, which is exactly the fallback a pre-13-slot file
     * already had.
     */
    public void restoreNationalAccounts(double[] a) {
        if (a == null || a.length < 11) return;
        boolean hasUnits = a.length >= 13;
        boolean hasFoodValue = a.length >= 14;
        /*
         * SLOT 14 IS THE LUXURY SHELF, appended the day the good was written
         * (2026-09-17) and read as zero by every file without it - which is
         * every file older than the sector, and those cities held none. Same
         * tail-append the food index got in slot 13, and for the same reason:
         * a reloaded city that thinks last month's stock was zero counts its
         * whole stockroom as this month's production.
         */
        boolean hasLuxury = a.length >= 15;
        nationalAccounts.restore(a[0], hasFoodValue ? a[13] : 0,
                a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10],
                hasUnits ? a[12] : 0, hasLuxury ? a[14] : 0, hasUnits);
        /*
         * SLOTS 15 ON ARE THE OTHER GOODS HELD (0.7.58), one each in
         * NationalAccounts.HELD's order. A file without them - every file
         * older than the term - leaves the baseline unknown, and the first
         * month books no change in them rather than every fleet in the city.
         */
        int heldAt = 15, held = Math.min(NationalAccounts.HELD.length, a.length - heldAt);
        // ...the three a 0.7.58-0.7.61 file carries, without FUEL's (0.7.62): see restoreHeld().
        nationalAccounts.restoreHeld(held >= NationalAccounts.HELD_BEFORE_FUEL
                ? java.util.Arrays.copyOfRange(a, heldAt, heldAt + held) : null);
    }

    public double[] getNationalAccountsState() {
        double[] base = new double[] {
            nationalAccounts.getGdp(),
            nationalAccounts.getLastFoodVolume(),
            nationalAccounts.getConsumptionGoods(),
            nationalAccounts.getConsumptionHousing(),
            nationalAccounts.getInvestmentConstruction(),
            nationalAccounts.getInvestmentInventories(),
            nationalAccounts.getGovernment(),
            nationalAccounts.getImportsFood(),
            nationalAccounts.getImportsMaterials(),
            nationalAccounts.getImportsRawMaterial(),
            nationalAccounts.getExports(),
            nationalAccounts.getLastFoodVolume(),
            nationalAccounts.getLastMaterialUnits(),
            nationalAccounts.getLastFoodVolume(),    // slot 13 - see restoreNationalAccounts()
            nationalAccounts.getLastLuxuryUnits()     // slot 14 - and the same note
        };
        // ...and slots 15 on, the other goods held (0.7.58), in HELD's order.
        double[] held = nationalAccounts.getLastHeldUnits();
        double[] out = java.util.Arrays.copyOf(base, base.length + held.length);
        System.arraycopy(held, 0, out, base.length, held.length);
        return out;
    }

    double[] governmentMonthToSave()          { return nationalAccounts.governmentToSave(); }
    void restoreGovernmentMonth(double[] m)   { nationalAccounts.restoreGovernment(m); }

    public double getMonthGdp() { return nationalAccounts.getGdp(); }
    public double getYearGdp()  { return yearGDP; }
    public double getGDP()      { return GDP; }
    /** The income rate - the three income taxes together, TaxPolicy.getIncomeTaxRate(): the profit rate once they have parted (0.7.4). */
    public double getTaxRate()  { return taxPolicy.getIncomeTaxRate(); }

    public void setPreviousGdp(HistorySave historySave) {
        List<Double> gdp = new ArrayList<>(historySave.getGdp());
        int start = Math.max(0, gdp.size() - 11);
        List<Double> last11 = gdp.subList(start, gdp.size());
        yearGDP = nationalAccounts.getAnnualGdp();
        if (yearGDP == 0) {
            yearGDP = GDP;
            for (Double d : last11) yearGDP += d;
        }
    }

    /* ===================================================================
       CONVENIENCES - the prices the screens and the harnesses ask for by name
       =================================================================== */

    /** What one person-month of food costs the shops at today's market prices. */
    public double getFoodLocalPrice() { return sectors.retail().getFoodPrice(); }
    public double getIronLocalPrice() { return markets.get(Good.IRON).getLocalPrice(); }

    /** Every warehouse and shelf of food in the city, in KILOGRAMS across the thirteen. */
    public long getFoodUnitsHeld() {
        double kg = 0;
        for (Sector s : sectors.all()) {
            for (Good fg : ham.citybuildersim.sectors.Retail.SHELF) kg += s.getStock(fg) + s.getPantry(fg);
        }
        return (long) Math.floor(kg);
    }

    /* ===================================================================
       SAVE AND RESTORE
       =================================================================== */

    public List<SectorState> getSectorStates()          { return sectors.toState(); }
    public void restoreSectorStates(List<SectorState> s) { sectors.restore(s); pushBalanceSheetInputs(); }

    /** The month's bills back over the rebuild's re-derivation, and the total they add to. */
    public void restoreSectorBills(List<SectorState> saved) {
        if (saved == null) return;
        totalPropertyTax = 0;
        for (SectorState st : saved) {
            if (st == null) continue;
            Sector s = sectors.byKey(st.key);
            if (s == null) continue;
            s.restoreBills(st);
            propertyTaxBySector.put(s.key(), s.getPropertyTaxExpense());
            maintenanceBySector.put(s.key(), s.getMaintenanceExpense());
            totalPropertyTax += s.getPropertyTaxExpense();
        }
    }
    public List<Markets.State> getMarketStates()        { return markets.toState(); }
    public void restoreMarketStates(List<Markets.State> s) { markets.restore(s); }

    public SalesTaxLedger.State getSalesTaxState()      { return salesTaxLedger.toState(); }

    /** The month's VAT back, AND the total that came out of it - one fact. */
    public boolean restoreSalesTaxState(SalesTaxLedger.State state) {
        if (!salesTaxLedger.restore(state)) return false;
        salesTax = salesTaxLedger.getTotalRemitted();
        return true;
    }

    /* ===================================================================
       PRINTERS, RESET, THE REFORM
       =================================================================== */

    public void printWageTaxInfo() {
        System.out.printf("\nTOTAL WAGE TAX INCOME: $%s%n", formatter.format(totalWageTax));
    }

    public void printCityStats() {
        System.out.println("\n====================== CITY FINANCIAL REPORT ======================");
        double totalRev = getBusinessTax() + getIndustrialTax() + salesTax + totalWageTax;
        System.out.println("\n--------------------------- REVENUES ---------------------------");
        System.out.printf("Business Tax Revenue:        $%s Thousand%n", formatter.format(getBusinessTax()));
        System.out.printf("Industrial Tax Revenue:      $%s Thousand%n", formatter.format(getIndustrialTax()));
        System.out.printf("Sales Tax Revenue:           $%s Thousand%n", formatter.format(salesTax));
        System.out.printf("Wage Tax Revenue:            $%s Thousand%n", formatter.format(totalWageTax));
        if (utilityIncome >= 0) {
            System.out.printf("Municipal Services Profit:    $%s Thousand%n", formatter.format(utilityIncome));
            totalRev += utilityIncome;
        }
        System.out.println("---------------------------------------------------------------");
        System.out.printf("TOTAL GOVERNMENT REVENUE:    $%s Thousand%n", formatter.format(totalRev));
        double totalExp = 0;
        System.out.println("\n--------------------------- EXPENSES ---------------------------");
        if (utilityIncome < 0) {
            System.out.printf("Municipal Services Loss:      $%s Thousand%n", formatter.format(utilityIncome));
            totalExp -= utilityIncome;
        }
        System.out.printf("Debt Interest Payments:      $%s Thousand%n", formatter.format(interest));
        totalExp += interest;
        System.out.println("---------------------------------------------------------------");
        System.out.printf("TOTAL GOVERNMENT EXPENSES:   $%s Thousand%n", formatter.format(totalExp));
        System.out.println("\n----------------------- BUDGET BALANCE ------------------------");
        System.out.printf("Monthly Budget Balance:      $%s Thousand%n", formatter.format(totalRev - totalExp));
        System.out.println("\n--------------------- ECONOMIC INDICATORS ---------------------");
        System.out.printf("Monthly GDP:                 $%s Thousand%n", formatter.format(GDP / 12));
        System.out.printf("Annualized GDP:              $%s Thousand%n", formatter.format(yearGDP));
        if (population > 0) {
            System.out.printf("GDP per Capita:              $%s%n", formatter.format(((yearGDP) / population) * 1000));
        }
        System.out.printf("Debt-to-GDP Ratio:           %.2f%%%n", (debt / (yearGDP)) * 100);
        System.out.println("================================================================\n");
    }

    public void resetEconomyManager() {
        cash = 0;
        totalJobs = 0;
        population = 0;
        households = 0;
        totalWageTax = 0;
        interest = 0;
        totalWage = 0;
        totalPropertyTax = 0;
        salesTax = 0;
        sectors.reset();
        markets.reset();
        salesTaxLedger.reset();
    }

    private static final NumberFormat formatter = NumberFormat.getNumberInstance(Locale.CANADA);

    static {
        formatter.setMaximumFractionDigits(2);
        formatter.setMinimumFractionDigits(0);
    }

    /**
     * Every figure the economy manager holds, and every sector and market
     * under it, in the new unit. The markets first: the price a month was
     * traded at and their copy of the exchange rate both move, or the
     * national accounts value the change in the food warehouse at a hundred
     * times the right price for one month and book it as production.
     */
    public void redenominate(double scale) {
        cash *= scale;
        landPricePerSqFt *= scale;
        totalPropertyTax *= scale;
        totalBankTax *= scale;
        totalWageTax *= scale;
        interest *= scale;
        totalWage *= scale;
        GDP *= scale;
        yearGDP *= scale;
        salesTax *= scale;
        utilityIncome *= scale;
        debt *= scale;
        marginalHousingCost *= scale;
        healthcareBill *= scale;   healthcareFees *= scale;
        educationBill  *= scale;   educationFees  *= scale;
        safetyBill     *= scale;
        subsidiesPaid  *= scale;
        totalContributions *= scale;
        totalEiPremiums *= scale;  eiBenefits *= scale;  studentGrants *= scale;
        totalHealthPremiums *= scale;  studentLoanInterest *= scale;
        centralBankRemittance *= scale;  centralBankInterest *= scale;
        fundTransfer *= scale;
        foodAssistance *= scale;
        // ...and the month's transit wages and fares (B6, 0.7.47): the next
        // month bills the households last month's fares (Game.startOfMonthUpdate,
        // households.setTransitFares()), and in the old unit a reform by a
        // thousand billed every working row a thousand times its ride.
        transitBill *= scale;
        transitFares *= scale;
        exchangeRate *= scale;
        pricePerWatt *= scale;
        pricePerWaterUnit *= scale;
        scaleArray(wageRates, scale);
        scaleArray(staffedWagePerType, scale);
        propertyTaxBySector.replaceAll((k, v) -> v * scale);
        maintenanceBySector.replaceAll((k, v) -> v * scale);
        maintenanceBillTotal *= scale;
        cityMaintenanceBill *= scale;
        bankMaintenanceBill *= scale;
        equityRaised.replaceAll((k, v) -> v * scale);
        dividendsPaid.replaceAll((k, v) -> v * scale);
        sharesBoughtBack.replaceAll((k, v) -> v * scale);
        depositInterestPaid.replaceAll((k, v) -> v * scale);
        overdraftForgivenBySector.replaceAll((k, v) -> v * scale);
        overdraftForgivenThisMonthBySector.replaceAll((k, v) -> v * scale);
        overdraftForgivenThisMonth *= scale;

        taxPolicy.redenominate(scale);
        markets.redenominate(scale);
        sectors.redenominate(scale);
        businessDebtManager.redenominate(scale);
        salesTaxLedger.redenominate(scale);
        nationalAccounts.redenominate(scale);
    }

    private static void scaleArray(double[] values, double scale) {
        if (values == null) return;
        for (int i = 0; i < values.length; i++) values[i] *= scale;
    }
}
