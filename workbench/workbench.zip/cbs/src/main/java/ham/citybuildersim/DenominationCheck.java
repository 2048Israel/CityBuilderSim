package ham.citybuildersim;

import java.io.OutputStream;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * A currency reform is a change of units, and this is how we know.
 *
 * WHAT IS ACTUALLY BEING ASKED. Jerus wanted a button that divides the money by
 * ten or a hundred so that three centuries of inflation do not end with bread
 * priced at 300M and the arithmetic losing digits at the bottom. That is a
 * currency reform, and the entire risk in one is that it is not ONLY a change
 * of units: miss one balance and the button quietly creates or destroys money;
 * miss one compile-time constant and a House is a hundred times dearer the next
 * morning.
 *
 * So the test is not a list of fields. It is TWO CITIES:
 *
 *   A runs normally.
 *   B is the same city, reformed, and then run for exactly as long.
 *
 * If the reform is only a change of units then B is A with a different label on
 * the axis: every real quantity identical to the person, every money quantity
 * identical after dividing by the factor, and the two trajectories still on top
 * of each other years later. Any field left unscaled changes a relative price,
 * and a changed relative price changes what gets built and who moves in - so
 * the populations part company and the harness says so.
 *
 * That is a much stronger assertion than "the balances add up", and it is the
 * only one that can be trusted, because nobody can enumerate this codebase's
 * money by reading it.
 */
public class DenominationCheck {

    static int fails = 0;
    static PrintStream out;
    static PrintStream quiet;

    static void assertTrue(String label, boolean ok) {
        if (!ok) fails++;
        out.printf("%-62s %s%n", label, ok ? "OK" : "FAIL");
    }

    /**
     * Everything real to the person, everything nominal to the factor.
     *
     * One helper rather than five repeated blocks, so the month, the year and
     * the decade are held to the SAME standard and the only thing that changes
     * between them is how much floating-point drift is allowed to accumulate.
     */
    static void sameCity(Game plain, Game lopped, double factor, double band) {
        assertTrue("the same people live there, to the person",
                plain.getPopulationManager().getPopulation()
                        == lopped.getPopulationManager().getPopulation());
        relative("the same output", lopped.getEconomyManager().getMonthGdp(),
                plain.getEconomyManager().getMonthGdp() / factor, band);
        relative("...and the same year of it", lopped.getEconomyManager().getYearGdp(),
                plain.getEconomyManager().getYearGdp() / factor, band);
        relative("the same rent", rent(lopped), rent(plain) / factor, band);
        relative("the same price level", lopped.getPriceIndex().getIndex(),
                plain.getPriceIndex().getIndex(), band);
        relative("the same currency", lopped.getForeignAccounts().getRate(),
                plain.getForeignAccounts().getRate() / factor, band);
        relative("the same treasury", lopped.getCash(), plain.getCash() / factor, band);
        relative("the same shops' till",
                lopped.getSectors().retail().getCash(),
                plain.getSectors().retail().getCash() / factor,
                band);
        relative("the same city debt", lopped.getDebtManager().getAllPrincipal(),
                plain.getDebtManager().getAllPrincipal() / factor, band);
        relative("the same bank", lopped.getBank().getDeposits(),
                plain.getBank().getDeposits() / factor, band);
    }

    /** Equal to within a RELATIVE band, so one helper works at any scale. */
    static void relative(String label, double actual, double expected, double band) {
        double scale = Math.max(1e-12, Math.abs(expected));
        double off = Math.abs(actual - expected) / scale;
        if (off > band) {
            fails++;
            out.printf("%-62s FAIL  %,.10f != %,.10f  (%.3g apart)%n",
                    label, actual, expected, off);
        } else {
            out.printf("%-62s OK  (%.1g apart, %.1g allowed)%n", label, off, band);
        }
    }

    /** How far apart two figures are, as a percentage of the expected one. */
    static double gap(double actual, double expected) {
        return Math.abs(expected) < 1e-12 ? 0
                : Math.abs(actual - expected) / Math.abs(expected) * 100;
    }

    static void within(String label, double actual, double expected, double band) {
        double gap = Math.abs(expected) > 1e-12
                ? Math.abs(actual - expected) / Math.abs(expected)
                : Math.abs(actual - expected);
        boolean ok = gap <= band;
        if (!ok) fails++;
        out.printf("%-62s %s  (%.2f%% apart, %.0f%% allowed)%n",
                label, ok ? "OK" : "FAIL", gap * 100, band * 100);
    }

    static void close(String label, double actual, double expected, double tol) {
        boolean ok = Math.abs(actual - expected) <= Math.max(tol, Math.abs(expected) * tol);
        if (!ok) {
            fails++;
            out.printf("%-62s FAIL  %,.8f != %,.8f%n", label, actual, expected);
        } else {
            out.printf("%-62s OK%n", label);
        }
    }

    static void quietly(Runnable work) {
        PrintStream real = System.out;
        System.setOut(quiet);
        try { work.run(); } finally { System.setOut(real); }
    }

    /* ------------------------------------------------------------------ */

    /** A city with a bit of everything in it, so the reform has work to do. */
    static Game city(String name) {
        Game g = new Game(GameFiles.scratch(name));
        quietly(() -> {
            g.run();
            // THE TREASURY THIS FIXTURE WAS WRITTEN AGAINST (0.7.10): its build list
            // is bought out of cash, and a city founds on D$100M since 0.7.10, not the
            // D$2.5B it assumed - so it is given that, the Wealthy preset's, explicitly.
            g.setCashForTest(Founding.WEALTHY_CASH);
            g.getGovernmentInvestor().spend(-2_000_000);
            g.getLandManager().setOwnedSqFt(g.getLandManager().getOwnedSqFt() + 200_000_000L);
            LongPlaytest.build(g, "House", 400);
            LongPlaytest.build(g, "Convenience Store", 20);
            LongPlaytest.build(g, "Construction Depot", 6);
            LongPlaytest.build(g, "Coal Power Plant", 2);
            LongPlaytest.build(g, "Water Treatment Plant", 2);
            LongPlaytest.build(g, "Industrial Bakery", 4);
            LongPlaytest.build(g, "Iron Mine", 2);
            LongPlaytest.build(g, "Steel Foundry", 2);
            LongPlaytest.build(g, "Commercial Bank", 1);
            LongPlaytest.build(g, "Elementary School", 3);
            LongPlaytest.build(g, "Walk-in Clinic", 3);
            LongPlaytest.build(g, "Paved Road", 20);
            g.simulateMonths(120);
        });
        return g;
    }

    /* ------------------------------------------------------------------ */

    public static void main(String[] args) throws Exception {

        out = System.out;
        quiet = new PrintStream(new OutputStream() { @Override public void write(int b) { } });
        Path root = Files.createTempDirectory("denomcheck");

        /* ============ 1. THE UNIT ============ */
        out.println("--- what a reform does to the unit ---");

        Denomination d = new Denomination();
        close("a founding city is in founding money", d.getUnit(), 1, 1e-12);
        assertTrue("...and cannot reform, because nothing has inflated",
                !d.unlocked(1.0));
        assertTrue("...nor at nine times", !d.unlocked(9.0));
        assertTrue("...and can at ten", d.unlocked(Denomination.UNLOCK_AT));

        d.lop(100);
        close("lopping two zeros makes a dollar a hundred old ones", d.getUnit(), 100, 1e-12);
        close("...so a founding price reads as a hundredth", d.money(30), .30, 1e-12);
        // ...of whatever the city named its money (0.7.10): a city founded as Arden.
        Currency arden = Currency.fromCityName("Arden");
        assertTrue("...and the money gets a new name", d.name(arden).startsWith("second"));
        assertTrue("...the city's own money's, renamed", d.name(arden).equals("second " + arden.name()));
        d.lop(1000);
        assertTrue("...and again", d.name(arden).startsWith("third"));
        close("the unit compounds", d.getUnit(), 100_000, 1e-9);

        Denomination big = new Denomination();
        while (big.canLop(1000)) big.lop(1000);
        assertTrue("it stops before a double runs out of digits",
                big.getUnit() <= Denomination.MAX_UNIT && !big.canLop(1000));

        /* ============ 2. IT IS THE SAME CITY ============

           The headline. One city, one reformed copy, and then a hundred months
           on both. Everything real must match to the person and the tonne;
           everything nominal must match after dividing by a hundred.
           ================================================================= */
        out.println("\n--- a reformed city is the same city ---");

        Game plain = city("denom-plain");
        Game lopped = city("denom-lopped");

        assertTrue("fixture: the two cities really are identical to start with",
                same(plain, lopped));

        double factor = 100;

        /*
         * The button is gated on the price level and this fixture's has not
         * moved, so the gate is opened by hand. What is under test is the
         * REFORM, not the threshold - the threshold is tested above, on the
         * Denomination itself, where it can be held still.
         */
        boolean done = force(lopped, factor);
        assertTrue("the reform goes through", done);

        close("cash divided", lopped.getCash(), plain.getCash() / factor, 1e-9);
        close("the exchange rate divided",
                lopped.getForeignAccounts().getRate(),
                plain.getForeignAccounts().getRate() / factor, 1e-9);
        close("the shelf price divided",
                shelf(lopped), shelf(plain) / factor, 1e-9);
        close("rent divided", rent(lopped), rent(plain) / factor, 1e-9);
        close("the minimum wage divided",
                lopped.getLabourMarket().getMinimumWage(),
                plain.getLabourMarket().getMinimumWage() / factor, 1e-9);
        close("a House costs a hundredth as many dollars",
                cost(lopped, "House"), cost(plain, "House") / factor, 1e-9);

        /* =================================================================
           ...AND THE SHARE DESK'S ROOM DOES NOT DIVIDE, WHICH IS THE POINT

           Every line above asks whether a money figure was divided. This one
           asks the opposite question about a figure that is NOT money, and it
           is the question that catches the harder half of this family.

           deskCanBuy() answers in SHARES. Underneath it are two money
           quantities - the desk's book limit and what its book is worth - so
           a reform that divides one and not the other changes an answer that
           has no business moving at all. bookLimit was the one left behind
           (2026-09-17), and because it is re-struck in startMonth() AFTER the
           households settle, a reformed city's desk spent the first half of
           every month believing it had a hundred times the room it had.

           NOTHING ELSE IN THIS HARNESS SAW IT for as long as it existed. The
           desk's room only binds when a household is short enough to sell its
           shares rather than borrow, so the fault sat latent until a change to
           GDP - a fourteenth sector, as it happens - moved the cancellation
           under the limit onto the other side of zero. Then it cost 4.2% of
           household debt in ONE month and a tenth of a percent on every
           headline figure a decade later.

           A RATIO OF TWO MONEY QUANTITIES IS THE GENERAL SHAPE and this is
           the assertion for it: if the answer is not in money, a reform must
           not change it.
           ================================================================= */
        double deskBook = 0;
        for (int c = 0; c < Equity.COMPANIES.length; c++) {
            double was = plain.getExchange().deskCanBuy(plain.getEquity(), c);
            double is = lopped.getExchange().deskCanBuy(lopped.getEquity(), c);
            deskBook += Math.max(0, plain.getEquity().getDealerShares(c));
            close("the desk's room in " + Equity.COMPANIES[c] + " is shares, so it is untouched",
                    is, was, 1e-9);
        }
        /*
         * THE FIXTURE GUARD IS THE DESK'S BOOK, NOT ITS ROOM, and the
         * difference is the whole reason the fault survived. This fixture's
         * desk is FULL: every company's room is zero, because bookAtFair has
         * reached bookLimit. A guard written on the room would read zero on a
         * correct build and call the section vacuous - when a full book is
         * exactly the state that makes the subtraction underneath it a
         * cancellation, and a cancellation is where a missing scale shows.
         *
         * Measured with the scale removed again after this was written: nine
         * of the fifteen companies went red, each of them at several hundred
         * shares of room the desk did not have.
         */
        assertTrue(String.format(
                "fixture: the desk had a book to be wrong about (%,.0f shares)", deskBook),
                deskBook > 0);

        /*
         * ...AND SO DOES EVERY LINE THE INCOME STATEMENT OPENS INTO.
         *
         * The per-good money behind Revenue and the cost of sales (Sector.Split,
         * 2026-09-16) is money like any other and has to divide like any other.
         * It was written with the two scale() calls in place and then they were
         * DELETED to see what would notice: the whole suite, all fifty-two
         * harnesses, stayed green. Nothing else in the game reads these maps -
         * only the screen does - so a reform that left them alone would have
         * shipped a statement whose parts were a hundred times its total, and
         * the only way to find it would have been to reform a city and click.
         *
         * That is the twenty-third of this family and the first one caught
         * before it existed. Both maps, both sides, every sector, every good -
         * the same shape as the claim above it, because "any field left
         * unscaled changes a relative price" is what this harness is for.
         */
        int splitLines = 0;
        for (Sector was : plain.getSectors().all()) {
            Sector is = lopped.getSectors().byKey(was.key());
            for (Good g : Good.values()) {
                Sector.Split soldWas = was.statement().sold.get(g);
                Sector.Split soldIs = is.statement().sold.get(g);
                if (soldWas != null || soldIs != null) {
                    splitLines++;
                    close(was.key() + ": " + g + " sold here divided",
                            soldIs == null ? 0 : soldIs.atHome,
                            (soldWas == null ? 0 : soldWas.atHome) / factor, 1e-9);
                    close(was.key() + ": " + g + " sold abroad divided",
                            soldIs == null ? 0 : soldIs.abroad,
                            (soldWas == null ? 0 : soldWas.abroad) / factor, 1e-9);
                }
                Sector.Split boughtWas = was.statement().bought.get(g);
                Sector.Split boughtIs = is.statement().bought.get(g);
                if (boughtWas != null || boughtIs != null) {
                    splitLines++;
                    close(was.key() + ": " + g + " bought here divided",
                            boughtIs == null ? 0 : boughtIs.atHome,
                            (boughtWas == null ? 0 : boughtWas.atHome) / factor, 1e-9);
                    close(was.key() + ": " + g + " imported divided",
                            boughtIs == null ? 0 : boughtIs.abroad,
                            (boughtWas == null ? 0 : boughtWas.abroad) / factor, 1e-9);
                }
            }
        }
        assertTrue("fixture: there was a per-good breakdown to divide (" + splitLines + " lines)",
                splitLines > 0);

        /* ...and the named parts of revenue that are not a good, the same way. */
        for (Sector was : plain.getSectors().all()) {
            Sector is = lopped.getSectors().byKey(was.key());
            for (java.util.Map.Entry<String, Double> part : was.otherRevenueParts().entrySet()) {
                close(was.key() + ": " + part.getKey().toLowerCase() + " divided",
                        is.otherRevenueParts().getOrDefault(part.getKey(), 0.0),
                        part.getValue() / factor, 1e-9);
            }
        }

        /*
         * ...AND THE RATIOS DID NOT MOVE, which is the other half of the claim
         * and the more important one. A reform that divided everything by
         * slightly different numbers would pass the lines above and fail these.
         */
        close("the price index did not move",
                lopped.getPriceIndex().getIndex(), plain.getPriceIndex().getIndex(), 1e-9);
        close("nor the rent burden",
                lopped.getHouseholds().getRentBurden(),
                plain.getHouseholds().getRentBurden(), 1e-9);
        close("nor the cost of living",
                lopped.getLabourMarket().getCostOfLiving(),
                plain.getLabourMarket().getCostOfLiving(), 1e-9);
        assertTrue("nor the population", plain.getPopulationManager().getPopulation()
                == lopped.getPopulationManager().getPopulation());

        /* ============ 3. AND IT STAYS THE SAME CITY ============

           The assertion that cannot be satisfied by luck, and the one this
           change had to earn the hard way. A reform is a change of UNITS, so
           the reformed city and its unreformed twin should stay the same city
           for ever. They now do: a hundred months on, the same 5,693 people
           live there, the price index agrees to four decimals, and every money
           figure agrees to the last digit once divided.

           WHAT IT TOOK, because this is the part worth writing down. Fourteen
           bugs were found by this harness and every one of them was the same
           SHAPE: a figure that is read before anything rewrites it, which makes
           it a STOCK for as long as it takes to read it, however much it looks
           like a flow. Not one of them created or destroyed a penny, so the
           money audit could not see any of them; they simply valued a real month
           at the wrong scale. In the order they were found:

             1-8   caches, statements and market prices, 2026-09-08
             9-11  the mills', the mines' and the builders' whole income
                   statements. HeavyIndustryHandler.redenominate() carried a
                   long comment explaining that a statement read before it is
                   rewritten is a stock, and then no code under it at all.
             12    THE MILLS' OWN COPY OF THE WAGE SCALE, and the loudest of the
                   lot. EconomyManager pushes it in every month, so it looks like
                   it cannot go stale - and it goes stale for exactly one month,
                   which is the month that matters. computeMonthlyReport() runs
                   at the top of the tick, before the push. So a reformed city's
                   mills paid a hundred times their whole revenue in wages for
                   one month, borrowed to cover the hole, and dragged the bank's
                   deposit book, its funding cost and its foreign borrowing with
                   them. The REAL economy stayed exact throughout, which is why
                   it survived so long: nothing a player looks at first was wrong.
             13    the tuition table, which is not merely a misreport - it feeds
                   affordability(), so a reformed city's students could no longer
                   pay for school and the pipeline stalled for ever.
             14    CapitalFlows.MIN_STOCK, a flat $1 floor under the hot money.
                   $3.01 of foreign money becomes $0.03 after a hundred-to-one
                   reform, which is under a threshold denominated in the old
                   money, so the reformed city wrote its foreign capital off and
                   the unreformed one did not.

           The last two are the general lesson: a CONSTANT in absolute money is
           the same bug as a cached figure, and a threshold in absolute money is
           worse, because it is discrete - it does not drift, it flips.

           HOW THIS IS ASSERTED NOW. The month after the reform, to the last
           digit; the year after, to a millionth; the decade after, to a
           millionth. There is no band left to hide in. If any of it ever moves
           again, it is a fifteenth of the same family and this catches it on
           the month it happens.
           ================================================================= */
        out.println("\n--- ...and the month after the reform is the same month ---");

        scanEmpty(plain);
        scanEmpty(lopped);
        emptyHeldAfterReform = emptyHolding;
        stepBoth(plain, lopped, 1);
        sameCity(plain, lopped, factor, 1e-9);

        out.println("\n--- ...and the same city a year later ---");
        stepBoth(plain, lopped, 11);
        sameCity(plain, lopped, factor, 1e-6);

        out.println("\n--- ...and the same city a decade later ---");
        /*
         * -Ddenom.trace=true: month by month, with the sectors' state at the
         * first month the two banks part. The instrument that found the
         * resolution floor read in the founding unit (Bank.resolutionExitEquity).
         */
        if (Boolean.getBoolean("denom.trace")) {
            for (int m = 0; m < 88; m++) {
                stepBoth(plain, lopped, 1);
                double a = plain.getBank().equity(), b = lopped.getBank().equity() * factor;
                double ca = plain.getCash(), cb = lopped.getCash() * factor;
                int pa = plain.getPopulationManager().getPopulation(), pb = lopped.getPopulationManager().getPopulation();
                out.printf("   m%d bank %.6f vs %.6f | cash %.6f vs %.6f | pop %d vs %d | matOwed %.3f vs %.3f | bankCash %.6f vs %.6f%n", plain.getMonth(), a, b, ca, cb, pa, pb,
                        plain.getBuildingManager().getMaterialsOwed(), lopped.getBuildingManager().getMaterialsOwed(),
                        plain.getBank().getCash(), lopped.getBank().getCash() * factor);
                if (Math.abs(a - b) > 1e-3 * Math.max(1, Math.abs(a))) {
                    for (String s : Sectors.KEYS) {
                        out.printf("      %s debt %.3f vs %.3f cash %.3f vs %.3f | %s || %s%n", s,
                                plain.getEconomyManager().getBusinessDebtManager().getPrincipal(s), lopped.getEconomyManager().getBusinessDebtManager().getPrincipal(s) * factor,
                                plain.getEconomyManager().getSectorCash(s), lopped.getEconomyManager().getSectorCash(s) * factor,
                                plain.getLastInvestment(s), lopped.getLastInvestment(s));
                    }
                    out.printf("      bank branches %.0f vs %.0f | city debt %.3f vs %.3f | bank book %.3f vs %.3f | securities %.3f vs %.3f%n",
                            plain.getBank().getBranches(), lopped.getBank().getBranches(), plain.getDebtManager().getAllPrincipal(), lopped.getDebtManager().getAllPrincipal() * factor,
                            plain.getBank().getBook(), lopped.getBank().getBook() * factor, plain.getBank().getSecurities(), lopped.getBank().getSecurities() * factor);
                    break;
                }
            }
        } else {
            stepBoth(plain, lopped, 88);
        }

        out.printf("   plain  pop %,d  GDP %,.2f  rent %.6f  index %.4f%n",
                plain.getPopulationManager().getPopulation(),
                plain.getEconomyManager().getMonthGdp(), rent(plain),
                plain.getPriceIndex().getIndex());
        out.printf("   lopped pop %,d  GDP %,.2f  rent %.6f  index %.4f%n",
                lopped.getPopulationManager().getPopulation(),
                lopped.getEconomyManager().getMonthGdp(), rent(lopped),
                lopped.getPriceIndex().getIndex());
        sameCity(plain, lopped, factor, 1e-6);

        /* ============ 3a. AND NO CELL UNDER HALF A HOUSEHOLD HOLDS ANYTHING ============

           What parted these two cities at month 166 once the currency's rate
           pull went to four (0.7.2), and on the pristine 0.7.1 tree held money
           from month 127 on: a household cell the census leaves at 1e-15 of a
           household, still holding savings and still being paid. Whether a
           count lands on 1e-15 or on exactly nothing is the fifteenth decimal,
           which is precisely what a reform by a hundred moves - so the twins
           paid different ghosts. HouseholdBalance.EMPTY_CELL now empties such
           a cell where its count is written (HouseholdCheck has the fixture);
           this is the same claim on a real city, reformed and not, every
           month: no cell under the line holds anything.
           ================================================================= */
        out.println("\n--- ...and no cell under half a household holds anything, reformed or not ---");
        assertTrue("right after the reform, in either city", emptyHeldAfterReform == 0);
        out.printf("   %d looks (both cities, after the reform and after every month): a cell under half a household in %d; %,d cells emptied of something%n",
                looks, looksWithEmpty, cellsFolded);
        assertTrue("fixture: the census left cells under half a household", looksWithEmpty > 0);
        assertTrue("...and after no month did one hold anything", emptyHolding == 0);

        /* ============ 4. AND NO MONEY WAS MADE OR LOST ============

           The audit, on the reformed city, for a year. A reform that dropped a
           balance would show up as a residual the month after.
           ================================================================= */
        out.println("\n--- and the books still balance ---");

        double worst = 0;
        for (int m = 0; m < 24; m++) {
            quietly(() -> lopped.simulateMonths(1));
            worst = Math.max(worst, lopped.getLastMoneyAudit().relative());
        }
        out.printf("   worst residual over two years after the reform: %.6f%%%n", worst * 100);
        assertTrue("a reformed city conserves money like any other", worst < 1e-4);

        /* ============ 5. AND IT SURVIVES A SAVE ============ */
        out.println("\n--- a reformed city reloads as itself ---");

        GameFiles files = new GameFiles(root.resolve("data"), root.resolve("no-legacy"));
        Game saved = new Game(files);
        quietly(() -> {
            saved.run();
            saved.getGovernmentInvestor().spend(-2_000_000);
            saved.getLandManager().setOwnedSqFt(saved.getLandManager().getOwnedSqFt() + 100_000_000L);
            LongPlaytest.build(saved, "House", 200);
            LongPlaytest.build(saved, "Convenience Store", 10);
            LongPlaytest.build(saved, "Construction Depot", 4);
            saved.simulateMonths(60);
        });
        force(saved, 10);
        double cashBefore = saved.getCash();
        double rentBefore = rent(saved);
        double unitBefore = saved.getDenomination().getUnit();
        quietly(() -> saved.saveGame(1));

        Game back = new Game(files);
        quietly(() -> back.loadGameSave(1));

        close("the unit came back", back.getDenomination().getUnit(), unitBefore, 1e-9);
        close("...and the money with it", back.getCash(), cashBefore, 1e-6);
        close("...and the rent it was charging", rent(back), rentBefore, 1e-9);
        close("...and a House still costs what it cost",
                cost(back, "House"), cost(saved, "House"), 1e-9);

        out.println(fails == 0 ? "\nAll checks passed." : "\n" + fails + " FAILED");
        System.exit(fails == 0 ? 0 : 1);
    }

    /* ------------------------------ helpers ------------------------------ */

    /** Cells under half a household holding something, counted over every scan. */
    static int emptyHolding = 0;
    /** ...and the same, as it stood right after the reform. */
    static int emptyHeldAfterReform = -1;
    static int looks = 0, looksWithEmpty = 0, cellsFolded = 0;

    /** Both cities a month at a time, each scanned after every month. */
    static void stepBoth(Game a, Game b, int months) {
        for (int m = 0; m < months; m++) {
            quietly(() -> { a.simulateMonths(1); b.simulateMonths(1); });
            scanEmpty(a);
            scanEmpty(b);
            cellsFolded += a.getHouseholdBalance().getCellsFolded() + b.getHouseholdBalance().getCellsFolded();
        }
    }

    /** One look at a city: whether any cell is under half a household, and any of them holding something. */
    static void scanEmpty(Game g) {
        HouseholdBalance hb = g.getHouseholdBalance();
        boolean any = false;
        for (Household c : hb.cells()) {
            if (!c.isEmpty()) continue;
            if (c.households() > 0) any = true;
            if (hb.holdsAnything(c)) emptyHolding++;
        }
        looks++;
        if (any) looksWithEmpty++;
    }

    /** Reforms regardless of the price-level gate, which is tested separately. */
    static boolean force(Game g, double factor) {
        final boolean[] ok = { false };
        quietly(() -> ok[0] = g.reformCurrencyForTest(factor));
        return ok[0];
    }

    /** The real city: who lives there and how much of everything there is. */
    static boolean same(Game a, Game b) {
        return a.getPopulationManager().getPopulation() == b.getPopulationManager().getPopulation()
                && a.getPopulationManager().getTotalJobs() == b.getPopulationManager().getTotalJobs()
                && a.getBuildingManager().getTotalHomes() == b.getBuildingManager().getTotalHomes()
                && a.getBuildingManager().getTotalStoreCoverage()
                   == b.getBuildingManager().getTotalStoreCoverage();
    }

    static double shelf(Game g) {
        return g.getSectors().retail().getStoreSellPrice();
    }

    static double rent(Game g) {
        return g.getSectors().realEstate().getRentPrice();
    }

    static double cost(Game g, String name) {
        BuildingsTemplate t = g.getBuildingManager().getTemplateByName(name);
        return t == null ? 0 : t.getCashCost();
    }
}
