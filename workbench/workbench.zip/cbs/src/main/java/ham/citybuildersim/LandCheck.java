package ham.citybuildersim;

/**
 * Verifies the land ledger: what the city owns, what it can allocate, what it
 * charges, and that the three numbers never drift apart.
 *
 * The one thing worth being paranoid about here is that allocated land can only
 * ever go up by exactly what was built. A leak in either direction is invisible
 * for a hundred months and then the city is either mysteriously full or
 * mysteriously infinite.
 *
 * Sections 1-11 are the ledger and the market. The land office has its own
 * at the end: land priced in dollars and the two ways to pay for it (0.7.6,
 * sections 12-13); and, since 0.7.13, the office in square kilometres (14),
 * the funding page a city short of the price is offered, converting and
 * from the vault, with the window abroad open and shut (15), and the next N
 * plots bought at once ending exactly as N bought one by one (16); and,
 * since 0.7.26, the three figures the redrawn office takes from the model:
 * the going rate, which it used to work out itself, the GROUND row's
 * verdict and the receipt in the screens' money (17); and, since 0.7.55,
 * the ground priced by how crowded the city is rather than how big, at the
 * world's price level and not the city's (18); and, since 0.7.57, the land
 * on the world (spec-land.md, batch J1b): forty offers, ten a side, each the
 * next band of its lane, priced from batch I's ground and holding the world's
 * fields (5 to 5f), the world's totals kept to the tonne, the ground worked
 * out in the order it was bought, ground set by hand, forest's regrowth and
 * the best offer for each need (19), a saved city's land field for field
 * (20), and an older save's land converted - the three research cities' (21);
 * and, since 0.7.58 (batch J1c), a field shared site by site among the
 * ground its sites lie under, its shares summing to it exactly, an offer
 * priced by its share's tonnes, and a new city's iron in reach of its
 * treasury (5e, 19); and the playtest's player keeping its ground ahead,
 * as the build advice keeps slack (22, batch J1d).
 */
public class LandCheck {

    static int fails = 0;

    static void check(String label, double actual, double expected) {
        boolean ok = Math.abs(actual - expected) < 1e-6;
        if (!ok) fails++;
        System.out.printf("%-52s %14.4f  expected %14.4f  %s%n",
                label, actual, expected, ok ? "OK" : "FAIL");
    }

    static void assertTrue(String label, boolean ok) {
        if (!ok) fails++;
        System.out.printf("%-52s %s%n", label, ok ? "OK" : "FAIL");
    }

    /** ...and to a part in `relative` of the expected figure (0.7.55): prices a ten-thousandth of a unit, where check()'s 1e-6 is no test. */
    static void near(String label, double actual, double expected, double relative) {
        boolean ok = Math.abs(actual - expected) <= relative * Math.abs(expected);
        if (!ok) fails++;
        System.out.printf("%-52s %14.8g  expected %14.8g  %s%n", label, actual, expected, ok ? "OK" : "FAIL");
    }

    static void quietly(Runnable work) {
        java.io.PrintStream out = System.out;
        System.setOut(new java.io.PrintStream(java.io.OutputStream.nullOutputStream()));
        try { work.run(); } finally { System.setOut(out); }
    }

    public static void main(String[] args) throws Exception {

        /* ==================== 1. what the city starts with ==================== */
        System.out.println("--- opening position ---");

        LandManager lm = new LandManager();

        check("owned", lm.getOwnedSqFt(), LandManager.STARTING_SQ_FT);
        check("allocated", lm.getAllocatedSqFt(), 0);
        check("available", lm.getAvailableSqFt(), LandManager.STARTING_SQ_FT);
        check("thirty blocks", lm.getAvailableBlocks(), 30);
        check("nothing built on -> 0% used", lm.getUtilisation(), 0);
        check("no blocks bought yet", lm.getBlocksPurchased(), 0);

        /* ==================== 2. allocating ==================== */
        System.out.println("\n--- building on it ---");

        assertTrue("room for a 600,000 sq ft plant", lm.canAllocate(600000));
        assertTrue("allocation succeeds", lm.allocate(600000));
        check("allocated", lm.getAllocatedSqFt(), 600000);
        check("available", lm.getAvailableSqFt(), 2400000);
        check("20% used", lm.getUtilisation(), .20);

        // Exactly the remainder is allowed; a square foot more is not.
        assertTrue("exactly what is left fits", lm.canAllocate(2400000));
        assertTrue("one sq ft more does not", !lm.canAllocate(2400001));

        assertTrue("an oversized allocation is refused", !lm.allocate(2400001));
        check("...and took nothing when it refused", lm.getAllocatedSqFt(), 600000);

        // Refusal leaving the ledger untouched is the whole point: the caller
        // reads the boolean and must not build, and if the land had been taken
        // anyway the city would lose a plot to a building that never went up.
        check("available unchanged after a refusal", lm.getAvailableSqFt(), 2400000);

        /* ==================== 3. filling up ==================== */
        System.out.println("\n--- full ---");

        assertTrue("the last of it fits", lm.allocate(2400000));
        check("nothing left", lm.getAvailableSqFt(), 0);
        check("100% used", lm.getUtilisation(), 1);
        assertTrue("even one sq ft is refused now", !lm.canAllocate(1));

        // Zero is not a request for land, and must never be refused - a
        // building with no footprint set would otherwise become unbuildable.
        assertTrue("zero always fits", lm.canAllocate(0));

        /* ==================== 4. releasing ==================== */
        System.out.println("\n--- demolition, when it exists ---");

        lm.release(900000);
        check("freed", lm.getAvailableSqFt(), 900000);
        lm.release(1e9);
        check("over-releasing floors at zero", lm.getAllocatedSqFt(), 0);
        check("...and cannot invent land", lm.getOwnedSqFt(), LandManager.STARTING_SQ_FT);

        /* ==================== 5. the listing ==================== */
        /*
         * TEN OFFERS A SIDE (0.7.57). Until then "nine plots are listed": a
         * shelf of parcels drawn from a generator. The city stands on the
         * world now (CityLand), and each of its forty lanes has one offer
         * standing - the next band of real ground from the lane's frontier.
         */
        System.out.println("\n--- ten offers a side ---");

        LandManager buy = new LandManager();
        buy.updateMarket(0);
        CityLand ground = buy.getCityLand();

        java.util.List<LandParcel> listing = buy.getListing();
        check("forty offers are listed", listing.size(), LandMarket.OFFERS);
        boolean tenEach = true, oneALane = true, fromTheCentre = true, theirArea = true;
        for (int side = 0; side < CityLand.SIDES; side++) {
            java.util.List<LandParcel> on = buy.getMarket().offersOn(side);
            tenEach &= on.size() == LandMarket.OFFERS_A_SIDE;
            for (int lane = 0; lane < on.size(); lane++) oneALane &= on.get(lane).getSide() == side && on.get(lane).getLane() == lane;
        }
        for (LandParcel p : listing) {
            fromTheCentre &= p.getR1() == ground.centreHalf();
            theirArea &= Math.abs(p.getKm2() - CityLand.bandKm2(p.getR1(), p.getR2())) <= 1e-12 * p.getKm2();
        }
        assertTrue("...ten on each side", tenEach);
        assertTrue("...one in each lane, lane by lane", oneALane);
        assertTrue("a new city's offers start at its centre's edge", fromTheCentre);
        assertTrue("...each the area of its band, a tenth of r2^2 - r1^2", theirArea);
        near("the ground costs batch I's price at the founding: the base, the founding's US prices, no crowding",
                buy.getGroundUsdPerSqFt(), LandMarket.openingUsdPerSqFt() * 1 * LandMarket.crowdingPremium(0), 0);
        check("...which is what it costs here at the founding rate", buy.getAcquisitionCostPerSqFt(),
                buy.getGroundUsdPerSqFt() * ForeignAccounts.OPENING_RATE);
        boolean priced = true;
        for (LandParcel p : listing) {
            double[] km2 = new double[CityLand.AREAS], amounts = new double[CityLand.KINDS];
            for (int a = 0; a < CityLand.AREAS; a++) km2[a] = p.getKm2(a);
            for (Resource r : Resource.values()) amounts[r.ordinal()] = p.getAmount(r);
            priced &= p.getPriceUsd() == LandMarket.price(km2, amounts, buy.getGroundUsdPerSqFt(), 1);
        }
        assertTrue("...and every offer is priced at it: dry ground, water cheaper, ore at its share", priced);

        // The point of a listing rather than a price: they have to differ, or
        // there is no decision in it.
        double smallest = Double.MAX_VALUE, largest = 0;
        int withIron = 0;
        boolean sized = true;
        for (LandParcel parcel : listing) {
            smallest = Math.min(smallest, parcel.getKm2());
            largest = Math.max(largest, parcel.getKm2());
            if (parcel.hasIron()) withIron++;
            sized &= parcel.getKm2() > 0 && parcel.getPriceUsd() > 0;
        }
        assertTrue("every offer has an area and a price", sized);
        assertTrue("the offers are different sizes", largest > smallest * 2);
        System.out.printf("   offers from %.4f to %.4f km2 round a centre of %.4f km2 (%.4f dry), %d with iron%n",
                smallest, largest, ground.centreKm2(CityLand.TOTAL), ground.centreKm2(CityLand.DRY), withIron);

        // The same world and the same city give the same offers, field for
        // field: what lets a reload never be a reroll.
        LandManager twin = new LandManager();
        twin.updateMarket(0);
        boolean identical = twin.getListing().size() == listing.size();
        for (int i = 0; identical && i < listing.size(); i++) identical = listing.get(i).same(twin.getListing().get(i));
        assertTrue("the same city always sees the same offers, field for field", identical);

        /* ==================== 5b. buying one ==================== */
        System.out.println("\n--- buying an offer ---");

        LandParcel wanted = buy.getListing().get(3);
        double before = buy.getOwnedSqFt();

        // A bare land office converts at the founding rate, 1.00 (0.7.6).
        double paid = buy.buyParcel(wanted.getId(), 1e9, 0);
        check("paid exactly what was listed", paid,
                wanted.localPrice(ForeignAccounts.OPENING_RATE));
        check("owned grew by the offer's dry ground",
                buy.getOwnedSqFt(), before + wanted.getSizeSqFt());
        check("recorded as a purchase this month", buy.getLandPurchasesThisMonth(), paid);
        check("the forty stand again", buy.getListing().size(), LandMarket.OFFERS);
        assertTrue("...and that offer is gone from them",
                buy.getMarket().find(wanted.getId()) == null);
        LandParcel next = buy.getMarket().offerIn(wanted.getSide(), wanted.getLane());
        check("its lane's frontier is the offer's outer edge", ground.frontier(wanted.getSide(), wanted.getLane()),
                wanted.getR2());
        check("a lane's next offer starts at the last one's r2", next.getR1(), wanted.getR2());
        assertTrue("...under a new id", next.getId() > wanted.getId());

        // What is listed stays listed: everything the player was weighing up is
        // still there, field for field, after somebody buys something else.
        boolean held = true;
        for (LandParcel parcel : listing) {
            if (parcel.getId() == wanted.getId()) continue;
            held &= parcel.same(buy.getMarket().find(parcel.getId()));
        }
        assertTrue("the other thirty-nine did not move, field for field", held);

        assertTrue("buying an unlisted offer does nothing",
                buy.buyParcel(999999, 1e9, 0) == 0);

        /* ============ 5c. a more crowded city pays more ============ */
        /*
         * CROWDED, NOT BIG (0.7.55). Until then this was "a bigger city pays
         * more ... but only slightly": forty blocks and eight thousand people
         * on, under four times a new city's price. The premium reads the
         * city's crowding now (LandMarket, THE CROWDING PREMIUM; section 18),
         * and that city is 12,302 people a square kilometre, past anything
         * played, so it pays near the curve's ceiling: "only slightly" was a
         * premise of the size premium, and went with it. What stands: more
         * people on the ground makes it dearer, and nothing makes it dearer
         * without limit.
         */
        System.out.println("\n--- and a more crowded city pays more ---");

        double smallCityRate = new LandManager() {{ updateMarket(0); }}
                .getAcquisitionCostPerSqFt();

        LandManager bigCity = new LandManager();
        bigCity.setOwnedSqFt(LandManager.STARTING_SQ_FT + 40 * LandManager.BLOCK_SQ_FT);
        bigCity.updateMarket(8000);

        assertTrue("more people on the land means dearer land",
                bigCity.getAcquisitionCostPerSqFt() > smallCityRate);
        System.out.printf("   $%.4f/sq ft for a new city, $%.4f for a crowded one (%,.0f people a km2)%n",
                smallCityRate, bigCity.getAcquisitionCostPerSqFt(), bigCity.getCrowding());
        assertTrue("...but never past the ceiling, however crowded",
                bigCity.getAcquisitionCostPerSqFt() <= smallCityRate * LandMarket.CROWDING_CEILING);

        /* ==================== 5d. supply and demand inside the city ========= */
        System.out.println("\n--- what businesses pay ---");

        LandManager empty = new LandManager();
        empty.updateMarket(0);
        double emptyPrice = empty.getPricePerSqFt();

        LandManager full = new LandManager();
        full.allocate(LandManager.STARTING_SQ_FT * .95);
        full.updateMarket(0);

        assertTrue("a full city sells land dearer than an empty one",
                full.getPricePerSqFt() > emptyPrice);

        /*
         * THE OLD ASSERTION HERE WAS "and both are above what the city paid for
         * it", and it is now DELIBERATELY FALSE at the empty end.
         *
         * That invariant only held because the sale price was the acquisition
         * price times a markup that never dropped below 1.15 - which is also why
         * scarcity did nothing: measured over 2,400 months the markup sat
         * between 85% and 105% for the whole game while utilisation sat between
         * 86% and 100%. The word "scarcity" was decoration.
         *
         * Inside land is priced on how much is left now, so a city holding far
         * more ground than it can build on sells below what it paid, and eats
         * the difference. Over-annexing is supposed to cost something.
         */
        assertTrue("a city with nothing built sells BELOW what it paid",
                emptyPrice < empty.getAcquisitionCostPerSqFt());
        assertTrue("...and a built-out one sells well above",
                full.getPricePerSqFt() > full.getAcquisitionCostPerSqFt() * 1.4);

        System.out.printf("   $%.4f/sq ft empty (%.0f%% of cost), "
                        + "$%.4f/sq ft full (%.0f%% of cost)%n",
                emptyPrice, emptyPrice / empty.getAcquisitionCostPerSqFt() * 100,
                full.getPricePerSqFt(),
                full.getPricePerSqFt() / full.getAcquisitionCostPerSqFt() * 100);

        /*
         * The property Jerus actually asked for, stated outright: annexing more
         * ground makes the ground already inside CHEAPER. It is the reason the
         * old measure had to go - utilisation moved so little that buying land
         * barely registered.
         */
        LandManager tight = new LandManager();
        tight.allocate(LandManager.STARTING_SQ_FT * .92);
        tight.updateMarket(2000);
        double whenTight = tight.getPricePerSqFt();

        tight.setOwnedSqFt(tight.getOwnedSqFt() + LandManager.BLOCK_SQ_FT * 12);
        tight.updateMarket(2000);
        double afterBuying = tight.getPricePerSqFt();

        System.out.printf("   tight $%.4f -> after annexing twelve blocks $%.4f%n",
                whenTight, afterBuying);
        assertTrue("buying land makes land cheaper for investors",
                afterBuying < whenTight);

        // And the curve is monotone, which a saturating ratio could get wrong.
        LandMarket curve = new LandMarket();
        double previous = -1;
        boolean rising = true;
        for (double built = .05; built <= 1.0; built += .05) {
            double m = curve.scarcityMultiplier(1_000_000, 1_000_000 * built);
            if (m < previous) rising = false;
            previous = m;
        }
        assertTrue("the scarcity curve never goes backwards", rising);
        check("nothing built is the cheapest it gets",
                curve.scarcityMultiplier(1_000_000, 0), .65);
        check("completely full is the dearest",
                curve.scarcityMultiplier(1_000_000, 1_000_000), 1.90);
        check("...and bad data cannot price below that",
                curve.scarcityMultiplier(1_000_000, 1_200_000), 1.90);

        /* ==================== 5e. iron in the ground ==================== */
        /*
         * THE WORLD'S FIELDS (0.7.57). Until then "some plot on offer has iron
         * under it": the office drew ore at random onto a fifth of its
         * parcels. An offer holds the world's fields now - and since 0.7.58
         * (batch J1c) a field's sites, not whole fields: "every field whose
         * centre lies in its band, whole" put the default world's founding
         * field, 35 sites and 449 Mt, in one US$180M offer. A site belongs to
         * the ground holding its own centre, so the first bands round the
         * founding site carry a few sites each, and the city finds the rest
         * of its ore by growing toward it: the founding site has an iron
         * field within World.SITE_IRON_KM, and pushing out the lane that
         * holds it reaches it.
         */
        System.out.println("\n--- ore: the world's fields ---");

        LandManager ore = new LandManager();
        ore.updateMarket(0);
        CityLand oreLand = ore.getCityLand();
        double[] inCentre = recount(oreLand, Resource.IRON, oreLand.centreHalf() + Deposit.mostReach(Resource.IRON),
                (dx, dy) -> CityLand.radius(dx, dy) <= oreLand.centreHalf());
        check("a new city holds the iron sites the world put in its centre, and no more",
                ore.getIronDeposits(), inCentre[0]);
        check("...and their tonnes", ore.getIronReserveTonnes(), inCentre[1]);
        Deposit field = nearestUnowned(oreLand, Resource.IRON);
        assertTrue("fixture: an iron field lies near the founding site", field != null);
        LandParcel deposit = ore.getMarket().richest(Resource.IRON);
        for (int i = 0; i < 400 && deposit == null && field != null; i++) {
            int at = CityLand.sideLane(field.x() - oreLand.siteX(), field.y() - oreLand.siteY());
            LandParcel push = ore.getMarket().offerIn(at / CityLand.LANES, at % CityLand.LANES);
            ore.buyParcel(push.getId(), 1e12, 0);
            deposit = ore.getMarket().richest(Resource.IRON);
        }
        assertTrue("pushing out the lane that holds it, an offer comes to hold iron", deposit != null);

        if (deposit != null) {
            double[] counted = bandFields(oreLand, deposit, Resource.IRON);
            check("its iron sites are the world's sites in its band, recounted site by site",
                    deposit.getDeposits(), counted[0]);
            check("...and its tonnes their shares of their fields, to the tonne", deposit.getIronTonnes(), counted[1]);
            double groundPart = ore.getGroundUsdPerSqFt() * LandManager.SQ_FT_PER_KM2
                    * (deposit.getDryKm2() + LandMarket.FRESH_PRICE_SHARE * deposit.getKm2(CityLand.FRESH)
                    + LandMarket.SEA_PRICE_SHARE * deposit.getKm2(CityLand.SEA));
            double orePart = counted[1] * Good.IRON.worldExportPrice() * Resource.IRON.inGroundShare();
            assertTrue("a deposit costs more than the ground it sits on", deposit.getPriceUsd() > groundPart);
            assertTrue("...by its share's tonnes at the in-ground price, 1/350 of the world's iron, to the US$5k it is rounded to",
                    Math.abs(deposit.getPriceUsd() - groundPart - orePart) <= 2.5);
            System.out.printf("   %s: %d sites, %,.0fk tonnes: US$%,.0fk against US$%,.0fk for its ground%n",
                    deposit.where(), deposit.getDeposits(), deposit.getIronTonnes() / 1000, deposit.getPriceUsd(), groundPart);

            int sitesBefore = ore.getIronDeposits();
            double tonnesBefore = ore.getIronReserveTonnes();
            ore.buyParcel(deposit.getId(), 1e12, 0);

            int sites = sitesBefore + deposit.getDeposits();
            check("buying it gives the city its sites", ore.getIronDeposits(), sites);
            check("...and its tonnage", ore.getIronReserveTonnes(), tonnesBefore + deposit.getIronTonnes());

            assertTrue("the sites support that many mines", ore.hasUnminedDeposit(sites - 1));
            assertTrue("...and not one more", !ore.hasUnminedDeposit(sites));

            double lifted = ore.extractIron(50000);
            check("mining takes ore out of the ground", lifted, 50000);
            check("...and the reserve falls",
                    ore.getIronReserveTonnes(), tonnesBefore + deposit.getIronTonnes() - 50000);

            // Finite means finite. A mine on an empty deposit lifts nothing and
            // still costs its payroll, which is the point of depletion.
            ore.extractIron(1e18);
            check("a deposit can be worked out", ore.getIronReserveTonnes(), 0);
            check("...and then yields nothing", ore.extractIron(1000), 0);
            assertTrue("...and supports no more mines", !ore.hasUnminedDeposit(0));
        }

        /* ============ 5f. the size rule ============ */
        /*
         * Jerus, after the hand-played run: buying ~200 parcels one click at a
         * time to reach 581 blocks was the single biggest time sink in playing
         * the game. Until 0.7.57 two rules answered it - nothing smaller than a
         * block, and a floor that rose a block for every forty bought, to
         * fifteen - and this section held them. The size rule replaces both
         * (spec-land star 2): an offer is a multiple of one block, or of 1% of
         * the city's whole area once that is more, the multiple drawn as the
         * parcels' sizes always were.
         */
        System.out.println("\n--- the size rule ---");

        LandManager young = new LandManager();
        young.updateMarket(0);
        check("a new city's unit is a block", young.getMarket().getMinBlocks(), 1);
        boolean blocks = true, aBlockAtLeast = true;
        for (LandParcel p : young.getListing()) {
            double m = LandMarket.sizeMultiple(young.getCityLand().seed(), p.getId());
            blocks &= Math.abs(p.getKm2() - m * LandMarket.UNIT_FLOOR_KM2) <= 1e-12 * p.getKm2();
            aBlockAtLeast &= p.getKm2() >= LandMarket.UNIT_FLOOR_KM2 * (1 - 1e-12);
        }
        assertTrue("...so every offer is its multiple of a block", blocks);
        assertTrue("...and nothing on offer is smaller than a block", aBlockAtLeast);

        // The multiple, as the parcels drew theirs: over many ids.
        int plots = 0, rooms = 0, tracts = 0, draws = 20_000;
        double sum = 0, lowest = Double.MAX_VALUE, highest = 0;
        for (int id = 1; id <= draws; id++) {
            double m = LandMarket.sizeMultiple(Founding.DEFAULT_WORLD_SEED, id);
            sum += m;
            lowest = Math.min(lowest, m);
            highest = Math.max(highest, m);
            if (m < 2.5) plots++; else if (m < 5) rooms++; else tracts++;
        }
        System.out.printf("   %,d multiples: %.1f%% plots, %.1f%% room to work, %.1f%% tracts, mean %.3f, %.3f to %.3f%n",
                draws, 100.0 * plots / draws, 100.0 * rooms / draws, 100.0 * tracts / draws, sum / draws, lowest, highest);
        assertTrue("55% of offers are a plot, 1 to 2.5 units (within a point)", Math.abs(plots / (double) draws - .55) < .01);
        assertTrue("...30% room to work, 2.5 to 5", Math.abs(rooms / (double) draws - .30) < .01);
        assertTrue("...15% a tract, 5 to 18", Math.abs(tracts / (double) draws - .15) < .01);
        assertTrue("...a mean of 3.81 units (within 0.05)", Math.abs(sum / draws - 3.8125) < .05);
        assertTrue("...never under one unit nor past eighteen", lowest >= 1 && highest < 18);

        System.out.println("\n--- and the unit grows with the city ---");

        LandManager grown = new LandManager();
        grown.updateMarket(0);
        grown.setOwnedSqFt(LandManager.STARTING_SQ_FT + 1_000 * LandManager.BLOCK_SQ_FT);
        grown.updateMarket(20000);
        double cityKm2 = grown.getOwnedKm2();
        near("a city past 0.929 km2 is offered multiples of 1% of its whole area", grown.getMarket().getUnitKm2(),
                LandMarket.UNIT_SHARE * cityKm2, 1e-12);
        boolean ofTheCity = true;
        for (LandParcel p : grown.getListing()) {
            ofTheCity &= Math.abs(p.getKm2() - LandMarket.sizeMultiple(grown.getCityLand().seed(), p.getId())
                    * LandMarket.UNIT_SHARE * cityKm2) <= 1e-9 * p.getKm2();
        }
        assertTrue("...every offer it is listed", ofTheCity);
        System.out.printf("   a city of %.2f km2 (%.2f dry) is offered multiples of %.4f km2 (%.1f blocks)%n",
                cityKm2, LandManager.km2(grown.getOwnedSqFt()), grown.getMarket().getUnitKm2(),
                grown.getMarket().getMinBlocks());

        System.out.println("\n--- the offers survive a save, field for field ---");

        LandMarket reloaded = new LandMarket();
        reloaded.attach(grown.getCityLand());
        reloaded.restoreOffers(grown.getMarket().getOffersState(), grown.getMarket().getNextOfferId());
        boolean survived = reloaded.getListing().size() == grown.getListing().size();
        for (int i = 0; survived && i < grown.getListing().size(); i++) {
            survived = grown.getListing().get(i).same(reloaded.getListing().get(i));
        }
        assertTrue("...every field of every offer", survived);
        check("...and the next id", reloaded.getNextOfferId(), grown.getMarket().getNextOfferId());
        double[][] torn = grown.getMarket().getOffersState();
        torn[7] = java.util.Arrays.copyOf(torn[7], 5);
        LandMarket mended = new LandMarket();
        mended.attach(grown.getCityLand());
        mended.restoreOffers(torn, grown.getMarket().getNextOfferId());
        check("a record of the wrong width is dropped", mended.getListing().size(), LandMarket.OFFERS - 1);
        mended.update(grown.getOwnedSqFt(), grown.getAllocatedSqFt(), 20000);
        check("...and its lane's next is listed in its place", mended.getListing().size(), LandMarket.OFFERS);
        check("...under the next id", mended.offerIn(0, 7).getId(), grown.getMarket().getNextOfferId());

        /* ==================== 6. not affording it ==================== */
        System.out.println("\n--- an empty treasury ---");

        LandManager broke = new LandManager();
        broke.updateMarket(0);
        LandParcel offer = broke.getListing().get(0);

        double offerLocal = offer.localPrice(ForeignAccounts.OPENING_RATE);
        check("cannot afford it -> pays nothing",
                broke.buyParcel(offer.getId(), offerLocal - 1, 0), 0);
        check("...and gets nothing", broke.getOwnedSqFt(), LandManager.STARTING_SQ_FT);
        check("...and is not recorded", broke.getLandPurchasesThisMonth(), 0);
        assertTrue("...and it is still on offer",
                broke.getMarket().find(offer.getId()) != null);
        check("exactly enough does buy it",
                broke.buyParcel(offer.getId(), offerLocal, 0), offerLocal);

        /* ==================== 7. selling ==================== */
        System.out.println("\n--- selling to businesses ---");

        LandManager sell = new LandManager();

        check("opening price is $1/sq ft", sell.getPricePerSqFt(), .001);
        check("a 8,000 sq ft house plot", sell.priceFor(8000), 8);
        check("margin at the opening price", sell.getMarginPerSqFt(), .001 - .0007);

        sell.recordSale(8000);
        check("sale recorded", sell.getLandSalesThisMonth(), 8);
        check("sq ft recorded", sell.getSqFtSoldThisMonth(), 8000);

        sell.recordSale(8000);
        check("sales accumulate over the month", sell.getLandSalesThisMonth(), 16);

        sell.clearMonth();
        check("cleared for the next month", sell.getLandSalesThisMonth(), 0);
        check("...sq ft too", sell.getSqFtSoldThisMonth(), 0);
        check("...and purchases", sell.getLandPurchasesThisMonth(), 0);

        // Clearing the month's flows must not touch the stock figures.
        check("owned survives the clear", sell.getOwnedSqFt(), LandManager.STARTING_SQ_FT);

        /* ==================== 8. the player's price ==================== */
        System.out.println("\n--- the price is the player's lever ---");

        sell.setPricePerSqFt(.003);
        check("price set", sell.getPricePerSqFt(), .003);
        check("the same plot now costs more", sell.priceFor(8000), 24);
        check("fatter margin", sell.getMarginPerSqFt(), .003 - .0007);

        // Selling below cost is allowed - subsidising land to attract industry
        // is a real policy - but it must read as the loss it is.
        sell.setPricePerSqFt(.0004);
        assertTrue("below cost reads as a negative margin", sell.getMarginPerSqFt() < 0);

        sell.setPricePerSqFt(0);
        check("free land is allowed", sell.getPricePerSqFt(), 0);
        check("...and costs the buyer nothing", sell.priceFor(8000), 0);

        sell.setPricePerSqFt(-5);
        check("a negative price floors at zero", sell.getPricePerSqFt(), 0);

        /* ==================== 9. reset ==================== */
        System.out.println("\n--- new game ---");

        sell.allocate(1500000);
        sell.buyBlock(1e6);
        sell.setPricePerSqFt(.05);
        sell.reset();

        check("owned back to the start", sell.getOwnedSqFt(), LandManager.STARTING_SQ_FT);
        check("nothing allocated", sell.getAllocatedSqFt(), 0);
        check("no blocks bought", sell.getBlocksPurchased(), 0);
        check("price back to default", sell.getPricePerSqFt(), .001);
        check("block cost back to the first", sell.getNextBlockCost(), 70);
        check("no flows", sell.getLandSalesThisMonth(), 0);

        /* ============ 10. every building fits on a starting city ============ */
        System.out.println("\n--- the buildings themselves ---");

        BuildingManager bm = new BuildingManager();
        bm.initializeTemplates();

        boolean allHaveLand = true;
        double biggest = 0;
        String biggestName = "";

        for (BuildingsTemplate t : bm.getTemplates()) {
            if (t.getLandSqFt() <= 0) {
                allHaveLand = false;
                System.out.println("  no footprint: " + t.getName());
            }
            if (t.getLandSqFt() > biggest) {
                biggest = t.getLandSqFt();
                biggestName = t.getName();
            }
        }

        assertTrue("every building has a footprint", allHaveLand);
        System.out.printf("   largest: %s at %,.0f sq ft (%.1f blocks)%n",
                biggestName, biggest, biggest / LandManager.BLOCK_SQ_FT);

        // The opening ten blocks have to be enough for the player's first moves,
        // or the mechanic is a wall rather than a constraint.
        LandManager fresh = new LandManager();
        assertTrue("a power plant fits on the starting land",
                fresh.canAllocate(bm.getTemplateByName("Coal Power Plant").getLandSqFt()));

        double house = bm.getTemplateByName("House").getLandSqFt();
        check("the starting land holds this many houses",
                Math.floor(LandManager.STARTING_SQ_FT / house), 375);

        // Both utilities fit, and between them they take 28 of the 30 blocks -
        // so a player who builds power and water first is out of land for
        // housing on the very next turn. That is the mechanic introducing itself.
        double bothUtilities = bm.getTemplateByName("Coal Power Plant").getLandSqFt()
                + bm.getTemplateByName("Water Treatment Plant").getLandSqFt();

        assertTrue("both utilities fit", fresh.canAllocate(bothUtilities));
        assertTrue("...with almost nothing to spare",
                LandManager.STARTING_SQ_FT - bothUtilities < 3 * LandManager.BLOCK_SQ_FT);

        fresh.allocate(bothUtilities);
        assertTrue("...and then a materials plant does not fit",
                !fresh.canAllocate(
                        bm.getTemplateByName("Construction Materials Plant").getLandSqFt()));
        System.out.printf("   after power + water: %,.0f sq ft left (%.1f blocks)%n",
                fresh.getAvailableSqFt(), fresh.getAvailableBlocks());

        /* ============ 11. the price is a density policy ============ */
        System.out.println("\n--- dear land should push developers upward ---");

        BuildingsTemplate detached = bm.getTemplateByName("House");
        BuildingsTemplate studio = bm.getTemplateByName("Studio Apartments");

        LandManager policy = new LandManager();

        // Cost of housing one resident, land included. Houses are cheap to
        // build and hungry for land; apartments are the reverse. Which one wins
        // is therefore a function of what land costs - which is the player's
        // lever, and the reason it is theirs to set.
        double cheapHouse = (detached.getCashCost()
                + policy.priceFor(detached.getLandSqFt())) / detached.getCapacity();
        double cheapFlat = (studio.getCashCost()
                + policy.priceFor(studio.getLandSqFt())) / studio.getCapacity();

        assertTrue("at the default price, sprawl is cheaper", cheapHouse < cheapFlat);
        System.out.printf("   $%.2f/resident in a house vs $%.2f in a studio%n",
                cheapHouse, cheapFlat);

        policy.setPricePerSqFt(.020);
        double dearHouse = (detached.getCashCost()
                + policy.priceFor(detached.getLandSqFt())) / detached.getCapacity();
        double dearFlat = (studio.getCashCost()
                + policy.priceFor(studio.getLandSqFt())) / studio.getCapacity();

        assertTrue("at $20/sq ft, density is cheaper", dearFlat < dearHouse);
        System.out.printf("   $%.2f/resident in a house vs $%.2f in a studio%n",
                dearHouse, dearFlat);

        inDollars();
        bothWays();
        inSquareKilometres();
        whenShort();
        severalAtOnce();
        theOfficesFigures();
        crowdedNotBig();
        onTheWorld();
        savedAndLoaded();
        converted();
        groundKeptAhead();

        System.out.println(fails == 0 ? "\nAll checks passed." : "\n" + fails + " FAILED");
        System.exit(fails == 0 ? 0 : 1);
    }

    /* ==================================================================
       18. CROWDED, NOT BIG, AND THE DOLLAR'S OWN INFLATION (0.7.55)

       Jerus: "Yes for land price do that, but tie it to inflation as well,
       usd inflation not domestic inflation." The premium on the ground is
       the city's crowding - its people per square kilometre of the land it
       owns - so a city a million times bigger and as crowded is quoted
       exactly what the small one is; and the dollar price is the base at
       the world's price level, which the city's own price level does not
       reach. A town of 6,000 people on 330 blocks (1,957 a square kilometre,
       city600's crowding) against the same a million times over: six billion
       people.
       ================================================================== */
    static void crowdedNotBig() {
        System.out.println("\n--- the premium is crowding, not size ---");

        LandManager town = new LandManager();
        town.setOwnedSqFt(LandManager.STARTING_SQ_FT + 300 * LandManager.BLOCK_SQ_FT);
        town.allocate(town.getOwnedSqFt() * .9);
        town.updateMarket(6_000);
        long k = 1_000_000;
        LandManager metropolis = new LandManager();
        metropolis.setOwnedSqFt(town.getOwnedSqFt() * k);
        metropolis.allocate(town.getAllocatedSqFt() * k);
        metropolis.updateMarket(6_000L * k);
        System.out.printf("   %,d people on %.2f km2 against %,d on %,.0f km2: %,.1f and %,.1f a km2%n",
                6_000, LandManager.km2(town.getOwnedSqFt()), 6_000L * k, LandManager.km2(metropolis.getOwnedSqFt()),
                town.getCrowding(), metropolis.getCrowding());
        assertTrue("fixture: the town is crowded enough to pay a premium",
                town.getCrowdingPremium() > 2);
        near("two cities equally crowded have the same premium", metropolis.getCrowdingPremium(),
                town.getCrowdingPremium(), 1e-12);
        near("...the world asks them the same dollars a sq ft", metropolis.getGroundUsdPerSqFt(),
                town.getGroundUsdPerSqFt(), 1e-12);
        near("...and their businesses pay the same", metropolis.getPricePerSqFt(), town.getPricePerSqFt(), 1e-12);

        LandManager crowded = new LandManager();
        crowded.setOwnedSqFt(town.getOwnedSqFt());
        crowded.allocate(town.getAllocatedSqFt());
        crowded.updateMarket(12_000);
        assertTrue("twice the people on the same ground pays more", crowded.getCrowdingPremium() > town.getCrowdingPremium());
        LandManager spread = new LandManager();
        spread.setOwnedSqFt(town.getOwnedSqFt() * 2);
        spread.allocate(town.getAllocatedSqFt());
        spread.updateMarket(6_000);
        assertTrue("...and the same people on twice the ground pays less", spread.getCrowdingPremium() < town.getCrowdingPremium());
        near("the premium is the curve's at the city's crowding", town.getCrowdingPremium(),
                LandMarket.crowdingPremium(6_000 / LandManager.km2(town.getOwnedSqFt())), 1e-15);
        near("...half way to the ceiling at CROWDING_MIDPOINT", LandMarket.crowdingPremium(LandMarket.CROWDING_MIDPOINT),
                (1 + LandMarket.CROWDING_CEILING) / 2, 1e-15);
        check("...and nothing on an empty city", LandMarket.crowdingPremium(0), 1);
        near("...and the ceiling at the limit", LandMarket.crowdingPremium(Double.POSITIVE_INFINITY),
                LandMarket.CROWDING_CEILING, 1e-15);

        System.out.println("\n--- the dollar price follows the world's prices, not the city's ---");

        double[] usPrices = { 1.0 };
        LandManager office = new LandManager(() -> ForeignAccounts.OPENING_RATE, () -> usPrices[0]);
        office.setOwnedSqFt(town.getOwnedSqFt());
        office.allocate(town.getAllocatedSqFt());
        office.updateMarket(6_000);
        double usd = office.getGroundUsdPerSqFt(), anchor = office.getMarket().getMarketPricePerSqFt();
        near("the parts: the base x the world's level x the premium", usd,
                LandMarket.openingUsdPerSqFt() * office.getUsPriceLevel() * office.getCrowdingPremium(), 1e-15);

        usPrices[0] = 1.25;
        office.updateMarket(6_000);
        near("US prices up 25%: the dollar price up 25%", office.getGroundUsdPerSqFt(), usd * 1.25, 1e-12);
        near("...what the treasury pays with it, at the same rate", office.getAcquisitionCostPerSqFt(),
                usd * 1.25 * ForeignAccounts.OPENING_RATE, 1e-12);
        near("...and the businesses' anchor not at all", office.getMarket().getMarketPricePerSqFt(), anchor, 1e-12);

        // The city's own inflation: the money constants struck at three times
        // the price level (seedConstants() takes the unit over the expected
        // level, Game.restrikeMoneyConstants()).
        office.seedConstants(1 / 3.0);
        office.updateMarket(6_000);
        near("the city's prices tripled: the dollar price is where the world put it",
                office.getGroundUsdPerSqFt(), usd * 1.25, 1e-12);
        near("...while the businesses' anchor follows the city's own prices",
                office.getMarket().getMarketPricePerSqFt(), anchor * 3, 1e-12);

        // Saved with the prices, so the office can name them after a load.
        LandMarket back = new LandMarket();
        back.restorePriceState(office.getMarket().getPriceState());
        near("the parts survive a save: the crowding", back.getCrowding(), office.getCrowding(), 0);
        near("...the premium", back.getCrowdingPremium(), office.getCrowdingPremium(), 0);
        near("...and the world's level", back.getUsPriceLevel(), 1.25, 0);
        LandMarket older = new LandMarket();
        double[] four = java.util.Arrays.copyOf(office.getMarket().getPriceState(), 4);
        older.restorePriceState(four);
        near("a save from before reads its price as the premium, at US prices of 1",
                older.getCrowdingPremium() * older.getUsPriceLevel(), office.getGroundUsdPerSqFt() / LandMarket.openingUsdPerSqFt(), 1e-12);
    }

    /* ==================================================================
       12. LAND IS PRICED IN DOLLARS (0.7.6)

       Jerus: "when you buy land, make it so that it costs USD not domestic
       currency". A land office reading a rate that moves under it: the
       listing's dollar prices stay put, what they cost here is exactly
       usd x rate on the day, and what businesses pay does not read the
       rate at all. Against a twin at the founding rate, so "does not move"
       is measured against something.
       ================================================================== */
    static void inDollars() {
        System.out.println("\n--- land is priced in dollars; what it costs here is the day's rate ---");

        double[] rate = { ForeignAccounts.OPENING_RATE };
        LandManager dollars = new LandManager(() -> rate[0]);
        dollars.updateMarket(0);
        LandManager atPar = new LandManager();
        atPar.updateMarket(0);
        LandParcel held = dollars.getListing().get(2);
        double heldUsd = held.getPriceUsd();

        rate[0] = 1.6;
        dollars.updateMarket(0);
        check("a listed parcel's dollar price does not move when the rate does",
                dollars.getMarket().find(held.getId()).getPriceUsd(), heldUsd);
        check("...nor the office's ground price in dollars",
                dollars.getGroundUsdPerSqFt(), atPar.getGroundUsdPerSqFt());
        check("...while what it quotes here is that at today's rate",
                dollars.getAcquisitionCostPerSqFt(), dollars.getGroundUsdPerSqFt() * 1.6);
        check("...and what businesses pay does not read the rate at all",
                dollars.getPricePerSqFt(), atPar.getPricePerSqFt());
        check("...so the margin carries the currency",
                dollars.getMarginPerSqFt(),
                dollars.getPricePerSqFt() - dollars.getGroundUsdPerSqFt() * 1.6);

        double paid = dollars.buyParcel(held.getId(), 1e9, 0);
        check("what a parcel costs is exactly its dollars times the rate", paid, heldUsd * 1.6);
        check("...and that is what the month's land purchases carry",
                dollars.getLandPurchasesThisMonth(), heldUsd * 1.6);
        LandParcel next = dollars.getListing().get(0);
        check("...and a parcel it cannot pay that for is refused",
                dollars.buyParcel(next.getId(), next.getPriceUsd() * 1.6 - 1, 0), 0);

        // A reform divides the local money; the dollars are the world's.
        java.util.List<LandParcel> board = dollars.getListing();
        double saleBefore = dollars.getPricePerSqFt();
        double groundBefore = dollars.getGroundUsdPerSqFt();
        dollars.redenominate(.01);
        boolean sameBoard = board.size() == dollars.getListing().size();
        for (int i = 0; sameBoard && i < board.size(); i++) {
            sameBoard = board.get(i).getId() == dollars.getListing().get(i).getId()
                    && board.get(i).getPriceUsd() == dollars.getListing().get(i).getPriceUsd();
        }
        assertTrue("a currency reform leaves the listing's dollar prices alone", sameBoard);
        check("...and the office's dollar ground price",
                dollars.getGroundUsdPerSqFt(), groundBefore);
        check("...while what businesses pay is reformed with every local price",
                dollars.getPricePerSqFt(), saleBefore * .01);
    }

    /* ==================================================================
       13. THE TWO WAYS TO PAY (0.7.6)

       Jerus: "a little toggle at the top to choose, when you buy land, to
       use up your USD reserves or to convert cash into usd exactly to buy
       the land, and the default is that you convert." Two cities founded
       the same way and ticked once (so the purchase is in an ordinary
       window, not the founding one), the rate held at 1.60 so local money
       and dollars differ - and neither currency defends itself with its
       vault, so the only difference between them is the way they paid.
       ================================================================== */
    static Game dollarCity(String label) {
        Game g = new Game(GameFiles.scratch(label));
        quietly(() -> { g.newGame(); g.toggleNextMonth(); });
        g.getForeignAccounts().pinRate(1.6);
        return g;
    }

    static double[] moved(double[] before, double[] after) {
        double[] m = new double[before.length];
        for (int i = 0; i < m.length; i++) m[i] = after[i] - before[i];
        return m;
    }

    static void bothWays() throws Exception {
        System.out.println("\n--- converting: the treasury buys the dollars and pays them over ---");

        Game convert = dollarCity("landcheck-convert");
        Game vault = dollarCity("landcheck-vault");
        assertTrue("fixture: a new city converts by default", !convert.isLandPaidFromVault());
        vault.setLandPaidFromVault(true);

        LandParcel plot = convert.getLandManager().getMarket().bestValue();
        double usd = plot.getPriceUsd();
        double rate = convert.getForeignAccounts().getRate();
        assertTrue("fixture: both cities list the same plot at the same dollars",
                vault.getLandManager().getMarket().find(plot.getId()) != null
                        && vault.getLandManager().getMarket().find(plot.getId()).getPriceUsd() == usd);

        double cash = convert.getCash();
        double dollarsHeld = convert.getForeignAccounts().getReservesUsd();
        double bought = convert.getForeignAccounts().getBoughtThisMonth();
        double[] pools = MoneyAudit.pools(convert);
        assertTrue("fixture: the plot is bought", convert.buyLandParcel(plot.getId()));
        double[] shift = moved(pools, MoneyAudit.pools(convert));

        check("converting: the treasury pays usd x rate", convert.getCash(), cash - usd * rate);
        check("...the vault ends where it began",
                convert.getForeignAccounts().getReservesUsd(), dollarsHeld);
        check("...the seller is paid the parcel's dollars",
                convert.getForeignAccounts().getLandUsdPending(), usd);
        check("...and nothing was bought for the vault",
                convert.getForeignAccounts().getBoughtThisMonth(), bought);
        double others = 0;
        for (int i = 1; i < shift.length; i++) others += Math.abs(shift[i]);
        check("...the city's pool fell by exactly that - money across the edge", shift[0], -usd * rate);
        check("...and no other pool took it", others, 0);
        assertTrue("...and the receipt names the conversion",
                convert.getLastLandReceipt().contains("converting"));

        System.out.println("\n--- from the vault: the dollars leave it, and no money moves ---");

        cash = vault.getCash();
        dollarsHeld = vault.getForeignAccounts().getReservesUsd();
        double intervention = vault.getForeignAccounts().getLifetimeIntervention();
        pools = MoneyAudit.pools(vault);
        assertTrue("fixture: the vault can pay for the plot", dollarsHeld > usd);
        assertTrue("fixture: the plot is bought", vault.buyLandParcel(plot.getId()));
        shift = moved(pools, MoneyAudit.pools(vault));

        check("from the vault: the treasury's cash does not move", vault.getCash(), cash);
        check("...the vault falls by the parcel's dollars",
                vault.getForeignAccounts().getReservesUsd(), dollarsHeld - usd);
        check("...its record by their local price, as a sale's would",
                vault.getForeignAccounts().getLifetimeIntervention(), intervention - usd * rate);
        double any = 0;
        for (double d : shift) any += Math.abs(d);
        check("...and no pool moved at all", any, 0);
        TreasuryJournal.Entry entry = null;
        for (TreasuryJournal.Entry e : vault.getTreasuryJournalBook().thisMonth()) {
            if (e.label().startsWith("Bought land with US$")) entry = e;
        }
        assertTrue("...the journal names it", entry != null);
        check("...at usd x rate, the other way up from the budget's land line",
                entry == null ? 0 : entry.amount(), usd * rate);
        assertTrue("...and the receipt says it came out of the vault",
                vault.getLastLandReceipt().contains("out of the vault"));

        System.out.println("\n--- and each month closes ---");

        quietly(convert::toggleNextMonth);
        quietly(vault::toggleNextMonth);
        for (Game g : new Game[] { convert, vault }) {
            String way = g == convert ? "converting" : "from the vault";
            assertTrue("the month after land bought " + way + " closes its audit",
                    Math.abs(g.getLastMoneyAudit().relative()) < 1e-9);
            assertTrue("...nothing moved after it struck", Math.abs(g.getPostAuditDrift()) < 1e-6);
            check("...the budget carries the land at usd x rate",
                    g.getEconomyManager().getNationalAccounts().getLandPurchases(), usd * rate);
            check("...and the month's dollars paid for it",
                    g.getForeignAccounts().getLandUsdThisMonth(), usd);
            check("...which cost here what the budget's line carries",
                    g.getForeignAccounts().getLandLocalThisMonth(), usd * rate);
        }
        check("the vault's part of them, converting", convert.getForeignAccounts()
                .getLandUsdFromVaultThisMonth(), 0);
        check("...and from the vault", vault.getForeignAccounts()
                .getLandUsdFromVaultThisMonth(), usd);
        check("the bridge leaves the same over either way: the journal carries the vault's",
                vault.getTreasuryResidual(), convert.getTreasuryResidual());

        System.out.println("\n--- a short vault pays what it holds and converts the rest ---");

        LandParcel dear = vault.getLandManager().getMarket().bestValue();
        double dearUsd = dear.getPriceUsd();
        double half = dearUsd / 2;
        rate = vault.getForeignAccounts().getRate();
        quietly(() -> vault.sellForeignCurrency(
                (vault.getForeignAccounts().getReservesUsd() - dearUsd / 2) * vault.getForeignAccounts().getRate()));
        double held = vault.getForeignAccounts().getReservesUsd();
        assertTrue("fixture: the vault holds about half the parcel",
                Math.abs(held - half) < 1e-3 && held < dearUsd);
        cash = vault.getCash();
        assertTrue("a purchase never fails for the toggle's sake", vault.buyLandParcel(dear.getId()));
        check("the vault paid what it held", vault.getForeignAccounts().getReservesUsd(), 0);
        check("...and the rest was converted from cash", vault.getCash(), cash - (dearUsd - held) * rate);
        assertTrue("...and the receipt says so",
                vault.getLastLandReceipt().contains("held only"));
        System.out.println("   " + vault.getLastLandReceipt());

        System.out.println("\n--- the toggle survives a save, and an older listing reads as dollars ---");

        GameFiles files = GameFiles.scratch("landcheck-save");
        Game saved = new Game(files);
        quietly(() -> { saved.newGame(); saved.toggleNextMonth(); });
        saved.getForeignAccounts().pinRate(1.6);
        saved.setLandPaidFromVault(true);
        java.util.List<LandParcel> board = saved.getLandListing();
        quietly(() -> saved.saveGame(4, "land in dollars"));

        Game[] back = new Game[1];
        quietly(() -> { back[0] = new Game(files); back[0].loadGameSave(4); });
        assertTrue("fixture: it loads", back[0].getLoadFailure() == null);
        assertTrue("the toggle survives a save", back[0].isLandPaidFromVault());
        boolean same = board.size() == back[0].getLandListing().size();
        for (int i = 0; same && i < board.size(); i++) {
            same = board.get(i).getPriceUsd() == back[0].getLandListing().get(i).getPriceUsd();
        }
        assertTrue("...and a dollar listing comes back to the cent", same);
        check("...and the office's dollar quote with it",
                back[0].getLandManager().getGroundUsdPerSqFt(),
                saved.getLandManager().getGroundUsdPerSqFt());

        /*
         * AN OLDER SAVE, written by hand from this one: format 30, no toggle
         * key, the parcels in the old marker with LOCAL prices that are not
         * this listing's dollars at any rate, and the office's prices three
         * slots long. Its quote reads as dollars at the loading rate (0.7.6);
         * since 0.7.57 its parcels are not read at all - the conversion lists
         * forty offers in their place, priced at that quote.
         */
        com.google.gson.JsonObject json = com.google.gson.JsonParser.parseString(
                java.nio.file.Files.readString(files.saveFile(4))).getAsJsonObject();
        assertTrue("fixture: the save carried the toggle", json.has("landPaidFromVault"));
        json.remove("landPaidFromVault");
        for (String key : new String[] { "worldSeaTheta", "worldTotals", "landCentre", "landLanes", "landPurchases",
                "landOffers", "nextOfferId", "depletion" }) json.remove(key);
        json.addProperty("saveFormat", LandConversion.LAST_FORMAT_BEFORE);
        com.google.gson.JsonArray listing = new com.google.gson.JsonArray();
        listing.add(-5.0);
        listing.add(10.0);
        int parcels = 9;
        for (int i = 0; i < parcels; i++) {
            for (double v : new double[] { i + 1, 250_000 + i * 1000, 1_000.0 + i * 10, 0, 0 }) listing.add(v);
        }
        json.add("landListing", listing);
        com.google.gson.JsonArray prices = json.getAsJsonArray("landMarketPrices");
        double localQuote = prices.get(0).getAsDouble();
        while (prices.size() > 3) prices.remove(prices.size() - 1);
        java.nio.file.Files.writeString(files.saveFile(4), json.toString());

        quietly(() -> { back[0] = new Game(files); back[0].loadGameSave(4); });
        Game old = back[0];
        assertTrue("fixture: the older save loads", old.getLoadFailure() == null);
        double loadRate = old.getForeignAccounts().getRate();
        check("fixture: at the rate it was saved at", loadRate, 1.6);
        assertTrue("an older save converts", !old.isLandPaidFromVault());
        check("the office's local quote reads as dollars at the loading rate",
                old.getLandManager().getGroundUsdPerSqFt(), localQuote / loadRate);
        check("its nine parcels are not read: forty offers stand in their place",
                old.getLandListing().size(), LandMarket.OFFERS);
        boolean atTheQuote = true;
        for (LandParcel p : old.getLandListing()) {
            double[] km2 = new double[CityLand.AREAS], amounts = new double[CityLand.KINDS];
            for (int a = 0; a < CityLand.AREAS; a++) km2[a] = p.getKm2(a);
            for (Resource r : Resource.values()) amounts[r.ordinal()] = p.getAmount(r);
            atTheQuote &= p.getPriceUsd() == LandMarket.price(km2, amounts, old.getLandManager().getGroundUsdPerSqFt(),
                    old.getLandManager().getUsPriceLevel());
        }
        assertTrue("...each priced at that quote", atTheQuote);
    }

    /* ==================================================================
       14. THE OFFICE IN SQUARE KILOMETRES (0.7.13)

       Jerus: "purely for visual purposes, instead of blocks, say km^2". The
       model keeps square feet; the office shows the same figure converted
       exactly, to three significant figures so the smallest plot it sells
       does not read 0.00.
       ================================================================== */
    static void inSquareKilometres() {
        System.out.println("\n--- the office in square kilometres ---");

        check("a square foot is 0.3048 m squared, exactly", LandManager.SQ_M_PER_SQ_FT, .3048 * .3048);
        check("a block is its square feet in square kilometres",
                LandManager.km2(LandManager.BLOCK_SQ_FT),
                LandManager.BLOCK_SQ_FT * LandManager.SQ_M_PER_SQ_FT / LandManager.SQ_M_PER_KM2);
        String block = LandManager.km2Words(LandManager.BLOCK_SQ_FT);
        System.out.println("   one block: " + block);
        assertTrue("...which reads 0.00929, not 0.00", block.startsWith("0.00929 "));
        LandManager office = new LandManager();
        office.updateMarket(0);
        boolean allRead = true;
        for (LandParcel parcel : office.getListing()) {
            String words = LandManager.km2Words(parcel.getSizeSqFt());
            double read = Double.parseDouble(words.substring(0, words.indexOf(' ')));
            double exact = LandManager.km2(parcel.getSizeSqFt());
            if (!(read > 0) || Math.abs(read - exact) > exact * 5e-3) allRead = false;
        }
        assertTrue("every plot on offer reads within half a percent of its area, and none as nothing", allRead);
    }

    /* ==================================================================
       15. SHORT OF THE PRICE: THE FUNDING PAGE (0.7.13)

       Jerus: "if you are on buy by converting and you dont have enough, you
       can stilll click buy, just the popup to issue debt appears, but if you
       are in buy with reserves, and click buy, then pop up to issue foreign
       debt should appear (aka the short or the 20y, like with buildings)".
       The page prints the model's figures (Game, WHEN THE CITY IS SHORT, AND
       SEVERAL AT ONCE), so they are asserted here: each offer sized to the
       gap in the money the toggle pays in, the plot bought once it is
       taken, and the month after closing its audit. Each fixture causes its
       shortage: the treasury given 40% of the plot, or the vault sold down to
       30% of it; and the window abroad shut by its own rule, a city that
       borrows dollars while it sells nothing abroad.
       ================================================================== */
    static void whenShort() throws Exception {
        System.out.println("\n--- short while converting: the build screen's two offers, sized to the gap ---");

        for (String paper : new String[] { "bond", "note" }) {
            Game g = dollarCity("landcheck-short-" + paper);
            LandParcel plot = g.landShelf().get(0);
            java.util.List<Integer> just = java.util.List.of(plot.getId());
            double price = plot.localPrice(g.getForeignAccounts().getRate());
            g.setCashForTest(price * .4);    // the treasury holds 40% of the plot
            double gap = g.landCashGap(just);
            assertTrue("fixture (" + paper + "): the treasury is short of the plot",
                    gap > 0 && !g.canAffordParcel(plot));
            check("the gap is the plot's local price less the cash", gap, price - g.getCash());
            assertTrue("...so its button opens the funding page", g.landNeedsFunding(just));
            boolean bond = paper.equals("bond");
            double granule = bond ? Game.BUILD_BOND_GRANULE : Game.BUILD_NOTE_GRANULE;
            DebtQuote quote = bond
                    ? g.quoteLongBondForCash(gap, Game.BUILD_BOND_YEARS, granule)
                    : g.quoteTBill(gap, Game.BUILD_NOTE_MONTHS, granule);
            assertTrue("the " + paper + "'s cash covers the gap", quote.cashReceived() >= gap - 1e-9);
            assertTrue("...by no more than a granule of face", quote.cashReceived() - gap <= granule);
            int debts = g.getDebtManager().getDebt().size();
            quietly(() -> {
                if (bond) g.handleLongBondForCash(gap, Game.BUILD_BOND_YEARS, granule);
                else g.handleTBillLogic(gap, Game.BUILD_NOTE_MONTHS, granule);
            });
            assertTrue("...issued, it is on the books", g.getDebtManager().getDebt().size() == debts + 1);
            double owned = g.getLandManager().getOwnedSqFt();
            assertTrue("...and the plot is bought", g.buyLandParcels(just) == 1);
            check("...the city owns it", g.getLandManager().getOwnedSqFt(), owned + plot.getSizeSqFt());
            check("...and the treasury keeps what the solver left over, as the build screen's does",
                    g.getCash(), quote.cashReceived() - gap);
            quietly(g::toggleNextMonth);
            assertTrue("...and the month after closes its audit", Math.abs(g.getLastMoneyAudit().relative()) < 1e-9);
            assertTrue("...with nothing moved after it struck", Math.abs(g.getPostAuditDrift()) < 1e-6);
        }

        System.out.println("\n--- short from the vault: dollar paper, sized to the dollar gap, into the vault ---");

        for (String type : new String[] { "Term", "Note" }) {
            Game g = dollarCity("landcheck-vault-" + type);
            g.setLandPaidFromVault(true);
            LandParcel plot = g.landShelf().get(0);
            java.util.List<Integer> just = java.util.List.of(plot.getId());
            double usd = plot.getPriceUsd();
            quietly(() -> g.sellForeignCurrency(      // the vault sold down to 30% of the plot
                    (g.getForeignAccounts().getReservesUsd() - usd * .3) * g.getForeignAccounts().getRate()));
            double held = g.getForeignAccounts().getReservesUsd();
            double gapUsd = g.landVaultGapUsd(just);
            assertTrue("fixture (" + type + "): the vault holds 30% of the plot", Math.abs(held - usd * .3) < 1e-6);
            check("the gap is in dollars: the plot less the vault", gapUsd, usd - held);
            assertTrue("fixture: the cash would cover the rest", g.canAffordParcel(plot) && g.landTopUpCovers(just));
            assertTrue("...and still the button opens the funding page: the rest converted is a choice, not the default",
                    g.landNeedsFunding(just));
            assertTrue("fixture: the window abroad is open", g.foreignWindowOpen());
            boolean bond = type.equals("Term");
            int term = bond ? Game.BUILD_BOND_YEARS : Game.BUILD_NOTE_MONTHS;
            double granule = bond ? Game.BUILD_BOND_GRANULE : Game.BUILD_NOTE_GRANULE;
            DebtQuote quote = g.quoteForeignForCash(type, gapUsd, term, granule);
            assertTrue("the dollar " + (bond ? "bond" : "note") + "'s dollars cover the gap",
                    quote.cashReceived() >= gapUsd - 1e-9);
            assertTrue("...by no more than a granule of face", quote.cashReceived() - gapUsd <= granule);
            check("...at the world's curve: the existing dollar quote at that face",
                    quote.marketRate(), g.quoteForeign(type, quote.requested(), term, granule).marketRate());
            double cash = g.getCash();
            quietly(() -> g.handleForeignForCash(type, gapUsd, term, granule, true));
            assertTrue("...issued abroad, it is dollar paper on the books", g.getDebtManager().hasForeignDebt());
            check("...the dollars land in the vault", g.getForeignAccounts().getReservesUsd(),
                    held + quote.cashReceived());
            check("...and the treasury's cash is where it was", g.getCash(), cash);
            assertTrue("...and the plot is bought", g.buyLandParcels(just) == 1);
            check("...out of the vault", g.getForeignAccounts().getReservesUsd(),
                    held + quote.cashReceived() - usd);
            check("...and no cash converted for it", g.getCash(), cash);
            quietly(g::toggleNextMonth);
            assertTrue("...and the month after closes its audit", Math.abs(g.getLastMoneyAudit().relative()) < 1e-9);
            assertTrue("...with nothing moved after it struck", Math.abs(g.getPostAuditDrift()) < 1e-6);
            check("...its dollars, the whole plot, the vault's", g.getForeignAccounts().getLandUsdFromVaultThisMonth(), usd);
        }

        System.out.println("\n--- with the window abroad shut, no dollar offer ---");

        Game g = dollarCity("landcheck-shut");
        g.setLandPaidFromVault(true);
        quietly(() -> g.handleForeignLogic("Note", 1_000, Game.BUILD_NOTE_MONTHS, Game.BUILD_NOTE_GRANULE, true));
        assertTrue("fixture: the window is shut - it owes dollars and sells nothing abroad", !g.foreignWindowOpen());
        System.out.println("   the window: " + g.foreignWindowReason());
        LandParcel plot = g.landShelf().get(0);
        java.util.List<Integer> just = java.util.List.of(plot.getId());
        double usd = plot.getPriceUsd();
        quietly(() -> g.sellForeignCurrency(
                (g.getForeignAccounts().getReservesUsd() - usd * .3) * g.getForeignAccounts().getRate()));
        double gapUsd = g.landVaultGapUsd(just);
        assertTrue("fixture: the vault is short of the plot", gapUsd > 0 && g.landNeedsFunding(just));
        assertTrue("no dollar bond is quoted",
                g.quoteForeignForCash("Term", gapUsd, Game.BUILD_BOND_YEARS, Game.BUILD_BOND_GRANULE).isEmpty());
        assertTrue("...nor a dollar note",
                g.quoteForeignForCash("Note", gapUsd, Game.BUILD_NOTE_MONTHS, Game.BUILD_NOTE_GRANULE).isEmpty());
        int debts = g.getDebtManager().getDebt().size();
        String[] said = new String[1];
        quietly(() -> said[0] = g.handleForeignForCash("Term", gapUsd, Game.BUILD_BOND_YEARS,
                Game.BUILD_BOND_GRANULE, true));
        assertTrue("...and asked anyway, nothing is issued", g.getDebtManager().getDebt().size() == debts);
        assertTrue("...and it says why, in the window's own words", said[0].contains(g.foreignWindowReason()));
        assertTrue("what remains is offered: the vault's dollars, the rest converted", g.landTopUpCovers(just));
        double held = g.getForeignAccounts().getReservesUsd(), cash = g.getCash();
        assertTrue("...which buys the plot", g.buyLandParcels(just) == 1);
        check("...the vault emptied into it", g.getForeignAccounts().getReservesUsd(), 0);
        check("...and the rest converted from cash", g.getCash(),
                cash - (usd - held) * g.getForeignAccounts().getRate());
        quietly(g::toggleNextMonth);
        assertTrue("...and the month after closes its audit", Math.abs(g.getLastMoneyAudit().relative()) < 1e-9);
    }

    /* ==================================================================
       16. THE NEXT N PLOTS, AT ONCE (0.7.13)

       Jerus: "add a button to buy multiple, so for example buy the next 5
       land options, and then also debt popup appears if not enough". Two
       cities founded alike; one buys the first five plots on the office's
       shelf in one go (Game.buyLandParcels()), the other one at a time
       (buyLandParcel()), and they must end the same to the cent - the same
       plots, the same prices, the same trail - converting, and from a vault
       that runs dry half way through, where the batch crosses from the vault
       to converting as five clicks would. A purchase moves only the plots
       listed after it (LandMarket, WHAT IS LISTED STAYS LISTED): asserted
       too, since it is why the two are the same. Then a total the treasury
       cannot cover opens the funding page, sized to the whole gap.
       ================================================================== */
    static void severalAtOnce() throws Exception {
        for (boolean fromVault : new boolean[] { false, true }) {
            String way = fromVault ? "from the vault" : "converting";
            System.out.println("\n--- the next five plots, " + way + ": at once is one by one ---");

            Game atOnce = dollarCity("landcheck-five-" + fromVault);
            Game oneByOne = dollarCity("landcheck-each-" + fromVault);
            java.util.List<Integer> ids = atOnce.nextLandParcels(5);
            java.util.List<LandParcel> shelf = atOnce.landShelf();
            boolean first = ids.size() == 5;
            for (int i = 0; first && i < 5; i++) first = shelf.get(i).getId() == ids.get(i);
            boolean ascending = true;
            for (int i = 1; i < shelf.size(); i++) {
                if (shelf.get(i).getUsdPerSqFt() < shelf.get(i - 1).getUsdPerSqFt()) ascending = false;
            }
            assertTrue("the next five are the first five on the office's shelf", first);
            assertTrue("...which is cheapest ground first", ascending);
            assertTrue("fixture: both cities list the same five", ids.equals(oneByOne.nextLandParcels(5)));
            double listed = 0;
            for (int id : ids) listed += atOnce.getLandManager().getMarket().find(id).getPriceUsd();
            check("their price together is their listed prices added", atOnce.landPriceUsd(ids), listed);
            check("...and in local money at today's rate", atOnce.landPriceLocal(ids),
                    listed * atOnce.getForeignAccounts().getRate());

            if (fromVault) {
                for (Game g : new Game[] { atOnce, oneByOne }) {
                    g.setLandPaidFromVault(true);
                    double keep = listed * .5;    // the vault holds half of the five
                    quietly(() -> g.sellForeignCurrency(
                            (g.getForeignAccounts().getReservesUsd() - keep) * g.getForeignAccounts().getRate()));
                }
                assertTrue("fixture: the vault runs dry part way through the five",
                        atOnce.landVaultGapUsd(ids) > 0 && atOnce.canAffordLandParcels(ids));
            } else {
                assertTrue("fixture: the treasury covers the five", !atOnce.landNeedsFunding(ids));
            }

            int bought = atOnce.buyLandParcels(ids);
            java.util.Map<Integer, Double> before = new java.util.HashMap<>();
            for (int id : ids) before.put(id, oneByOne.getLandManager().getMarket().find(id).getPriceUsd());
            boolean stood = true;
            for (int i = 0; i < ids.size(); i++) {
                oneByOne.buyLandParcel(ids.get(i));
                for (int j = i + 1; j < ids.size(); j++) {
                    LandParcel still = oneByOne.getLandManager().getMarket().find(ids.get(j));
                    if (still == null || still.getPriceUsd() != before.get(ids.get(j))) stood = false;
                }
            }
            assertTrue("all five were bought at once", bought == 5);
            assertTrue("each purchase left the plots still to come at their listed price", stood);
            check("the same cash, " + way, atOnce.getCash(), oneByOne.getCash());
            check("...the same vault", atOnce.getForeignAccounts().getReservesUsd(),
                    oneByOne.getForeignAccounts().getReservesUsd());
            check("...the same land owned", atOnce.getLandManager().getOwnedSqFt(),
                    oneByOne.getLandManager().getOwnedSqFt());
            check("...the same land purchases on the month's budget",
                    atOnce.getLandManager().getLandPurchasesThisMonth(),
                    oneByOne.getLandManager().getLandPurchasesThisMonth());
            check("...the same deposits", atOnce.getLandManager().getIronDeposits(),
                    oneByOne.getLandManager().getIronDeposits());
            boolean sameShelf = atOnce.landShelf().size() == oneByOne.landShelf().size();
            for (int i = 0; sameShelf && i < atOnce.landShelf().size(); i++) {
                sameShelf = atOnce.landShelf().get(i).getId() == oneByOne.landShelf().get(i).getId()
                        && atOnce.landShelf().get(i).getPriceUsd() == oneByOne.landShelf().get(i).getPriceUsd();
            }
            assertTrue("...and the same plots on offer after, at the same prices", sameShelf);
            assertTrue("the receipt names the five", atOnce.getLastLandReceipt().startsWith("Bought 5 plots"));
            quietly(atOnce::toggleNextMonth);
            quietly(oneByOne::toggleNextMonth);
            assertTrue("the month after closes its audit, at once", Math.abs(atOnce.getLastMoneyAudit().relative()) < 1e-9);
            assertTrue("...and one by one", Math.abs(oneByOne.getLastMoneyAudit().relative()) < 1e-9);
            check("...and the two cities end it with the same cash", atOnce.getCash(), oneByOne.getCash());
            check("...the month's dollars for land the five's, at once", atOnce.getForeignAccounts().getLandUsdThisMonth(), listed);
            check("...and one by one", oneByOne.getForeignAccounts().getLandUsdThisMonth(), listed);
            check("...the vault's part of them the same either way",
                    atOnce.getForeignAccounts().getLandUsdFromVaultThisMonth(),
                    oneByOne.getForeignAccounts().getLandUsdFromVaultThisMonth());
            if (fromVault) {
                assertTrue("fixture: the vault paid part of them and not all",
                        atOnce.getForeignAccounts().getLandUsdFromVaultThisMonth() > 0
                                && atOnce.getForeignAccounts().getLandUsdFromVaultThisMonth() < listed);
            }
        }

        System.out.println("\n--- a total the treasury cannot cover opens the funding page, for the whole gap ---");

        Game g = dollarCity("landcheck-five-short");
        java.util.List<Integer> ids = g.nextLandParcels(5);
        double rate = g.getForeignAccounts().getRate();
        LandParcel firstPlot = g.getLandManager().getMarket().find(ids.get(0));
        LandParcel second = g.getLandManager().getMarket().find(ids.get(1));
        g.setCashForTest(firstPlot.localPrice(rate) + second.localPrice(rate) / 2);   // one and a half plots
        assertTrue("fixture: the first plot alone is covered", !g.landNeedsFunding(ids.subList(0, 1)));
        assertTrue("the five are not, and open the funding page", g.landNeedsFunding(ids));
        double gap = g.landCashGap(ids);
        check("...for the whole gap", gap, g.landPriceLocal(ids) - g.getCash());
        DebtQuote quote = g.quoteLongBondForCash(gap, Game.BUILD_BOND_YEARS, Game.BUILD_BOND_GRANULE);
        assertTrue("the bond's cash covers it", quote.cashReceived() >= gap - 1e-9);
        quietly(() -> g.handleLongBondForCash(gap, Game.BUILD_BOND_YEARS, Game.BUILD_BOND_GRANULE));
        assertTrue("...and, issued, the five are bought", g.buyLandParcels(ids) == 5);
        check("...leaving what the solver left over", g.getCash(), quote.cashReceived() - gap);
        quietly(g::toggleNextMonth);
        assertTrue("...and the month after closes its audit", Math.abs(g.getLastMoneyAudit().relative()) < 1e-9);
    }

    /* ==================================================================
       17. THE OFFICE'S OWN FIGURES, IN THE MODEL (0.7.26)

       Jerus, on the screens not yet redone: "the others are still full of
       text and the design could be more intuitive and fun". The land office
       redrawn takes three things from the model: the going rate each plot
       is judged against - the median the screen took of the listing,
       LandMarket.goingUsdPerSqFt() now; the GROUND row its ground-free cell
       is coloured by - CityNeeds.ground(), the row NEEDS YOU lists, which
       Build's LAND FREE and the left panel read too, so none of them colours
       the ground used; and the receipt, which the model always wrote but in
       its own thousands ("US$101,800k"), in the screens' money now
       (Formats.amount() and rate()). Hand-made listings and a city's free
       ground set by hand cause each case.
       ================================================================== */
    static void theOfficesFigures() {
        System.out.println("\n--- the going rate is the listing's median, a square foot ---");

        LandMarket market = new LandMarket();
        // Nine offers of different sizes, priced so the median a square foot
        // (US$5) is neither the mean (US$14) nor the median of the prices.
        double[] perSqFt = { .007, .001, .090, .003, .005, .002, .008, .004, .006 };
        double[] sizes   = { 200_000, 9_000_000, 400_000, 1_000_000, 300_000, 7_000_000, 500_000,
                             2_000_000, 600_000 };
        market.putOffers(handMade(perSqFt, sizes, 9));
        assertTrue("fixture: the nine hand-made offers are listed", market.getListing().size() == 9);
        check("the going rate is the median of the offers' dollars a square foot",
                market.goingUsdPerSqFt(), .005);
        double mean = 0;
        for (double r : perSqFt) mean += r / perSqFt.length;
        assertTrue("...not their mean, which the one dear offer drags", Math.abs(market.goingUsdPerSqFt() - mean) > 1e-3);
        double[] prices = new double[9];
        for (int i = 0; i < 9; i++) prices[i] = perSqFt[i] * sizes[i];
        java.util.Arrays.sort(prices);
        double plotAtMedianPrice = 0;
        for (LandParcel p : market.getListing()) if (p.getPriceUsd() == prices[4]) plotAtMedianPrice = p.getUsdPerSqFt();
        assertTrue("...nor the dollars a square foot of the offer at the median price",
                Math.abs(market.goingUsdPerSqFt() - plotAtMedianPrice) > 1e-6);

        market.putOffers(handMade(new double[] { .001, .002, .003, .004, .005, .006, .007, .090 },
                new double[] { 1e6, 1e6, 1e6, 1e6, 1e6, 1e6, 1e6, 1e6 }, 8));
        check("with an even count, the upper of the two middle prices", market.goingUsdPerSqFt(), .005);
        market.putOffers(handMade(new double[0], new double[0], 0));
        check("with nothing listed, none", market.goingUsdPerSqFt(), 0);

        System.out.println("\n--- the ground's verdict is NEEDS YOU's GROUND row, on free ground alone ---");

        Game g = dollarCity("landcheck-ground");
        LandManager land = g.getLandManager();
        double owned = land.getOwnedSqFt();
        double allocated = land.getAllocatedSqFt();
        double[] frees = { 0, 50_000, CityNeeds.GROUND_YELLOW, CityNeeds.GROUND_YELLOW + 1_000, owned * .05 };
        int[] levels = { 2, 1, 1, 0, 0 };
        for (int i = 0; i < frees.length; i++) {
            land.setAllocatedSqFt(owned - frees[i]);
            CityNeeds.Need alone = CityNeeds.ground(g, CityNeeds.PLAIN);
            CityNeeds.Need listed = null;
            for (CityNeeds.Need n : CityNeeds.measure(g, CityNeeds.PLAIN)) {
                if (n.kind() == CityNeeds.Kind.GROUND) listed = n;
            }
            System.out.printf("   %,.0f sq ft free, %.1f%% used: %s%n", frees[i], land.getUtilisation() * 100,
                    alone.reading());
            check("the GROUND row's level is its free ground's", alone.level(), levels[i]);
            assertTrue("...is the row measure() lists, word for word",
                    listed != null && listed.level() == alone.level() && listed.reading().equals(alone.reading()));
        }
        assertTrue("fixture: the last is over 90% used, and still fine", land.getUtilisation() > .9);
        land.setAllocatedSqFt(allocated);

        System.out.println("\n--- the receipt writes its money as the office does ---");

        Game buyer = dollarCity("landcheck-receipt");
        LandParcel plot = buyer.landShelf().get(0);
        double rate = buyer.getForeignAccounts().getRate();
        String here = buyer.getCurrency().qualifiedSymbol();
        assertTrue("fixture: the plot is bought", buyer.buyLandParcel(plot.getId()));
        String receipt = buyer.getLastLandReceipt();
        System.out.println("   " + receipt);
        assertTrue("the receipt prices the plot as the screens do",
                receipt.contains(" for " + Formats.INSTANCE.amount(plot.getPriceUsd()).replace("$", "US$") + ","));
        assertTrue("...and the cash it converted",
                receipt.contains(Formats.INSTANCE.amount(plot.localPrice(rate)).replace("$", here) + " of cash"));
        assertTrue("...at the rate as the screens write it",
                receipt.contains(here + Formats.INSTANCE.rate(rate) + " to the dollar"));
        assertTrue("...and no thousands with a k stuck on", !receipt.matches(".*[0-9]k[ ,.].*"));
    }

    /** A listing of `n` offers by hand: dry ground of each size at its dollars a square foot, ids from 1, each in its own lane, no ore. */
    static java.util.List<LandParcel> handMade(double[] perSqFt, double[] sizes, int n) {
        java.util.List<LandParcel> list = new java.util.ArrayList<>();
        for (int i = 0; i < n; i++) {
            double km2 = LandManager.km2(sizes[i]);
            list.add(new LandParcel(i + 1, i / CityLand.LANES, i % CityLand.LANES, 0, 0,
                    new double[] { km2, km2, 0, 0, 0 }, new int[CityLand.KINDS], new double[CityLand.KINDS],
                    perSqFt[i] * sizes[i], 0));
        }
        return list;
    }

    /* ==================================================================
       19. THE LAND ON THE WORLD (0.7.57)

       The project's spec-land.md, batch J1b. The world's totals are kept to
       the tonne: what no city owns, what remains in the city's ground and
       what it has taken out add up to the world's, through a purchase and
       through extraction. The ground is worked out in the order it was
       bought, the centre first. A restated city keeps its iron and what it
       has taken out. Forest grows back. And the best offer for each need.
       ================================================================== */
    static void onTheWorld() {
        System.out.println("\n--- the world's totals are kept to the tonne ---");

        LandManager land = new LandManager();
        land.updateMarket(0);
        CityLand city = land.getCityLand();
        double[] stored = land.getWorldTotalsState();
        double[] again = new World(city.seed()).computeTotals();
        assertTrue("the city stores the world's totals, recomputed to the tonne", java.util.Arrays.equals(stored, again));
        near("...and its sea's level", land.getWorldSeaTheta(), World.of(city.seed()).seaTheta(), 0);

        // A purchase with iron in it, and one more resource it holds, if any.
        Deposit field = nearestUnowned(city, Resource.IRON);
        LandParcel rich = land.getMarket().richest(Resource.IRON);
        for (int i = 0; i < 400 && rich == null && field != null; i++) {
            int at = CityLand.sideLane(field.x() - city.siteX(), field.y() - city.siteY());
            land.buyParcel(land.getMarket().offerIn(at / CityLand.LANES, at % CityLand.LANES).getId(), 1e12, 0);
            rich = land.getMarket().richest(Resource.IRON);
        }
        assertTrue("fixture: an offer with iron in it", rich != null);
        double[] w = new double[CityLand.KINDS], u = new double[CityLand.KINDS], o = new double[CityLand.KINDS];
        boolean adds = true;
        for (Resource r : Resource.values()) {
            w[r.ordinal()] = land.getWorldTotal(r);
            u[r.ordinal()] = land.getUnowned(r);
            o[r.ordinal()] = land.getRemaining(r);
            adds &= land.getUnowned(r) + land.getRemaining(r) + land.getExtracted(r) == land.getWorldTotal(r);
        }
        assertTrue("unowned, remaining and extracted add up to the world's, every resource", adds);
        if (rich != null) {
            land.buyParcel(rich.getId(), 1e12, 0);
            boolean moved = true, still = true;
            for (Resource r : Resource.values()) {
                moved &= land.getUnowned(r) == u[r.ordinal()] - rich.getAmount(r)
                        && land.getRemaining(r) == o[r.ordinal()] + rich.getAmount(r);
                still &= land.getUnowned(r) + land.getRemaining(r) + land.getExtracted(r) == w[r.ordinal()];
            }
            assertTrue("a purchase moves exactly what it listed from the world's unowned to the city's ground", moved);
            assertTrue("...and the three still add up to the world's, to the tonne", still);
        }
        double lifted = land.extractIron(1_234_567.5);
        boolean taken = land.getExtracted(Resource.IRON) == lifted && lifted == 1_234_567.5;
        double sum = land.getUnowned(Resource.IRON) + land.getRemaining(Resource.IRON) + land.getExtracted(Resource.IRON);
        assertTrue("extraction moves what was lifted from the ground to the extracted", taken);
        near("...and the three still add up to the world's (to a part in 1e15)", sum,
                land.getWorldTotal(Resource.IRON), 1e-15);

        System.out.println("\n--- a field is shared site by site, and its shares sum to it ---");

        /*
         * 0.7.58 (batch J1c): a field's sites and tonnes are shared among the
         * centre and the bands its sites lie in, a site to the ground holding
         * its centre. Conservation needs the shares of every field to sum to
         * it exactly whoever lists what when, so every field near the default
         * site is cut by a tiling of the plane - the new city's centre and,
         * in every lane, bands from its edge outward at a width no offer has
         * (DEAL plots, a prime number of them) - and each field's pieces are
         * added up.
         */
        LandManager tiled = new LandManager();
        tiled.updateMarket(0);
        CityLand t = tiled.getCityLand();
        World world = World.of(t.seed());
        int fieldsCut = 0, acrossPieces = 0, sitesAll = 0;
        boolean sumsSites = true, sumsAmount = true, sitesWhole = true;
        double far = 220;
        for (int cell : CityLand.cellsUnder(t.siteX() - far, t.siteY() - far, t.siteX() + far, t.siteY() + far)) {
            for (Resource r : Resource.values()) {
                if (!r.inFields()) continue;
                for (Deposit d : world.fieldsInCell(cell, r)) {
                    double cr = CityLand.radius(d.x() - t.siteX(), d.y() - t.siteY());
                    if (cr - d.reach() > far) continue;
                    double each = 0;
                    for (int k = 0; k < d.sites(); k++) each += d.siteAmount(k);
                    sitesWhole &= each == d.amount();
                    int[] s = new int[CityLand.KINDS];
                    double[] a = new double[CityLand.KINDS];
                    int pieces = 0;
                    int before = s[r.ordinal()];
                    CityLand.centreShare(d, t.siteX(), t.siteY(), t.centreHalf(), s, a);
                    if (s[r.ordinal()] > before) pieces++;
                    double outTo = cr + d.reach() + DEAL;
                    for (int side = 0; side < CityLand.SIDES; side++) {
                        for (int lane = 0; lane < CityLand.LANES; lane++) {
                            for (double r1 = t.centreHalf(); r1 < outTo; r1 += DEAL) {
                                before = s[r.ordinal()];
                                CityLand.bandShare(d, t.siteX(), t.siteY(), side, lane, r1, r1 + DEAL, s, a);
                                if (s[r.ordinal()] > before) pieces++;
                            }
                        }
                    }
                    fieldsCut++;
                    sitesAll += d.sites();
                    if (pieces > 1) acrossPieces++;
                    sumsSites &= s[r.ordinal()] == d.sites();
                    sumsAmount &= a[r.ordinal()] == d.amount();
                }
            }
        }
        System.out.printf("   %d fields within %.0f plots of the site (%d sites), %d of them across more than one piece%n",
                fieldsCut, far, sitesAll, acrossPieces);
        assertTrue("fixture: fields near the site, some across more than one piece", fieldsCut > 10 && acrossPieces > 0);
        assertTrue("a field's sites' shares of its amount sum to it exactly", sitesWhole);
        assertTrue("its sites in the pieces of ground they lie under add up to its sites exactly", sumsSites);
        assertTrue("...and their amounts to its amount, to the unit", sumsAmount);

        // The founding field: the iron field nearest the site, which the
        // site's fourth test (an iron field within World.SITE_IRON_KM) found.
        Deposit founding = null;
        double nearest = Double.MAX_VALUE;
        double km = World.SITE_IRON_KM * 1000 / World.PLOT_M;
        for (int cell : CityLand.cellsUnder(t.siteX() - km, t.siteY() - km, t.siteX() + km, t.siteY() + km)) {
            for (Deposit d : world.fieldsInCell(cell, Resource.IRON)) {
                double dx = d.x() - t.siteX(), dy = d.y() - t.siteY(), l2 = Math.sqrt(dx * dx + dy * dy);
                if (l2 > km || l2 >= nearest) continue;
                nearest = l2;
                founding = d;
            }
        }
        assertTrue("fixture: the founding site's iron field", founding != null);
        int offersOnIt = 0, sitesOffered = 0;
        for (LandParcel p : tiled.getListing()) {
            int[] s = new int[CityLand.KINDS];
            double[] a = new double[CityLand.KINDS];
            if (founding != null) CityLand.bandShare(founding, t.siteX(), t.siteY(), p.getSide(), p.getLane(), p.getR1(), p.getR2(), s, a);
            if (s[Resource.IRON.ordinal()] > 0) offersOnIt++;
            sitesOffered += s[Resource.IRON.ordinal()];
        }
        if (founding != null) {
            System.out.printf("   the founding field: %d sites, %,.0f Mt, its centre %.0f plots out; %d of its sites on %d of a new city's forty offers%n",
                    founding.sites(), founding.amount() / 1e6, CityLand.radius(founding.x() - t.siteX(), founding.y() - t.siteY()),
                    sitesOffered, offersOnIt);
            assertTrue("a new city's first offers carry some of the founding field, not all of it",
                    sitesOffered > 0 && sitesOffered < founding.sites());
        }

        System.out.println("\n--- a new city can buy iron at once ---");

        /*
         * The point of sharing a field (0.7.58): the first ring of a default
         * city holds iron at a price its founding treasury pays. Measured on
         * the default world: the cheapest offer with iron is a site of
         * 12.8 Mt for about US$5.3M (its ground and 12.8 Mt at US$0.40),
         * where whole fields first offered the founding field's 35 sites at
         * US$180M.
         */
        Game founded = new Game(GameFiles.scratch("landcheck-early-iron"));
        quietly(() -> { founded.newGame(); founded.toggleNextMonth(); });
        LandParcel firstIron = null;
        for (LandParcel p : founded.getLandListing()) {
            if (p.hasIron() && (firstIron == null || p.getPriceUsd() < firstIron.getPriceUsd())) firstIron = p;
        }
        assertTrue("a new default city is offered iron in its first ring", firstIron != null);
        if (firstIron != null) {
            System.out.printf("   %s: %d site(s), %,.1f Mt, for US$%,.2fM; the treasury holds %s%,.1fM at %.2f to the dollar%n",
                    firstIron.where(), firstIron.getDeposits(), firstIron.getIronTonnes() / 1e6, firstIron.getPriceUsd() / 1000,
                    founded.getCurrency().qualifiedSymbol(), founded.getCash() / 1000, founded.getForeignAccounts().getRate());
            assertTrue("...and can pay for it out of its founding treasury", founded.canAffordParcel(firstIron));
        }

        System.out.println("\n--- the ground is worked out in the order it was bought ---");

        LandManager order = new LandManager();
        order.updateMarket(0);
        order.restoreIron(2, 3_000_000);           // the centre: two sites, 3 Mt
        CityLand ordered = order.getCityLand();
        field = nearestUnowned(ordered, Resource.IRON);
        LandParcel first = order.getMarket().richest(Resource.IRON);
        for (int i = 0; i < 400 && first == null && field != null; i++) {
            int at = CityLand.sideLane(field.x() - ordered.siteX(), field.y() - ordered.siteY());
            order.buyParcel(order.getMarket().offerIn(at / CityLand.LANES, at % CityLand.LANES).getId(), 1e12, 0);
            first = order.getMarket().richest(Resource.IRON);
        }
        assertTrue("fixture: an offer with iron, after the centre's", first != null);
        if (first != null) {
            order.buyParcel(first.getId(), 1e12, 0);
            double[] held = ordered.amountsInOrder(Resource.IRON);
            int last = held.length - 1;
            order.extractIron(1_000_000);
            double[] left = order.remainingByHolding(Resource.IRON);
            check("a million tonnes out comes out of the centre first", left[0], 2_000_000);
            check("...leaving the purchase whole", left[last], held[last]);
            order.extractIron(2_500_000);
            left = order.remainingByHolding(Resource.IRON);
            check("past the centre's 3 Mt, the centre is worked out", left[0], 0);
            check("...and the rest comes out of the next bought", left[last], held[last] - 500_000);
            double all = 0;
            for (double d : left) all += d;
            check("...the holdings' remainders add to what remains", all, order.getIronReserveTonnes());
        }

        System.out.println("\n--- ground set by hand: the land drawn again, the iron kept ---");

        LandManager hand = new LandManager();
        hand.updateMarket(0);
        hand.restoreIron(5, 40_000_000);
        hand.extractIron(1_000_000);
        double want = LandManager.STARTING_SQ_FT + 400 * LandManager.BLOCK_SQ_FT;
        hand.setOwnedSqFt(want);
        CityLand drawn = hand.getCityLand();
        check("the city owns exactly the figure", hand.getOwnedSqFt(), want);
        near("...and its land's dry ground is that figure, to a part in a billion", hand.getLandDrySqFt(), want,
                LandConversion.SAME_GROUND);
        check("...all of it in the centre, nothing bought", drawn.purchases().size(), 0);
        check("its iron sites are kept", hand.getIronDeposits(), 5);
        check("...and what remains of its tonnes", hand.getIronReserveTonnes(), 39_000_000);
        check("...and what it had taken out", hand.getExtracted(Resource.IRON), 1_000_000);
        check("forty offers stand from the new centre's edge", hand.getListing().size(), LandMarket.OFFERS);
        boolean edge = true;
        for (LandParcel p : hand.getListing()) edge &= p.getR1() == drawn.centreHalf();
        assertTrue("...each starting at it", edge);

        System.out.println("\n--- forest grows back: a twentieth left in sixty years ---");

        // World 2, whose founding coast is wooded: 32.9 of the first 37.4 km2
        // of dry ground round its site (measured; the default world's site
        // stands among lakes, with none).
        LandManager wood = new LandManager(() -> ForeignAccounts.OPENING_RATE, () -> 1.0, () -> 2L, () -> 0);
        wood.setOwnedSqFt(LandManager.STARTING_SQ_FT + 4_000 * LandManager.BLOCK_SQ_FT);
        wood.updateMarket(0);
        double timber = wood.getRemaining(Resource.FOREST);
        assertTrue("fixture: the city's ground has forest on it", timber > 0);
        double cut = wood.extract(Resource.FOREST, timber / 2);
        wood.clearMonth();
        check("clearing a month's flows grows nothing back (a load does that)", wood.getExtracted(Resource.FOREST), cut);
        for (int m = 0; m < 240; m++) wood.endMonth();
        near("each month's end takes FOREST_REGROWTH off what was cut: after twenty years",
                wood.getExtracted(Resource.FOREST), cut * Math.pow(1 - LandManager.FOREST_REGROWTH, 240), 1e-12);
        for (int m = 240; m < 720; m++) wood.endMonth();
        assertTrue("...and after sixty, 95% has grown back", wood.getExtracted(Resource.FOREST) <= cut * .05);

        System.out.println("\n--- the best offer for each need ---");

        Game g = dollarCity("landcheck-best");
        LandMarket market = g.getLandManager().getMarket();
        LandParcel best = g.bestOffer(Game.LandNeed.room());
        boolean bestRoom = best != null && !best.isMostlySea() && g.canAffordParcel(best);
        for (LandParcel p : market.getListing()) {
            if (p.isMostlySea() || !g.canAffordParcel(p)) continue;
            bestRoom &= p.getDryKm2PerUsd() <= best.getDryKm2PerUsd();
        }
        assertTrue("room: the most dry ground a dollar the city can afford, never mostly sea", bestRoom);
        double need = 0;
        for (LandParcel p : market.getListing()) need = Math.max(need, p.getSizeSqFt() / 2);
        LandParcel covers = g.bestOffer(Game.LandNeed.shortfall(need));
        boolean cheapestCovering = covers != null;
        for (LandParcel p : market.getListing()) {
            if (p.getSizeSqFt() >= need) cheapestCovering &= covers.getSizeSqFt() >= need && p.getPriceUsd() >= covers.getPriceUsd();
        }
        assertTrue("a shortfall: the cheapest offer whose dry ground covers it", cheapestCovering);
        assertTrue("a deposit: the most sites a dollar (LandMarket.richest())",
                g.bestOffer(Game.LandNeed.deposit(Resource.IRON)) == market.richest(Resource.IRON));
        assertTrue("a coast: the cheapest offer with sea in it",
                g.bestOffer(Game.LandNeed.coast()) == market.cheapestWithSea());
    }

    /* ==================================================================
       20. A CITY SAVED AND LOADED IS THE SAME LAND (0.7.57)

       Two cities founded alike buy the same offer; one is saved and loaded.
       Its land comes back field for field - the centre, the lanes, the
       purchase, the forty offers, what was taken out, the world's totals -
       the other thirty-nine offers as they were listed, and its next month
       plays to the same people, cash and offers as the one that was not.
       ================================================================== */
    static void savedAndLoaded() throws Exception {
        System.out.println("\n--- a city saved and loaded is the same land ---");

        GameFiles files = GameFiles.scratch("landcheck-world-save");
        Game live = new Game(files);
        quietly(() -> { live.newGame(); live.toggleNextMonth(); });
        LandParcel bought = live.getLandManager().getMarket().bestValue();
        java.util.List<LandParcel> others = live.getLandListing();
        assertTrue("fixture: the city buys an offer", live.buyLandParcel(bought.getId()));
        quietly(() -> live.saveGame(4, "land on the world"));
        Game[] back = new Game[1];
        quietly(() -> { back[0] = new Game(files); back[0].loadGameSave(4); });
        Game loaded = back[0];
        assertTrue("fixture: it loads", loaded.getLoadFailure() == null);
        CityLand a = live.getCityLand(), b = loaded.getCityLand();
        assertTrue("the centre, the lanes and the purchase come back field for field", a.same(b));
        boolean offers = live.getLandListing().size() == loaded.getLandListing().size();
        for (int i = 0; offers && i < live.getLandListing().size(); i++) {
            offers = live.getLandListing().get(i).same(loaded.getLandListing().get(i));
        }
        assertTrue("...the forty offers", offers);
        boolean stood = true;
        for (LandParcel p : others) {
            if (p.getId() == bought.getId()) continue;
            stood &= p.same(loaded.getLandManager().getMarket().find(p.getId()));
        }
        assertTrue("...the other thirty-nine exactly as listed before the purchase", stood);
        check("...the next offer's id", loaded.getLandManager().getMarket().getNextOfferId(),
                live.getLandManager().getMarket().getNextOfferId());
        assertTrue("...what was taken out of the ground",
                java.util.Arrays.equals(live.getLandManager().getDepletionState(), loaded.getLandManager().getDepletionState()));
        assertTrue("...the world's totals and its sea's level",
                java.util.Arrays.equals(live.getLandManager().getWorldTotalsState(), loaded.getLandManager().getWorldTotalsState())
                        && live.getLandManager().getWorldSeaTheta() == loaded.getLandManager().getWorldSeaTheta());
        check("...the square feet owned", loaded.getLandManager().getOwnedSqFt(), live.getLandManager().getOwnedSqFt());
        check("...and the office's unit", loaded.getLandManager().getMarket().getMinBlocks(),
                live.getLandManager().getMarket().getMinBlocks());

        quietly(live::toggleNextMonth);
        quietly(loaded::toggleNextMonth);
        check("its next month plays to the same population", loaded.getPopulationManager().getPopulation(),
                live.getPopulationManager().getPopulation());
        check("...the same cash", loaded.getCash(), live.getCash());
        assertTrue("...and the same land and offers",
                live.getCityLand().same(loaded.getCityLand())
                        && java.util.Arrays.deepEquals(live.getLandManager().getMarket().getOffersState(),
                                loaded.getLandManager().getMarket().getOffersState()));
    }

    /* ==================================================================
       21. AN OLDER SAVE'S LAND IS CONVERTED (0.7.57)

       spec-land 2.9: a save of format 30 carries one figure of ground, a
       pool of iron and nine parcels. The three research cities' land, as
       their saves carry it - city600 at month 612, city2400 at 2412, Jerus's
       at 1851: each one's square feet, iron sites and tonnes, its mines and
       the world seed its 0.7.56 save derives (fixJ1a's notes) - written into
       a format-30 save by hand, and loaded: its dry ground within a part in a
       billion, at least as many iron sites as mines, its tonnes exact, forty
       offers. And a city with more mines than sites, which are raised to
       them.
       ================================================================== */

    /** One research city's land as its save carries it: its name, its world's seed, its square feet, iron sites and tonnes, and its Iron Mines. */
    record Research(String name, long seed, double landOwned, int ironSites, double ironTonnes, int mines) { }

    /** The three research saves' land (the autosaves at months 612, 2412 and 1851), and a city whose mines outnumber its sites. */
    static final Research[] RESEARCH = {
        new Research("city600 m612", 906013741141069877L, 32_635_000, 10, 36200450.60153519, 1),
        new Research("city2400 m2412", -8480926900264452605L, 358_285_000, 64, 218643630.67146584, 0),
        new Research("Jerus m1851", -2365104814562977942L, 964_751_000, 155, 508088779.4794291, 21),
        new Research("more mines than sites", Founding.DEFAULT_WORLD_SEED, 30_000_000, 1, 2_000_000, 3),
    };

    static void converted() throws Exception {
        System.out.println("\n--- an older save's land is put on the world, once ---");

        for (Research r : RESEARCH) {
            GameFiles files = GameFiles.scratch("landcheck-convert-" + r.seed());
            Game city = new Game(files);
            quietly(() -> {
                city.newGame();
                BuildingsTemplate mine = city.getBuildingManager().getTemplateByName("Iron Mine");
                if (r.mines() > 0) city.getBuildingManager().addStack(mine, r.mines(), true);
                city.saveGame(4, "older land");
            });
            com.google.gson.JsonObject json = com.google.gson.JsonParser.parseString(
                    java.nio.file.Files.readString(files.saveFile(4))).getAsJsonObject();
            for (String key : new String[] { "worldSeaTheta", "worldTotals", "landCentre", "landLanes", "landPurchases",
                    "landOffers", "nextOfferId", "depletion" }) json.remove(key);
            json.addProperty("saveFormat", LandConversion.LAST_FORMAT_BEFORE);
            json.addProperty("worldSeed", r.seed());
            json.addProperty("landOwned", r.landOwned());
            json.addProperty("ironDeposits", r.ironSites());
            json.addProperty("ironReserveTonnes", r.ironTonnes());
            com.google.gson.JsonArray parcels = new com.google.gson.JsonArray();
            parcels.add(-105.0);
            parcels.add(10.0);
            for (int i = 0; i < 9; i++) for (double v : new double[] { i + 1, 250_000, 175, 0, 0 }) parcels.add(v);
            json.add("landListing", parcels);
            java.nio.file.Files.writeString(files.saveFile(4), json.toString());

            Game[] back = new Game[1];
            long t0 = System.nanoTime();
            quietly(() -> { back[0] = new Game(files); back[0].loadGameSave(4); });
            double ms = (System.nanoTime() - t0) / 1e6;
            Game old = back[0];
            assertTrue("fixture (" + r.name() + "): the format-30 save loads", old.getLoadFailure() == null);
            LandManager land = old.getLandManager();
            CityLand put = old.getCityLand();
            double share = put.centreKm2(CityLand.DRY) / put.centreKm2(CityLand.TOTAL);
            System.out.printf("   %s: %.2f km2 dry in a centre of %.2f km2 (%.0f%% dry) at (%d, %d), %d sites on %d mines,"
                            + " %,.0f t; loaded in %,.0f ms%n", r.name(), put.centreKm2(CityLand.DRY), put.centreKm2(CityLand.TOTAL),
                    share * 100, put.siteX(), put.siteY(), land.getIronDeposits(), old.minesCommitted(),
                    land.getIronReserveTonnes(), ms);
            check("its world is its save's seed", old.getWorldSeed(), r.seed());
            near("...its dry ground the save's square feet, to a part in a billion", land.getLandDrySqFt(), r.landOwned(),
                    LandConversion.SAME_GROUND);
            check("...owned as before", land.getOwnedSqFt(), r.landOwned());
            assertTrue("...at least as many iron sites as mines standing and on order",
                    land.getIronDeposits() >= old.minesCommitted());
            check("...its sites the save's, or its mines where they are more", land.getIronDeposits(),
                    Math.max(r.ironSites(), r.mines()));
            check("...its tonnes the save's, exactly", land.getIronReserveTonnes(), r.ironTonnes());
            check("...nothing taken out yet", land.getExtracted(Resource.IRON), 0);
            check("...the nine parcels gone and forty offers in their place", land.getListing().size(), LandMarket.OFFERS);
            assertTrue("...all of them at the centre's edge, nothing bought",
                    put.purchases().isEmpty() && land.getListing().stream().allMatch(p -> p.getR1() == put.centreHalf()));
            double lx = put.legacyX() - put.siteX(), ly = put.legacyY() - put.siteY();
            boolean legacy = put.legacySites() == 0
                    || Math.sqrt(lx * lx + ly * ly) >= LandConversion.LEGACY_FIELD_KM * 1000 / World.PLOT_M - 1;
            assertTrue("...and a legacy iron field, if the map needs one, a kilometre or more from the site", legacy);
            if (share >= LandConversion.CENTRE_DRY_MIN) {
                assertTrue("...its centre at least 80% dry (the fifth test)", share >= LandConversion.CENTRE_DRY_MIN);
            } else {
                System.out.printf("   (no site in %d cells passed the fifth test: the driest found, %.0f%%)%n",
                        LandConversion.SITE_CELLS, share * 100);
            }
            quietly(() -> old.saveGame(5, "converted"));
            Game[] again = new Game[1];
            quietly(() -> { again[0] = new Game(files); again[0].loadGameSave(5); });
            assertTrue("...converted once: saved again, it loads as it is", again[0].getCityLand().same(put)
                    && java.util.Arrays.deepEquals(again[0].getLandManager().getMarket().getOffersState(),
                            land.getMarket().getOffersState()));
        }
    }

    /** The iron field nearest a city's site, in the nine cells round it, whose centre the city does not own; null when none. */
    static Deposit nearestUnowned(CityLand land, Resource kind) {
        World world = World.of(land.seed());
        long cx = land.siteX() / World.CELL, cy = land.siteY() / World.CELL;
        Deposit nearest = null;
        double best = Double.MAX_VALUE;
        for (long y = cy - 1; y <= cy + 1; y++) {
            for (long x = cx - 1; x <= cx + 1; x++) {
                if (x < 0 || y < 0 || x >= World.CELLS || y >= World.CELLS) continue;
                for (Deposit d : world.fieldsInCell((int) (y * World.CELLS + x), kind)) {
                    double r = CityLand.radius(d.x() - land.siteX(), d.y() - land.siteY());
                    if (land.ownsPlot(d.x(), d.y()) || r >= best) continue;
                    best = r;
                    nearest = d;
                }
            }
        }
        return nearest;
    }

    /** The width of the bands the shares are tiled with: 7 plots, which no offer is. */
    static final double DEAL = 7;

    /* ==================================================================
       22. THE TEST PLAYER KEEPS ITS GROUND AHEAD (0.7.58, batch J1d)

       LongPlaytest.keepGroundAhead(), at each of the playtest's looks: the
       best value for room until no more of the dry ground is built on than
       the ground in use grown BuildAdvice.HORIZON months by the businesses'
       growthFactor(), with BuildAdvice.SLACK past it, spending at most
       GROUND_AHEAD_CASH_SHARE of the cash. The fixtures build a new city's
       ground to 99% and give it its founding treasury, then a tenth too
       little for the best offer, and leave a third city as it was founded.
       ================================================================== */
    static void groundKeptAhead() {
        System.out.println("\n--- the test player keeps its ground ahead (0.7.58) ---");

        Game g = dollarCity("landcheck-ahead");
        LandManager land = g.getLandManager();
        double line = LongPlaytest.groundAheadUtilisation(g);
        check("the line is the ground in use HORIZON months out, SLACK past it", line,
                1 / (g.getBusinessInvestment().growthFactor(BuildAdvice.HORIZON) * (1 + BuildAdvice.SLACK)));
        assertTrue("...never more built on than 1 / (1 + SLACK)", line <= 1 / (1 + BuildAdvice.SLACK) + 1e-12);
        land.allocate(land.getAvailableSqFt() - .01 * land.getOwnedSqFt());
        assertTrue("fixture: 99% of the ground is built on, past the line",
                land.getAllocatedSqFt() / land.getOwnedSqFt() > line);
        double cash = g.getCash(), owned = land.getOwnedSqFt();
        int bought = LongPlaytest.groundAheadBought, purchases = g.getCityLand().purchases().size();
        quietly(() -> LongPlaytest.keepGroundAhead(g));
        int made = g.getCityLand().purchases().size() - purchases;
        System.out.printf("   %d offer(s), %.4f km2 dry, D$%,.0fk of D$%,.0fk; built on %.4f against the line %.4f%n",
                made, LandManager.km2(land.getOwnedSqFt() - owned), cash - g.getCash(), cash,
                land.getAllocatedSqFt() / land.getOwnedSqFt(), line);
        assertTrue("it bought ground, each purchase counted", made > 0 && LongPlaytest.groundAheadBought - bought == made);
        assertTrue("...until no more is built on than the line",
                land.getAllocatedSqFt() / land.getOwnedSqFt() <= line);
        assertTrue("...for no more than the cash share",
                cash - g.getCash() <= LongPlaytest.GROUND_AHEAD_CASH_SHARE * cash * (1 + 1e-12));

        Game poor = dollarCity("landcheck-ahead-poor");
        LandManager pl = poor.getLandManager();
        pl.allocate(pl.getAvailableSqFt() - .01 * pl.getOwnedSqFt());
        LandParcel best = poor.bestOffer(Game.LandNeed.room());
        double price = best.localPrice(poor.getForeignAccounts().getRate());
        poor.setCashForTest(price / LongPlaytest.GROUND_AHEAD_CASH_SHARE * .9);
        double poorCash = poor.getCash(), poorOwned = pl.getOwnedSqFt();
        int poorShort = LongPlaytest.groundAheadShort;
        assertTrue("fixture: the best value is past the cash share, inside the cash",
                price > LongPlaytest.GROUND_AHEAD_CASH_SHARE * poorCash && poor.canAffordParcel(best));
        quietly(() -> LongPlaytest.keepGroundAhead(poor));
        assertTrue("a look the cash share cannot cover buys nothing", pl.getOwnedSqFt() == poorOwned && poor.getCash() == poorCash);
        assertTrue("...and is counted stopped short", LongPlaytest.groundAheadShort == poorShort + 1);

        Game founded = dollarCity("landcheck-ahead-founded");
        LandManager fl = founded.getLandManager();
        double foundedOwned = fl.getOwnedSqFt();
        assertTrue("fixture: a city as founded is under the line",
                fl.getAllocatedSqFt() / fl.getOwnedSqFt() <= LongPlaytest.groundAheadUtilisation(founded));
        quietly(() -> LongPlaytest.keepGroundAhead(founded));
        assertTrue("...and buys nothing", fl.getOwnedSqFt() == foundedOwned);
    }

    /** An offer's sites of one resource, recounted from the world (0.7.58): every site of every field whose centre lies in its band, and its share of its field. */
    static double[] bandFields(CityLand land, LandParcel offer, Resource kind) {
        int want = offer.getSide() * CityLand.LANES + offer.getLane();
        return recount(land, kind, offer.getR2() + Deposit.mostReach(kind), (dx, dy) -> {
            double r = CityLand.radius(dx, dy);
            return r > offer.getR1() && r <= offer.getR2() && CityLand.sideLane(dx, dy) == want;
        });
    }

    /** Every site of a resource within `out` plots of a city's site (L-infinity) whose centre, seen from the site, passes `in`: how many, and their shares of their fields - placed one by one from Deposit.siteAt(), with none of CityLand's short cuts. */
    static double[] recount(CityLand land, Resource kind, double out, java.util.function.BiPredicate<Double, Double> in) {
        World world = World.of(land.seed());
        double sites = 0, amount = 0;
        for (int cell : CityLand.cellsUnder(land.siteX() - out, land.siteY() - out, land.siteX() + out, land.siteY() + out)) {
            for (Deposit d : world.fieldsInCell(cell, kind)) {
                for (int k = 0; k < d.sites(); k++) {
                    double[] at = d.siteAt(k);
                    if (in.test(d.x() - land.siteX() + at[0], d.y() - land.siteY() + at[1])) {
                        sites++;
                        amount += d.siteAmount(k);
                    }
                }
            }
        }
        return new double[] { sites, amount };
    }

}
