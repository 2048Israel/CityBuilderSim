package ham.citybuildersim;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The city's land on the world: the centre it was founded or converted with, the ten lanes on each of its four sides and every purchase made along them, and what all of it holds - its area dry, fresh, sea and forest, and the sites and amounts of the seven resources.
 *
 * WHY THIS EXISTS (0.7.57, batch J1b; the project's spec-land.md 2.2). Until
 * now the city's land was one number, the square feet it owned, and the land
 * office sold parcels drawn by a generator seeded with the parcel's id: a
 * size, a price and some iron, and no place. The world (World, 0.7.56) is
 * real ground, so the city's land is a piece of it now: a square round the
 * founding site - the CENTRE - and, on each of four sides, ten lanes fanning
 * out from the site, each pushed out band by band as the city buys.
 *
 * THE GEOMETRY (spec-land star 1). Every point is seen from the founding
 * site's plot centre: its side is N, E, S or W by the larger of |x| and |y|
 * (y runs south), its radius r = max(|x|, |y|), and its lane
 * floor((t + 1) x 5), where t is x/|y| or y/|x| read across the side, so lane
 * 0 is the left-hand one facing out. The city owns a point when r is within
 * the centre's half-side, or within its lane's frontier. A band of a lane
 * from r1 to r2 holds LANE_SHARE x (r2^2 - r1^2) plots, so forty equal lanes
 * make a square with straight frontiers.
 *
 * NOTHING ROLLS INTO THE CENTRE (spec-land star 3). The centre is the land
 * the city was founded or converted with, fixed; a side is its ten lanes,
 * each holding its purchases in order. Only a restatement (LandConversion.
 * restate()) - a harness's ground by fiat, a copy of a city K times over -
 * draws the centre again, and folds everything into it.
 *
 * WHAT A PIECE OF GROUND HOLDS is measured once, when it is founded or
 * listed, and kept: the centre from a profile of the ground ring by ring
 * round the site (sized so it holds exactly the dry ground asked for), an
 * offer's band from BAND_SAMPLES x BAND_SAMPLES area-uniform samples, and
 * every site of every field of every resource whose centre lies in it
 * (THE FIELDS IN A PIECE OF GROUND, below). Purchases are kept in the order
 * they were made, which is the order the ground is worked out in
 * (LandManager's depletion).
 *
 * A FIELD IS SHARED SITE BY SITE (0.7.58, batch J1c). Until then a field
 * belonged whole to the piece of ground holding its centre (spec-land star
 * 12): the default world's founding field, 35 sites and 449 Mt, came as one
 * offer at US$180M, past any young treasury, and the playtest's first iron
 * moved from month 31 to month 1,088. A field is its sites now
 * (Deposit.siteAt()), and each site, with its share of the field's amount
 * (Deposit.siteAmount()), belongs to the piece of ground holding the site's
 * centre: so the centre and the bands a field lies across share it in
 * proportion to the area of it each covers, a whole site at a time, and the
 * shares sum to the field exactly whoever lists what when - a site is in
 * exactly one piece of ground, since the centre and the bands of the forty
 * lanes tile the plane. The first bands round the founding site carry a few
 * of its field's sites each, priced by their own tonnes.
 */
public final class CityLand {

    /** Sides of the city, seen from the founding site: north, east, south and west, in that order - the larger of |x| and |y| says which (spec-land star 1). */
    public static final int SIDES = 4;

    /** Lanes on a side: ten wedges fanning out from the site, each with one offer standing (spec-land star 1). */
    public static final int LANES = 10;

    /** The sides' names, in their order. */
    static final String[] SIDE_NAMES = { "North", "East", "South", "West" };

    /** A lane's share of its side's r squared: a tenth - a side within radius r holds r^2 plots, so a band of a lane from r1 to r2 holds this x (r2^2 - r1^2). */
    public static final double LANE_SHARE = 1.0 / LANES;

    /** Where a record keeps its whole area, in square kilometres. */
    public static final int TOTAL = 0;

    /** ...its dry ground: what buildings stand on, and what the city's square feet count. */
    public static final int DRY = 1;

    /** ...its fresh water: lakes and the founding river. */
    public static final int FRESH = 2;

    /** ...its sea. */
    public static final int SEA = 3;

    /** ...and its forest, which is dry ground too. */
    public static final int FOREST = 4;

    /** How many areas a record keeps: total, dry, fresh, sea and forest. */
    public static final int AREAS = 5;

    /** How many resources a record keeps the sites and amounts of: Resource's seven, in its order. */
    public static final int KINDS = Resource.values().length;

    /** Samples across an offer's band each way: 64, so 4,096 area-uniform points of its terrain measure its areas (spec-land 2.2). */
    public static final int BAND_SAMPLES = 64;

    /**
     * Samples across a centre's profile from the site to twice the radius
     * its dry ground would need if all of it were dry: 1,024 - the stride is
     * one plot (every plot counted, a tile at a time) up to about 236 km2 of
     * dry ground, and coarser past it, so a profile is about a million
     * samples at any size (the design's 2,048 across its whole reach).
     */
    public static final int PROFILE_SPAN = 1024;

    /* =====================================================================
       THE STATE
       ===================================================================== */

    private final long seed;
    private final long siteX, siteY;
    private double centreHalf;
    private final double[] centreKm2 = new double[AREAS];
    private final int[] centreSites = new int[KINDS];
    private final double[] centreAmounts = new double[KINDS];
    private long legacyX = -1, legacyY = -1;
    private int legacySites;
    private final double[] frontier = new double[SIDES * LANES];
    private final List<Purchase> purchases = new ArrayList<>();

    /* What the whole holds, kept in step: the centre's and every purchase's, added in acquisition order. */
    private final double[] totalKm2 = new double[AREAS];
    private final long[] totalSites = new long[KINDS];
    private final double[] totalAmounts = new double[KINDS];

    /**
     * One purchase: the offer bought, as it was listed, the month it was
     * bought in and what the treasury paid for it in local money.
     */
    public record Purchase(LandParcel offer, int month, double paidLocal) { }

    private CityLand(long seed, long siteX, long siteY) {
        this.seed = seed;
        this.siteX = siteX;
        this.siteY = siteY;
    }

    /**
     * A city's land at founding: a centre round the site (x, y) holding
     * exactly dryKm2 of dry ground, its lanes at the centre's edge, nothing
     * bought.
     */
    public static CityLand found(World world, long x, long y, double dryKm2) {
        CityLand land = new CityLand(world.seed(), x, y);
        land.drawCentre(world, dryKm2);
        return land;
    }

    /** Draws the centre again round the same site, holding dryKm2 of dry ground, and folds every purchase into it: the lanes back at its edge. */
    void drawCentre(World world, double dryKm2) {
        Centre c = sizeCentre(world, siteX, siteY, dryKm2);
        centreHalf = c.half();
        System.arraycopy(c.km2(), 0, centreKm2, 0, AREAS);
        Arrays.fill(centreSites, 0);
        Arrays.fill(centreAmounts, 0);
        fieldsWithin(world, siteX, siteY, centreHalf, centreSites, centreAmounts);
        centreAmounts[Resource.FOREST.ordinal()] = Math.rint(centreKm2[FOREST] * World.FOREST_M3_PER_KM2);
        legacyX = legacyY = -1;
        legacySites = 0;
        Arrays.fill(frontier, centreHalf);
        purchases.clear();
        recount();
    }

    /** Sets what the centre holds of one resource - an older save's iron, or a restatement keeping the city's (LandConversion). */
    void setCentre(Resource r, int sites, double amount) {
        centreSites[r.ordinal()] = Math.max(0, sites);
        centreAmounts[r.ordinal()] = Math.max(0, amount);
        recount();
    }

    /** Where the map draws a converted centre's iron when the world put none in it: a plot and its sites (spec-land 2.4). */
    void setLegacyField(long x, long y, int sites) {
        legacyX = x;
        legacyY = y;
        legacySites = sites;
    }

    /** Adds the totals up again, in acquisition order. */
    private void recount() {
        System.arraycopy(centreKm2, 0, totalKm2, 0, AREAS);
        for (int k = 0; k < KINDS; k++) {
            totalSites[k] = centreSites[k];
            totalAmounts[k] = centreAmounts[k];
        }
        for (Purchase p : purchases) add(p.offer());
    }

    private void add(LandParcel o) {
        for (int a = 0; a < AREAS; a++) totalKm2[a] += o.getKm2(a);
        for (Resource r : Resource.values()) {
            totalSites[r.ordinal()] += o.getSites(r);
            totalAmounts[r.ordinal()] += o.getAmount(r);
        }
    }

    /**
     * Buys an offer: its lane's frontier moves out to the offer's outer
     * radius, and the purchase is kept, after every one before it.
     */
    public void extend(LandParcel offer, int month, double paidLocal) {
        frontier[offer.getSide() * LANES + offer.getLane()] = offer.getR2();
        purchases.add(new Purchase(offer, month, paidLocal));
        add(offer);
    }

    /* =====================================================================
       WHAT IT IS
       ===================================================================== */

    /** The seed of the world it lies on. */
    public long seed()                  { return seed; }

    /** The founding site, as a plot: east from the world's west edge... */
    public long siteX()                 { return siteX; }

    /** ...and south from its north edge. */
    public long siteY()                 { return siteY; }

    /** The centre's half-side, in plots from the site's centre. */
    public double centreHalf()          { return centreHalf; }

    /** One of the centre's areas, in square kilometres (TOTAL, DRY, FRESH, SEA or FOREST). */
    public double centreKm2(int area)   { return centreKm2[area]; }

    /** The centre's sites of a resource. */
    public int centreSites(Resource r)  { return centreSites[r.ordinal()]; }

    /** The centre's amount of a resource, in its unit. */
    public double centreAmount(Resource r) { return centreAmounts[r.ordinal()]; }

    /** A converted centre's legacy iron field: its plot east, -1 when there is none... */
    public long legacyX()               { return legacyX; }

    /** ...south... */
    public long legacyY()               { return legacyY; }

    /** ...and its sites. */
    public int legacySites()            { return legacySites; }

    /** A lane's frontier: how far out the city owns it, in plots from the site. */
    public double frontier(int side, int lane) { return frontier[side * LANES + lane]; }

    /** The purchases, in the order they were made. */
    public List<Purchase> purchases()   { return Collections.unmodifiableList(purchases); }

    /** One of the whole city's areas, centre and purchases, in square kilometres. */
    public double totalKm2(int area)    { return totalKm2[area]; }

    /** The whole city's sites of a resource. */
    public long totalSites(Resource r)  { return totalSites[r.ordinal()]; }

    /** The whole city's amount of a resource, as listed: O, what conservation counts the city's (spec-land 2.1). */
    public double totalAmount(Resource r) { return totalAmounts[r.ordinal()]; }

    /** What the purchases alone hold of a resource's sites. */
    public long purchasedSites(Resource r) { return totalSites[r.ordinal()] - centreSites[r.ordinal()]; }

    /** ...and of its amount. */
    public double purchasedAmount(Resource r) {
        double sum = 0;
        for (Purchase p : purchases) sum += p.offer().getAmount(r);
        return sum;
    }

    /** What each holding listed of a resource, in acquisition order: the centre first, then each purchase - the order it is worked out in. */
    public double[] amountsInOrder(Resource r) {
        double[] out = new double[1 + purchases.size()];
        out[0] = centreAmounts[r.ordinal()];
        for (int i = 0; i < purchases.size(); i++) out[i + 1] = purchases.get(i).offer().getAmount(r);
        return out;
    }

    /** A side's name: North, East, South or West. */
    public static String sideName(int side) { return SIDE_NAMES[side]; }

    /* =====================================================================
       THE GEOMETRY (spec-land star 1)
       ===================================================================== */

    /** A point's radius from the site: the larger of |dx| and |dy|, in plots. */
    public static double radius(double dx, double dy) { return Math.max(Math.abs(dx), Math.abs(dy)); }

    /** A point's side and lane, as side x LANES + lane: the side by the larger of |dx| and |dy| (dy south), the lane floor((t + 1) x LANES / 2) across it, lane 0 on the left facing out. */
    public static int sideLane(double dx, double dy) {
        double ax = Math.abs(dx), ay = Math.abs(dy), t;
        int side;
        if (ay >= ax) {
            if (dy < 0) { side = 0; t = dx / ay; }
            else        { side = 2; t = ay > 0 ? -dx / ay : 0; }
        } else {
            if (dx > 0) { side = 1; t = dy / ax; }
            else        { side = 3; t = -dy / ax; }
        }
        int lane = (int) Math.floor((t + 1) * LANES / 2);
        return side * LANES + Math.max(0, Math.min(LANES - 1, lane));
    }

    /** The point at radius r and lane coordinate t (-1 to 1, left to right facing out) on a side, as {dx, dy} from the site. */
    static double[] point(int side, double r, double t) {
        switch (side) {
            case 0:  return new double[] { t * r, -r };
            case 1:  return new double[] { r, t * r };
            case 2:  return new double[] { -t * r, r };
            default: return new double[] { -r, -t * r };
        }
    }

    /** What a band of a lane from r1 to r2 holds, in square kilometres: LANE_SHARE x (r2^2 - r1^2) plots. */
    public static double bandKm2(double r1, double r2) {
        return LANE_SHARE * (r2 * r2 - r1 * r1) * World.KM2_PER_PLOT;
    }

    /** The outer radius of a band of km2 square kilometres starting at r1: sqrt(r1^2 + km2 / (LANE_SHARE x a plot)). */
    public static double outerRadius(double r1, double km2) {
        return Math.sqrt(r1 * r1 + km2 / (LANE_SHARE * World.KM2_PER_PLOT));
    }

    /** Whether the city owns the point (dx, dy) from the site: within the centre, or within its lane's frontier. */
    public boolean owns(double dx, double dy) {
        double r = radius(dx, dy);
        return r <= centreHalf || r <= frontier[sideLane(dx, dy)];
    }

    /** Whether the city owns a plot, at its centre. */
    public boolean ownsPlot(long x, long y) { return owns(x - siteX, y - siteY); }

    /* =====================================================================
       THE CENTRE: A PROFILE RING BY RING ROUND THE SITE

       Dry ground is counted ring by ring (L-infinity) out from the site at a
       stride, and the square stops in the ring where the running sum reaches
       the target, the ring's area shared out in proportion: so the centre
       holds the dry ground asked for exactly, and its other areas are the
       same share of their rings. At a stride of one plot the profile reads
       every plot a tile at a time (World.tileTerrain()); past PROFILE_SPAN it
       reads plot centres at the stride (terrainAt()). A profile is kept per
       site and stride and grown outward as it is asked for more, and every
       ring it counts is the same however far it has been grown, so the
       centre is the same whoever asks first.
       ===================================================================== */

    /** A centre's half-side and its five areas. */
    record Centre(double half, double[] km2) { }

    /** The centre round (x, y) that holds dryKm2 of dry ground. */
    static Centre sizeCentre(World world, long x, long y, double dryKm2) {
        double[] km2 = new double[AREAS];
        if (!(dryKm2 > 0)) return new Centre(0, km2);
        int stride = strideFor(dryKm2);
        Profile p = profile(world, x, y, stride);
        double cell = (double) stride * stride * World.KM2_PER_PLOT;
        int rings = (int) Math.ceil(2 * idealHalf(dryKm2) / stride) + 2;
        while (true) {
            synchronized (p) {
                p.reach(rings);
                double dry = 0, fresh = 0, sea = 0, forest = 0;
                for (int k = 0; k < p.rings; k++) {
                    double d = p.dry[k] * cell;
                    if (d > 0 && dry + d >= dryKm2) {
                        double f = (dryKm2 - dry) / d;
                        double lo = k == 0 ? 0 : (k - 0.5) * stride, hi = (k + 0.5) * stride;
                        double half = Math.sqrt(lo * lo + f * (hi * hi - lo * lo));
                        km2[TOTAL] = 4 * half * half * World.KM2_PER_PLOT;
                        km2[DRY] = dryKm2;
                        km2[FRESH] = fresh + f * p.fresh[k] * cell;
                        km2[SEA] = sea + f * p.sea[k] * cell;
                        km2[FOREST] = forest + f * p.forest[k] * cell;
                        return new Centre(half, km2);
                    }
                    dry += d;
                    fresh += p.fresh[k] * cell;
                    sea += p.sea[k] * cell;
                    forest += p.forest[k] * cell;
                }
                if ((double) p.rings * stride > World.SIDE) {
                    throw new IllegalStateException("the world holds less dry ground than " + dryKm2 + " km2");
                }
                rings = p.rings * 2;
            }
        }
    }

    /**
     * What lies within L-infinity radius `radius` of (x, y), on the profile
     * a centre of dryKm2 is sized from: its five areas, the ring the radius
     * falls in shared out by area. What LandConversion's tests read.
     */
    static double[] within(World world, long x, long y, double dryKm2, double radius) {
        int stride = strideFor(dryKm2);
        Profile p = profile(world, x, y, stride);
        double cell = (double) stride * stride * World.KM2_PER_PLOT;
        int last = (int) Math.floor(radius / stride + 0.5);
        double[] out = new double[AREAS];
        synchronized (p) {
            p.reach(last + 1);
            for (int k = 0; k <= last; k++) {
                double lo = k == 0 ? 0 : (k - 0.5) * stride, hi = (k + 0.5) * stride;
                double f = radius >= hi ? 1 : Math.max(0, (radius * radius - lo * lo) / (hi * hi - lo * lo));
                out[DRY] += f * p.dry[k] * cell;
                out[FRESH] += f * p.fresh[k] * cell;
                out[SEA] += f * p.sea[k] * cell;
                out[FOREST] += f * p.forest[k] * cell;
            }
        }
        out[TOTAL] = 4 * radius * radius * World.KM2_PER_PLOT;
        return out;
    }

    /** The half-side a square of dryKm2 would have if all of it were dry, in plots. */
    static double idealHalf(double dryKm2) { return Math.sqrt(dryKm2 / World.KM2_PER_PLOT) / 2; }

    /** The profile's stride for a centre of dryKm2: one plot until twice the ideal radius passes PROFILE_SPAN / 2 plots, and then as many as keep PROFILE_SPAN samples across that radius. */
    static int strideFor(double dryKm2) {
        return (int) Math.max(1, Math.ceil(4 * idealHalf(dryKm2) / PROFILE_SPAN));
    }

    /** The ground round one site at one stride: samples of each kind ring by ring. */
    private static final class Profile {
        final World world;
        final long x, y;
        final int stride;
        long[] dry = new long[0], fresh = new long[0], sea = new long[0], forest = new long[0];
        int rings;

        Profile(World world, long x, long y, int stride) {
            this.world = world;
            this.x = x;
            this.y = y;
            this.stride = stride;
        }

        /** Counts out to at least `want` rings, doubling. */
        void reach(int want) {
            if (want <= rings) return;
            int to = Math.max(want, rings * 2);
            dry = Arrays.copyOf(dry, to);
            fresh = Arrays.copyOf(fresh, to);
            sea = Arrays.copyOf(sea, to);
            forest = Arrays.copyOf(forest, to);
            if (stride == 1) countTiles(rings, to); else countPoints(rings, to);
            rings = to;
        }

        private void tally(byte c, int ring) {
            if (c == World.SALT) sea[ring]++;
            else if (c == World.FRESH) fresh[ring]++;
            else {
                dry[ring]++;
                if (c == World.FOREST) forest[ring]++;
            }
        }

        /** Every plot with a ring from `from` to `to` - 1, a tile at a time. */
        private void countTiles(int from, int to) {
            long reach = to - 1;
            long tx0 = Math.floorDiv(x - reach, World.TILE), tx1 = Math.floorDiv(x + reach, World.TILE);
            long ty0 = Math.floorDiv(y - reach, World.TILE), ty1 = Math.floorDiv(y + reach, World.TILE);
            byte[] t = new byte[World.TILE * World.TILE];
            for (long ty = ty0; ty <= ty1; ty++) {
                for (long tx = tx0; tx <= tx1; tx++) {
                    long px0 = tx * World.TILE, py0 = ty * World.TILE;
                    long far = Math.max(Math.max(Math.abs(px0 - x), Math.abs(px0 + World.TILE - 1 - x)),
                            Math.max(Math.abs(py0 - y), Math.abs(py0 + World.TILE - 1 - y)));
                    if (far < from) continue;
                    world.tileTerrain(tx, ty, t);
                    for (int i = 0; i < t.length; i++) {
                        long ring = Math.max(Math.abs(px0 + i % World.TILE - x), Math.abs(py0 + i / World.TILE - y));
                        if (ring >= from && ring < to) tally(t[i], (int) ring);
                    }
                }
            }
        }

        /** Every sample at the stride with a ring from `from` to `to` - 1, a plot's centre at a time. */
        private void countPoints(int from, int to) {
            int reach = to - 1;
            for (int j = -reach; j <= reach; j++) {
                int aj = Math.abs(j);
                for (int i = -reach; i <= reach; i++) {
                    if (aj < from && Math.abs(i) < from) {
                        i = from - 1;       // skip the counted middle of the row
                        continue;
                    }
                    tally(world.terrainAt(x + (long) i * stride, y + (long) j * stride), Math.max(aj, Math.abs(i)));
                }
            }
        }
    }

    private record ProfileKey(long seed, long x, long y, int stride) { }

    /** How many profiles are kept: 8, the city's and a few a conversion tried. */
    static final int PROFILES_KEPT = 8;

    private static final Map<ProfileKey, Profile> PROFILES = new LinkedHashMap<>(16, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<ProfileKey, Profile> eldest) {
            return size() > PROFILES_KEPT;
        }
    };

    private static Profile profile(World world, long x, long y, int stride) {
        synchronized (PROFILES) {
            return PROFILES.computeIfAbsent(new ProfileKey(world.seed(), x, y, stride),
                    k -> new Profile(world, x, y, stride));
        }
    }

    /** Adds every site of every field of every resource whose centre lies within L-infinity radius `half` of (x, y), with its share of its field's amount (0.7.58; until then every field whose own centre did, whole). */
    static void fieldsWithin(World world, long x, long y, double half, int[] sites, double[] amounts) {
        for (Resource r : Resource.values()) {
            if (!r.inFields()) continue;
            double reach = Deposit.mostReach(r);
            for (int cell : cellsUnder(x - half - reach, y - half - reach, x + half + reach, y + half + reach)) {
                for (Deposit d : fields(world, cell, r)) centreShare(d, x, y, half, sites, amounts);
            }
        }
    }

    /* =====================================================================
       THE FIELDS IN A PIECE OF GROUND (0.7.58, batch J1c)

       A site belongs to the piece of ground holding its centre: the centre
       when its radius from the founding site is within the centre's
       half-side, else the band of its side's lane whose r1 < r <= r2 - the
       same tests owns() and a band's own samples make, so the centre and the
       forty lanes' bands share every site in the plane between them, once.
       A field wholly inside or wholly outside is counted without its sites
       being placed; one across an edge is counted a site at a time.
       ===================================================================== */

    /** Adds what of one field lies within L-infinity radius `half` of (x, y): its sites there and their share of its amount. */
    static void centreShare(Deposit d, long x, long y, double half, int[] sites, double[] amounts) {
        double cx = d.x() - x, cy = d.y() - y, r = radius(cx, cy), reach = d.reach();
        int k = d.kind().ordinal();
        if (r - reach > half) return;
        if (r + reach <= half) {
            sites[k] += d.sites();
            amounts[k] += d.amount();
            return;
        }
        for (int s = 0; s < d.sites(); s++) {
            double[] at = d.siteAt(s);
            if (radius(cx + at[0], cy + at[1]) <= half) {
                sites[k]++;
                amounts[k] += d.siteAmount(s);
            }
        }
    }

    /** Adds what of one field lies in the band of a lane from r1 to r2, seen from (x, y): its sites whose centres are on that side and lane with r1 < r <= r2, and their share of its amount. */
    static void bandShare(Deposit d, long x, long y, int side, int lane, double r1, double r2, int[] sites, double[] amounts) {
        double cx = d.x() - x, cy = d.y() - y, reach = d.reach();
        if (radius(cx, cy) + reach <= r1 || radius(cx, cy) - reach > r2) return;
        int want = side * LANES + lane, k = d.kind().ordinal();
        for (int s = 0; s < d.sites(); s++) {
            double[] at = d.siteAt(s);
            double dx = cx + at[0], dy = cy + at[1], r = radius(dx, dy);
            if (r > r1 && r <= r2 && sideLane(dx, dy) == want) {
                sites[k]++;
                amounts[k] += d.siteAmount(s);
            }
        }
    }

    /** The world cells under a box of plots, clipped to the world, row by row. */
    static int[] cellsUnder(double bx0, double by0, double bx1, double by1) {
        long cx0 = Math.max(0, (long) Math.floor(bx0 / World.CELL)), cx1 = Math.min(World.CELLS - 1, (long) Math.floor(bx1 / World.CELL));
        long cy0 = Math.max(0, (long) Math.floor(by0 / World.CELL)), cy1 = Math.min(World.CELLS - 1, (long) Math.floor(by1 / World.CELL));
        if (cx0 > cx1 || cy0 > cy1) return new int[0];
        int[] out = new int[(int) ((cx1 - cx0 + 1) * (cy1 - cy0 + 1))];
        int at = 0;
        for (long cy = cy0; cy <= cy1; cy++) for (long cx = cx0; cx <= cx1; cx++) out[at++] = (int) (cy * World.CELLS + cx);
        return out;
    }

    private record CellKey(long seed, int cell, Resource kind) { }

    /** How many cells' fields are kept: 256 - the nine round a site for every resource, and the cells a large centre or a long lane reaches. */
    static final int CELLS_KEPT = 256;

    private static final Map<CellKey, List<Deposit>> CELLS = new LinkedHashMap<>(64, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<CellKey, List<Deposit>> eldest) {
            return size() > CELLS_KEPT;
        }
    };

    /** A cell's fields of a resource (World.fieldsInCell()), kept: drawing them places every field again, and the bands of one city ask for the same few cells. */
    static List<Deposit> fields(World world, int cell, Resource r) {
        CellKey key = new CellKey(world.seed(), cell, r);
        List<Deposit> got;
        synchronized (CELLS) { got = CELLS.get(key); }
        if (got == null) {
            got = Collections.unmodifiableList(new ArrayList<>(world.fieldsInCell(cell, r)));
            synchronized (CELLS) { CELLS.put(key, got); }
        }
        return got;
    }

    /** Whether the world laid any field of a resource in the centre - what a converted centre's map draws its iron from. */
    boolean worldFieldsInCentre(World world, Resource r) {
        int[] s = new int[KINDS];
        fieldsWithin(world, siteX, siteY, centreHalf, s, new double[KINDS]);
        return s[r.ordinal()] > 0;
    }

    /* =====================================================================
       A BAND OF A LANE: WHAT AN OFFER HOLDS
       ===================================================================== */

    /** What a band holds: its five areas in square kilometres, and each resource's sites and amount. */
    public record Band(double[] km2, int[] sites, double[] amounts) { }

    private record BandKey(long seed, long x, long y, int side, int lane, long r1, long r2) { }

    /** How many bands' contents are kept: 4,096 - a band is the same ground whichever city on the same site asks, so the harnesses' cities share them. */
    static final int BANDS_KEPT = 4096;

    private static final Map<BandKey, Band> BANDS = new LinkedHashMap<>(256, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<BandKey, Band> eldest) {
            return size() > BANDS_KEPT;
        }
    };

    /** What the band of a lane from r1 to r2 holds, on this city's world from its site. */
    public Band band(int side, int lane, double r1, double r2) {
        BandKey key = new BandKey(seed, siteX, siteY, side, lane, Double.doubleToLongBits(r1), Double.doubleToLongBits(r2));
        Band b;
        synchronized (BANDS) { b = BANDS.get(key); }
        if (b == null) {
            b = evaluate(World.of(seed), siteX, siteY, side, lane, r1, r2);
            synchronized (BANDS) { BANDS.put(key, b); }
        }
        return new Band(b.km2().clone(), b.sites().clone(), b.amounts().clone());
    }

    /**
     * Measures a band: BAND_SAMPLES x BAND_SAMPLES points spread evenly over
     * its area (r^2 uniform between r1^2 and r2^2, t uniform across the
     * lane), each the class of the plot it falls in; and every site of every
     * field whose centre lies in the band - its side and lane, and
     * r1 < r <= r2 - with its share of its field (bandShare(); until 0.7.58
     * every field whose own centre did, whole).
     */
    static Band evaluate(World world, long x, long y, int side, int lane, double r1, double r2) {
        double km2 = bandKm2(r1, r2);
        int n = BAND_SAMPLES;
        int dry = 0, fresh = 0, sea = 0, forest = 0;
        for (int i = 0; i < n; i++) {
            double r = Math.sqrt(r1 * r1 + (i + 0.5) / n * (r2 * r2 - r1 * r1));
            for (int j = 0; j < n; j++) {
                double t = -1 + (lane + (j + 0.5) / n) * 2.0 / LANES;
                double[] p = point(side, r, t);
                byte c = world.terrainAt(x + (long) Math.floor(p[0] + 0.5), y + (long) Math.floor(p[1] + 0.5));
                if (c == World.SALT) sea++;
                else if (c == World.FRESH) fresh++;
                else {
                    dry++;
                    if (c == World.FOREST) forest++;
                }
            }
        }
        double all = n * n;
        double[] areas = { km2, km2 * dry / all, km2 * fresh / all, km2 * sea / all, km2 * forest / all };
        int[] sites = new int[KINDS];
        double[] amounts = new double[KINDS];
        // The band's bounding box, from its corners, and every field that can
        // reach into it: the cells under the box widened by the most a
        // resource's field reaches (Deposit.mostReach()).
        double t0 = -1 + lane * 2.0 / LANES, t1 = t0 + 2.0 / LANES;
        double[][] corners = { point(side, r1, t0), point(side, r1, t1), point(side, r2, t0), point(side, r2, t1) };
        double bx0 = Double.MAX_VALUE, by0 = Double.MAX_VALUE, bx1 = -Double.MAX_VALUE, by1 = -Double.MAX_VALUE;
        for (double[] c : corners) {
            bx0 = Math.min(bx0, c[0]); bx1 = Math.max(bx1, c[0]);
            by0 = Math.min(by0, c[1]); by1 = Math.max(by1, c[1]);
        }
        for (Resource res : Resource.values()) {
            if (!res.inFields()) continue;
            double reach = Deposit.mostReach(res);
            for (int cell : cellsUnder(x + bx0 - reach, y + by0 - reach, x + bx1 + reach, y + by1 + reach)) {
                for (Deposit d : fields(world, cell, res)) {
                    double dx = d.x() - x, dy = d.y() - y, out = d.reach();
                    if (dx + out < bx0 || dx - out > bx1 || dy + out < by0 || dy - out > by1) continue;
                    bandShare(d, x, y, side, lane, r1, r2, sites, amounts);
                }
            }
        }
        amounts[Resource.FOREST.ordinal()] = Math.rint(areas[FOREST] * World.FOREST_M3_PER_KM2);
        return new Band(areas, sites, amounts);
    }

    /* =====================================================================
       SAVE AND RESTORE (DataSave's landCentre, landLanes, landPurchases)
       ===================================================================== */

    /** The centre's record: its half-side, its five areas, its sites and amounts, the legacy field's plot and sites, and the site's plot - CENTRE_FIELDS doubles. */
    public double[] centreState() {
        double[] s = new double[CENTRE_FIELDS];
        int i = 0;
        s[i++] = centreHalf;
        for (int a = 0; a < AREAS; a++) s[i++] = centreKm2[a];
        for (int k = 0; k < KINDS; k++) s[i++] = centreSites[k];
        for (int k = 0; k < KINDS; k++) s[i++] = centreAmounts[k];
        s[i++] = legacyX;
        s[i++] = legacyY;
        s[i++] = legacySites;
        s[i++] = siteX;
        s[i] = siteY;
        return s;
    }

    /** How wide the centre's record is: 25. */
    public static final int CENTRE_FIELDS = 1 + AREAS + 2 * KINDS + 3 + 2;

    /** The lanes' frontiers, side by side, lane by lane: SIDES x LANES doubles. */
    public double[] lanesState() { return frontier.clone(); }

    /** The purchases, one record each in the order they were made (LandParcel.purchaseRow()). */
    public double[][] purchasesState() {
        double[][] rows = new double[purchases.size()][];
        for (int i = 0; i < rows.length; i++) {
            Purchase p = purchases.get(i);
            rows[i] = p.offer().purchaseRow(p.month(), p.paidLocal());
        }
        return rows;
    }

    /** A city's land as saved; null when the centre's record is missing or the wrong width. */
    public static CityLand restore(long seed, double[] centre, double[] lanes, double[][] bought) {
        if (centre == null || centre.length != CENTRE_FIELDS) return null;
        int i = 0;
        double half = centre[i++];
        double[] km2 = Arrays.copyOfRange(centre, i, i + AREAS);
        i += AREAS;
        CityLand land = new CityLand(seed, (long) centre[CENTRE_FIELDS - 2], (long) centre[CENTRE_FIELDS - 1]);
        land.centreHalf = half;
        System.arraycopy(km2, 0, land.centreKm2, 0, AREAS);
        for (int k = 0; k < KINDS; k++) land.centreSites[k] = (int) centre[i++];
        for (int k = 0; k < KINDS; k++) land.centreAmounts[k] = centre[i++];
        land.legacyX = (long) centre[i++];
        land.legacyY = (long) centre[i++];
        land.legacySites = (int) centre[i];
        if (lanes != null && lanes.length == SIDES * LANES) System.arraycopy(lanes, 0, land.frontier, 0, SIDES * LANES);
        else Arrays.fill(land.frontier, half);
        if (bought != null) {
            for (double[] row : bought) {
                LandParcel offer = LandParcel.fromPurchaseRow(row);
                if (offer == null) continue;
                land.purchases.add(new Purchase(offer, LandParcel.purchaseMonth(row), LandParcel.purchasePaid(row)));
            }
        }
        land.recount();
        return land;
    }

    /** Whether two cities' land is the same, field for field. */
    public boolean same(CityLand o) {
        return o != null && seed == o.seed && siteX == o.siteX && siteY == o.siteY
                && Arrays.equals(centreState(), o.centreState()) && Arrays.equals(frontier, o.frontier)
                && Arrays.deepEquals(purchasesState(), o.purchasesState());
    }
}
