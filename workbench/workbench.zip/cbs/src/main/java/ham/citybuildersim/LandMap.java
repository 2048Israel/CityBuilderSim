package ham.citybuildersim;

import java.util.ArrayList;
import java.util.List;

/**
 * The city's land as the map view sees it: the outlines it draws - the centre's square, the frontier lane by lane, an offer's band - what lies under a plot (its ground, whose it is, the fields there), the box the land office opens on, and the hover card's words; pure, so MapCheck holds the hit-testing.
 *
 * WHY THIS EXISTS (0.7.61, batch J4; the project's spec-land.md 2.6 and
 * 2.8). The land office's map is how a player now chooses ground: a click
 * on a side selects it, a click on an offer's band selects that offer, a
 * hover names what is under the pointer. Each of those is a question about
 * the land - which side and lane a point lies in, how far out, whose it is -
 * that CityLand already answers for the model (owns(), sideLane()); this
 * class asks it the view's way and keeps the answers out of the toolkit, so
 * a harness can check that the map and the model agree on every plot.
 *
 * COORDINATES: the world's plots. A plot x covers x to x + 1; the model
 * tests a plot's ownership at its index (CityLand.ownsPlot(): x less the
 * site's), so the outlines here are drawn about the site plot's centre,
 * site + 0.5, and a band of radius r ends half a plot past the last plot it
 * holds.
 */
public final class LandMap {

    private LandMap() { }

    /** Whose a plot is: nobody's, the centre's, a purchase's, or an offer's. */
    public static final int OUTSIDE = 0, CENTRE = 1, BOUGHT = 2, OFFER = 3;

    /** What lies under a plot: its ground (a World class), whose it is, its side and lane, the purchase (from 0, in the order bought) or the offer. */
    public record Pick(long x, long y, byte ground, int owner, int side, int lane, int purchase, LandParcel offer) { }

    /** The plot (x, y) on this land, against these offers. */
    public static Pick pick(CityLand land, LandMarket market, long x, long y) {
        byte ground = World.of(land.seed()).terrainAt(x, y);
        double dx = x - land.siteX(), dy = y - land.siteY();
        int sl = CityLand.sideLane(dx, dy), side = sl / CityLand.LANES, lane = sl % CityLand.LANES;
        double r = CityLand.radius(dx, dy);
        if (r <= land.centreHalf()) return new Pick(x, y, ground, CENTRE, side, lane, -1, null);
        if (r <= land.frontier(side, lane)) {
            List<CityLand.Purchase> bought = land.purchases();
            for (int k = 0; k < bought.size(); k++) {
                LandParcel o = bought.get(k).offer();
                if (o.getSide() == side && o.getLane() == lane && r > o.getR1() && r <= o.getR2()) {
                    return new Pick(x, y, ground, BOUGHT, side, lane, k, o);
                }
            }
            return new Pick(x, y, ground, BOUGHT, side, lane, -1, null);
        }
        LandParcel offer = market == null ? null : market.offerIn(side, lane);
        if (offer != null && r > offer.getR1() && r <= offer.getR2()) return new Pick(x, y, ground, OFFER, side, lane, -1, offer);
        return new Pick(x, y, ground, OUTSIDE, side, lane, -1, null);
    }

    /** The side and lane a plot lies in, seen from the site: side x LANES + lane (CityLand.sideLane()). */
    public static int sideLaneOf(CityLand land, long x, long y) {
        return CityLand.sideLane(x - land.siteX(), y - land.siteY());
    }

    /* ----------------------------- the outlines ----------------------------- */

    /** A band of a lane, from r1 to r2, as its four corners in plots: inner left, inner right, outer right, outer left (facing out), x then y. */
    public static double[] band(CityLand land, int side, int lane, double r1, double r2) {
        double t0 = -1 + lane * 2.0 / CityLand.LANES, t1 = t0 + 2.0 / CityLand.LANES;
        double ox = land.siteX() + 0.5, oy = land.siteY() + 0.5;
        double[] a = CityLand.point(side, r1, t0), b = CityLand.point(side, r1, t1);
        double[] c = CityLand.point(side, r2, t1), d = CityLand.point(side, r2, t0);
        return new double[] { ox + a[0], oy + a[1], ox + b[0], oy + b[1], ox + c[0], oy + c[1], ox + d[0], oy + d[1] };
    }

    /** An offer's band. */
    public static double[] band(CityLand land, LandParcel offer) {
        return band(land, offer.getSide(), offer.getLane(), offer.getR1(), offer.getR2());
    }

    /** The centre's square: {x0, y0, x1, y1} in plots. */
    public static double[] centre(CityLand land) {
        double ox = land.siteX() + 0.5, oy = land.siteY() + 0.5, h = land.centreHalf();
        return new double[] { ox - h, oy - h, ox + h, oy + h };
    }

    /** How far out a lane's ground runs: its frontier, or the centre's half-side when that is further. */
    public static double reachOf(CityLand land, int side, int lane) {
        return Math.max(land.centreHalf(), land.frontier(side, lane));
    }

    /**
     * The city's edge as one closed outline, {xs, ys}: each lane's outer
     * edge at its reach, side by side round from the north's left end, the
     * steps between lanes radial and the corners on the diagonals - 80 points.
     */
    public static double[][] frontier(CityLand land) {
        int n = CityLand.SIDES * CityLand.LANES * 2;
        double[] xs = new double[n], ys = new double[n];
        double ox = land.siteX() + 0.5, oy = land.siteY() + 0.5;
        int at = 0;
        for (int s = 0; s < CityLand.SIDES; s++) {
            for (int l = 0; l < CityLand.LANES; l++) {
                double r = reachOf(land, s, l), t0 = -1 + l * 2.0 / CityLand.LANES, t1 = t0 + 2.0 / CityLand.LANES;
                double[] a = CityLand.point(s, r, t0), b = CityLand.point(s, r, t1);
                xs[at] = ox + a[0]; ys[at++] = oy + a[1];
                xs[at] = ox + b[0]; ys[at++] = oy + b[1];
            }
        }
        return new double[][] { xs, ys };
    }

    /** The farthest the city's own ground reaches from the site (L-infinity), in plots. */
    public static double ownedReach(CityLand land) {
        double r = land.centreHalf();
        for (int s = 0; s < CityLand.SIDES; s++) for (int l = 0; l < CityLand.LANES; l++) r = Math.max(r, land.frontier(s, l));
        return r;
    }

    /** ...and the farthest any offer standing reaches. */
    public static double offersReach(CityLand land, LandMarket market) {
        double r = ownedReach(land);
        if (market != null) for (LandParcel p : market.getListing()) r = Math.max(r, p.getR2());
        return r;
    }

    /** The box the land office opens on: the city's own ground - its outline's extent each way - with MapFrame.OPENING_MARGIN of its half-size round it on each axis, {x0, y0, x1, y1}. */
    public static double[] openingBox(CityLand land) {
        double[][] e = frontier(land);
        double x0 = Double.MAX_VALUE, y0 = Double.MAX_VALUE, x1 = -Double.MAX_VALUE, y1 = -Double.MAX_VALUE;
        for (int i = 0; i < e[0].length; i++) {
            x0 = Math.min(x0, e[0][i]);
            x1 = Math.max(x1, e[0][i]);
            y0 = Math.min(y0, e[1][i]);
            y1 = Math.max(y1, e[1][i]);
        }
        double mx = MapFrame.OPENING_MARGIN * (x1 - x0) / 2 + 1, my = MapFrame.OPENING_MARGIN * (y1 - y0) / 2 + 1;
        return new double[] { x0 - mx, y0 - my, x1 + mx, y1 + my };
    }

    /* ----------------------------- the fields ----------------------------- */

    /** A field one of whose sites lies under a plot, and which site. */
    public record FieldAt(Deposit field, int site) { }

    /** The fields with a site on plot (x, y): the world's, and a converted centre's legacy iron field. */
    public static List<FieldAt> fieldsAt(CityLand land, long x, long y) {
        List<FieldAt> out = new ArrayList<>();
        World world = World.of(land.seed());
        for (Resource r : Resource.values()) {
            if (!r.inFields()) continue;
            double reach = Deposit.mostReach(r);
            List<Deposit> near = new ArrayList<>();
            for (int cell : CityLand.cellsUnder(x - reach, y - reach, x + reach, y + reach)) near.addAll(CityLand.fields(world, cell, r));
            if (r == Resource.IRON && land.legacySites() > 0 && land.legacyX() >= 0) {
                near.add(new Deposit(Resource.IRON, -1, 0, land.legacyX(), land.legacyY(),
                        Math.min(World.MAX_SITES, land.legacySites()), land.centreAmount(Resource.IRON)));
            }
            double w = Deposit.siteWidth(r);
            for (Deposit f : near) {
                double o = f.reach();
                if (Math.abs(f.x() - x) > o + 1 || Math.abs(f.y() - y) > o + 1) continue;
                for (int s = 0; s < f.sites(); s++) {
                    double[] at = f.siteAt(s);
                    double cx = f.x() + at[0], cy = f.y() + at[1];
                    // A site's square of plots, as the map draws it (CityMap.siteList()).
                    long sx0 = Math.round(cx - w / 2), sy0 = Math.round(cy - w / 2);
                    long sx1 = Math.max(sx0, Math.round(cx + w / 2) - 1), sy1 = Math.max(sy0, Math.round(cy + w / 2) - 1);
                    if (x >= sx0 && x <= sx1 && y >= sy0 && y <= sy1) {
                        out.add(new FieldAt(f, s));
                        break;
                    }
                }
            }
        }
        return out;
    }

    /** The fields of a resource whose centres lie in a box of plots - the deposits the far views mark - at most `most` of them. */
    public static List<Deposit> fieldsIn(CityLand land, Resource r, double x0, double y0, double x1, double y1, int most) {
        List<Deposit> out = new ArrayList<>();
        if (!r.inFields()) return out;
        World world = World.of(land.seed());
        for (int cell : CityLand.cellsUnder(x0, y0, x1, y1)) {
            for (Deposit f : CityLand.fields(world, cell, r)) {
                if (f.x() < x0 || f.x() > x1 || f.y() < y0 || f.y() > y1) continue;
                out.add(f);
                if (out.size() >= most) return out;
            }
        }
        if (r == Resource.IRON && land.legacySites() > 0 && land.legacyX() >= x0 && land.legacyX() <= x1
                && land.legacyY() >= y0 && land.legacyY() <= y1) {
            out.add(new Deposit(Resource.IRON, -1, 0, land.legacyX(), land.legacyY(),
                    Math.min(World.MAX_SITES, land.legacySites()), land.centreAmount(Resource.IRON)));
        }
        return out;
    }

    /* ----------------------------- the words ----------------------------- */

    /** A World class as the hover card names it. */
    public static String groundWords(byte ground) {
        switch (ground) {
            case World.FOREST: return "Forest";
            case World.FRESH:  return "Lake or river";
            case World.SALT:   return "Sea";
            case World.SAND:   return "Beach";
            default:           return "Grass";
        }
    }

    /** Tonnes to three figures in their unit: "449 Mt", "12.8 Mt", "150 kt", "200 t", "1.12 Pt". */
    public static String tonnes(double t) {
        double a = Math.abs(t);
        double[] at = { 1e15, 1e12, 1e9, 1e6, 1e3 };
        String[] unit = { " Pt", " Tt", " Gt", " Mt", " kt" };
        for (int i = 0; i < at.length; i++) if (a >= at[i]) return three(t / at[i]) + unit[i];
        return String.format("%,.0f t", t);
    }

    /** A figure to three significant figures, no trailing zeros: 449, 12.8, 1.12. */
    static String three(double v) {
        if (v == 0) return "0";
        return new java.math.BigDecimal(v).round(new java.math.MathContext(3)).stripTrailingZeros().toPlainString();
    }

    /** What a resource's amount is, in its unit: tonnes for the fields, cubic metres for forest. */
    public static String amountWords(Resource r, double amount) {
        return r == Resource.FOREST ? String.format("%,.0f m³", amount) : tonnes(amount);
    }

    /** Thousands of US dollars as the screens write them: "US$12.1M". */
    public static String usd(double thousands) {
        return Formats.INSTANCE.amount(thousands).replace("$", Currency.FOREIGN_SYMBOL);
    }

    /** An area in km2 to three figures: "0.842 km2" (LandManager.km2Words()'s shape). */
    public static String km2(double km2) {
        return LandManager.km2Words(LandManager.sqFt(km2));
    }

    /** Whose a plot is, in the hover card's words: "The city's centre", "The city's: North 3, bought in month 1,204", "On offer: North 3 · 0.842 km², 0.79 dry · US$12.1M", "Not the city's". */
    public static String ownerWords(CityLand land, Pick p) {
        switch (p.owner()) {
            case CENTRE:
                return "The city's centre, its land at the founding";
            case BOUGHT: {
                if (p.purchase() < 0) return "The city's: " + CityLand.sideName(p.side()) + " " + (p.lane() + 1);
                CityLand.Purchase bought = land.purchases().get(p.purchase());
                return String.format("The city's: %s, bought in month %,d", bought.offer().where(), bought.month());
            }
            case OFFER: {
                LandParcel o = p.offer();
                return "On offer: " + o.where() + " · " + km2(o.getKm2()) + ", "
                        + three(o.getDryKm2()) + " dry · " + usd(o.getPriceUsd());
            }
            default:
                return "Not the city's";
        }
    }

    /** A field under the pointer: "Iron ore: a field of 35 sites, 449 Mt · this site 12.8 Mt". */
    public static String fieldWords(FieldAt f) {
        Deposit d = f.field();
        return d.kind().label() + ": a field of " + d.sites() + (d.sites() == 1 ? " site, " : " sites, ")
                + amountWords(d.kind(), d.amount()) + " · this site " + amountWords(d.kind(), d.siteAmount(f.site()));
    }

    /** The hover card's lines for a plot: its ground, whose it is, and each field with a site on it. */
    public static List<String> hoverWords(CityLand land, LandMarket market, long x, long y) {
        Pick p = pick(land, market, x, y);
        List<String> lines = new ArrayList<>();
        lines.add(groundWords(p.ground()));
        lines.add(ownerWords(land, p));
        for (FieldAt f : fieldsAt(land, x, y)) lines.add(fieldWords(f));
        return lines;
    }

    /** One building of each class, as the hover card names a drawn workplace or a type it has no name for. */
    public static final String[] CLASS_ONE = { "Home", "Shop", "Offices", "Industry", "Farm", "Utility", "School",
            "Health", "Safety", "Mine" };

    /**
     * What a painted plot holds, in the hover card's words, or null for bare
     * ground: a drawn home - "Flats · 42 people", "House · 6 people" - a
     * drawn workplace by its class ("Shop", "Offices", "Industry"), a model
     * building by its name (nameOf, by type id; its class when null), or a
     * road's kind, "a bridge" over water.
     */
    public static String plotWords(TilePainter.Input in, TilePainter.Painted p, int plot,
                                   java.util.function.IntFunction<String> nameOf) {
        if (plot < 0 || plot >= TilePainter.PLOTS) return null;
        if (p.use[plot] == TilePainter.BUILDING) {
            int b = p.bld[plot] - 1;
            if (b < 0 || b >= p.buildings || p.btype[b] < 0 || p.btype[b] >= in.types.length) return null;
            BuildingVisual.Type t = in.types[p.btype[b]];
            if (t == null) return null;
            long seed = TilePainter.tileSeed(in.seed, in.tx, in.ty);
            if (BuildingVisual.visual(t)) {
                int k = Math.max(0, Math.min(BuildingVisual.VISUAL_KINDS - 1, t.id() - BuildingVisual.VISUAL_ID));
                if (k == 0) {
                    double people = BuildingVisual.peopleIn(in.peoplePerHome, p.bj[b], seed);
                    return (BuildingVisual.flats(in.peoplePerHome, p.bj[b], seed) ? "Flats" : "House")
                            + String.format(" · %,.0f people", people);
                }
                return CLASS_ONE[BuildingVisual.VISUAL_CLASSES[k]];
            }
            String name = nameOf == null ? null : nameOf.apply(t.id());
            return name != null ? name : CLASS_ONE[t.cls()];
        }
        if (p.use[plot] == TilePainter.ROAD) {
            String kind = p.highway[plot] ? "Highway" : p.road[plot] >= BuildingVisual.PAVED ? "Paved road" : "Gravel road";
            return p.bridge[plot] ? kind + ", a bridge" : kind;
        }
        return null;
    }
}
