package ham.citybuildersim;

/**
 * The share register: who owns the city's companies, what they paid for them,
 * and what the companies pay them back.
 *
 * ==================== WHY ====================
 *
 * Until this evening nobody owned anything. Six sectors and a bank earned,
 * banked, borrowed and defaulted, and every dollar a company ever cleared was
 * still on its balance sheet - at month 4,000 the sectors held US$1.7-2.4
 * trillion abroad and $150-190bn at home in cities of 20,000 people, because
 * no company paid a dividend, bought back a share, or had an owner to pay.
 * And the other way round: every expansion was cash or a loan, so a city with
 * no bank borrowed at nineteen percent to open its first shop, and the bank's
 * own capital was declared to arrive from "savers down the road" without any
 * saver paying for it.
 *
 * Jerus, 2026-09-10: "businesses first do offerings domestically and if not
 * enough is raised they go foreign... each household type gets the offer and
 * based on their situation and their cash available they accept or decline...
 * each household needs a number of shares owned per company."
 *
 * ==================== THE SEVEN ====================
 *
 * The six sectors and the bank - "specially the bank, they need equity to
 * avoid rough start". Each is one company with one class of share, listed
 * here by name; the households hold their shares per cell (Household.shares),
 * and the rest are held abroad. There was no exchange at first: a share was
 * bought at an offering, paid its dividend, and was held. Jerus: "when we
 * build the exchange, which we will but not just yet." It came after
 * (Exchange), and since 0.7.12 round 2 a share changes hands on its
 * company's order book.
 *
 * ==================== WHEN A COMPANY GOES TO THE MARKET ====================
 *
 * Every company lists on day one, and the bank's founding capital is the
 * first thing sold. After that, Jerus's rule:
 *
 *   "at the beginning, and equity before debt, specially in good times...
 *    it will check if it thinks it might expand in the next 2-5 years, and
 *    raise equity for it; they will try not to raise equity in bad times; if
 *    the situation is normal, they'll use debt, or if they have too much
 *    equity relative to assets."
 *
 * So each company reads its own last twelve months and is in one of four
 * states (see regime()):
 *
 *   NEW      fewer than twelve months on the books: every plan is part
 *            equity, at the founding share, because there is no record to
 *            borrow against and the founders are still putting money in
 *   GOOD     profitable in nine months of twelve and not declining: it raises
 *            AHEAD - the equity share of three years of what it has been
 *            building, so the next expansions are funded before they are
 *            wanted, and the till carries the war chest
 *   NORMAL   it borrows, unless it has slipped well under its equity target,
 *            in which case it raises back up to it
 *   BAD      losses: it does not go to the market at all
 *
 * ==================== HOW MUCH EQUITY ====================
 *
 * "They adjust based on their profitability: if the business is stable
 * they'll go for less equity compared to debt, if more risky, then more
 * equity... debt is the leverage aspect."
 *
 * The target share of the balance sheet that is equity rises with how much
 * the last twelve months' income swung: a steady earner runs at thirty
 * percent equity and seventy percent debt, a business whose income swings by
 * its own size runs at fifty, and nothing runs past seventy. See
 * targetEquityShareOf().
 *
 * ==================== WHAT THE OWNERS GET ====================
 *
 * A fixed share of net income - "net income, not cash, and only if it's
 * positive" - paid every month a company made money, from its till, and
 * from what it holds abroad if the till is short. Nothing is paid on a loss
 * and nothing is borrowed to pay a dividend. The households' part lands in
 * their savings; the rest leaves on the income account.
 *
 * AFTER THE PRINCIPAL since round 2 of 0.7.11 (Jerus: "Pay out after
 * principal"): the share is of the month's net income less the principal
 * the company repaid in it, and nothing when the principal is the larger
 * (dividendDue()) - and since 0.7.12 round 2 the principal NET of what
 * refinanced it: the principal repaid less the new borrowing that rolled
 * it, free cash flow to equity (Game.payDividends()).
 *
 * ==================== WHO BUYS ====================
 *
 * The households first, on HouseholdBalance.subscribe()'s rule. Then the
 * world, at the same price, if the yield beats what the world pays plus a
 * premium - a founding offering excepted, which is bought on prospects
 * because there is no record to price. What neither will take is not raised,
 * and the plan is trimmed to what debt will carry, as it always was.
 *
 * ==================== PRICE ====================
 *
 * The register's reckoning is fair value: book, or THE DIVIDEND THE COMPANY
 * ACTUALLY PAYS capitalised at what the world asks, whichever is more
 * (priceOf(), since 0.7.12 round 2 - it read PAYOUT of the income before,
 * which a company repaying principal did not pay). The price is the
 * exchange's: the last trade on its book (Exchange.price()), which an
 * offering sells at; the first offering of a company with no shares sells
 * them at a thousand dollars each.
 */
public class Equity {

    /** The companies, in register order: every sector in the registry's order, then the bank. */
    public static final String[] COMPANIES;
    public static final int BANK;
    static {
        String[] sectors = Sectors.KEYS;
        COMPANIES = new String[sectors.length + 1];
        System.arraycopy(sectors, 0, COMPANIES, 0, sectors.length);
        COMPANIES[sectors.length] = "Bank";
        BANK = sectors.length;
    }

    public static int indexOf(String company) {
        for (int i = 0; i < COMPANIES.length; i++) if (COMPANIES[i].equals(company)) return i;
        return -1;
    }

    /* ------------------------------- the dials ------------------------------- */

    /** The share of a positive month's net income paid to the owners - of what it leaves after the principal repaid, since round 2 of 0.7.11 (dividendDue()) - every company's but the bank's, which pays by its own capital rule since 0.7.8 (Bank.dividendDue()). */
    public static final double PAYOUT = .40;

    /** A founding share: a thousand dollars, in the game's thousands. */
    public static final double FOUNDING_PRICE = 1.0;

    /**
     * The same price in TODAY's money, after any currency reform.
     *
     * A MONEY CONSTANT THAT A REFORM NEVER RESEEDED - found 2026-09-12, and it
     * had been there since the exchange was built. FOUNDING_PRICE is the
     * yardstick every share is measured against: Exchange.splitWhatNeedsIt() takes
     * `mid / FOUNDING_PRICE` and splits above SPLIT_AT or consolidates below
     * one over it. Exchange.redenominate() dutifully scales mid, fair and
     * lastMid; the yardstick they are divided by stayed at 1.0. So a city that
     * lopped two zeroes woke up with every share reading a hundred times
     * cheaper against founding, and the consolidation rule fired on companies
     * that had not moved at all.
     *
     * DenominationCheck caught it the moment households had enough money to
     * push share prices near the threshold - the reformed city ended 88 months
     * later holding $23,834 of securities the unreformed one did not, and
     * eight other figures apart with it. It would have passed unnoticed
     * indefinitely otherwise, which is the whole argument for that harness.
     */
    private double foundingPrice = FOUNDING_PRICE;

    /** A founding share in today's money. See foundingPrice. */
    public double foundingPrice() { return foundingPrice; }

    /** Re-seeds the yardstick at a given unit - since 0.7.42 the unit over the expected price level it is struck at, every month (Game.restrikeMoneyConstants()). See Denomination. */
    public void seedConstants(double unit) {
        foundingPrice = FOUNDING_PRICE / (unit > 0 ? unit : 1);
    }

    /** Months on the books before a company has a record to be judged on. */
    public static final int RECORD_MONTHS = 12;

    /** Profitable months of the last twelve that make a good year. */
    public static final int GOOD_MONTHS = 9;

    /** ...and the most a bad year has. */
    public static final int BAD_MONTHS = 6;

    /** What a steady business keeps as equity: the rest is leverage. */
    public static final double BASE_EQUITY_SHARE = .30;

    /** How much the target rises per unit of income swing (std dev over |mean|). */
    public static final double RISK_SLOPE = .20;

    public static final double MAX_EQUITY_SHARE = .70;

    /** A new company's plans are this much equity, whatever its assets say. */
    public static final double NEW_EQUITY_SHARE = .50;

    /** In good times, the years of expansion a company raises for ahead. */
    public static final double HORIZON_YEARS = 3;

    /** Under target by this much before a normal year raises instead of borrows. */
    public static final double UNDER_TARGET = .10;

    /** What the world wants over its own rate to buy a share here, annual. */
    public static final double FOREIGN_PREMIUM = .03;

    /**
     * The earnings yield the market prices a company here on: what a dollar
     * of its yearly income has to earn its owners for them to hold the share
     * at book. priceOf() values the earnings at PAYOUT x income over the
     * world's rate plus FOREIGN_PREMIUM, so the same valuation read the other
     * way up is (worldRate + FOREIGN_PREMIUM) / PAYOUT - 12.5% a year at the
     * defaults. The bank prices the capital a loan ties up at this since
     * 0.7.7 (Bank.capitalCharge()): it lends to earn what its shares are
     * priced on, one method rather than a second number.
     */
    public static double requiredYield(double worldRate) {
        return (Math.max(0, worldRate) + FOREIGN_PREMIUM) / PAYOUT;
    }

    public enum Regime { NEW, GOOD, NORMAL, BAD }

    /* ------------------------------- a company ------------------------------- */

    /** One listing. Package-private fields; read through the register. */
    static final class Listing {
        final String name;
        double shares;          // in issue
        double foreignShares;   // of those, held abroad
        double dealerShares;    // ...and held by the bank's trading desk (never its own: those are cancelled)
        /**
         * ...AND HELD BY THE CITY'S FUND (0.7.14, TreasuryFund): everything
         * it holds, and of that the part it took in rescuing the bank - its
         * rescue book, which its rule never sells and its 10% limit does
         * not count. Zero on every company but the bank for the rescue
         * book. A save from before 0.7.14 reads nothing.
         */
        double cityShares;
        double cityRescue;
        double lastPrice = FOUNDING_PRICE;
        final double[] income = new double[RECORD_MONTHS];   // net income, a ring
        final double[] spent  = new double[RECORD_MONTHS];   // on buildings, a ring
        int months;             // recorded so far
        double lifetimeRaisedHome, lifetimeRaisedAbroad;
        double lifetimeDividendsHome, lifetimeDividendsAbroad;
        int offerings;
        /**
         * THE DIVIDENDS IT ACTUALLY PAID, a ring of the last twelve months
         * (0.7.12 round 2): the ordinary dividend every holder was paid, the
         * desk's part and the world's included - the special dividends kept
         * out while there were any (a buyback's money, not a yield; none since
         * 0.7.12 round 4). What every participant values the share on
         * (dividendPerShareAnnual(), priceOf()). Saved.
         */
        final double[] paid = new double[RECORD_MONTHS];
        int paidMonths;
        double paidThisMonth;

        // this month
        double offered, raisedHome, raisedAbroad, dividendHome, dividendDesk, dividendAbroad;
        /** The city's fund's part of this month's dividend (0.7.14), and over its life. */
        double dividendCity, lifetimeDividendsCity;
        double boughtBackThisMonth, lifetimeBoughtBack;
        Regime regime = Regime.NEW;
        double targetShare = NEW_EQUITY_SHARE;

        Listing(String name) { this.name = name; }

        /** Held by the city's households: what is neither abroad nor on the desk - nor, since 0.7.14, the city's fund's. */
        double domesticShares() { return shares - foreignShares - dealerShares - cityShares; }
        double raised()   { return raisedHome + raisedAbroad; }
        double dividend() { return dividendHome + dividendAbroad; }

        void clearMonth() {
            offered = 0; raisedHome = 0; raisedAbroad = 0;
            dividendHome = 0; dividendDesk = 0; dividendAbroad = 0; dividendCity = 0;
            boughtBackThisMonth = 0;
        }

        double trailingIncome() {
            double sum = 0;
            int n = Math.min(months, RECORD_MONTHS);
            for (int i = 0; i < n; i++) sum += income[i];
            return sum;
        }

        double trailingSpent() {
            double sum = 0;
            int n = Math.min(months, RECORD_MONTHS);
            for (int i = 0; i < n; i++) sum += spent[i];
            return sum;
        }

        /** The ordinary dividends paid over the last twelve months. */
        double trailingPaid() {
            double sum = 0;
            int n = Math.min(paidMonths, RECORD_MONTHS);
            for (int i = 0; i < n; i++) sum += paid[i];
            return sum;
        }
    }

    private final Listing[] listings = new Listing[COMPANIES.length];

    public Equity() {
        for (int i = 0; i < COMPANIES.length; i++) listings[i] = new Listing(COMPANIES[i]);
    }

    /* =====================================================================
       THE RECORD

       Fed once a month with each company's closed figures, so the regime is
       read off twelve real months and not off whatever the screen was showing.
       ===================================================================== */

    /**
     * @param company   register index
     * @param netIncome the month's, after tax
     * @param spentOnBuildings what it put into its own premises this month
     */
    public void recordMonth(int company, double netIncome, double spentOnBuildings) {
        Listing l = listings[company];
        /*
         * A COMPANY THAT HAS NOT STARTED HAS NO RECORD. The seventh sector is
         * registered from month one like the other six but owns nothing
         * until the city can use a plant, and every one of those months was
         * being filed as a month of zero income: by the time it had a plan
         * it had a BAD record - twelve months, none profitable - and the
         * register's answer to its first offering was to raise nothing. So
         * the first plant ever built was financed entirely by the bank, and
         * when it failed the bank went with it. A company with no shares,
         * nothing earned and nothing spent has not traded; its twelve months
         * start with its first month of doing something.
         */
        if (l.shares <= 0 && netIncome == 0 && spentOnBuildings <= 0) return;
        int slot = l.months % RECORD_MONTHS;
        l.income[slot] = netIncome;
        l.spent[slot] = Math.max(0, spentOnBuildings);
        l.months++;
        l.regime = regimeOf(l);
        l.targetShare = targetEquityShareOf(l);
    }

    /** Clears the month's flows. Call at the top of the month, before any offering. */
    public void startMonth() {
        for (Listing l : listings) l.clearMonth();
    }

    private static Regime regimeOf(Listing l) {
        if (l.months < RECORD_MONTHS) return Regime.NEW;
        int profitable = 0;
        double firstHalf = 0, secondHalf = 0;
        // The ring is in order of age modulo twelve; the last twelve entries
        // are all of it, so read the older six and the newer six by slot age.
        for (int age = 0; age < RECORD_MONTHS; age++) {
            int slot = ((l.months - 1 - age) % RECORD_MONTHS + RECORD_MONTHS) % RECORD_MONTHS;
            double v = l.income[slot];
            if (v > 0) profitable++;
            if (age < RECORD_MONTHS / 2) secondHalf += v; else firstHalf += v;
        }
        double total = firstHalf + secondHalf;
        if (profitable <= BAD_MONTHS || total <= 0) return Regime.BAD;
        if (profitable >= GOOD_MONTHS && secondHalf >= firstHalf) return Regime.GOOD;
        return Regime.NORMAL;
    }

    /**
     * The share of the balance sheet a company wants as equity.
     *
     * The swing in its income over its size: a business earning the same
     * every month has none and runs at the base; one whose income swings by
     * as much as it earns adds twenty points; a loss-maker is treated as
     * riskiest of all.
     */
    private static double targetEquityShareOf(Listing l) {
        if (l.months < RECORD_MONTHS) return NEW_EQUITY_SHARE;
        int n = RECORD_MONTHS;
        double mean = 0;
        for (double v : l.income) mean += v;
        mean /= n;
        if (mean <= 0) return MAX_EQUITY_SHARE;
        double var = 0;
        for (double v : l.income) var += (v - mean) * (v - mean);
        double swing = Math.sqrt(var / n) / mean;
        return Math.min(MAX_EQUITY_SHARE, Math.max(BASE_EQUITY_SHARE,
                BASE_EQUITY_SHARE + RISK_SLOPE * swing));
    }

    /* =====================================================================
       HOW MUCH TO RAISE

       Asked by the investor with a plan in hand, before it decides what to
       borrow. The answer is in money; the offering below turns it into shares.
       ===================================================================== */

    /**
     * What a company with this plan would raise from its owners first.
     *
     * @param company  register index
     * @param assets   its balance sheet, total assets
     * @param equity   ...and the owners' part of it
     * @param planCost what it wants to build this month
     * @return money to offer, zero when it would rather borrow
     */
    public double raiseFor(int company, double assets, double equity, double planCost) {
        Listing l = listings[company];
        if (planCost <= 0) return 0;
        double target = l.targetShare;
        switch (l.regime) {
            case NEW:
                // Equity before debt at the beginning: the founders' share of
                // every plan, whatever the balance sheet says yet.
                return planCost * NEW_EQUITY_SHARE;
            case GOOD: {
                // Raise ahead. What it expects to build over the horizon is
                // what it has been building, three years of it, and at least
                // this plan; the equity share of that, less what it already
                // has past the target, capped at the expansion itself.
                double expected = Math.max(planCost, l.trailingSpent() * HORIZON_YEARS);
                double need = target * (assets + expected) - equity;
                return Math.max(0, Math.min(expected, need));
            }
            case NORMAL: {
                // Debt, unless it has slipped well under target.
                double after = assets + planCost;
                if (after <= 0) return 0;
                double shareAfter = equity / after;
                if (shareAfter < target - UNDER_TARGET) {
                    return Math.max(0, Math.min(planCost, target * after - equity));
                }
                return 0;
            }
            case BAD:
            default:
                return 0;
        }
    }

    /* =====================================================================
       THE OFFERING
       ===================================================================== */

    /**
     * Sells shares: to the households first, to the world for what is left.
     *
     * @param company    register index
     * @param amount     money asked for
     * @param bookEquity the company's equity before the offering, for the price
     * @param households who is offered it first
     * @param worldRate  what the world pays, annual, for the foreign buyer's test
     * @return money raised, home and abroad together
     */
    public double offer(int company, double amount, double bookEquity,
                        HouseholdBalance households, double worldRate) {
        return offer(company, amount, bookEquity, households, worldRate, 0);
    }

    /**
     * @param marketPrice what the exchange quotes a share at, or zero when
     *                    there is no market: a listed company sells new shares
     *                    at the market, not at the register's reckoning
     */
    public double offer(int company, double amount, double bookEquity,
                        HouseholdBalance households, double worldRate, double marketPrice) {
        Listing l = listings[company];
        if (amount <= 0) return 0;

        /*
         * THE FOUNDERS FIRST. A company's first offering can find equity
         * already on its books and owned by nobody - Retail founds with $9.5M
         * of stores the endowment built. Sold at the founding price against
         * no shares, that book would be handed to the first buyer for free.
         * So the founding book is issued to the city's households before the
         * new money is priced: the founders own what they founded, and the
         * new shares buy exactly what they pay for.
         */
        if (l.shares <= 0 && bookEquity > 0 && households != null) {
            double founders = bookEquity / foundingPrice;
            households.grantFounders(company, founders);
            l.shares += founders;
        }

        double price = marketPrice > 0 && l.shares > 0 ? marketPrice : priceOf(l, bookEquity, worldRate);
        l.offered += amount;
        l.offerings++;

        double home = households == null ? 0 : households.subscribe(company, amount, price);
        double left = Math.max(0, amount - home);

        /*
         * THE WORLD'S TEST. Its money comes at the same price, and only if
         * the record says the dividend will beat the world's own rate by the
         * premium - the payout on the last twelve months, over the equity
         * after the offering. A founding offering has no record and is
         * bought on prospects; a company with twelve months of losses is not.
         */
        double abroad = 0;
        if (left > 1e-9) {
            boolean founding = l.months < RECORD_MONTHS;
            double equityAfter = Math.max(0, bookEquity) + home + left;
            double yield = equityAfter > 0 ? PAYOUT * Math.max(0, l.trailingIncome()) / equityAfter : 0;
            if (founding || yield >= Math.max(0, worldRate) + FOREIGN_PREMIUM) {
                abroad = left;
            }
        }

        l.shares += (home + abroad) / price;
        l.foreignShares += abroad / price;
        l.lastPrice = price;
        l.raisedHome += home;
        l.raisedAbroad += abroad;
        l.lifetimeRaisedHome += home;
        l.lifetimeRaisedAbroad += abroad;
        return home + abroad;
    }

    /**
     * What one share sells for: the company's value over its shares.
     *
     * BOOK, OR WHAT THE EARNINGS ARE WORTH, WHICHEVER IS MORE. Book alone
     * was tried and it did what book alone does to a leveraged company: Real
     * Estate, borrowing ninety cents on the dollar of its buildings, had a
     * book near zero and sold 1.37 million shares for $270k - the new money
     * bought the whole company for nothing and the founders were diluted to
     * a rounding error. A landlord with no equity still has the rents, so a
     * share is worth at least the dividend it pays capitalised at what the
     * world asks of it: the last year's dividends over the world's rate plus
     * the premium. A company with neither book nor dividends sells at the
     * last price it sold at; a company with no shares at all, at the founding
     * one.
     *
     * THE DIVIDEND IT ACTUALLY PAID since 0.7.12 round 2 (Listing.paid). It
     * was PAYOUT x the last year's income until then, and round 2 of 0.7.11
     * pays the dividend on the income less the principal repaid - so a
     * company repaying principal was valued on a dividend larger than the one
     * it paid, which that batch left as an open question and this one closes.
     */
    private double priceOf(Listing l, double bookEquity, double worldRate) {
        if (l.shares <= 0) return foundingPrice;
        double dividendValue = Math.max(0, l.trailingPaid())
                / (Math.max(0, worldRate) + FOREIGN_PREMIUM);
        double value = Math.max(bookEquity, dividendValue);
        /*
         * NEITHER BOOK NOR DIVIDENDS MEANS NOTHING A SHARE COULD BE PRICED ON,
         * NOT A VALUE ABOVE ZERO (0.7.17). A company's book is its assets less
         * what it owes, and a sector that has just listed on a book of nothing
         * reports a few picodollars either side of zero, not zero - the sign
         * of a cancellation. Read as "value > 0" that residue priced its
         * shares at a picodollar over fifty-nine thousand of them, the exchange
         * floored them at Exchange.MIN_FAIR and treated the company as
         * worthless, where a residue on the other side of zero sold at the
         * last price. DenominationCheck's twin cities parted on it: the same
         * Automotive listing, book 0 in one and 1.1e-13 in the other, the desk
         * holding its shares in one city and the world in the other, and a
         * decade later the bank 0.3% and the output 4% apart. So a value that
         * comes to no more than that floor a share - MIN_FAIR in today's money,
         * the same yardstick the exchange floors fair value at - is no value.
         */
        return value > noValue() * l.shares ? value / l.shares : l.lastPrice;
    }

    /** A share's worth at the market's floor, in today's money: Exchange.MIN_FAIR, seeded by the unit. What a residue of a cancellation comes to less than, a share at a time. See priceOf() and dividendPerShareAnnual(). */
    private double noValue() {
        return Exchange.MIN_FAIR * (foundingPrice / FOUNDING_PRICE);
    }

    /**
     * Lists a company that has equity and no owners: the founders' shares
     * are issued against its book, as the first offering would have done.
     *
     * "Every company lists on day one" - and a company that never went to
     * the market never did. Construction ran for four thousand months with
     * $20M in the till, no shares, no dividend and no buyback, because its
     * plans were always cash; Retail in the playtest city the same. Called
     * every month, it lists them the month they first have a book.
     *
     * @return true if it was listed now
     */
    public boolean listIfUnlisted(int company, double bookEquity, HouseholdBalance households) {
        Listing l = listings[company];
        if (l.shares > 0 || !(bookEquity > 0) || households == null) return false;
        double founders = bookEquity / foundingPrice;
        households.grantFounders(company, founders);
        l.shares += founders;
        l.lastPrice = foundingPrice;
        return true;
    }

    /** What one share is worth on the books today. */
    public double bookPerShare(int company, double bookEquity) {
        Listing l = listings[company];
        return l.shares > 0 ? Math.max(0, bookEquity) / l.shares : 0;
    }

    /* =====================================================================
       THE DIVIDEND
       ===================================================================== */

    /**
     * What a company owes its owners on a month's result.
     *
     * @param netIncome the closed month's, after tax
     * @return the dividend, before anybody asks whether the till can pay it
     */
    public double dividendDue(int company, double netIncome) {
        Listing l = listings[company];
        if (l.shares <= 0 || netIncome <= 0) return 0;
        return netIncome * PAYOUT;
    }

    /**
     * ...PAID AFTER THE PRINCIPAL IT OWED (0.7.11, round 2): PAYOUT of the
     * month's net income less the principal that fell due in it, and nothing
     * when the principal is the larger. Jerus: "Pay out after principal."
     *
     * WHY. Net income is an accounting figure, and the principal a loan
     * repays is not in it, because it is not a cost. A company that paid its
     * owners a share of net income could pay out more cash than it had left
     * after its lender was paid. Round 1 of this batch found that happening:
     * a landlord on an insured mortgage paid 40% of a profit smaller than
     * the principal its payments took, emptied its till, and borrowed the
     * difference from the shortfall desk every month
     * (Game.payDividends()). What is left for the owners after the lender
     * is free cash flow to equity, the basis corporate finance uses for
     * dividend capacity. Real loan agreements write the same thing into
     * their covenants: they restrict distributions when debt service is not
     * covered ("restricted payments").
     *
     * ...NET OF WHAT REFINANCED IT since 0.7.12 round 2: the caller passes
     * the principal repaid less the new borrowing that rolled it - free cash
     * flow to equity is net income less NET repayment. 0.7.11 passed the
     * gross principal, so the month a bullet matured paid nothing past it
     * even when the shortfall desk simply rolled the loan; that cut the
     * sectors' dividends by $33B a run (Jerus's brief, round 2).
     *
     * @param principalDue the principal repaid this month, net of what the
     *                     shortfall desk lent in it to roll it - the
     *                     mortgages' principal parts and the bullets and
     *                     bonds that matured, less the refinancing
     *                     (Game.payDividends())
     */
    public double dividendDue(int company, double netIncome, double principalDue) {
        return dividendDue(company, netIncome - Math.max(0, principalDue));
    }

    /**
     * The month's ordinary dividend, as paid - noted by Game.payDividends()
     * beside payDividend(), which the special dividends went through too
     * until round 4 removed them, so that only the ordinary one is a yield
     * (0.7.12 round 2).
     */
    public void noteDividendPaid(int company, double paid) {
        if (paid > 0) listings[company].paidThisMonth += paid;
    }

    /** Files every company's month of dividends into its ring, paid or not: once a month, after the dividends. */
    public void closeDividendMonth() {
        ordinaryPaidAtClose = 0;
        for (Listing l : listings) {
            ordinaryPaidAtClose += l.paidThisMonth;
            // A company that has never had an owner has no record to keep.
            if (l.shares <= 0 && l.paidMonths == 0 && !(l.paidThisMonth > 0)) continue;
            l.paid[l.paidMonths % RECORD_MONTHS] = l.paidThisMonth;
            l.paidMonths++;
            l.paidThisMonth = 0;
        }
    }

    /**
     * Shares that left the city with their holders this month are held
     * abroad from now on.
     *
     * The register's count of domestic shares and the households' own count
     * differ by exactly what emigrants took with them (see
     * HouseholdBalance.getSharesTakenAway()), and the two have to agree
     * before a dividend is split - so this runs every month for every
     * company, whether or not it pays.
     */
    public void followEmigrants(HouseholdBalance households) {
        if (households == null) return;
        for (int c = 0; c < listings.length; c++) {
            double gone = households.getSharesTakenAway(c);
            if (gone > 0) {
                Listing l = listings[c];
                l.foreignShares = Math.min(l.shares, l.foreignShares + gone);
            }
        }
    }

    /**
     * Pays a dividend: the households' part into their savings, the rest to
     * the shareholders abroad. Every share is paid exactly once, which needs
     * followEmigrants() to have run for the month first.
     *
     * @param paid the money actually paid, decided by the caller from the till
     * @return the part paid abroad
     */
    public double payDividend(int company, double paid, HouseholdBalance households) {
        Listing l = listings[company];
        if (paid <= 0 || l.shares <= 0) return 0;

        /*
         * ...OVER EVERY SHARE SOMEBODY IS PAID ON, which is the register's
         * count unless the households' own count has drifted past it (0.7.7).
         * A few hundredths of a share of drift - seed 0 of the 0.7.7 playtest
         * had the households holding 627,527.663 of a company the register
         * had issued 627,527.618 of - paid them more than the company paid
         * out, since `abroad` below cannot go under nothing: money from
         * nowhere, 0.005 to 0.31 a month from month 3,471, the whole of that
         * run's audit residual. Divided over what is actually held, the split
         * never pays out more than it was handed. Where the drift comes from
         * is open (the register and the cells are moved separately).
         */
        double held = households == null ? 0 : households.sharesHeld(company);
        double perShare = paid / Math.max(l.shares, held + l.dealerShares + l.foreignShares + l.cityShares);
        double home = households == null ? 0 : households.creditDividend(company, perShare);
        // The desk is paid on what it holds - and PAYS on what it is short,
        // like any short seller: the holders of the shares it sold and does
        // not have are paid in full, and the difference is the desk's.
        double desk = l.dealerShares * perShare;
        // ...and the city's fund on what it holds (0.7.14), never "abroad":
        // its part is the caller's to hand to the fund (Game.payDividends()).
        double city = l.cityShares * perShare;
        double abroad = Math.max(0, paid - home - desk - city);
        l.dividendHome += home;
        l.dividendDesk += desk;
        l.dividendCity += city;
        l.lifetimeDividendsCity += city;
        l.dividendAbroad += abroad;
        l.lifetimeDividendsHome += home;
        l.lifetimeDividendsAbroad += abroad;
        return abroad;
    }

    /** What the bank's trading desk was paid on its inventory this month. */
    public double getDividendDeskThisMonth(int company) { return listings[company].dividendDesk; }

    /** ...and the city's fund on what it holds (0.7.14), and over its life. */
    public double getDividendCityThisMonth(int company) { return listings[company].dividendCity; }
    public double getLifetimeDividendsCity(int company) { return listings[company].lifetimeDividendsCity; }
    public double getDividendDeskThisMonth() { double s = 0; for (Listing l : listings) s += l.dividendDesk; return s; }

    /* =====================================================================
       THE HOLDERS

       The exchange moves shares between the holders - the households' cells,
       the bank's desk, the world, a company buying its own back, and since
       0.7.14 the city's fund - and the register keeps the count so the
       identity "in issue = households + desk + abroad + the city" lives in
       one place. See Exchange. The bank's OWN shares never
       sit on the desk: bought, they are cancelled; sold, they are issued -
       which is what treasury stock is.
       ===================================================================== */

    /** Shares the desk holds; negative when it has sold what it did not have. */
    public double getDealerShares(int company) { return listings[company].dealerShares; }

    /** Shares in the owners' hands: in issue less what the desk is long. */
    public double getOutstanding(int company) {
        Listing l = listings[company];
        return l.shares - Math.max(0, l.dealerShares);
    }

    /** The desk's holding moves by this many shares: bought, positive; sold, negative (0.7.12 round 2). Never the bank's own. */
    void moveDesk(int company, double n) {
        if (company == BANK || n == 0) return;
        listings[company].dealerShares += n;
    }

    /** ...and the world's: bought, positive; sold, negative - never under nothing. */
    void moveForeign(int company, double n) {
        if (n == 0) return;
        Listing l = listings[company];
        l.foreignShares = Math.max(0, l.foreignShares + n);
    }

    /* ---- the city's fund (0.7.14) ---- */

    /** The fund's market book in this company moves by this many shares: bought, positive; sold, negative - never into its rescue book, never under nothing. */
    void moveCity(int company, double n) {
        if (n == 0) return;
        Listing l = listings[company];
        l.cityShares = Math.max(l.cityRescue, l.cityShares + n);
    }

    /**
     * The player's hand sells this many of the fund's shares: its market
     * book first, then its rescue book (TreasuryFund - "the hand may sell
     * anything the fund holds, including the rescue book").
     *
     * @return how many of them came out of the rescue book
     */
    double sellCityByHand(int company, double n) {
        if (!(n > 0)) return 0;
        Listing l = listings[company];
        double market = Math.max(0, l.cityShares - l.cityRescue);
        double fromRescue = Math.max(0, Math.min(l.cityRescue, n - market));
        l.cityShares = Math.max(0, l.cityShares - n);
        l.cityRescue = Math.max(0, l.cityRescue - fromRescue);
        l.cityShares = Math.max(l.cityShares, l.cityRescue);
        return fromRescue;
    }

    /**
     * EVERY COMMON SHARE PASSES TO THE CITY: a failed bank's resolution
     * (0.7.14; Jerus: "City takes the shares"). The households' and the
     * world's are the city's now, and so is whatever the fund held of it on
     * its market book - all of it the rescue book. The count in issue does
     * not move; the old holders get nothing (CDIC, "How bail-in works": "all
     * of the common shares ... are automatically transferred to CDIC, and
     * the pre-existing common shareholders no longer own their common
     * shares"). The households' cells are the caller's to empty
     * (HouseholdBalance.surrenderShares()), before this. A company with no
     * shares in issue is issued `ifNone` to the city - the founders' shares
     * a company with a book and no owners is listed with (listIfUnlisted()).
     *
     * @return {the world's shares, the fund's market book's} before
     */
    double[] takeAllForCity(int company, double ifNone) {
        Listing l = listings[company];
        double world = l.foreignShares, market = Math.max(0, l.cityShares - l.cityRescue);
        if (!(l.shares > 0) && ifNone > 0) l.shares = ifNone;
        l.foreignShares = 0;
        l.dealerShares = 0;
        l.cityShares = l.shares;
        l.cityRescue = l.shares;
        return new double[] { world, market };
    }

    /** New shares issued to the city's rescue book - warrants exercised at their expiry (0.7.14): in issue by this many, the city's by the same. */
    void issueToCityRescue(int company, double n) {
        if (!(n > 0)) return;
        Listing l = listings[company];
        l.shares += n;
        l.cityShares += n;
        l.cityRescue += n;
    }

    /** Everything the city's fund holds of this company, both books. */
    public double getCityShares(int company)       { return listings[company].cityShares; }
    /** ...of that, its rescue book. */
    public double getCityRescueShares(int company) { return listings[company].cityRescue; }
    /** ...and its market book: what its rule bought and may sell. */
    public double getCityMarketShares(int company) { return Math.max(0, listings[company].cityShares - listings[company].cityRescue); }
    /** The city's stake in the company, 0-1: both books over what is in issue. */
    public double cityShare(int company) {
        Listing l = listings[company];
        return l.shares > 0 ? l.cityShares / l.shares : 0;
    }

    /** The bank issues its own shares through its desk: in issue by this many. */
    void issueOwn(int company, double n) {
        if (n > 0) listings[company].shares += n;
    }

    /** ...and buys them back, cancelled: out of issue by this many. */
    void cancelOwn(int company, double n) {
        if (n > 0) listings[company].shares = Math.max(0, listings[company].shares - n);
    }

    /**
     * A company buys back and cancels shares it bought on the book - the
     * seller's holding already moved by the exchange - out of issue, and on
     * its record of buybacks.
     */
    void retire(int company, double n) {
        if (!(n > 0)) return;
        Listing l = listings[company];
        l.shares = Math.max(0, l.shares - n);
        l.boughtBackThisMonth += n;
        l.lifetimeBoughtBack += n;
    }

    /**
     * A split (k > 1) or a consolidation (k < 1): every count by k, the
     * last price by its inverse. The households' and the desk's counts are
     * the exchange's to move alongside (see Exchange.splitWhatNeedsIt).
     */
    void split(int company, double k) {
        if (!(k > 0) || k == 1) return;
        Listing l = listings[company];
        l.shares *= k;
        l.foreignShares *= k;
        l.dealerShares *= k;
        l.cityShares *= k;
        l.cityRescue *= k;
        l.lastPrice /= k;
        l.boughtBackThisMonth *= k;
        l.lifetimeBoughtBack *= k;
    }

    public double getBoughtBackThisMonth(int company) { return listings[company].boughtBackThisMonth; }
    public double getLifetimeBoughtBack(int company)  { return listings[company].lifetimeBoughtBack; }

    /**
     * What a share is worth on the register's own reckoning: book or
     * capitalised earnings, whichever is more, over the shares in issue. The
     * exchange quotes around this; an offering with no market sells at it.
     */
    public double fairValue(int company, double bookEquity, double worldRate) {
        return priceOf(listings[company], bookEquity, worldRate);
    }

    /** The dividend a share paid over the last twelve months - the ordinary dividend actually paid, since 0.7.12 round 2 (it was PAYOUT of the income before the principal, which nobody was paid). What the exchange's participants value a share on (Exchange.yieldAt()). */
    public double dividendPerShareAnnual(int company) {
        Listing l = listings[company];
        /*
         * ...AND NOTHING WHEN WHAT WAS PAID IS A RESIDUE (0.7.17). A year's
         * dividends that come to less than a share at the market's floor
         * (noValue()) a share are the arithmetic's dust - a payout struck on
         * an income a few picodollars from zero - not a dividend, and every
         * reader of this asks "does it pay?" by its sign: a cell short of
         * money asked the price at which that dust yields its borrowing rate,
         * 5e-17 a share, and sold a Real Estate holding for nothing in one of
         * DenominationCheck's twin cities and at nine dollars in the other.
         */
        double paid = Math.max(0, l.trailingPaid());
        return l.shares > 0 && paid > noValue() * l.shares ? paid / l.shares : 0;
    }

    /** Every company's ordinary dividends at the last close (closeDividendMonth()): the month's, for the playtest. */
    private double ordinaryPaidAtClose;
    public double getOrdinaryDividendsLastClose() { return ordinaryPaidAtClose; }

    /** The ordinary dividends paid over the last twelve months, the company's whole (0.7.12 round 2). */
    public double getDividendsPaidOverYear(int company) { return listings[company].trailingPaid(); }

    /* ------------------------------- reading ------------------------------- */

    public double getShares(int company)         { return listings[company].shares; }
    public double getForeignShares(int company)  { return listings[company].foreignShares; }
    public double getDomesticShares(int company) { return listings[company].domesticShares(); }
    public double getLastPrice(int company)      { return listings[company].lastPrice; }
    public Regime getRegime(int company)         { return listings[company].regime; }
    public double getTargetEquityShare(int company) { return listings[company].targetShare; }
    public int getMonthsRecorded(int company)    { return listings[company].months; }
    public int getOfferings(int company)         { return listings[company].offerings; }

    /** Share of the company held abroad, 0-1. */
    public double foreignShare(int company) {
        Listing l = listings[company];
        return l.shares > 0 ? l.foreignShares / l.shares : 0;
    }

    /** Share of the company on the bank's trading desk, 0-1: what the desk is long over what is in issue - nothing while it is short. The Bank tab and the owners' block read it (0.7.9). */
    public double deskShare(int company) {
        Listing l = listings[company];
        return l.shares > 0 ? Math.max(0, l.dealerShares) / l.shares : 0;
    }

    public double getOfferedThisMonth(int company)      { return listings[company].offered; }
    public double getRaisedHomeThisMonth(int company)   { return listings[company].raisedHome; }
    public double getRaisedAbroadThisMonth(int company) { return listings[company].raisedAbroad; }
    public double getDividendHomeThisMonth(int company)   { return listings[company].dividendHome; }
    public double getDividendAbroadThisMonth(int company) { return listings[company].dividendAbroad; }
    public double getRaisedThisMonth(int company)   { return listings[company].raised(); }
    public double getDividendThisMonth(int company) { return listings[company].dividend(); }

    public double getLifetimeRaisedHome(int company)      { return listings[company].lifetimeRaisedHome; }
    public double getLifetimeRaisedAbroad(int company)    { return listings[company].lifetimeRaisedAbroad; }
    public double getLifetimeDividendsHome(int company)   { return listings[company].lifetimeDividendsHome; }
    public double getLifetimeDividendsAbroad(int company) { return listings[company].lifetimeDividendsAbroad; }

    /* ---- the city, for MoneyAudit and the summary ---- */

    public double getRaisedHomeThisMonth()   { double s = 0; for (Listing l : listings) s += l.raisedHome; return s; }
    public double getRaisedAbroadThisMonth() { double s = 0; for (Listing l : listings) s += l.raisedAbroad; return s; }
    public double getDividendHomeThisMonth()   { double s = 0; for (Listing l : listings) s += l.dividendHome; return s; }
    public double getDividendAbroadThisMonth() { double s = 0; for (Listing l : listings) s += l.dividendAbroad; return s; }
    public double getLifetimeRaisedHome()      { double s = 0; for (Listing l : listings) s += l.lifetimeRaisedHome; return s; }
    public double getLifetimeRaisedAbroad()    { double s = 0; for (Listing l : listings) s += l.lifetimeRaisedAbroad; return s; }
    public double getLifetimeDividendsHome()   { double s = 0; for (Listing l : listings) s += l.lifetimeDividendsHome; return s; }
    public double getLifetimeDividendsAbroad() { double s = 0; for (Listing l : listings) s += l.lifetimeDividendsAbroad; return s; }
    public int getOfferings() { int s = 0; for (Listing l : listings) s += l.offerings; return s; }

    /* ------------------------------- saving -------------------------------
     *
     * Named company by company, like the household cells: a sector added to
     * the list cannot read another's register. SLOTS a company, in the order
     * below; the rings first, then the position, then the lifetime figures.
     */

    /** Slots a company before the desk (2026-09-10, night). */
    public static final int SLOTS_BEFORE_DESK = RECORD_MONTHS * 2 + 10;

    /** ...and before the dividends actually paid (0.7.12 round 2). */
    public static final int SLOTS_BEFORE_PAID = SLOTS_BEFORE_DESK + 2;

    /** ...and before the city's fund (0.7.14): the ring of dividends paid and its count, appended. */
    public static final int SLOTS_BEFORE_CITY = SLOTS_BEFORE_PAID + RECORD_MONTHS + 1;

    /** The city's shares, its rescue book and what it has been paid, appended (0.7.14). */
    public static final int SLOTS = SLOTS_BEFORE_CITY + 3;

    public String[] keys() { return COMPANIES.clone(); }

    public double[] toSaveArray() {
        double[] out = new double[listings.length * SLOTS];
        int i = 0;
        for (Listing l : listings) {
            for (double v : l.income) out[i++] = v;
            for (double v : l.spent) out[i++] = v;
            out[i++] = l.months;
            out[i++] = l.shares;
            out[i++] = l.foreignShares;
            out[i++] = l.lastPrice;
            out[i++] = l.offerings;
            out[i++] = l.lifetimeRaisedHome;
            out[i++] = l.lifetimeRaisedAbroad;
            out[i++] = l.lifetimeDividendsHome;
            out[i++] = l.lifetimeDividendsAbroad;
            out[i++] = l.targetShare;
            out[i++] = l.dealerShares;
            out[i++] = l.lifetimeBoughtBack;
            for (double v : l.paid) out[i++] = v;
            out[i++] = l.paidMonths;
            out[i++] = l.cityShares;
            out[i++] = l.cityRescue;
            out[i++] = l.lifetimeDividendsCity;
        }
        return out;
    }

    /** @return false if nothing was restored: a null, or an array not the keys' length */
    public boolean restore(String[] keys, double[] saved) {
        if (keys == null || saved == null || keys.length == 0) return false;
        int slots = saved.length / keys.length;
        if (saved.length != keys.length * slots
                || (slots != SLOTS && slots != SLOTS_BEFORE_CITY && slots != SLOTS_BEFORE_PAID
                    && slots != SLOTS_BEFORE_DESK)) return false;
        int i = 0;
        for (String key : keys) {
            int c = indexOf(key);
            if (c < 0) { i += slots; continue; }
            Listing l = listings[c];
            for (int k = 0; k < RECORD_MONTHS; k++) l.income[k] = saved[i++];
            for (int k = 0; k < RECORD_MONTHS; k++) l.spent[k] = saved[i++];
            l.months        = (int) Math.round(saved[i++]);
            l.shares        = saved[i++];
            l.foreignShares = saved[i++];
            l.lastPrice     = saved[i++];
            l.offerings     = (int) Math.round(saved[i++]);
            l.lifetimeRaisedHome      = saved[i++];
            l.lifetimeRaisedAbroad    = saved[i++];
            l.lifetimeDividendsHome   = saved[i++];
            l.lifetimeDividendsAbroad = saved[i++];
            l.targetShare   = saved[i++];
            l.dealerShares = 0;
            l.lifetimeBoughtBack = 0;
            if (slots >= SLOTS_BEFORE_PAID) {
                l.dealerShares      = saved[i++];
                l.lifetimeBoughtBack = saved[i++];
            }
            l.cityShares = 0;
            l.cityRescue = 0;
            l.lifetimeDividendsCity = 0;
            if (slots >= SLOTS_BEFORE_CITY) {
                for (int k = 0; k < RECORD_MONTHS; k++) l.paid[k] = saved[i++];
                l.paidMonths = (int) Math.round(saved[i++]);
                // ...and the city's (0.7.14): a save from before it holds none.
                if (slots >= SLOTS) {
                    l.cityShares = saved[i++];
                    l.cityRescue = saved[i++];
                    l.lifetimeDividendsCity = saved[i++];
                }
            } else {
                /*
                 * A SAVE FROM BEFORE THE RING has no record of what was paid,
                 * month by month. It opens on what the register used to value
                 * the share on - PAYOUT of each month's income - so a loaded
                 * city's prices start where its players left them, and a year
                 * of real dividends replaces it.
                 */
                for (int k = 0; k < RECORD_MONTHS; k++) l.paid[k] = PAYOUT * Math.max(0, l.income[k]);
                l.paidMonths = l.months;
            }
            l.paidThisMonth = 0;
            l.regime = regimeOf(l);
        }
        return true;
    }

    public void reset() {
        for (int i = 0; i < listings.length; i++) listings[i] = new Listing(COMPANIES[i]);
    }

    /**
     * Everything in money, in the new unit. Share counts do not move; the
     * price of one, the incomes on the record and the lifetime flows do.
     */
    public void redenominate(double scale) {
        foundingPrice *= scale;
        for (Listing l : listings) {
            for (int k = 0; k < RECORD_MONTHS; k++) { l.income[k] *= scale; l.spent[k] *= scale; l.paid[k] *= scale; }
            l.paidThisMonth *= scale;
            l.lastPrice *= scale;
            l.lifetimeRaisedHome *= scale;      l.lifetimeRaisedAbroad *= scale;
            l.lifetimeDividendsHome *= scale;   l.lifetimeDividendsAbroad *= scale;
            l.offered *= scale;  l.raisedHome *= scale;  l.raisedAbroad *= scale;
            l.dividendHome *= scale;  l.dividendDesk *= scale;  l.dividendAbroad *= scale;
            l.dividendCity *= scale;  l.lifetimeDividendsCity *= scale;
        }
    }
}
