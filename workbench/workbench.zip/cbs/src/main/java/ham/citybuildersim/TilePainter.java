package ham.citybuildersim;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Paints one tile of the city map: from the world's seed, the tile's ground, what the city owns of it, its buildings and road budget, which neighbours have roads and the resource sites under it, the roads it grows and where every building stands - the same picture from the same inputs, on any machine.
 *
 * WHY THIS EXISTS (0.7.60, batch J3; the project's spec-land.md 2.6, a port
 * of the design's MapProto). Jerus's mockup (city-map.html) grew a whole city
 * step by step - roads from their ends, plots beside them - and stamped every
 * object with the step it appeared. A city of ten billion people cannot be
 * grown that way or stored plot by plot, so the map stores only counts by
 * district (CityMap), and this paints a 32 x 32-plot tile from them when the
 * screen needs it, with the mockup's rules made local to the tile:
 *
 *   PORTS    1 to 3 on each edge shared with a neighbour that has roads,
 *            hashed from the shared edge, so the two tiles agree; at least
 *            3 plots from a corner and 5 apart. A road reaches a tile's edge
 *            only at a port.
 *   GROWTH   ends enter from the ports, or one is seeded inside; paved ends
 *            are picked twice as often as gravel; a step runs 3 to 7 plots
 *            (paved 4 to 8), stopping at a join, the edge ring, the sea, or
 *            within 2 plots of a parallel road; then it goes straight (40%),
 *            turns (20%), makes a T (28%) or a + (12%); when every end is
 *            dead a T branches off a road laid (or, on a tile that laid none,
 *            starts afresh on its own ground); it stops when the budget is
 *            spent - since J3b the frontage the tile's buildings need
 *            (CityMap.drawCounts()), as the mockup grew a road for so many
 *            buildings wanted. The 3 plots ahead of each live end are kept
 *            free.
 *   HIGHWAYS the mockup's two (its star 5): along the founding site's row and
 *            column, from the site to the sea, laid before anything grows and
 *            from no budget, over fresh water whatever its width, drawn dimmed
 *            where the city does not own them (the road to the next city);
 *            their exits, every 7 to 13 plots, are paved ends once owned.
 *   BRIDGES  paved roads cross up to 6 plots of fresh water, highways up to
 *            14, gravel never, nothing the sea (the mockup's star 1).
 *   SITES    a resource's sites are its fields on the ground: no building
 *            covers one (the mockup's star 6); a mine or well stands on its
 *            own site, with a straight gravel spur to the nearest road.
 *   PLACES   candidates are owned, dry, and not road, reserved or field,
 *            ordered by their row from the road, then forest after grass
 *            (the mockup's star 10), then the plot's own hash; each building
 *            (type t, number j) takes a hashed preferred place u^1.5 of the
 *            way through the first PLACE_ROWS rows (J3b: the mockup's plots
 *            within reach of a road, so homes line their streets), as a row
 *            and a point in its hash rather than an index, and probes forward
 *            to the first plot its footprint fits (spec-land star 11). They
 *            are placed kind by kind and number by number - homes, shops,
 *            offices, plants, then the one-for-one types (J3b; star 11 placed
 *            them in the order of their places, and in dense rows one more
 *            building set off long cascades): the plots taken are the same
 *            in any order, a building added moves only those placed after it,
 *            and those are the sparse kinds - so one more building moves a
 *            median of none of the others.
 *
 * Pure: no state between calls but the scratch it is handed, nothing read
 * from the game. At Jerus's density (about 240 buildings a tile drawn from
 * his people and jobs since J3b) it paints a tile in about 0.1 ms (MapCheck
 * 5).
 */
public final class TilePainter {

    private TilePainter() { }

    /** Plots on a tile's side: World.TILE, 32. */
    public static final int TILE = World.TILE;

    /** Plots on a tile: 1,024. */
    public static final int PLOTS = TILE * TILE;

    /* --------------------------------------------------------- what a plot is */

    /** Nothing on it yet. */
    public static final byte EMPTY = 0;
    /** A road. */
    public static final byte ROAD = 1;
    /** A building. */
    public static final byte BUILDING = 2;
    /** Kept free ahead of a live road end, so no road is blocked. */
    public static final byte RESERVED = 3;
    /** A resource's site with nothing on it: no building covers one. */
    public static final byte FIELD = 4;

    /* ------------------------------------------------------ a site's state */

    /** A site on ground the city does not own. */
    public static final int UNOWNED = 0;
    /** ...on the city's ground, its holding not yet worked. */
    public static final int UNWORKED = 1;
    /** ...in the holding being worked: drawn half grey. */
    public static final int WORKING = 2;
    /** ...in a holding worked out: drawn grey (the mockup's star 7). */
    public static final int WORKED_OUT = 3;

    /* =====================================================================
       THE RULES' CONSTANTS (the mockup's, in plots)
       ===================================================================== */

    /** A port stands at least this many plots from a tile's corner: 3. */
    public static final int PORT_CORNER = 3;

    /** ...and at least this many from the next port on the edge: 5. */
    public static final int PORT_APART = 5;

    /** The most ports an edge carries: 3. */
    public static final int PORTS_MOST = 3;

    /** A step of a gravel road runs at least this many plots: 3 (the mockup's)... */
    public static final int STEP_GRAVEL = 3;

    /** ...a paved road or highway at least 4... */
    public static final int STEP_PAVED = 4;

    /** ...and either up to this many more: 4. */
    public static final int STEP_SPAN = 4;

    /** At a step's end, the share that goes straight on: 40% (the mockup's). */
    public static final double GO_STRAIGHT = 0.40;

    /** ...that turns, up to 60%: 20%. */
    public static final double GO_TURN = 0.60;

    /** ...that makes a T, up to 88%: 28%; the rest, 12%, a +. */
    public static final double GO_T = 0.88;

    /** A gravel end's weight against a paved end's 1 when an end is picked: a half, so paved ends grow twice as often. */
    public static final double GRAVEL_PICK = 0.5;

    /** A new end is paved when its own draw falls under the tile's paved share (its budget's paved part): a gravel road's branches stay gravel (J3b; J3 paved 60% of a paved road's branches while its paved budget lasted, which made the roads hang on what was left). */
    static int kindFor(long h, double share) {
        return World.unit(h) < share ? BuildingVisual.PAVED : BuildingVisual.GRAVEL;
    }

    /** A port's road's kind: by the shared edge's own draw, so a road crossing it is mostly one kind both sides. */
    static int portKind(long seed, long ax, long ay, boolean vertical, int at, double share) {
        return kindFor(World.mix(seed ^ World.mix((ax << 32) ^ (ay & 0xffffffffL) ^ ((long) at << 8) ^ (vertical ? 0x7E57L : 0x0E57L))), share);
    }

    /** How far ahead of a live end is kept free: 3 plots. */
    public static final int RESERVE_AHEAD = 3;

    /** How many rows from a road a plot's row counts to: 6; past it, all one. */
    public static final int ROWS_COUNTED = 6;

    /** The longest crossing of fresh water, in plots, by road kind: gravel never, paved 6 (180 m), a highway 14 (the mockup's star 1). */
    static final int[] MAX_BRIDGE = { 0, 0, 6, 14 };

    /** The exponent a building's preferred place is drawn with, u^1.5 of the way through the rows near a road (spec-land star 11, over every candidate: 2 put 52% beside roads but moved 2.9 others per new building, 1 32% and 0.47; 1.5 gave 44% and 0.71). */
    public static final double PREFERENCE = 1.5;

    /** The rows from a road a building's preferred place is drawn among: 3, the mockup's "free dry cells within 3 of a road" (J3b) - over every candidate, a tile's buildings scattered across its whole field; a building finding no room there probes on past them. */
    public static final int PLACE_ROWS = 2;

    /** The longest gravel spur to a mine or well, in plots: 36 (the mockup's track). */
    public static final int SPUR_MOST = 36;

    /** Steps of growth a tile takes at the most: 400, past any budget a tile can hold. */
    static final int GROWTH_STEPS = 400;

    /** Tries at a T off a road laid when every end is dead: 24. */
    static final int RESPAWN_TRIES = 24;

    /** North, east, south, west. */
    static final int[] DX = { 0, 1, 0, -1 }, DY = { -1, 0, 1, 0 };

    /* =====================================================================
       THE INPUTS AND THE PICTURE
       ===================================================================== */

    /** What a tile is painted from: filled by CityMap, or by hand in a harness. */
    public static final class Input {
        /** The world's seed. */
        public long seed;
        /** The tile's column and row: plots / TILE. */
        public long tx, ty;
        /** Its ground, a World class a plot, in rows. */
        public final byte[] terrain = new byte[PLOTS];
        /** Whether the city owns each plot. */
        public final boolean[] owned = new boolean[PLOTS];
        /** Its buildings as drawn, by the index of `types` (the map's types, then the visual kinds); a site-bound type here has no site and is placed as any building. */
        public int[] counts = new int[0];
        /** The model's buildings it was drawn from, by type id: the deal's (CityMap.tileInput()), kept for a hover and a harness. */
        public int[] model = new int[0];
        /** The people its homes hold each, on average (BuildingVisual.peoplePerHome()): what tells a house from flats. */
        public double peoplePerHome = BuildingVisual.HOUSE_PEOPLE;
        /** Its road budget in plots, by kind: [0, gravel, paved, highway] - grown as one budget, its paved and highway parts the share of new ends paved (J3b). */
        public final int[] roadBudget = new int[4];
        /** Which neighbours, north, east, south, west, have roads. */
        public final boolean[] neighbourRoads = new boolean[4];
        /** The plots the two world highways cross, laid before anything grows and from no budget. */
        public final boolean[] highway = new boolean[PLOTS];
        /** The highways' exits on this tile: each one's plot (in the tile) and the way its road leaves, perpendicular to the highway. */
        public int exits;
        public int[] exitX = new int[8], exitY = new int[8], exitDX = new int[8], exitDY = new int[8];

        /** Adds an exit: a paved end off the highway at (x, y), leaving in direction (dx, dy). */
        public void addExit(int x, int y, int dx, int dy) {
            if (exits == exitX.length) {
                int n = exits * 2;
                exitX = Arrays.copyOf(exitX, n); exitY = Arrays.copyOf(exitY, n);
                exitDX = Arrays.copyOf(exitDX, n); exitDY = Arrays.copyOf(exitDY, n);
            }
            exitX[exits] = x; exitY[exits] = y; exitDX[exits] = dx; exitDY[exits] = dy;
            exits++;
        }
        /** The types, by the index counts use: the map's by id, then the visual kinds (BuildingVisual.paintTable()). */
        public BuildingVisual.Type[] types = new BuildingVisual.Type[0];

        /** How many sites lie on it. */
        public int sites;
        /** Each site's square, in plots of the tile (clipped to it): its first column and row, its last. */
        public int[] siteX0 = new int[16], siteY0 = new int[16], siteX1 = new int[16], siteY1 = new int[16];
        /** ...its resource's ordinal, its state (UNOWNED to WORKED_OUT), and the type id of the mine or well on it, or -1. */
        public int[] siteKind = new int[16], siteState = new int[16], siteMine = new int[16];

        /** Clears the sites and the counts' meaning; the arrays are reused. */
        public void clearSites() { sites = 0; }

        /** Adds a site: its square (clipped to the tile), resource, state and the mine on it (-1 for none). */
        public void addSite(int x0, int y0, int x1, int y1, int kind, int state, int mine) {
            if (sites == siteX0.length) {
                int n = sites * 2;
                siteX0 = Arrays.copyOf(siteX0, n); siteY0 = Arrays.copyOf(siteY0, n);
                siteX1 = Arrays.copyOf(siteX1, n); siteY1 = Arrays.copyOf(siteY1, n);
                siteKind = Arrays.copyOf(siteKind, n); siteState = Arrays.copyOf(siteState, n);
                siteMine = Arrays.copyOf(siteMine, n);
            }
            siteX0[sites] = Math.max(0, x0); siteY0[sites] = Math.max(0, y0);
            siteX1[sites] = Math.min(TILE - 1, x1); siteY1[sites] = Math.min(TILE - 1, y1);
            siteKind[sites] = kind; siteState[sites] = state; siteMine[sites] = mine;
            sites++;
        }

        /** Whether any of its plots is owned. */
        public boolean anyOwned() {
            for (boolean b : owned) if (b) return true;
            return false;
        }
    }

    /** A painted tile: what each plot is, and every building on it. Reused between calls. */
    public static final class Painted {
        /** Each plot's use: EMPTY, ROAD, BUILDING, RESERVED or FIELD. */
        public final byte[] use = new byte[PLOTS];
        /** A road plot's kind, GRAVEL to HIGHWAY. */
        public final byte[] road = new byte[PLOTS];
        /** A road plot that bridges fresh water. */
        public final boolean[] bridge = new boolean[PLOTS];
        /** A plot of one of the two world highways. */
        public final boolean[] highway = new boolean[PLOTS];
        /** The building on a plot, its index + 1; 0 for none. */
        public final short[] bld = new short[PLOTS];
        /** The site a plot lies in, its index + 1; 0 for none. */
        public final short[] site = new short[PLOTS];
        /** Each plot's row from a road: 0 a road, then 1 beside it, to ROWS_COUNTED. */
        public final byte[] row = new byte[PLOTS];
        /** The buildings: each one's box in plots, type id, and number among its type in the tile (-1 for a mine on its site). */
        public int[] bx = new int[256], by = new int[256], bw = new int[256], bh = new int[256], btype = new int[256], bj = new int[256];
        /** The site a mine or well stands on, or -1. */
        public int[] bsite = new int[256];
        /** How many buildings were drawn, and how many found no place. */
        public int buildings, dropped;
        /** Road plots laid from the budget, and spur plots laid to mines. */
        public int roadPlots, spurPlots;

        void reset() {
            Arrays.fill(use, EMPTY);
            Arrays.fill(road, (byte) 0);
            Arrays.fill(bridge, false);
            Arrays.fill(highway, false);
            Arrays.fill(bld, (short) 0);
            Arrays.fill(site, (short) 0);
            buildings = dropped = roadPlots = spurPlots = 0;
        }

        int add(int x0, int y0, int w, int h, int type, int j, int siteIndex) {
            if (buildings == bx.length) {
                int n = buildings * 2;
                bx = Arrays.copyOf(bx, n); by = Arrays.copyOf(by, n); bw = Arrays.copyOf(bw, n); bh = Arrays.copyOf(bh, n);
                btype = Arrays.copyOf(btype, n); bj = Arrays.copyOf(bj, n); bsite = Arrays.copyOf(bsite, n);
            }
            bx[buildings] = x0; by[buildings] = y0; bw[buildings] = w; bh[buildings] = h;
            btype[buildings] = type; bj[buildings] = j; bsite[buildings] = siteIndex;
            return buildings++;
        }
    }

    /** One thread's working arrays. */
    private static final class Scratch {
        final int[] queue = new int[PLOTS];
        final long[] keys = new long[PLOTS];
        final int[] order = new int[PLOTS];
        final int[] next = new int[PLOTS + 1];
        final int[] at = new int[PLOTS];
        long[] places = new long[2048];
        long[] prefs = new long[2048];
        final int[] ports = new int[PORTS_MOST];
    }

    private static final ThreadLocal<Scratch> SCRATCH = ThreadLocal.withInitial(Scratch::new);

    /** A road end growing. */
    private static final class End {
        int x, y, dx, dy, kind;
        boolean alive = true;
        End(int x, int y, int dx, int dy, int kind) { this.x = x; this.y = y; this.dx = dx; this.dy = dy; this.kind = kind; }
    }

    /* =====================================================================
       PORTS: WHERE ROADS CROSS A SHARED EDGE
       ===================================================================== */

    /**
     * The ports on one edge, written into out (sorted), and how many: 1 to
     * PORTS_MOST crossing points hashed from the edge itself - the edge on the
     * north of tile (ax, ay) when horizontal, on its west when vertical - so
     * the tiles either side read the same ones.
     */
    public static int ports(long seed, long ax, long ay, boolean vertical, int[] out) {
        long h = World.mix(seed ^ World.mix((ax << 32) ^ (ay & 0xffffffffL) ^ (vertical ? 0x5bd1e995L : 0x1b873593L)));
        int n = 1 + (int) ((h >>> 61) % PORTS_MOST), used = 0;
        for (int i = 0; i < n; i++) {
            int at = PORT_CORNER + (int) (((h >>> (i * 9)) & 0x1ff) % (TILE - 2 * PORT_CORNER));
            boolean clash = false;
            for (int j = 0; j < used; j++) if (Math.abs(out[j] - at) < PORT_APART) clash = true;
            if (!clash) out[used++] = at;
        }
        Arrays.sort(out, 0, used);
        return used;
    }

    /* =====================================================================
       THE PAINT
       ===================================================================== */

    /** Paints a tile from its inputs into p. */
    public static void paint(Input in, Painted p) {
        Scratch s = SCRATCH.get();
        p.reset();
        // The sites first: their plots are fields, which no building covers.
        for (int k = 0; k < in.sites; k++) {
            for (int y = in.siteY0[k]; y <= in.siteY1[k]; y++) {
                for (int x = in.siteX0[k]; x <= in.siteX1[k]; x++) {
                    int i = y * TILE + x;
                    if (p.site[i] == 0) {
                        p.site[i] = (short) (k + 1);
                        p.use[i] = FIELD;
                    }
                }
            }
        }
        // The two world highways next: from no budget, never on the sea.
        for (int i = 0; i < PLOTS; i++) {
            if (!in.highway[i] || in.terrain[i] == World.SALT) continue;
            p.use[i] = ROAD;
            p.road[i] = (byte) BuildingVisual.HIGHWAY;
            p.highway[i] = true;
            p.bridge[i] = in.terrain[i] == World.FRESH;
        }
        growRoads(in, p, s);
        standMines(in, p);
        placeBuildings(in, p, s);
    }

    /* ----------------------------------------------------------- the roads */

    private static void growRoads(Input in, Painted p, Scratch s) {
        byte[] terrain = in.terrain;
        boolean[] owned = in.owned;
        long seed = in.seed, tx = in.tx, ty = in.ty;
        // One budget, its paved share deciding each new end's kind by the end's own draw (J3b): nothing in the
        // growth hangs on how much is left, so a larger budget grows the same roads further and nothing else.
        int total = in.roadBudget[BuildingVisual.GRAVEL] + in.roadBudget[BuildingVisual.PAVED] + in.roadBudget[BuildingVisual.HIGHWAY];
        double share = total > 0 ? (in.roadBudget[BuildingVisual.PAVED] + in.roadBudget[BuildingVisual.HIGHWAY]) / (double) total : 0;
        List<End> ends = new ArrayList<>();
        long r = World.mix(seed ^ World.mix((tx << 32) ^ (ty & 0xffffffffL)));
        if (total > 0) {
            // N and S edges carry columns, W and E edges rows; a port's road is paved or gravel by the shared edge's draw.
            int[] pt = s.ports;
            int n;
            if (in.neighbourRoads[0]) { n = ports(seed, tx, ty, false, pt);     for (int i = 0; i < n; i++) ends.add(new End(pt[i], -1, 0, 1, portKind(seed, tx, ty, false, pt[i], share))); }
            if (in.neighbourRoads[2]) { n = ports(seed, tx, ty + 1, false, pt); for (int i = 0; i < n; i++) ends.add(new End(pt[i], TILE, 0, -1, portKind(seed, tx, ty + 1, false, pt[i], share))); }
            if (in.neighbourRoads[3]) { n = ports(seed, tx, ty, true, pt);      for (int i = 0; i < n; i++) ends.add(new End(-1, pt[i], 1, 0, portKind(seed, tx, ty, true, pt[i], share))); }
            if (in.neighbourRoads[1]) { n = ports(seed, tx + 1, ty, true, pt);  for (int i = 0; i < n; i++) ends.add(new End(TILE, pt[i], -1, 0, portKind(seed, tx + 1, ty, true, pt[i], share))); }
            // The highways' exits, once owned: paved ends leaving the highway.
            for (int k = 0; k < in.exits; k++) {
                int x = in.exitX[k], y = in.exitY[k];
                if (in.owned[y * TILE + x] && p.use[y * TILE + x] == ROAD) addEnd(p, owned, terrain, ends, x, y, in.exitDX[k], in.exitDY[k], BuildingVisual.PAVED);
            }
            if (ends.isEmpty()) {
                r = World.mix(r);
                int k = (int) (r >>> 62);
                r = World.mix(r);
                int a = TILE / 4 + (int) ((r >>> 40) % (TILE / 2));
                ends.add(new End(k % 2 == 0 ? a : TILE / 2, k % 2 == 0 ? TILE / 2 : a, DX[k], DY[k], kindFor(World.mix(r ^ 0x5EED), share)));
            }
        }
        int guard = 0;
        while (total > 0 && guard++ < GROWTH_STEPS) {
            double weights = 0;
            int live = 0;
            for (End e : ends) if (e.alive) { weights += e.kind >= BuildingVisual.PAVED ? 1 : GRAVEL_PICK; live++; }
            if (live == 0) {
                r = World.mix(r);
                if (!respawn(p, ends, terrain, owned, r, share)) break;
                continue;
            }
            r = World.mix(r);
            double pick = World.unit(r) * weights;
            End e = null;
            for (End c : ends) {
                if (!c.alive) continue;
                pick -= c.kind >= BuildingVisual.PAVED ? 1 : GRAVEL_PICK;
                if (pick <= 0) { e = c; break; }
            }
            if (e == null) for (End c : ends) if (c.alive) e = c;
            int kind = e.kind;
            r = World.mix(r);
            int length = (kind >= BuildingVisual.PAVED ? STEP_PAVED : STEP_GRAVEL) + (int) ((r >>> 40) % (STEP_SPAN + 1));
            int laid = 0;
            int stop = 0;                   // 0 ran its length, 1 joined or left by the edge, 2 blocked
            for (int step = 0; step < length && total > 0; step++) {
                int nx = e.x + e.dx, ny = e.y + e.dy;
                if (nx < 0 || ny < 0 || nx >= TILE || ny >= TILE) { stop = 1; break; }
                int ni = ny * TILE + nx;
                if (p.use[ni] == ROAD) { stop = 1; break; }
                if (!owned[ni] || terrain[ni] == World.SALT) { stop = 2; break; }
                boolean fromEdge = e.x < 0 || e.y < 0 || e.x >= TILE || e.y >= TILE
                        || (laid == 0 && (e.x == 0 || e.y == 0 || e.x == TILE - 1 || e.y == TILE - 1));
                if (terrain[ni] == World.FRESH) {
                    int span = bridge(p, terrain, owned, nx, ny, e.dx, e.dy, MAX_BRIDGE[kind], total);
                    if (span == 0) { stop = 2; break; }
                    for (int m = 0; m < span; m++) {
                        int bi = (ny + e.dy * m) * TILE + nx + e.dx * m;
                        p.use[bi] = ROAD; p.road[bi] = (byte) kind; p.bridge[bi] = terrain[bi] == World.FRESH;
                        total--; p.roadPlots++;
                    }
                    e.x = nx + e.dx * (span - 1);
                    e.y = ny + e.dy * (span - 1);
                    laid += span;
                    step += span - 1;
                    continue;
                }
                boolean onRing = e.dx != 0 ? (nx == 0 || nx == TILE - 1) : (ny == 0 || ny == TILE - 1);
                if (!fromEdge && onRing) { stop = 2; break; }
                if (!fromEdge && tooClose(p, nx, ny, e.dx, e.dy)) { stop = 2; break; }
                if (p.use[ni] != EMPTY && p.use[ni] != FIELD && p.use[ni] != RESERVED) { stop = 2; break; }
                p.use[ni] = ROAD; p.road[ni] = (byte) kind; total--; p.roadPlots++;
                e.x = nx; e.y = ny; laid++;
            }
            if (stop == 1) { e.alive = false; continue; }
            if (stop == 2 || laid == 0) {
                r = World.mix(r);
                if (World.unit(r) < 0.5) {
                    boolean leftTurn = World.unit(World.mix(r)) < 0.5;
                    int ndx = leftTurn ? e.dy : -e.dy, ndy = leftTurn ? -e.dx : e.dx;
                    if (canStart(p, owned, terrain, e.x, e.y, ndx, ndy)) { e.dx = ndx; e.dy = ndy; continue; }
                }
                e.alive = false;
                continue;
            }
            r = World.mix(r);
            double u = World.unit(r);
            int lx = e.dy, ly = -e.dx, rx = -e.dy, ry = e.dx;
            int childKind = kind == BuildingVisual.GRAVEL ? BuildingVisual.GRAVEL : kindFor(World.mix(r ^ 7), share);
            if (u < GO_STRAIGHT) continue;
            if (u < GO_TURN) {
                boolean leftTurn = World.unit(World.mix(r ^ 3)) < 0.5;
                e.dx = leftTurn ? lx : rx;
                e.dy = leftTurn ? ly : ry;
                if (!canStart(p, owned, terrain, e.x, e.y, e.dx, e.dy)) e.alive = false;
                continue;
            }
            if (u < GO_T) {
                if (World.unit(World.mix(r ^ 5)) < 0.5) {
                    boolean leftTurn = World.unit(World.mix(r ^ 9)) < 0.5;
                    addEnd(p, owned, terrain, ends, e.x, e.y, leftTurn ? lx : rx, leftTurn ? ly : ry, childKind);
                } else {
                    addEnd(p, owned, terrain, ends, e.x, e.y, lx, ly, childKind);
                    e.dx = rx;
                    e.dy = ry;
                    if (!canStart(p, owned, terrain, e.x, e.y, e.dx, e.dy)) e.alive = false;
                }
                continue;
            }
            addEnd(p, owned, terrain, ends, e.x, e.y, lx, ly, childKind);
            addEnd(p, owned, terrain, ends, e.x, e.y, rx, ry, childKind);
        }
        // Keep RESERVE_AHEAD plots free ahead of every live end: never block a road.
        for (End e : ends) {
            if (!e.alive) continue;
            for (int k = 1; k <= RESERVE_AHEAD; k++) {
                int x = e.x + e.dx * k, y = e.y + e.dy * k;
                if (x < 0 || y < 0 || x >= TILE || y >= TILE) break;
                int i = y * TILE + x;
                if (p.use[i] == EMPTY) p.use[i] = RESERVED;
            }
        }
    }

    /**
     * A crossing of fresh water from (x, y) on: the plots of water and the
     * dry plot past them it lands on - all inside the tile's edge ring, the
     * water no wider than `most` and the budget able to pay - or 0 when it
     * cannot cross. The mockup's bridge (its star 1).
     */
    private static int bridge(Painted p, byte[] terrain, boolean[] owned, int x, int y, int dx, int dy, int most, int budget) {
        if (most <= 0) return 0;
        int k = 0;
        while (true) {
            int bx = x + dx * k, by = y + dy * k;
            if (bx < 1 || by < 1 || bx >= TILE - 1 || by >= TILE - 1) return 0;
            int bi = by * TILE + bx;
            if (terrain[bi] != World.FRESH) break;
            if (!owned[bi] || p.use[bi] == ROAD) return 0;
            k++;
            if (k > most) return 0;
        }
        int lx = x + dx * k, ly = y + dy * k, li = ly * TILE + lx;
        if (terrain[li] == World.SALT || !owned[li] || p.use[li] == ROAD || p.use[li] == BUILDING) return 0;
        if (tooClose(p, lx, ly, dx, dy)) return 0;
        return k + 1 <= budget ? k + 1 : 0;
    }

    /** Whether a road within 2 plots runs beside (x, y), across the direction of travel. */
    private static boolean tooClose(Painted p, int x, int y, int dx, int dy) {
        int px = -dy, py = dx;
        for (int m = -2; m <= 2; m++) {
            if (m == 0) continue;
            int cx = x + px * m, cy = y + py * m;
            if (cx < 0 || cy < 0 || cx >= TILE || cy >= TILE) continue;
            if (p.use[cy * TILE + cx] == ROAD) return true;
        }
        return false;
    }

    /** Whether a road could leave (x, y) in direction (dx, dy): its next plot inside the edge ring, free, owned, not sea, and no parallel road beside it. */
    private static boolean canStart(Painted p, boolean[] owned, byte[] terrain, int x, int y, int dx, int dy) {
        int nx = x + dx, ny = y + dy;
        if (nx < 1 || ny < 1 || nx >= TILE - 1 || ny >= TILE - 1) return false;
        int ni = ny * TILE + nx;
        return (p.use[ni] == EMPTY || p.use[ni] == FIELD) && owned[ni] && terrain[ni] != World.SALT
                && !tooClose(p, nx, ny, dx, dy);
    }

    private static void addEnd(Painted p, boolean[] owned, byte[] terrain, List<End> ends, int x, int y, int dx, int dy, int kind) {
        if (canStart(p, owned, terrain, x, y, dx, dy)) ends.add(new End(x, y, dx, dy, kind));
    }

    /**
     * When every end is dead: a T off a road plot drawn from the hash - never
     * one on a bridge, so no junction stands in the water - as a new end of
     * its kind; and when the tile has laid no road at all (its ports all on
     * ground it does not own: a tile on the land's edge), a new end at an
     * owned dry plot drawn from the hash (J3b), so its buildings still have
     * a street.
     */
    private static boolean respawn(Painted p, List<End> ends, byte[] terrain, boolean[] owned, long r, double share) {
        for (int tries = 0; tries < RESPAWN_TRIES; tries++) {
            r = World.mix(r);
            int i = (int) ((r >>> 33) % PLOTS);
            if (p.use[i] != ROAD || p.bridge[i]) continue;
            int x = i % TILE, y = i / TILE, k = (int) ((r >>> 8) & 3);
            if (canStart(p, owned, terrain, x, y, DX[k], DY[k])) {
                ends.add(new End(x, y, DX[k], DY[k], p.road[i] >= BuildingVisual.PAVED ? BuildingVisual.PAVED : BuildingVisual.GRAVEL));
                return true;
            }
        }
        if (p.roadPlots > 0) return false;
        for (int tries = 0; tries < RESPAWN_TRIES; tries++) {
            r = World.mix(r);
            int i = (int) ((r >>> 33) % PLOTS);
            if (p.use[i] != EMPTY || !owned[i] || terrain[i] == World.SALT || terrain[i] == World.FRESH) continue;
            int x = i % TILE, y = i / TILE, k = (int) ((r >>> 8) & 3);
            if (canStart(p, owned, terrain, x, y, DX[k], DY[k])) {
                ends.add(new End(x, y, DX[k], DY[k], kindFor(World.mix(r ^ 0x5EED), share)));
                return true;
            }
        }
        return false;
    }

    /* --------------------------------------------- the mines on their sites */

    /** Each site with a mine or well on it: the mine on its free dry plots, and a straight gravel spur from it to the nearest road. */
    private static void standMines(Input in, Painted p) {
        for (int k = 0; k < in.sites; k++) {
            int type = in.siteMine[k];
            if (type < 0) continue;
            int x0 = TILE, y0 = TILE, x1 = -1, y1 = -1;
            int b = -1;
            for (int y = in.siteY0[k]; y <= in.siteY1[k]; y++) {
                for (int x = in.siteX0[k]; x <= in.siteX1[k]; x++) {
                    int i = y * TILE + x;
                    if (p.use[i] != FIELD || p.site[i] != k + 1 || !in.owned[i]) continue;
                    byte t = in.terrain[i];
                    if (t == World.SALT || t == World.FRESH) continue;
                    if (b < 0) b = p.add(0, 0, 0, 0, type, -1, k);
                    p.use[i] = BUILDING;
                    p.bld[i] = (short) (b + 1);
                    x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y);
                }
            }
            if (b < 0) { p.dropped++; continue; }
            p.bx[b] = x0; p.by[b] = y0; p.bw[b] = x1 - x0 + 1; p.bh[b] = y1 - y0 + 1;
            spur(in, p, b);
        }
    }

    /** The shortest straight gravel track from a mine's edge to a road, in one of four directions, inside the tile's edge ring; none when no road is in reach. No budget: the mockup's track. */
    private static void spur(Input in, Painted p, int b) {
        int bestLen = Integer.MAX_VALUE, bestX = 0, bestY = 0, bestD = -1;
        for (int d = 0; d < 4; d++) {
            // From the middle of the side facing this way.
            int x = d == 1 ? p.bx[b] + p.bw[b] - 1 : d == 3 ? p.bx[b] : p.bx[b] + p.bw[b] / 2;
            int y = d == 2 ? p.by[b] + p.bh[b] - 1 : d == 0 ? p.by[b] : p.by[b] + p.bh[b] / 2;
            // Already beside a road on this side: no spur.
            int ax = x + DX[d], ay = y + DY[d];
            if (ax >= 0 && ay >= 0 && ax < TILE && ay < TILE && p.use[ay * TILE + ax] == ROAD) return;
            for (int k = 1; k <= SPUR_MOST; k++) {
                int cx = x + DX[d] * k, cy = y + DY[d] * k;
                if (cx < 1 || cy < 1 || cx >= TILE - 1 || cy >= TILE - 1) break;
                int ci = cy * TILE + cx;
                if (p.use[ci] == ROAD) {
                    if (k - 1 < bestLen && k > 1) { bestLen = k - 1; bestX = x; bestY = y; bestD = d; }
                    break;
                }
                byte t = in.terrain[ci];
                if (!in.owned[ci] || t == World.SALT || t == World.FRESH) break;
                if (p.use[ci] == BUILDING || (p.use[ci] == FIELD && p.site[ci] != p.bsite[b] + 1)) break;
            }
        }
        if (bestD < 0) return;
        for (int k = 1; k <= bestLen; k++) {
            int ci = (bestY + DY[bestD] * k) * TILE + bestX + DX[bestD] * k;
            p.use[ci] = ROAD;
            p.road[ci] = (byte) BuildingVisual.GRAVEL;
            p.spurPlots++;
        }
    }

    /* ----------------------------------------------------- the buildings */

    private static void placeBuildings(Input in, Painted p, Scratch s) {
        byte[] terrain = in.terrain;
        boolean[] owned = in.owned;
        long seed = in.seed, tx = in.tx, ty = in.ty;
        // Rows from the road, breadth first, to ROWS_COUNTED.
        Arrays.fill(p.row, (byte) 99);
        int[] q = s.queue;
        int qh = 0, qt = 0;
        boolean anyRoad = false;
        for (int i = 0; i < PLOTS; i++) if (p.use[i] == ROAD) { p.row[i] = 0; q[qt++] = i; anyRoad = true; }
        while (qh < qt) {
            int i = q[qh++], x = i % TILE, y = i / TILE;
            if (p.row[i] >= ROWS_COUNTED) continue;
            for (int k = 0; k < 4; k++) {
                int nx = x + DX[k], ny = y + DY[k];
                if (nx < 0 || ny < 0 || nx >= TILE || ny >= TILE) continue;
                int j = ny * TILE + nx;
                if (p.row[j] > p.row[i] + 1) { p.row[j] = (byte) (p.row[i] + 1); q[qt++] = j; }
            }
        }
        // The candidates in their base order: row, then forest after grass, then the plot's own hash.
        int nc = 0;
        long[] keys = s.keys;
        for (int i = 0; i < PLOTS; i++) {
            if (p.use[i] != EMPTY || !owned[i]) continue;
            byte t = terrain[i];
            if (t == World.SALT || t == World.FRESH) continue;
            int rw = anyRoad ? p.row[i] : 1;
            long jit = (World.mix(seed ^ ((tx * TILE + i % TILE) * 0x9E3779B97F4A7C15L) ^ ((ty * TILE + i / TILE) * 0xC2B2AE3D27D4EB4FL)) >>> 48) & 0x3ff;
            keys[nc++] = ((long) Math.min(rw, 15) << 40) | ((long) (t == World.FOREST ? 1 : 0) << 39) | (jit << 12) | i;
        }
        Arrays.sort(keys, 0, nc);
        int[] order = s.order, next = s.next, at = s.at;
        Arrays.fill(at, -1);
        for (int k = 0; k < nc; k++) {
            order[k] = (int) (keys[k] & 0xfff);
            at[order[k]] = k;
            next[k] = k;
        }
        next[nc] = nc;
        // Every building's own preferred place, u^1.5 of the way through the rows near a road - a row and a point in
        // that row's hash - each taking the first free from it: placed kind by kind and number by number, homes
        // first, the one-for-one types last (J3b). The plots taken are the same in any order, and a building added
        // moves only those placed after it.
        BuildingVisual.Type[] types = in.types;
        int firstVisual = types.length;
        for (int t = 0; t < types.length; t++) if (BuildingVisual.visual(types[t])) { firstVisual = t; break; }
        int want = 0;
        for (int t = 0; t < in.counts.length; t++) {
            if (in.counts[t] <= 0 || t >= types.length || types[t] == null || !types[t].drawn()) continue;
            want += Math.min(in.counts[t], PLOTS);
            p.dropped += Math.max(0, in.counts[t] - PLOTS);
        }
        if (s.places.length < want) {
            s.places = new long[Math.max(want, s.places.length * 2)];
            s.prefs = new long[s.places.length];
        }
        long[] places = s.places, prefs = s.prefs;
        int rows = anyRoad ? PLACE_ROWS : 1;
        int m = 0;
        long tseed = tileSeed(seed, tx, ty);
        for (int t = 0; t < in.counts.length; t++) {
            if (in.counts[t] <= 0 || t >= types.length || types[t] == null || !types[t].drawn()) continue;
            long base = World.mix(tseed ^ ((long) types[t].id() << 44));
            int c = Math.min(in.counts[t], PLOTS);
            for (int j = 0; j < c; j++) {
                double u = World.unit(World.mix(base + j));
                double at1 = 1 + rows * u * Math.sqrt(u);
                int row = (int) at1;
                prefs[m] = ((long) row << 40) | ((long) ((at1 - row) * 1024) << 12);
                places[m] = ((long) placeRank(t, firstVisual, types.length) << 40) | ((long) j << 20) | m;
                m++;
            }
        }
        Arrays.sort(places, 0, m);
        int free = nc;
        for (int k = 0; k < m; k++) {
            int t = rankType((int) (places[k] >>> 40), firstVisual, types.length), j = (int) ((places[k] >>> 20) & 0xfffff);
            int pref = lowerBound(keys, nc, prefs[(int) (places[k] & 0xfffff)]);
            if (free <= 0) { p.dropped++; continue; }
            int[] shape = BuildingVisual.footprint(types[t], j, tseed);
            boolean placed = false;
            // The first free candidate from its place on, skipping those taken (a path-halving union-find: the
            // same plot the walk one at a time finds, in time that does not grow with the buildings).
            for (int c = firstFree(next, pref); c < nc && !placed; c = firstFree(next, c + 1)) {
                placed = place(p, owned, terrain, order[c], shape[0], shape[1], shape[2] == 1, t, j);
            }
            // Past the last candidate with room: from the first (a tile whose candidates near its road are few).
            for (int c = firstFree(next, 0); c < pref && !placed; c = firstFree(next, c + 1)) {
                placed = place(p, owned, terrain, order[c], shape[0], shape[1], shape[2] == 1, t, j);
            }
            if (placed) {
                free -= shape[0] * shape[1];
                int b = p.buildings - 1;
                for (int y = p.by[b]; y < p.by[b] + p.bh[b]; y++) {
                    for (int x = p.bx[b]; x < p.bx[b] + p.bw[b]; x++) {
                        int c = at[y * TILE + x];
                        if (c >= 0) next[c] = c + 1;
                    }
                }
            } else p.dropped++;
        }
    }

    /** A type's turn to be placed: the visual kinds first - homes, shops, offices, plants - then the map's types in their order. A building added displaces only those placed after it, so the most numerous go first and a cascade runs through the sparse kinds after them, not through the homes. */
    static int placeRank(int t, int firstVisual, int length) {
        return t >= firstVisual ? t - firstVisual : (length - firstVisual) + t;
    }

    /** ...and back: the type whose turn it is. */
    static int rankType(int r, int firstVisual, int length) {
        int visual = length - firstVisual;
        return r < visual ? firstVisual + r : r - visual;
    }

    /** The first index in keys[0, n) whose key is at least k. */
    static int lowerBound(long[] keys, int n, long k) {
        int lo = 0, hi = n;
        while (lo < hi) {
            int mid = (lo + hi) >>> 1;
            if (keys[mid] < k) lo = mid + 1; else hi = mid;
        }
        return lo;
    }

    /** The first candidate from c on not yet taken: next[c] == c while it is free, and points past it once taken. */
    private static int firstFree(int[] next, int c) {
        while (next[c] != c) {
            next[c] = next[next[c]];
            c = next[c];
        }
        return c;
    }

    /** A tile's own stream: what its buildings' places and shapes are drawn from. */
    public static long tileSeed(long seed, long tx, long ty) {
        return World.mix(seed ^ World.mix((tx * 0x9E3779B97F4A7C15L) ^ ty));
    }

    /** A w x h footprint with its front on the road side of plot i, extending away from the road; false when it does not fit. */
    private static boolean place(Painted p, boolean[] owned, byte[] terrain, int i, int w, int h, boolean grassOnly, int type, int j) {
        int x = i % TILE, y = i / TILE;
        int face = -1;
        for (int k = 0; k < 4 && face < 0; k++) {
            int nx = x + DX[k], ny = y + DY[k];
            if (nx >= 0 && ny >= 0 && nx < TILE && ny < TILE && p.use[ny * TILE + nx] == ROAD) face = k;
        }
        // Away from the road; with none beside it, south (J3b: J3 took (1, 1) here, a diagonal, which laid a footprint
        // out as a diamond whose box overlapped its neighbours).
        int ax = face < 0 ? 0 : -DX[face], ay = face < 0 ? 1 : -DY[face];
        int alx = -ay, aly = ax;                                                // along it
        int along = (face == 1 || face == 3) ? h : w, deep = (face == 1 || face == 3) ? w : h;
        for (int off = 0; off < along; off++) {
            boolean ok = true;
            for (int a = 0; a < along && ok; a++) {
                for (int d = 0; d < deep && ok; d++) {
                    int cx = x + alx * (a - off) + ax * d, cy = y + aly * (a - off) + ay * d;
                    if (cx < 0 || cy < 0 || cx >= TILE || cy >= TILE) { ok = false; break; }
                    int ci = cy * TILE + cx;
                    byte t = terrain[ci];
                    if (p.use[ci] != EMPTY || !owned[ci] || t == World.SALT || t == World.FRESH
                            || (grassOnly && t != World.GRASS)) ok = false;
                }
            }
            if (!ok) continue;
            int x0 = TILE, y0 = TILE, x1 = -1, y1 = -1;
            int b = p.buildings;
            for (int a = 0; a < along; a++) {
                for (int d = 0; d < deep; d++) {
                    int cx = x + alx * (a - off) + ax * d, cy = y + aly * (a - off) + ay * d, ci = cy * TILE + cx;
                    p.use[ci] = BUILDING;
                    p.bld[ci] = (short) (b + 1);
                    x0 = Math.min(x0, cx); y0 = Math.min(y0, cy); x1 = Math.max(x1, cx); y1 = Math.max(y1, cy);
                }
            }
            p.add(x0, y0, x1 - x0 + 1, y1 - y0 + 1, type, j, -1);
            return true;
        }
        return false;
    }
}
