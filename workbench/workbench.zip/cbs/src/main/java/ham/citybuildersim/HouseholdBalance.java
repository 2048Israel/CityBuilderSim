package ham.citybuildersim;

import java.util.function.Consumer;
import java.util.function.ToDoubleBiFunction;
import java.util.function.ToDoubleFunction;

/**
 * The households' balance sheet: what they have saved, what they owe, and what
 * happens in the month they cannot cover the shop.
 *
 * ==================== WHY THIS EXISTS ====================
 *
 * Retail demand was `min(storeCoverage, population)` - a headcount, with no
 * reference whatever to what anybody earned. So the shops sold the same basket
 * to an unskilled single adult on $552 and to an Elite household on $18,673,
 * and the household screen carried a five-line paragraph admitting it:
 *
 *     "Nothing in the model ties spending to income yet - rent is the same per
 *      head for everyone and so is the weekly shop - so a poor household is
 *      charged what a rich one is. Those deficits are a missing budget
 *      constraint, not a result."
 *
 * A deficit that nothing funds is money from nowhere. This is the constraint.
 *
 * ==================== THE WATERFALL ====================
 *
 * Jerus's design, and it is the right shape: a household short of money does
 * not simply eat less. It spends its savings, then it borrows, and only when
 * both are gone does it go without - at which point going without is a health
 * problem rather than an accounting one.
 *
 *     payslip  ->  rent  ->  fees (healthcare, tuition, interest)  ->  food
 *
 *     food short?   savings first, then credit, then go hungry
 *     food spare?   pay down the debt first, then bank it
 *
 *     ...and the clinic's fee is the one bill that gives way before food
 *     (2026-09-19): a household that has run through its income, its
 *     savings, its shares and its credit and would still eat less skips
 *     the care bill first, and that share of its people goes untreated.
 *     See Household.affordCare().
 *
 * Debt before hunger and repayment before saving are both deliberate: they are
 * what a household actually does, and each is the direction that makes the
 * failure arrive slowly enough for the player to see it coming. The waterfall
 * itself lives in Household.settle(); this class decides what each household
 * is handed and adds up what they did.
 *
 * ==================== SIXTY-EIGHT CELLS, NOT SEVEN ROWS ====================
 *
 * Jerus, 2026-09-10: "I need it per household and pay tier type."
 *
 * Until then the stocks were kept per pay tier - seven rows - and the header
 * here argued that the shape could not carry a stock because FamilyModel
 * rebuilds every household from scratch each month: "a stock attached to
 * 'unskilled couple with a teen' would be a stock of nothing, handed to a
 * different set of people every month." The tier survived; the shape did not.
 *
 * It does now, because the money follows the people. Every cell of the family
 * matrix is a Household object with its own savings, debt and credit line, and
 * when the monthly rebuild moves households between cells - a child ages into
 * a teen, five singles take a flatshare, a worker retires - their money moves
 * with them. See followThePeople(). What used to be seven rows of arrays is
 * sixty-eight objects this class holds, sums and strikes; the row getters the
 * screens read are sums of the cells, and the tier is a view rather than the
 * unit.
 *
 * ==================== PER HOUSEHOLD, NOT PER CELL ====================
 *
 * The stocks are kept PER HOUSEHOLD, which is the one decision here worth
 * arguing about. A cell total would be diluted every month the city grew: a
 * hundred arrivals would halve the average family's savings without anybody
 * spending a penny, and the screen would show a city getting poorer for
 * growing. Per household, a newcomer arrives with what a household like theirs
 * has, which is both truer and the only version whose figure means anything on
 * a screen.
 *
 * ==================== WHAT IT IS NOT ====================
 *
 * Not part of the money audit. Households have never been one of MoneyAudit's
 * pools - wages leaving the city's businesses leave the audited system, and rent
 * and shopping arrive back into it - so savings and household debt sit outside
 * the identity by construction, exactly as they did when they were invisible.
 * What changes is that they are now written down.
 */
public class HouseholdBalance {

    /**
     * One row per pay tier, the retired, and since 2026-09-11 the out of work,
     * the students and the orphans - the same shape as HouseholdAccounts.
     */
    public static final int ROWS = Household.ROWS;

    /** The rows before the people outside the families had books: the six tiers and the retired. */
    public static final int ROWS_BEFORE_OUTSIDE = Household.RETIRED_ROW + 1;

    /* ------------------------------- the dials ------------------------------- */

    /**
     * How many months of take-home a household can owe before the lender stops.
     *
     * Six is roughly half a year's income, which is about where unsecured
     * consumer credit actually stops for somebody with no assets. It is also the
     * number that sets how long a household can be short before the hunger
     * starts: an unskilled single adult short $117 a month hits the ceiling in
     * about twenty months, which is slow enough to be a warning and fast enough
     * to matter inside a playthrough.
     */
    public static final double CREDIT_LIMIT_MONTHS = 6;

    /*
     * WHAT A HOUSEHOLD PAYS OVER ITS BANK'S RATE STARTED AT THREE POINTS -
     * BASE_SPREAD, over the city's own borrowing rate - until 0.7.7. The
     * start is the bank's household rate now (Bank.householdRate(): its
     * funds-transfer price, running costs, expected loss and capital at
     * RISK_HOUSEHOLD), and the slope below is the household's own risk on it.
     */

    /**
     * Extra spread per month of income owed.
     *
     * A household at the ceiling - six months of income in debt - pays its
     * bank's household rate plus 6 x this, nine points over it. That is a
     * credit card, which is what this is. The slope is what makes the debt
     * compound faster the deeper it goes, and it is why a household that starts
     * borrowing to eat rarely stops.
     */
    public static final double RISK_SLOPE = .015;

    /** Nobody is charged more than this, however deep they are. */
    public static final double MAX_RATE = .36;

    /**
     * How much of the money above subsistence a household spends.
     *
     * WITHOUT THIS THE RICH BANK EVERYTHING. Demand was one basket per person,
     * so a College household with $3,800 spare after the bills bought $713 of
     * goods and saved the rest - measured at $715,012 per household after three
     * hundred months, and $4.0M for an Elite one. Numbers like that are not a
     * balance problem, they are a missing behaviour: a household with money
     * spends more of it, on more and better things, and the shops sell them.
     *
     * 0.80 puts a high earner's saving rate near 16-19%, which is the top end
     * of what real households manage. The floor underneath it is subsistence -
     * one basket a head, the old headcount demand - so the poor still want
     * exactly what they always wanted, and only the top of the distribution
     * moves. Which is the point: this is the other half of "spending follows
     * income", and without it the constraint only ever bites downward.
     */
    public static final double MARGINAL_PROPENSITY = .80;

    /* =====================================================================
       AND A HOUSEHOLD SPENDS OUT OF WHAT IT HAS, NOT ONLY OUT OF WHAT IT
       EARNS (2026-09-17)

       Jerus, having been shown where the money went: yes, "a wealth term in
       the plan".

       WHY NOTHING ELSE COULD HAVE WORKED, and it was measured in that order
       rather than argued. Two changes went in first. Paying the foreign coupon
       home instead of rolling it abroad took household net worth from 5,380
       months of the city's GDP to 3,412. Then letting dividends and that coupon
       into the spending plan - which is plainly right and which Jerus asked for
       - put it back up to 5,465, HIGHER than where it started.

       THAT IS NOT A PARADOX AND IT IS THE WHOLE LESSON. Investment income is a
       FLOW. Spending more of a flow makes the city bigger; a bigger city pays
       more wages and more dividends; MARGINAL_PROPENSITY saves a fifth of all
       of it. Every term in the ratio grew together and the ratio did not move.
       A STOCK THAT COMPOUNDS CAN ONLY BE BOUNDED BY A DRAIN THAT READS THE
       STOCK. Nothing that reads a flow can do it, however large.

       FOUR PENCE IN THE POUND A YEAR is where the empirical work sits - the
       marginal propensity to consume out of wealth is measured at three to five
       cents on the dollar a year across a lot of countries and a lot of decades
       - and it is a pure ratio, so a currency reform cannot touch it.

       AND IT IS SELF-STABILISING, which is the property to want. The households'
       money abroad compounds at the world's rate on the share they keep there:
       about 1.6% a year, mechanically, whatever the city does. A drain of four
       percent a year on the whole stock beats that at every level, so the stock
       has a ceiling instead of an exponent - and the richer the households get,
       the harder they spend, which is both true of people and the only shape
       that closes the loop.
       ===================================================================== */

    /**
     * What share of its net worth a household spends in a month, over and above
     * what it spends out of income.
     *
     * A third of a percent a month is four percent a year, the middle of the
     * measured range. A pure number: both sides are money and a reform moves
     * neither.
     */
    public static final double WEALTH_SPENT_A_MONTH = .0033;

    /**
     * What share of the income a household does NOT spend on food goes over a
     * luxury counter instead of into the bank.
     *
     * A LUXURY IS A GOOD WHOSE SHARE RISES WITH INCOME - that is the
     * definition, and it is the other half of Engel's law, which this model
     * has only ever had the food half of. `want` above takes
     * MARGINAL_PROPENSITY of the surplus for the grocer and the shape of
     * Consumption's basket means most of that is refused past appetite; what
     * is left is the income a rich household has and a poor one does not.
     * Half of it, here.
     *
     * AND IT IS A SHARE RATHER THAN A CURVE, deliberately, for now. The
     * genuinely income-elastic part of this is the wealth term beside it,
     * which is unbounded and is where the fortunes go; this line is the
     * ordinary earner buying something nice, and a constant is an honest
     * description of that until something measures otherwise.
     */
    public static final double LUXURY_SHARE_OF_SURPLUS = .5;

    /* =====================================================================
       ...AND WHAT IT SPENDS EATING OUT (2026-09-18)

       A QUARTER OF THE SAME SURPLUS, so the two together take three quarters
       of it and a household that got everything it asked for still banks the
       rest. Smaller than the counter's half, because eating out has a ceiling
       the counter does not: a person eats ninety meals a month and a fortune
       buys DEARER ones, not more of them. See Household.plan().

       NO WEALTH TERM for the same reason, which is the whole difference
       between this sector and the boutiques as a drain on the hoard - and the
       reason this is the one that feeds anybody.
       ===================================================================== */
    public static final double MEAL_SHARE_OF_SURPLUS = .25;

    /**
     * ...and the share of a FORTUNE'S monthly spend that goes on a table.
     *
     * Half of what the counter gets, and additive with it rather than a
     * partition of it - the same "adds without subtracting" the luxury term
     * itself was written under. Without this the sector has no demand at all
     * in any city rich enough to matter, because `want` carries the wealth
     * term and the surplus is therefore zero; see Household.plan().
     */
    public static final double MEAL_SHARE_OF_WEALTH = .5;

    /* =====================================================================
       AND THE CEILING, WHICH IS IN MEALS AND NOT IN MONEY (2026-09-18)

       A person eats ninety meals a month whatever they are worth, and a third
       of them is one a day - about the most anybody eats out. This is what
       stops a fortune buying a ninety-first dinner, and it is the reason the
       wealth term above is safe: money says what a household CAN spend, and
       appetite says how many dinners it can actually get through.

       THE SAME SHAPE CONSUMPTION PUTS ON THE BASKET, and for the same reason -
       a rich household buys a DEARER meal, which the margin gives it, not
       more of them. Applied at the counter rather than in the plan because
       that is the only place a meal has a price.
       ===================================================================== */
    public static final double MOST_MEALS_EATEN_OUT = 1 / 3.0;

    /* =====================================================================
       AND IT IS NOT ENOUGH, WHICH IS THE REAL ANSWER (2026-09-17)

       This term does what it was built to do and the stock still diverges: 85
       months of GDP at month 240, 3,982 by month 3,840. Slower than before -
       5,072 without it - and the same exponent.

       SO THE COEFFICIENT WAS PUSHED TO THIRTY-SIX PERCENT A YEAR, nine times
       the empirical range and far past anything defensible, purely to find out
       whether the consumption side CAN bound this. It cannot. The stock came
       down a great deal, wandered instead of climbing smoothly - and ended at
       946 months, still rising. What fell instead was DELIVERY: the shops got
       from 76% of what was planned to 57%.

       BECAUSE THE BINDING CONSTRAINT IS NOT THE CONSUMPTION FUNCTION. It is
       that the city cannot sell its households what they already want to buy.
       A quarter of every plan goes undelivered at the honest coefficient and
       nearly half at the absurd one, and WHATEVER IS NOT DELIVERED IS BANKED,
       by construction - settle() has nowhere else to put it. Wanting to spend
       more money in a city with nothing left on the shelf does not spend it;
       it just moves the shortage.

       The households are not hoarding because they are misers. They are
       hoarding because there is nothing to buy. That is a supply question and
       it is the next one - see the design note
       claude/the-savings-that-cannot-be-spent.md, which asked half of it
       before any of this was measured.
       ===================================================================== */

    /* =====================================================================
       AND WHAT IT SPENDS ANSWERS THE REAL RATE (0.7.3)

       Jerus's design for the central bank, the-central-bank.md section 9:
       "for the rate to bite at home, a household's saving must answer the
       real return" - so a hike moves consumption and not only credit.

       WHY. Until this the only household decision that read a rate was where
       to keep the money: at home or abroad, and since 0.7.1 whether to take
       the city's paper. A hike moved credit and, since 0.7.2, the currency;
       it did not move a dollar of what anybody spent. MonetaryCheck section
       6 measured it - one founding held at 3, 10, 20 and 40%, inflation
       +0.02, +0.01, -0.38 and -0.98% a year: about a point across the whole
       range, all of it through the currency.

       WHAT MOVES IS THE DISCRETIONARY PART, AND ONLY THAT. Subsistence is a
       basket a head, and nobody eats less of it because the bank pays more.
       Everything above it - the propensity's share of what is left after the
       bills, the wealth term, and the surplus the luxury counter and the
       table spend out of - is multiplied by one factor,

           spendFactor = 1 - SAVING_RESPONSE x the real deposit rate,

       held between SPEND_FLOOR and SPEND_CEILING. What is not spent is
       banked by settle(), which is what saving is.

       WHY THE DEPOSIT RATE AND NOT THE CURVE. The marginal saver's return is
       what the bank pays on savings: it is paid on every balance, every
       month, and it is the rate on the money a household is deciding whether
       to spend. The city's paper is taken at issue only, by the households
       that take it, and the world's rate is reached through investAbroad()'s
       own choice, which answers to it already. One rate, one dial.

       REAL, ex ante since 0.7.42: the deposit rate less the inflation the
       city expects, as the real rate differential reads it (the year-on-year
       rate the parity reads, until then) - Game.realDepositRate(), one
       definition for the month and for the monetary page. Struck once a
       month by Game before the households plan and handed in
       (setSpendFactor()). Nothing is saved - the load path derives it again
       from the deposit rate and the anchor a save restores - and a caller
       that hands nothing plans at 1, which is the model as it was.
       ===================================================================== */

    /** How hard a household's spending above subsistence answers the real deposit rate: at 1.0 ten points of real return cut it by a tenth and ten points of negative real return raise it by a tenth (provisional - Jerus's number to settle). */
    public static final double SAVING_RESPONSE = 1.0;

    /** The least share of its spending above subsistence a household keeps however well saving pays: half - no real return makes a household spend nothing above a basket a head. */
    public static final double SPEND_FLOOR = .5;

    /** The most it spends however badly saving pays: half as much again - no negative real return makes a household spend without limit. */
    public static final double SPEND_CEILING = 1.5;

    /**
     * The share of its spending above subsistence a household keeps at this
     * real deposit rate (annual, a fraction): 1 at zero, less when saving
     * pays, more when it costs, between SPEND_FLOOR and SPEND_CEILING. A
     * rate that is not a number is no return at all.
     */
    public static double spendFactor(double realDepositRate) {
        if (!Double.isFinite(realDepositRate)) return 1;
        return Math.max(SPEND_FLOOR, Math.min(SPEND_CEILING,
                1 - SAVING_RESPONSE * realDepositRate));
    }

    /**
     * A month's savings a founding city's households already have.
     *
     * Not zero, because a city where every household is one bad month from the
     * food bank on the day it is founded reads as a bug rather than as poverty -
     * and because people who move somewhere new have, by revealed preference,
     * been able to afford to.
     */
    public static final double OPENING_BUFFER_MONTHS = 1.5;

    /* =====================================================================
       BANKRUPTCY

       Jerus: "if families get hit with too much debt they go bankrupt and reset
       their financial position... wiped, locked out, but only some leave."

       Which is the missing end of the waterfall. Before this a tier that ran
       out of savings and credit simply sat at its ceiling for the rest of the
       game, going hungry, paying interest it could not afford on a debt that
       could never be repaid - a permanent condition rather than an event, and
       nothing in the model ever closed it out.

       Now it closes: the debt is written off against the bank, the savings go
       with it, the cell cannot borrow for a year, and some of them leave. All
       three parts matter. Without the lockout a broke cell cycles straight back
       into debt and the bank bleeds on a loop; without the emigration poverty
       costs the city nothing; and without the write-off the money vanishes
       instead of landing on somebody, which is the whole reason the bank exists.

       PER CELL, since the cells exist: an unskilled large family at its ceiling
       discharges while the unskilled single adult next door keeps its credit
       line, where before the whole tier was locked out together.
       ===================================================================== */

    /**
     * Months of income owed at which a household stops being able to carry it.
     *
     * The credit ceiling is six months; this is past it, because reaching the
     * ceiling is not the same as failing - a household at the ceiling that can
     * still service the interest is merely poor. What fails is the one that
     * cannot, so the trigger is BOTH: at the ceiling, and short of the shop.
     */
    public static final double BANKRUPT_AT_MONTHS = CREDIT_LIMIT_MONTHS * .98;

    /** Share of a stuck cell that goes under in a month. A trickle, not a purge. */
    public static final double BANKRUPT_RATE = .04;

    /** Months a discharged household cannot borrow. */
    public static final int LOCKOUT_MONTHS = 12;

    /** ...and the share of them who give up on the city entirely. */
    public static final double LEAVE_ON_BANKRUPTCY = .25;

    /* ------------------------------- the cells ------------------------------- */

    /**
     * Every meaningful cell of the family matrix, in one fixed order: the
     * working shapes by declaration, each across the six tiers, then the two
     * retired shapes. Sixty-eight. Looked up by shape and tier through
     * `index`, and by name through key() on the save path.
     */
    private final Household[] cells;
    private final int[][] index =
            new int[FamilyStructure.values().length][PayTier.values().length];
    private final java.util.List<Household> view;
    private final int[] unemployedIndex = new int[UnemployedHousehold.Status.values().length];
    private int studentIndex;
    private final int[] orphanIndex = new int[AgeBand.values().length];
    private int prisonerIndex;

    /**
     * How many households are in each cell the family matrix does not hold -
     * the out of work, the students, the orphans. Set by Game off Unemployment,
     * the students and FamilyModel; nobody in them by default, so a fixture
     * that never sets it has the city it always had.
     */
    private ToDoubleFunction<Household> outsideCensus = c -> 0;

    public void setOutsideCensus(ToDoubleFunction<Household> census) {
        this.outsideCensus = census == null ? c -> 0 : census;
    }

    /**
     * The share of a door's rent one household of a cell pays: 1 alone in its
     * own home, a fifth sharing, half doubled up, none with no door. Set by
     * Game off the housing match; everybody pays a whole door by default.
     */
    private ToDoubleFunction<Household> rentShares = c -> 1;

    public void setRentShares(ToDoubleFunction<Household> shares) {
        this.rentShares = shares == null ? c -> 1 : shares;
    }

    /**
     * Dependants living in each cell the family matrix does not hold.
     *
     * A LIVE FUNCTION, like the census and the rent shares beside it, and for
     * the same reason: it is FamilyModel's figure, re-derived every month, and
     * a copy kept here would be a second version of it that drifts. Set by Game
     * off FamilyModel.dependantsPerOutsideHousehold(); nobody has anybody by
     * default, so a fixture that never sets it has the city it always had.
     */
    private ToDoubleFunction<Household> outsideDependants = c -> 0;

    public void setOutsideDependants(ToDoubleFunction<Household> kin) {
        this.outsideDependants = kin == null ? c -> 0 : kin;
    }

    /* =====================================================================
       THE PRICE AT THE CLINIC DOOR (2026-09-19)

       Jerus: a household that cannot pay the clinic's fee "goes without
       care", not without food. The rule is one household's and lives in
       Household.affordCare(); this is where the cells are handed what they
       need to apply it and where its two consequences land:

         THE SPLIT. The row's health bill follows the heads WHO PAID at the
         row level - HouseholdAccounts weights each row's people by
         carePaidShare(), so a row the price turned away is billed less -
         and within the row it follows heads as it always has. That second
         half is an approximation, the same one the split has always made,
         and it is kept deliberately: a re-split of the care part by paying
         heads within the row was written, and DenominationCheck went red a
         decade after a reform. The payers' bills rounded differently in
         the two units, a hair of borrowing came out positive in one twin
         and exactly zero in the other, and the gate on holding money
         abroad reads that sign. The bill follows heads; the people it is
         for are relieved at the row.

         THE TEST. After every cell has settled and planned, each is asked
         what share of its FULL-SERVICE treatment bill fits after a basket
         for everybody in it - see the banner in Household. What it answers
         is read by Game.careAffordability() in the middle of the month, and
         becomes the share of its people the clinics treat. Treatment only:
         the funeral levy is on the same line of the statement but a fee of
         nothing must leave nobody priced out.

       The two bills arrive by row from HouseholdAccounts, through
       setCareBills(), for the strike that follows; a harness that never
       calls it gets the books it always got, with everybody served.
       ===================================================================== */

    /** This month's treatment fees by row, as the households were billed them, or null for a caller that does not price care. */
    private double[] careBillByRow;

    /** ...and the treatment bill the same rows would have faced at full service. */
    private double[] careBillFullByRow;

    /** The care bills the households skipped this month, summed over the city: what they ate instead. */
    private double lastCareSkipped;

    /**
     * Hands the strike the month's treatment bills, by row: what the
     * households were billed (HouseholdAccounts.getRowCareBilled) and what
     * the same rows would have been billed at full service
     * (getRowCareFull). One strike's worth: advanceMonth() consumes them.
     */
    public void setCareBills(double[] treatmentBilled, double[] treatmentAtFullService) {
        this.careBillByRow = padRows(treatmentBilled);
        this.careBillFullByRow = padRows(treatmentAtFullService);
    }

    /**
     * Of a row's people, the share who paid for care at the last strike -
     * people-weighted over its cells, 1 for a row with nobody in it. What
     * HouseholdAccounts splits the next bill by.
     */
    public double carePaidShare(int row) {
        double people = 0, paid = 0;
        for (Household c : cells) {
            if (c.row() != row) continue;
            double n = c.people();
            people += n;
            paid += n * c.carePaid;
        }
        return people > 0 ? paid / people : 1;
    }

    /** The same, for every row at once, in row order. */
    public double[] carePaidShares() {
        double[] out = new double[ROWS];
        for (int r = 0; r < ROWS; r++) out[r] = carePaidShare(r);
        return out;
    }

    /** What the city's households skipped of their care bills this month, in money - and ate instead. */
    public double getCareSkipped() { return lastCareSkipped; }

    /* ----------------------- the student loan's rate (2026-09-21) -----------------------
     * The treasury's annual rate on a graduate's loan, told to every cell
     * before it settles or re-strikes, as the exchange rate is: a policy,
     * saved on TaxPolicy and handed in by Game each month and after a load.
     * A harness that never sets it gets the interest-free loan it always
     * had. See Household's THE LOAN'S RATE.
     */
    private double studentLoanRate = TaxPolicy.DEFAULT_STUDENT_LOAN_RATE;

    /** Sets the annual rate the graduates are charged this month. See TaxPolicy.getStudentLoanRate(). */
    public void setStudentLoanRate(double annual) {
        studentLoanRate = Math.max(0, Math.min(TaxPolicy.MAX_STUDENT_LOAN_RATE, annual));
    }

    /* ---------------------- the bank's account fee (0.7.7) ----------------------
     * A month's fee on every housed household, in today's money - Game sets
     * it from Bank.accountFee() at the month's price index before the cells
     * settle, on both paths. Paid with the other fixed bills, so a household
     * that cannot meet it draws on its savings and its credit as it would for
     * the clinic's. housedShares says how much of a cell has a home: 1 for a
     * household in one (alone or sharing), 0 for the orphans, the prisoners
     * and the unhoused; set by Game off the same housing match the rent
     * shares come from. Nobody pays by default, so a fixture that never sets
     * it has the city it always had.
     */
    private double accountFee;
    private ToDoubleFunction<Household> housedShares = c -> 0;

    public void setAccountFee(double perHousehold) { this.accountFee = Math.max(0, perHousehold); }
    public double getAccountFee() { return accountFee; }

    /**
     * THE BANK'S CAPITAL RULE FOR THE MONTH (0.7.8), from
     * Bank.lendingGrowthLimit() and lendsOnlyToKeepBorrowersGoing(), set by
     * Game at the top of the month before any family borrows: each cell may
     * owe at most what it owes now, grown by the month's limit - nothing
     * more under the minimum, no limit while the bank lends freely. A
     * family's month of interest is outside it (Household.fundShortfall()),
     * and the car loans read it too (wantOf()). A balance nobody sets lends
     * freely, which is what the harnesses that build one by hand had.
     */
    public void setCapitalRule(double monthlyGrowth, boolean keepGoingOnly) {
        boolean free = !keepGoingOnly && Double.isInfinite(monthlyGrowth);
        double growth = keepGoingOnly || Double.isNaN(monthlyGrowth) ? 0 : Math.max(0, monthlyGrowth);
        for (Household c : cells) {
            c.capitalCeiling = free ? Double.POSITIVE_INFINITY : c.debt * (1 + growth);
        }
    }

    /** What the bank sets aside against the families' debt (0.7.8), summed cell by cell - see Household.lossAllowance(). */
    public double lossAllowance() { return sum(Household::lossAllowance); }

    /** ...and how much of their debt is in cells that are in trouble. */
    public double debtInTrouble() { return sum(Household::debtInTrouble); }

    public void setHousedShares(ToDoubleFunction<Household> shares) {
        this.housedShares = shares == null ? c -> 0 : shares;
    }

    /** The fee one household of this cell is charged, when the cell holds this many: nothing in a cell too empty to strike, which is paid nothing and pays nothing. */
    private double accountFeeFor(Household c, double households) {
        if (households < EMPTY_CELL || accountFee <= 0) return 0;
        return accountFee * Math.max(0, Math.min(1, housedShares.applyAsDouble(c)));
    }

    /**
     * What each row's households will be charged in account fees this month,
     * on this census: the figure the household books show on their own line
     * (HouseholdAccounts.setAccountFees()), struck BEFORE the cells settle -
     * the books are split first - by the same census, the same emptiness and
     * the same fee the settle charges, so the two agree to the cent.
     */
    public double[] accountFeesByRow(ToDoubleBiFunction<FamilyStructure, PayTier> census) {
        double[] out = new double[ROWS];
        if (census == null) return out;
        double[] fresh = takeCensus(census);
        for (int i = 0; i < cells.length; i++) {
            out[cells[i].row()] += fresh[i] * accountFeeFor(cells[i], fresh[i]);
        }
        return out;
    }

    /** What the households paid the bank in account fees this month: the sum the bank takes. */
    public double totalAccountFees() { return sum(Household::totalAccountFees); }

    /** ...and the loan fees the bank added to what they owe on the credit they drew this month. The cars' are their own figures - see getCarLoanFees(). */
    public double totalLoanFees() { return sum(Household::totalLoanFees); }

    /** The annual rate the cells were last told. */
    public double getStudentLoanRate() { return studentLoanRate; }

    /* ------------------------------- the month ------------------------------- */

    private double lastWrittenOff;
    private double lastLeaving;
    private double lastEvicted;
    private double lastStudentDebtTakenAway;
    private double lastTakenAway;
    private double graduating;
    private double lastGraduated;
    private double lastDepositInterest;
    private double lastDelivered = 1;
    private double plannedSpend;
    private double hungryPeople;
    private double totalPeople;
    /** ...of whom hungry even had the shops handed over all that was planned: the money half (0.7.27). */
    private double hungryAtFullShelves;

    public HouseholdBalance() {
        java.util.List<Household> built = new java.util.ArrayList<>();
        for (int[] row : index) java.util.Arrays.fill(row, -1);
        for (FamilyStructure shape : FamilyStructure.values()) {
            if (shape.isRetired()) continue;
            for (PayTier tier : PayTier.values()) {
                index[shape.ordinal()][tier.ordinal()] = built.size();
                built.add(new WorkingHousehold(shape, tier));
            }
        }
        for (FamilyStructure shape : FamilyStructure.values()) {
            if (!shape.isRetired()) continue;
            // The retired sit at tier index 0 in FamilyModel's matrix; the
            // same convention here, so one lookup serves both.
            index[shape.ordinal()][0] = built.size();
            built.add(new RetiredHousehold(shape));
        }
        // The people outside the families, after them, so every family cell
        // keeps its place. See Household's rows.
        for (UnemployedHousehold.Status s : UnemployedHousehold.Status.values()) {
            unemployedIndex[s.ordinal()] = built.size();
            built.add(new UnemployedHousehold(s));
        }
        studentIndex = built.size();
        built.add(new StudentHousehold());
        java.util.Arrays.fill(orphanIndex, -1);
        for (AgeBand b : new AgeBand[] { AgeBand.BABY, AgeBand.CHILD, AgeBand.TEEN }) {
            orphanIndex[b.ordinal()] = built.size();
            built.add(new OrphanHousehold(b));
        }
        // ...and the prisoners' ledger, last, so every cell before it keeps its place.
        prisonerIndex = built.size();
        built.add(new PrisonerHousehold());
        cells = built.toArray(new Household[0]);
        view = java.util.Collections.unmodifiableList(java.util.Arrays.asList(cells));
        carsToReplace = new double[cells.length];
    }

    /* =====================================================================
       EVERY HOUSEHOLD, OR ONE OF THEM

       "That way it's a lot easier to sum everything up, or modify across all."
       These are the sum and the modify.
       ===================================================================== */

    /** The cell for this shape at this tier. For a retired shape the tier is ignored. */
    public Household cell(FamilyStructure shape, PayTier tier) {
        int i = index[shape.ordinal()][shape.isRetired() ? 0 : tier.ordinal()];
        return cells[i];
    }

    /** The cell for a retired shape, which has no tier. */
    public Household cell(FamilyStructure shape) {
        if (!shape.isRetired()) {
            throw new IllegalArgumentException(shape + " needs a tier");
        }
        return cells[index[shape.ordinal()][0]];
    }

    /** The out-of-work cell in this situation. */
    public UnemployedHousehold unemployed(UnemployedHousehold.Status status) {
        return (UnemployedHousehold) cells[unemployedIndex[status.ordinal()]];
    }

    /** The students' cell. */
    public StudentHousehold students() { return (StudentHousehold) cells[studentIndex]; }

    /** The orphans of a child band, or null for a band that has none. */
    public OrphanHousehold orphans(AgeBand band) {
        int i = orphanIndex[band.ordinal()];
        return i < 0 ? null : (OrphanHousehold) cells[i];
    }

    /** The prisoners' ledger. */
    public PrisonerHousehold prisoners() { return (PrisonerHousehold) cells[prisonerIndex]; }

    /** Every cell, in the fixed order. Read-only. */
    public java.util.List<Household> cells() { return view; }

    public int cellCount() { return cells.length; }

    public void forEach(Consumer<Household> action) {
        for (Household c : cells) action.accept(c);
    }

    /** Adds a figure up across every cell. */
    public double sum(ToDoubleFunction<Household> figure) {
        double total = 0;
        for (Household c : cells) total += figure.applyAsDouble(c);
        return total;
    }

    /** ...or across one row: a tier's cells, or the retired. */
    public double sumRow(int row, ToDoubleFunction<Household> figure) {
        double total = 0;
        for (Household c : cells) if (c.row() == row) total += figure.applyAsDouble(c);
        return total;
    }

    /** Households in the row: the denominator of every per-household row figure. */
    public double rowHouseholds(int row) {
        return sumRow(row, Household::households);
    }

    /** A row total, per household of the row. Zero for an empty row. */
    private double perHousehold(int row, ToDoubleFunction<Household> perCell) {
        double homes = rowHouseholds(row);
        if (homes <= 0) return 0;
        double total = 0;
        for (Household c : cells) {
            if (c.row() == row) total += perCell.applyAsDouble(c) * c.households;
        }
        return total / homes;
    }

    /* =====================================================================
       THE MONTH

       Settles the month that just ran, then plans the next one. Both here,
       because the plan IS the settlement's other half: what a household can
       spend next month is exactly what this month left it holding.

       WHAT IT IS HANDED. The census is who lives here now, by cell -
       FamilyModel.get, with the retired at tier index 0 by that class's
       convention. The money comes as ROW totals, straight off the books
       HouseholdAccounts keeps: the tier's take-home, its fees, what it
       actually spent in the shops. Split here, by the one rule that makes the
       sum of the cells the row exactly - income by grown-ups, fees by people,
       the shop by who planned to spend - so nothing on the city's books is
       re-derived and every figure on the tier row is the sum of the cells
       under it.
       ===================================================================== */

    /**
     * @param census           households in each cell, as FamilyModel::get
     * @param rowDisposable    row total of wages + pensions - tax - contributions
     * @param rentPerHousehold what one let home pays, the same for all of them
     * @param rowFees          row total of healthcare fees and tuition
     * @param rowShopping      row total actually spent in the shops this month
     * @param foodPricePerHead one person's monthly basket at today's shelf price
     * @param riskFreeAnnual   the bank's household rate, which each household's
     *                         months owed sit on (Bank.householdRate() since
     *                         0.7.7; the city's own borrowing rate before it)
     * @param supplyRatio      the share of the baskets asked for at the price that
     *                         the shops handed over (Retail.getHouseholdShare();
     *                         of what was planned until 0.7.43) - the screens'
     *                         figure, which the hunger no longer reads
     */
    public void advanceMonth(ToDoubleBiFunction<FamilyStructure, PayTier> census,
                             double[] rowDisposable, double rentPerHousehold,
                             double[] rowFees, double[] rowShopping,
                             double foodPricePerHead, double riskFreeAnnual,
                             double supplyRatio) {

        rowDisposable = padRows(rowDisposable);
        rowFees = padRows(rowFees);
        rowShopping = padRows(rowShopping);
        if (census == null || rowDisposable == null || rowDisposable.length != ROWS) {
            return;   // refused whole, per the standing rule on state arrays
        }

        double[] fresh = takeCensus(census);

        /*
         * HUNGER, BEFORE ANYTHING IS OVERWRITTEN.
         *
         * What each household was handed at the last sale against the baskets
         * it needs (0.7.43; its plan times the supply ratio until then). Two
         * failures make it, and they are different - one is a household priced
         * out, the other is a city with no stock - so a player who fixes the
         * wrong one gets nowhere. Measured against a basket a head, because a
         * household that wanted a better television and bought a worse one is
         * not hungry.
         */
        hungryPeople = 0;
        totalPeople = 0;
        hungryAtFullShelves = 0;
        lastWrittenOff = 0;
        lastLeaving = 0;
        lastEvicted = 0;
        lastTakenAway = 0;
        lastAbroadTakenAway = 0;
        lastCareSkipped = 0;
        java.util.Arrays.fill(lastSharesTakenAway, 0);
        for (Household c : cells) c.dividends = 0;
        /*
         * WHAT THE SHOPS ACTUALLY HANDED OVER, as a share of what was asked
         * for at the price (2026-09-17; Retail.getHouseholdShare(), sold over
         * the baskets demanded at the shelf price since 0.7.43). It used to
         * be getSupplyRatio(), whose denominator the shops had already capped
         * at their own coverage. Since 0.7.43 it is the screen's figure and
         * nothing more: the eating below reads the baskets each household was
         * actually handed, which add up to what was sold by construction.
         */
        double delivered = Math.max(0, Math.min(1, supplyRatio));
        lastDelivered = delivered;
        /* =================================================================
           ...AND A MEAL OUT IS FOOD (2026-09-18)

           Jerus's rule for the kitchens: *a meal out replaces groceries*. This
           line is where it is true of anything. A restaurant meal is one
           ninetieth of a person-month of eating, and one person-month of
           eating costs `foodPricePerHead` - so what the household ate out is
           worth that much of the subsistence it would otherwise have had to
           buy at a shop.

           IT IS PRICED AT THE GROCER'S, NOT AT THE RESTAURANT'S, and that is
           the whole of the honesty here. A kitchen charges two and a half to
           five times what the food in the plate cost, and NONE of that markup
           is nourishment: it is wages, rent and somebody else's washing up.
           Counting the ticket would have a city fill its stomachs by putting
           its prices up.

           WHAT THIS BUYS THE MODEL is a second door. Retail's binding
           constraint is coverage times the operating rate - people the shops
           can physically serve - and a city at that wall has been unable to
           feed anybody a different way. Now it can build kitchens, and they
           compete for the same thirteen foods, which is exactly the pressure
           on the food price Jerus asked for when he chose to let the basket
           get dearer rather than bigger.

           A MONTH LATE, AND ON THE RIGHT SIDE OF THE BOUNDARY. `ate` is
           already last month's - the baskets each household was handed at last
           month's sale (last month's plan against last month's delivery until
           0.7.43) - so last month's meals belong beside it. See
           Household.mealsEaten.
           ================================================================= */
        /*
         * IN BASKETS SINCE 0.7.43 (spec-inflation.md 4.2). What a household
         * ate is the baskets the shops handed it at the last sale
         * (allocateGroceries()) and the meals it ate out, a ninetieth of a
         * basket each, against the baskets it needed at that sale - all three
         * positions the sale wrote, so a reload counts what the live city
         * counts (a cell struck empty at the plan and grown since needed
         * nothing at the sale, whatever a re-struck plan says) - the same comparison the
         * money one was, with the price taken out of both sides. It used to be
         * the plan times the share delivered, in money, against subsistence:
         * one share for the whole city, so the shortage fell on everybody
         * alike; the allocation prices the poorest out first now, and this is
         * where that shows.
         */
        double basketsPerMeal = ham.citybuildersim.sectors.Restaurants.PERSON_MONTHS_PER_MEAL;
        lastMealsEaten = 0;
        for (int i = 0; i < cells.length; i++) {
            Household c = cells[i];
            double people = fresh[i] * c.headcount();
            totalPeople += people;
            lastMealsEaten += c.mealsEaten * c.households;
            double ate = c.groceriesGot + c.mealsEaten * basketsPerMeal;
            if (c.groceriesNeed > 0 && ate < c.groceriesNeed) {
                hungryPeople += people * (1 - ate / c.groceriesNeed);
            }
            /*
             * ...AND THE SAME AT FULL SHELVES (0.7.27): what the household
             * would have been short of had the shops handed over every basket
             * it asked for at the price they charged (groceriesAsked, 0.7.43;
             * its plan until then). That is the money half of the hunger
             * above - priced out; the rest is the shelves. The People page
             * splits GOING SHORT by it, so a player can tell the two failures
             * apart. Nothing reads it in the month.
             */
            double askedFed = c.groceriesAsked + c.mealsEaten * basketsPerMeal;
            if (c.groceriesNeed > 0 && askedFed < c.groceriesNeed) {
                hungryAtFullShelves += people * (1 - askedFed / c.groceriesNeed);
            }
            /*
             * READ, THEN CLEARED, here rather than in clearWorking(), because
             * this field is the one thing in the cell that is deliberately a
             * month old. Leaving it would feed a household the same dinner
             * every month for ever.
             */
            c.mealsEaten = 0;
        }

        /*
         * WHO DID THE SHOPPING, decided before anything is overwritten.
         *
         * The row's takings are split across its cells by the baskets each
         * was handed at the sale (0.7.43; by the plan until then) - a cell
         * that was priced out is a cell that bought less, not one that ran a
         * deficit, and since every basket was charged the one price, each
         * cell pays exactly its baskets at it. With nothing handed over yet
         * (the founding month) the split follows people, which is what the
         * model did before there was a budget.
         */
        double[] shopWeight = new double[cells.length];
        double[] rowShopWeight = new double[ROWS];
        boolean[] rowHasPlan = new boolean[ROWS];
        for (Household c : cells) {
            if (c.groceriesGot * c.households > 0) rowHasPlan[c.row()] = true;
        }
        for (int i = 0; i < cells.length; i++) {
            Household c = cells[i];
            shopWeight[i] = rowHasPlan[c.row()] ? c.groceriesGot * c.households : fresh[i] * c.headcount();
            rowShopWeight[c.row()] += shopWeight[i];
        }

        /* ---- what each cell is handed, per household ---- */
        double[] disposablePer = splitIncome(fresh, rowDisposable);
        double[] feesPer = splitByPeople(fresh, rowFees);
        /*
         * ...AND THE TWO TREATMENT BILLS BESIDE THEM (2026-09-19), per
         * household by the same heads: what the row was billed for treatment
         * and what it would have been billed at full service, for the
         * affordability test at the bottom of the loop. The bill itself is
         * not re-split here - see the banner on setCareBills() for why the
         * relief stays at the row.
         */
        double[] careBilledPer = careBillByRow == null ? new double[cells.length]
                : splitByPeople(fresh, careBillByRow);
        double[] careFullPer = careBillFullByRow == null ? new double[cells.length]
                : splitByPeople(fresh, careBillFullByRow);
        careBillByRow = null;
        careBillFullByRow = null;
        double[] buffer = new double[cells.length];
        for (int i = 0; i < cells.length; i++) {
            buffer[i] = Math.max(0, disposablePer[i]) * OPENING_BUFFER_MONTHS;
        }

        /* ---- the stock belongs to the people, not to the cells ---- */
        followThePeople(fresh, buffer);

        /* ---- and every household's month ---- */
        plannedSpend = 0;
        for (int i = 0; i < cells.length; i++) {
            Household c = cells[i];
            if (c.isEmpty()) {
                // Too few to strike - the position stands, carried for the
                // month the cell fills, and the working is blank.
                c.clearWorking();
                continue;
            }
            double spentPer = rowShopping == null || rowShopWeight[c.row()] <= 0 ? 0
                    : rowShopping[c.row()] * shopWeight[i] / rowShopWeight[c.row()] / c.households;

            c.rentShare = Math.max(0, rentShares.applyAsDouble(c));
            double rentDue = rentPerHousehold * c.rentShare;
            c.studentLoanRate = studentLoanRate;
            // ...and the bank's account fee with the other fixed bills (0.7.7).
            double accountDue = accountFeeFor(c, c.households);
            double feesDue = feesPer[i] + accountDue;
            c.settle(disposablePer[i], rentDue, feesDue, spentPer,
                    foodPricePerHead, riskFreeAnnual, liquidity, localPerUsd);
            c.accountFee = accountDue;

            /*
             * EVICTION (2026-09-11). Jerus: once EI is over and the savings are
             * gone, a share leaves and the rest are unhoused. The cells are
             * averages, so the share of the fixed bills nobody could fund is
             * the share of the households who could not pay them - a level
             * struck from the month, not a rate typed in. Unemployment moves
             * them next month.
             */
            if (c.canBeEvicted() && c.unfunded > 0 && rentDue > 0) {
                double bills = rentDue + feesDue + c.interest;
                c.evicted = c.households * Math.min(1, c.unfunded / bills);
                lastEvicted += c.evicted;
            }

            lastWrittenOff += c.discharge();
            lastLeaving += c.bankrupt * LEAVE_ON_BANKRUPTCY;

            // The food assistance voucher, on the month just settled, before
            // the plan adds it to the money the household takes to the grocer -
            // its means test on the year's investment income, smoothed here
            // once a month (0.7.45; see MEANS_INCOME_MONTHS).
            c.meansIncome += (Math.max(0, c.investmentIncome) - c.meansIncome) / MEANS_INCOME_MONTHS;
            c.voucher = foodAssistanceFor(c, foodPricePerHead);
            plannedSpend += c.plan(localPerUsd, paperRatio, spendFactor, bondRatio) * c.households;

            /*
             * AND WHETHER IT CAN AFFORD THE CLINIC (2026-09-19), asked last,
             * of the plan just struck: what fits after a basket for everybody
             * is paid, and the rest of its people go without care rather
             * than without food. See Household.affordCare(). With no bill -
             * a caller that does not price care, or a fee scale of 0 -
             * everybody is served.
             */
            c.affordCare(careFullPer[i], careBilledPer[i]);
            lastCareSkipped += c.careSkipped * c.households;
        }

        /*
         * AND THE MONTH'S INVESTMENT INCOME IS SPENT ONCE (2026-09-17).
         *
         * Cleared HERE, after every cell has planned, and not at the top of
         * this method beside `c.dividends = 0`. Two reasons, and the second is
         * the one that would have cost a day:
         *
         * IT HAS TO SURVIVE UNTIL plan(), which runs at the bottom of the loop
         * above. Clearing it at the top would hand every household a zero.
         *
         * AND THE LOAD PATH MUST REPRODUCE THE SAME PLAN. The restrike loop in
         * planOnly() re-plans without coming through here, so anything
         * plan() reads has to be a SAVED stock that a reload restores
         * unchanged - which is why investmentIncome is saved and why nothing
         * clears it except this line. A field cleared inside plan() would give
         * one answer live and another on reload, and LongPlaytest compares
         * those two every single month.
         *
         * (One input breaks the rule since 0.7.3: the spend factor, which is
         * not saved. The load path strikes it on the deposit rate and the
         * index the save restored - the month's closing figures, the ones the
         * NEXT month's plan is struck at - so a reloaded plan is not the saved
         * month's to the bit. The design note, the-demand-channel.md section
         * 4, reads it as harmless because the retail capacity is carried; it
         * is on the list.)
         */
        for (Household c : cells) c.investmentIncome = 0;
    }

    /**
     * A seven-row array - the tiers and the retired, from a caller written
     * before the people outside the families had rows - padded with empty
     * rows. Nobody is in them unless the outside census says so.
     */
    private static double[] padRows(double[] rows) {
        if (rows == null || (rows.length != ROWS_BEFORE_OUTSIDE
                && rows.length != Household.ROWS_BEFORE_PRISON)) return rows;
        return java.util.Arrays.copyOf(rows, ROWS);
    }

    /** Who lives in each cell now, in cell order. */
    private double[] takeCensus(ToDoubleBiFunction<FamilyStructure, PayTier> census) {
        double[] fresh = new double[cells.length];
        PayTier retiredSlot = PayTier.values()[0];
        for (int i = 0; i < cells.length; i++) {
            Household c = cells[i];
            if (c.shape() == null) {
                fresh[i] = Math.max(0, outsideCensus.applyAsDouble(c));
                // Struck with the count, from the same month's rebuild.
                c.dependants = Math.max(0, outsideDependants.applyAsDouble(c));
            } else {
                fresh[i] = Math.max(0, census.applyAsDouble(c.shape(),
                        c.isRetired() ? retiredSlot : c.tier()));
            }
        }
        return fresh;
    }

    /**
     * A row's take-home, per household of each of its cells.
     *
     * By grown-ups: the tier's wage bill divided among its earners, the
     * pension bill among its pensioners. A couple takes home twice a single
     * adult's pay at the same tier, which is most of why the two can afford
     * such different lives - and it is the same arithmetic
     * HouseholdAccounts.statementFor() shows the player, so the cell's books
     * and the screen's statement agree.
     */
    private double[] splitIncome(double[] fresh, double[] rowTotal) {
        double[] rowWeight = new double[ROWS];
        for (int i = 0; i < cells.length; i++) {
            rowWeight[cells[i].row()] += fresh[i] * cells[i].earningWeight();
        }
        double[] per = new double[cells.length];
        for (int i = 0; i < cells.length; i++) {
            Household c = cells[i];
            per[i] = rowWeight[c.row()] > 0
                    ? rowTotal[c.row()] * c.earningWeight() / rowWeight[c.row()] : 0;
        }
        return per;
    }

    /** A row's fees, per household of each of its cells, by the people in them. */
    private double[] splitByPeople(double[] fresh, double[] rowTotal) {
        double[] per = new double[cells.length];
        if (rowTotal == null) return per;
        double[] rowWeight = new double[ROWS];
        for (int i = 0; i < cells.length; i++) {
            rowWeight[cells[i].row()] += fresh[i] * cells[i].headcount();
        }
        for (int i = 0; i < cells.length; i++) {
            Household c = cells[i];
            per[i] = rowWeight[c.row()] > 0
                    ? rowTotal[c.row()] * c.headcount() / rowWeight[c.row()] : 0;
        }
        return per;
    }

    /* =====================================================================
       THE STOCK BELONGS TO THE PEOPLE, NOT TO THE CELLS

       FamilyModel re-allocates every household from the pyramid and the job
       mix each month, so a cell's count moves for reasons that have nothing
       to do with anybody arriving or leaving: a child turns thirteen and a
       COUPLE_CHILD becomes a COUPLE_TEEN; five single adults take a flatshare;
       a job mix that shifts a point moves a point of every shape up a tier; a
       worker turns sixty-five. The people in those households are the same
       people with the same money, and a ledger that let a cell's stock
       evaporate every time its count fell would be a ledger of nothing - which
       is exactly why the stocks used to be kept per tier.

       So when a cell loses households, what they had goes into a pool: their
       savings and their debt, at the cell's own average. The cells that gained
       households draw on it. Within the tier first - a family's child ageing
       is the commonest move by far and it never crosses a tier - and then
       across the city, for the retirements and the job changes. Only what no
       cell claims has actually left the city, and only a gain no pool covers
       is a genuine arrival:

           left the city   savings gone with them; debt written off to the bank,
                           which is a real loss to whoever lent it
           arrived         no debt, and the same opening buffer a founding
                           household gets - people who move somewhere new have,
                           by revealed preference, been able to afford to

       Which is what the old per-row rule did at the row's edge, now done at
       the city's edge, with everything inside it conserved.

       WEIGHTED BY GROWN-UPS, not by households. Five singles becoming one
       flatshare is five households lost and one gained; counted by household
       four of them would have "left the city" and the flatshare would inherit
       a fifth of their money. Counted by the adults in them it is five for
       five, and the flatshare carries five wallets. A couple splitting is two
       for two; a child arriving brings nothing and takes nothing; one of a
       senior couple dying leaves half the position to the survivor and takes
       the other half out - because that is who carries the money.
       ===================================================================== */

    /** The bonds' ids in the order stocks() last listed them, one stock each from its named slot. */
    private int[] bondStockIds = new int[0];

    /** One stock a household carries, for followThePeople() to move. */
    private interface Stock {
        double get(Household c);
        void set(Household c, double perHousehold);
    }

    /**
     * Every stock a household carries, in the order followThePeople() moves
     * them and foldEmptyCells() folds them. Adding a stock is adding it here.
     *
     * @param named where to write the two positions the census names - the
     *              student loan's at [0] and the city's paper's at [1] - or null
     */
    private java.util.List<Stock> stocks(int[] named) {
        java.util.List<Stock> stocks = new java.util.ArrayList<>();
        stocks.add(new Stock() {
            public double get(Household c) { return c.savings; }
            public void set(Household c, double v) { c.savings = v; }
        });
        stocks.add(new Stock() {
            public double get(Household c) { return c.debt; }
            public void set(Household c, double v) { c.debt = v; }
        });
        for (int k = 0; k < Equity.COMPANIES.length; k++) {
            final int company = k;
            stocks.add(new Stock() {
                public double get(Household c) { return c.shares[company]; }
                public void set(Household c, double v) { c.shares[company] = v; }
            });
        }
        stocks.add(new Stock() {
            public double get(Household c) { return c.abroad; }
            public void set(Household c, double v) { c.abroad = v; }
        });
        // The student loan follows the graduate into a family - and out of
        // the city with one who leaves, which the treasury writes off.
        //
        // ITS POSITION IN THE LIST IS NOW NAMED. It used to be "the last one",
        // read off stocks.size() - 1 inside followThePeople()'s loop, true for
        // exactly as long as it was last. The car that follows it would have
        // silently taken the graduates' census and moved the loans on the
        // plain one - nobody's loan wrong by much, everybody's loan wrong.
        if (named != null) named[0] = stocks.size();
        stocks.add(new Stock() {
            public double get(Household c) { return c.studentDebt; }
            public void set(Household c, double v) { c.studentDebt = v; }
        });
        /*
         * AND THE CAR GOES WITH THE PEOPLE (2026-09-16), which is the whole
         * reason it is a household stock rather than a city-wide count. A
         * couple who move in together have two cars between them and then one
         * household; five flatmates who split have a car each. Nobody had to
         * write that down - the pool does not know what it is moving,
         * which is what the note at the top of this section promised the day
         * the shares were added.
         */
        stocks.add(new Stock() {
            public double get(Household c) { return c.cars; }
            public void set(Household c, double v) { c.cars = v; }
        });
        // ...and the city's paper (0.7.1), named like the loans, not "the last one".
        if (named != null) named[1] = stocks.size();
        stocks.add(new Stock() {
            public double get(Household c) { return c.paper; }
            public void set(Household c, double v) { c.paper = v; }
        });
        /*
         * ...and the businesses' bonds (0.7.12), BOND BY BOND since round 2:
         * the cell holds each bond itself now (Household.bondFace), so each is
         * its own stock and follows its holders like a company's shares - a
         * household that moves cell takes its bonds with it, and what nobody
         * claims left the city, bond by bond (BondMarket.householdLeft()).
         * Named from here: the first bond's slot, in bondStockIds' order.
         */
        java.util.TreeSet<Integer> ids = new java.util.TreeSet<>();
        for (Household c : cells) ids.addAll(c.bondFace.keySet());
        if (named != null && named.length > 2) named[2] = stocks.size();
        int[] order = new int[ids.size()];
        int j = 0;
        for (int id : ids) {
            final int bond = id;
            order[j++] = id;
            // Set without the total, which followThePeople() recounts once
            // every bond has moved: a recount per bond per cell is the
            // square of the bonds a cell holds, every month.
            stocks.add(new Stock() {
                public double get(Household c) { return c.bondFace(bond); }
                public void set(Household c, double v) { if (v > 0) c.bondFace.put(bond, v); else c.bondFace.remove(bond); }
            });
        }
        bondStockIds = order;
        return stocks;
    }

    /**
     * Moves every stock with the people, then sets every cell's count.
     *
     * Savings, debt, and the shares in each company - the same pool, the same
     * weights, one at a time. Adding a stock is adding it to stocks();
     * the arithmetic does not know what it is moving.
     *
     * @param fresh  households in each cell now
     * @param buffer what a newly arrived household of each cell brings, in savings
     */
    private void followThePeople(double[] fresh, double[] buffer) {
        int[] named = new int[3];
        java.util.List<Stock> stocks = stocks(named);
        final int loanSlot = named[0];
        final int paperSlot = named[1];
        final int bondSlot = named[2];

        int n = cells.length;
        double[] before = new double[n];
        for (int i = 0; i < n; i++) before[i] = cells[i].households;
        double[] beforeLoans = carryGraduatesLoans(before);

        double[] left = new double[stocks.size()];
        for (int k = 0; k < stocks.size(); k++) {
            boolean loans = k == loanSlot;
            left[k] = moveStock(stocks.get(k), fresh, loans ? beforeLoans : before, k == 0 ? buffer : null);
        }
        // Each cell's bonds total, from the bonds that moved (round 2).
        if (bondStockIds.length > 0) for (Household c : cells) c.recountBonds();
        // What nobody claimed has left the city: the savings with them, the
        // debt on the bank, the shares to wherever they went - held abroad
        // from now on, as far as the register is concerned.
        lastTakenAway += left[0];
        lastWrittenOff += left[1];
        for (int k = 0; k < Equity.COMPANIES.length; k++) lastSharesTakenAway[k] = left[2 + k];
        // ...and the dollars they held abroad go with them: already abroad,
        // so nothing crosses the border - a stock that changes hands.
        lastAbroadTakenAway = left[2 + Equity.COMPANIES.length];
        lastStudentDebtTakenAway = left[3 + Equity.COMPANIES.length];
        // ...and the cars drove out of the city with their owners. Not written
        // off and not sold: a car that left is simply not here any more, which
        // is why nothing but the road reads this.
        lastCarsTakenAway = left[4 + Equity.COMPANIES.length];
        /*
         * ...AND THE CITY'S PAPER IS SOLD ON THE WAY OUT (0.7.1). The shares a
         * leaver held are held abroad from then on, as far as the register is
         * concerned; the city's paper is not - it is on the city's own books,
         * split by holder, and a fourth holder "somewhere else" would be paid
         * coupons nobody could see. So a household that leaves sells what it
         * held to the bank's desk at the month's value first, and the cash
         * leaves with its savings. Without a desk (a bare fixture) it simply
         * goes, which a bare fixture's paper - none - never notices.
         */
        double paperGone = left[paperSlot];
        if (paperGone > 0 && paperDesk != null) {
            double cash = paperGone * paperRatio;
            paperDesk.buy(paperGone, cash);
            lastTakenAway += cash;
        }
        /*
         * ...AND THEIR BONDS ARE HELD FROM ABROAD (0.7.12), as a leaver's
         * shares are: the world is one of a bond's holders, so nothing has to
         * be sold on the way out - nobody is obliged to buy - and the face
         * simply moves from the households' to the world's, bond by bond
         * since round 2.
         */
        lastBondsTakenAway = 0;
        for (int b = 0; b < bondStockIds.length; b++) {
            double gone = left[bondSlot + b];
            if (!(gone > 0)) continue;
            lastBondsTakenAway += gone;
            if (bondMarket != null) bondMarket.householdLeft(bondStockIds[b], gone);
        }

        for (int i = 0; i < n; i++) {
            // A cell that lost households keeps its average: the ones who
            // stayed have what they had.
            cells[i].households = fresh[i];
            if (fresh[i] <= 0) cells[i].clearAll();
        }
        // ...and a cell the census left under half a household is emptied
        // into the rest. See A CELL UNDER HALF A HOUSEHOLD IS EMPTY, below.
        foldEmptyCells(stocks);
    }

    /* =====================================================================
       A CELL UNDER HALF A HOUSEHOLD IS EMPTY (0.7.2)

       The census hands every cell a count, and a count is a real number: a
       shape that has all but gone from a tier comes back as 1e-13 of a
       household, or 1e-16, and whether it lands there or on exactly nothing
       is floating-point noise. The month already treated such a cell as too
       few to strike (the clear at a half), but the payments did not: the
       deposit interest, the theft's proceeds, the tender and the dividends
       all asked "households > 0", so a cell of 1e-15 households was paid -
       and creditByWeight() paid it a whole cell's share, divided by that
       count. On the pristine 0.7.1 tree, after a reform, such cells held
       savings from month 127 on. Which cell is a ghost differs between two
       runs of one city at the fifteenth decimal, so a reformed city and its
       twin parted company on it (DenominationCheck, month 166, 2026-09-22).
       Households are outside the audit, and nothing else could see it.

       So one threshold, EMPTY_CELL, and one test, Household.isEmpty(), at
       every site that writes a count or pays a cell. A cell that falls under
       it is emptied where the count is written, and what it held - savings,
       debt, shares, dollars abroad, student loans, cars, the city's paper -
       is folded into the cells that are not empty, so the household ledger
       conserves. WHERE IT GOES is where the census pool sends a leaver's
       money: its own stock group first (Household.stockGroup() - the row, the
       out of work with the unskilled), then the city; within either, pro rata
       to what each cell already holds of it, and by households where nobody
       does. The group comes first because the city-wide pro rata alone
       would be regressive: an unskilled cell's last savings would go mostly to
       the professionals, who hold most of the savings, every month a small
       cell dipped under the line. Nothing is carried for the cell: the month it
       fills again it fills from the pool, like any other cell that grows. Its
       count stands - the census's, not ours to round.
       ===================================================================== */

    /** Fewer households than this in a cell and it is empty: it holds nothing and is paid nothing. */
    public static final double EMPTY_CELL = .5;

    /** Cells the census left under EMPTY_CELL this month that still held something, and were emptied. */
    private int lastCellsFolded;

    /**
     * Empties every cell under EMPTY_CELL into the cells that are not. See
     * the banner above; for the load path and the harnesses.
     *
     * @return how many cells held something to fold
     */
    int foldEmptyCells() { return foldEmptyCells(stocks(null)); }

    private int foldEmptyCells(java.util.List<Stock> stocks) {
        lastCellsFolded = 0;
        boolean anyLive = false;
        for (Household d : cells) if (!d.isEmpty()) { anyLive = true; break; }
        if (!anyLive) return 0;             // nobody left to hold it: it stays where it is
        for (Household c : cells) {
            if (!c.isEmpty()) continue;
            boolean held = false;
            for (Stock s : stocks) {
                double amount = s.get(c) * c.households;
                s.set(c, 0);
                if (amount == 0) continue;
                held = true;
                if (!spread(s, amount, c.stockGroup())) spread(s, amount, -1);
            }
            if (held) lastCellsFolded++;
        }
        // Each cell's bonds total, from the bonds the fold moved (round 2:
        // the bond stocks are set without it - see stocks()).
        if (lastCellsFolded > 0) for (Household c : cells) c.recountBonds();
        return lastCellsFolded;
    }

    /**
     * One stock's amount onto the cells that are not empty, in one stock
     * group (or the whole city, for -1): pro rata to what each holds of it,
     * or by households when none holds any.
     *
     * @return false when the group has no cell that is not empty, and nothing moved
     */
    private boolean spread(Stock s, double amount, int group) {
        double base = 0, live = 0;
        for (Household d : cells) {
            if (d.isEmpty() || (group >= 0 && d.stockGroup() != group)) continue;
            live += d.households;
            if (s.get(d) > 0) base += s.get(d) * d.households;
        }
        if (!(live > 0)) return false;
        if (base > 0) {
            double scale = 1 + amount / base;
            for (Household d : cells) {
                if (d.isEmpty() || (group >= 0 && d.stockGroup() != group)) continue;
                if (s.get(d) > 0) s.set(d, s.get(d) * scale);
            }
        } else {
            double each = amount / live;
            for (Household d : cells) {
                if (d.isEmpty() || (group >= 0 && d.stockGroup() != group)) continue;
                s.set(d, s.get(d) + each);
            }
        }
        return true;
    }

    /** True when the cell holds any stock at all, which an empty cell must not. For the harnesses. */
    boolean holdsAnything(Household c) {
        for (Stock s : stocks(null)) if (s.get(c) != 0) return true;
        return false;
    }

    /** Cells emptied this month that still held something when the census left them under EMPTY_CELL. */
    public int getCellsFolded() { return lastCellsFolded; }

    /**
     * The graduates' student loans, handed to the working families before the
     * census moves anything. See setGraduates().
     *
     * Straight to the families, by grown-ups, and not through the pool: the
     * pool is anonymous, and in a college that takes in as many as it lets out
     * the only household claiming what the graduates released would be the
     * freshers. Only the loan goes this way. Their savings and everything else
     * still move on the net change, as every other household's do.
     *
     * @param before every cell's households coming into the month
     * @return the same, less the graduates on the students cell - the loans
     *         the census still has to move are carried by the ones who stayed
     */
    private double[] carryGraduatesLoans(double[] before) {
        double[] out = before.clone();
        lastGraduated = 0;
        double leaving = graduating;
        graduating = 0;
        Household s = students();
        if (s == null || leaving <= 0 || s.households <= 0) return out;

        double weight = 0;
        for (Household c : cells) {
            if (c instanceof WorkingHousehold && !c.isEmpty()) weight += c.households * c.grownUps();
        }
        if (weight <= 0) return out;            // nobody working to carry it: it stays with the students

        double graduates = Math.min(leaving, s.households);
        double carried = s.studentDebt * graduates;
        for (Household c : cells) {
            if (c instanceof WorkingHousehold && !c.isEmpty()) {
                c.studentDebt += carried * c.grownUps() / weight;
            }
        }
        for (int i = 0; i < cells.length; i++) {
            if (cells[i] == s) out[i] = s.households - graduates;
        }
        lastGraduated = graduates;
        return out;
    }

    /**
     * One stock through the pool: released by the cells that shrank at their
     * own average, claimed by the cells that grew - within the row first, then
     * across the city - and what nobody claimed returned.
     *
     * @param before  the households each cell's stock was carried by coming in:
     *                the cell's count, except where some already left with it
     *                (the graduates and their loans - see carryGraduatesLoans())
     * @param arrival what a household nobody released brings of this stock,
     *                per cell, or null for nothing
     * @return the total of this stock that left the city
     */
    private double moveStock(Stock stock, double[] fresh, double[] before, double[] arrival) {
        int n = cells.length;
        double[] rowLoss = new double[ROWS];
        double[] rowGain = new double[ROWS];
        double[] rowPool = new double[ROWS];

        // Matched within the cell's stock group first - its own row, except for
        // the out of work, who move with the unskilled tier. See Household.stockGroup().
        double[] delta = new double[n];
        for (int i = 0; i < n; i++) {
            Household c = cells[i];
            delta[i] = fresh[i] - before[i];
            double weight = Math.abs(delta[i]) * c.grownUps();
            if (delta[i] < 0) {
                rowLoss[c.stockGroup()] += weight;
                rowPool[c.stockGroup()] += stock.get(c) * -delta[i];
            } else if (delta[i] > 0) {
                rowGain[c.stockGroup()] += weight;
            }
        }

        /* =================================================================
           EVERY SHARE HERE IS A FRACTION, AND IS HELD TO BEING ONE (2026-09-16)

           `moved` is a MINIMUM of the two sides, so every ratio below is at
           most one on paper - and `weight * moved / gain` with moved == gain
           can still come back a ULP ABOVE `weight`, which makes `rest`
           a hair NEGATIVE. A negative share hands a cell a negative slice of
           the pool, and from then on the cell is carrying a signed residue
           instead of a position.

           WHY THAT IS NOT HARMLESS, AND HOW IT WAS FOUND. The residue is
           1e-29 of a dollar and nothing reads it as money - but something
           reads its SIGN. investAbroad() asks `c.debt <= 0` to decide whether
           a household may keep money abroad, and a negative dust reads
           debt-free while a positive dust reads indebted. DenominationCheck
           ran a city and its reformed twin exactly together for 158 months
           and then parted: the reform changed the last bit of this
           cancellation, four retired cells flipped, their money abroad came
           home at HOME_SPEED, the financial account moved by thousands, and
           with it the exchange rate - which is every import and export price
           in the city. By the decade the two were 2-4% apart on population,
           GDP, rent, the price level and the bank. NINE FIXTURES IN TEN NEVER
           SAW IT; the sign of a residue is luck and this fixture was unlucky.

           THE CLAMPS ARE EXACT AND FREE OF UNITS. A cell cannot take more
           than its own weight from its own row, and a pool cannot hand out
           more than it holds. No tolerance, no figure in dollars - a bound in
           absolute money is the mistake this project keeps finding, and the
           way not to make it again is not to write a number at all.
           ================================================================= */

        /* ---- within each row first ---- */
        double[] rowMoved = new double[ROWS];
        double cityPool = 0, cityLoss = 0, cityGain = 0;
        for (int r = 0; r < ROWS; r++) {
            double moved = Math.min(rowLoss[r], rowGain[r]);
            rowMoved[r] = moved;
            if (rowLoss[r] > 0) {
                double kept = Math.min(1, moved / rowLoss[r]);
                cityPool += rowPool[r] * (1 - kept);
                rowPool[r] *= kept;
                cityLoss += Math.max(0, rowLoss[r] - moved);
            }
            cityGain += Math.max(0, rowGain[r] - moved);
        }

        /* ---- then across the city ---- */
        double cityMoved = Math.min(cityLoss, cityGain);
        double cityKept = cityLoss > 0 ? Math.min(1, cityMoved / cityLoss) : 0;
        double gone = cityPool * (1 - cityKept);
        cityPool *= cityKept;
        double cityShare = cityGain > 0 ? Math.min(1, cityMoved / cityGain) : 0;

        /* ---- and hand it out ---- */
        for (int i = 0; i < n; i++) {
            Household c = cells[i];
            if (delta[i] <= 0 || c.grownUps() <= 0) continue;
            int r = c.stockGroup();
            double weight = delta[i] * c.grownUps();
            double fromRow = rowGain[r] > 0 ? Math.min(weight, weight * rowMoved[r] / rowGain[r]) : 0;
            double rest = Math.max(0, weight - fromRow);
            double fromCity = Math.min(rest, rest * cityShare);
            double newcomers = Math.max(0, rest - fromCity) / c.grownUps();

            double received = (rowMoved[r] > 0 ? rowPool[r] * fromRow / rowMoved[r] : 0)
                    + (cityMoved > 0 ? cityPool * fromCity / cityMoved : 0);
            double brought = arrival == null ? 0 : newcomers * arrival[i];

            /*
             * AND THE POSITION IS CLAMPED ON THE WAY IN (2026-09-16).
             *
             * Every stock this method moves is a thing a household HOLDS -
             * savings, debt, shares in a company, dollars abroad, a student
             * loan - and not one of them can be less than nothing. The share
             * clamps above stop a cell taking a negative SLICE; this stops a
             * cell ending up with a negative POSITION, which is the same
             * defect one step further on and reachable by a different route:
             * a pool that is itself a hair negative divides out into every
             * cell that draws on it, month after month.
             *
             * Found by the eight-seed ensemble on the day the railway started
             * buying locomotives. Seed 2 carried `debt -4.61e-19` on one cell
             * for THREE THOUSAND MONTHS - 35,199 flagged months against the
             * dozen the known rounding noise produces - because once a cell
             * holds a signed dust it hands it on to everyone it shares a pool
             * with. Nothing about rolling stock was wrong; the trajectory
             * simply put a cell somewhere the old residue could persist.
             *
             * WHY THE SIGN MATTERS WHEN THE MAGNITUDE CANNOT: investAbroad()
             * asks `c.debt <= 0` to decide whether a household may hold money
             * abroad, so a negative dust reads debt-free and a positive one
             * reads indebted. See the header above this loop for the 158-month
             * divergence that cost.
             *
             * Exact, and free of units, for the reason written up there: a
             * bound in absolute money is the mistake this project keeps
             * finding, and the way not to make it again is not to write a
             * number at all.
             */
            double position = (stock.get(c) * before[i] + received + brought) / fresh[i];
            stock.set(c, position > 0 ? position : 0);
        }
        return gone;
    }

    /** Shares of each company that left the city with their holders this month. */
    private final double[] lastSharesTakenAway = new double[Equity.COMPANIES.length];
    public double getSharesTakenAway(int company) { return lastSharesTakenAway[company]; }

    /* =====================================================================
       THE CARS (2026-09-16)

       Jerus, on how ownership should work: "income decides who can afford
       one, good transit makes people not bother" - and, on what it should do
       to the street, "if everyone has cars then road demand is enormous".

       WHAT THE MEASUREMENT SAID BEFORE A LINE OF THIS WAS WRITTEN, because it
       decided the shape. A six-hundred-month city: an UNSKILLED couple takes
       home $4,880 a month, banks $3,160 of it, and is sitting on $799,100 -
       a hundred and sixty-four months of income. Every cell in the city is
       between a hundred and three hundred months. Total household savings
       $17.6bn against zero household debt.

       That is not a rich city, it is a city WITH NOTHING TO BUY. Rent is
       rent, the grocery basket is capped at what a person eats, and every
       dollar past those two has had nowhere to go since the game was written.
       A car is the first durable this city has ever been able to own, and the
       pile is why affordability barely binds in a mature one and binds hard
       in a young one - which is exactly the right way round and took no
       tuning at all.

       SO THE CONSTRAINT IS NOT MONEY, IT IS TIME. Everybody could buy a car
       this month; nobody does, because that is not how a country motorises.
       CAR_ADOPTION spreads it over about three decades of game time, and the
       fleet then holds itself up against CAR_LIFE_MONTHS for ever after. The
       road feels the level, the industry feels the flow, and the two settle
       at different times - which is the interesting part.

       WHAT REPLACEMENT IS NOT THROTTLED BY. A household whose car has died
       buys another at once; only a household that has NEVER owned one waits
       its turn. Put the diffusion rate on both and the fleet plateaus at 78%
       for ever, which is an arithmetic accident of two constants and not a
       fact about anywhere.
       ===================================================================== */

    /** How long a car lasts. Fifteen years, and then it is replaced or it is not. */
    public static final double CAR_LIFE_MONTHS = 180;

    /**
     * What share of the households who have never owned a car buy one in a
     * month, before they are asked whether they can afford it.
     *
     * A DIFFUSION RATE AND NOT A PREFERENCE. Two percent is a half-life of
     * about thirty-five months, so a city that could motorise instantly takes
     * something like three decades to get most of the way - which is roughly
     * what motorisation took everywhere it happened, and is slow enough that a
     * player watches it rather than being handed it.
     */
    public static final double CAR_ADOPTION = .02;

    /**
     * How much of the wanting a fully-served transit system takes away.
     *
     * The other half of Jerus's rule. This is the ONLY place transit touches
     * the decision to BUY; what it does to the decision to DRIVE, on a given
     * morning, with a car already in the drive, is InfrastructureManager's and
     * is a different mechanism. Since 0.7.49 it is scaled by the share of the
     * households to whom a month's pass beats a car's full monthly cost
     * (Motoring, THE BUYER WEIGHS THE FARE): at the default fare that share
     * is 1 and the ceiling is what it was.
     *
     * IT IS A CEILING ON OWNERSHIP AND NOT A BRAKE ON ADOPTION, and the
     * difference is the whole of whether a player has a move here. Scaled
     * against the RATE it only delays: a well-served city motorises at half
     * speed and arrives at the same place a few decades later, so transit buys
     * a postponement and nothing else. Against the LEVEL it is a decision - a
     * city whose lines could carry everybody tops out at half a car per
     * household, for ever, because half of its households never bother owning
     * one.
     *
     * AND IT WORKS BACKWARDS TOO, which is the part worth building for. A city
     * that motorises first and builds its metro afterwards does not lose its
     * cars overnight; it stops REPLACING them, and the fleet decays over
     * CAR_LIFE_MONTHS toward what the new ceiling allows. Fifteen years to
     * unmotorise, which is about what it takes.
     */
    public static final double TRANSIT_DETERRENT = .5;

    /* =====================================================================
       AND THEY BORROW FOR IT (2026-09-17)

       Jerus: "make it so that citizens the car requirements are lowered and
       instead they finance with the bank."

       WHAT WAS WRONG WITH THE FIRST VERSION, and it is worse than a high bar.
       A household had to have the WHOLE price in spare savings, and - this is
       the part that reads as a bug rather than a dial - it was refused
       outright if it owed a single dollar to anybody. `c.debt > 0` was in the
       gate, copied from the share offer, where it belongs: a family that
       cannot pay its grocer has no business speculating on equities. A car is
       not a speculation. Nobody on earth buys one that way, and a family that
       is $40 down on a bad month is not thereby barred from driving to work.

       SO A HOUSEHOLD PAYS WHAT IT HAS AND BORROWS THE DIFFERENCE, against the
       SAME credit room the grocery waterfall uses - no new ceiling, no new
       field, no second debt to save. A family that can buy the car outright
       still does, and still owes nothing.

       WHICH IS DELIBERATELY NOT "A FIFTH DOWN AND FOUR FIFTHS BORROWED", and
       that was the first draft, and the ensemble threw it out. These
       households are cash-RICH and income-POOR: a hundred and sixty months of
       take-home in savings against a credit line of six. Making the loan
       mandatory moved the binding constraint off the thing they have and onto
       the thing they have not, and ownership at month 266 fell from 42% to
       11% - the opposite of what was asked for. Pay-what-you-have reduces
       exactly to the old cash rule when the credit line is zero, so it cannot
       refuse a purchase the rule it replaced would have allowed. That is the
       property to preserve if this is ever touched again.

       WHERE IT ACTUALLY BITES is the young city and not the rich one. Eight of
       the playtest's seeds run four thousand months and seven of them come out
       bit-identical, because a mature city's households are never short of the
       cash; the education fixture's city, which is poor and growing, diverges
       in month EIGHT and buys nearly twice the cars by month ten. Lowering a
       requirement can only show up where the requirement was binding.

       WHAT THAT COSTS THE HOUSEHOLD, deliberately: a family carrying a car
       loan is four months closer to its ceiling, so the month it goes short it
       reaches the discharge sooner. Household debt in this game has been
       exactly zero in every measured city; this is the first thing that puts a
       real credit cycle on the residents, and a city where everybody financed
       a car is a city with something to lose. That is the game.
       ===================================================================== */

    /**
     * The least of a car's price a household must find in cash before a lender
     * will put up the rest.
     *
     * A MINIMUM AND NOT AN INSTALMENT. A household hands over every dollar it
     * has spare and borrows what is left, so most buyers put down far more
     * than this; what the fifth does is stop a family with nothing borrowing a
     * car into existence. The deposit is a test of savings and savings are a
     * test of income, so Jerus's rule - "income decides who can afford one" -
     * survives the change intact. It is the level it bites at that moved.
     */
    public static final double CAR_DEPOSIT = .20;

    /**
     * How much of what a household could still borrow a lender will actually
     * advance against a car.
     *
     * NO UNDERWRITER LENDS YOU YOUR LAST DOLLAR, which is the honest reading
     * and is genuinely how car finance works: the line is sized so that the
     * borrower can still absorb a bad month, because a borrower who cannot is
     * a borrower who defaults. Half leaves a financed household three months
     * of its six-month ceiling free.
     *
     * AND IT WAS FOUND BY A HARNESS RATHER THAN REASONED TO, which is worth
     * saying. Without it, every financed household parked itself within a
     * whisker of BANKRUPT_AT_MONTHS - the discharge fires at
     * `debt >= 5.88 x disposable` - and a currency reform sent the two cities
     * to opposite sides of that comparison within a year. DenominationCheck
     * went red on nine assertions: bit-identical the month after the reform,
     * 9% apart on output a year later, which is the signature of a discrete
     * decision taken differently once rather than of an arithmetic that
     * drifts. The comparison itself is sound - both sides are money, so a
     * reform moves them together - and a threshold grazed by every household
     * every month will be crossed differently eventually whatever the
     * arithmetic. The fix is not to sharpen the knife; it is to stop standing
     * on it.
     */
    public static final double CAR_CREDIT_SHARE = .5;

    /* =====================================================================
       THE SECOND-HAND MARKET (2026-09-17)

       Jerus: "if they are doing bad they cut back expenses, sell their cars or
       go for cheaper groceries and so on."

       WHAT A HOUSEHOLD IN TROUBLE DID BEFORE THIS. The waterfall in
       Household.settle() was savings, then the paper abroad, then the shares,
       then the credit line, then going without - and a CAR was in none of it.
       A family could sell every share it owned, draw its last dollar of credit
       and then go hungry with five months of take-home parked in the drive,
       for fifteen years, until the thing wore out. That is not poverty; that is
       an asset the model could not see.

       SO THEY SELL IT, AND SOMEBODY BUYS IT. Jerus's call, and the harder of
       the two: the alternative was selling it abroad, which is one line and a
       lie - a city's used cars are bought by the people who live in it. The
       fleet does not shrink when a household sells; it CHANGES HANDS, from a
       family that cannot keep it to one that could never have afforded a new
       one. Which is the actual social fact about used cars and is worth having
       in a game about who can afford what.

       AND THE PRICE IS STRUCK, NOT SET, which is where the mechanic comes from.
       It is the same rule GoodsMarket.strike() uses - a floor, a ceiling, and a
       position between them off demand against supply - so it falls out for
       free that A CITY CANNOT SELL ITS WAY OUT OF A GENERAL CRASH. When one
       family is short it offers one car into a market full of buyers and gets
       near the ceiling. When the whole city is short every family offers at
       once, nobody is buying, and the price collapses to scrap. Personal bad
       luck is insurable; a downturn is not. Nobody had to write that down.

       WHERE IT SITS IN THE MONTH, and this is the part that needed care.
       Motoring.month() runs AFTER the household ledger, so by the time this clears,
       every cell's month has been struck: afterFixed, savings, subsistence and
       the credit room are all this month's. A household sells when the month
       AHEAD does not add up - when savings and the whole credit line together
       will not buy the food - so the cash is in the bank before the bills it
       is for. That is a household seeing it coming, which is what people do,
       and it means not one line of the settle waterfall had to change.

       THE SELLERS CANNOT ALSO BE THE BUYERS, and that is free too. wantOf()
       has always refused a cell that is going short, and a cell short of bare
       subsistence is going short by definition - planned is the smaller of
       want and what it can spend, so if it cannot afford subsistence it cannot
       afford want either. A household selling its car this month cannot buy a
       new one this month, and nothing had to be added to say so.
       ===================================================================== */

    /**
     * What a scrapper pays, as a share of a new car.
     *
     * THE FLOOR OF THE BAND, and a share rather than an amount because a bound
     * in absolute money is not a bound - it is a bug waiting for a reform. See
     * the twenty-five constants of that family. A car has metal in it and the
     * metal is worth something, so this is where the price goes when there is
     * nobody at all on the other side.
     */
    public static final double USED_CAR_FLOOR = .15;

    /**
     * ...and what one fetches when buyers are queueing, on the same terms.
     *
     * NEVER THE PRICE OF A NEW ONE. Seventy percent is a two- or three-year-old
     * car in a tight market, and the gap between this and 1.0 is what the
     * showroom sells: a warranty, a choice of colour, and nobody else's miles.
     */
    public static final double USED_CAR_CEILING = .70;

    /** What died this month, per cell, waiting to be replaced. Within-month working. */
    private final double[] carsToReplace;

    /** ...and the cars whose owners left the city. */
    private double lastCarsTakenAway;

    public double getCarsTakenAway() { return lastCarsTakenAway; }

    /** Every car in the city. */
    public double totalCars() { return sum(Household::totalCars); }

    /*
     * WHO HAS A CAR OF THEIR OWN (0.7.49), Jerus's arithmetic per cell: "if
     * one household category has 3k workers and 2k cars, then well, 1k has
     * to take transit cause they have no choice". The working cells only
     * (rows under RETIRED_ROW): each household's grown-ups are its commuters,
     * and it holds at most one car, so a couple's second earner and four of
     * five flatmates have none. Pure reads of the cells; see
     * InfrastructureManager, WHO RIDES, BY WHAT THEY PAY.
     */

    /** The working cells' commuters by row: households times grown-ups. */
    public double[] commuteWorkersByRow() {
        double[] w = new double[Household.ROWS];
        for (Household c : cells) {
            if (!c.isEmpty() && c.row() < Household.RETIRED_ROW) w[c.row()] += c.households * c.grownUps();
        }
        return w;
    }

    /** ...and the cars they hold by row, at most one per grown-up: households times the lesser of the two. */
    public double[] commuteCarsByRow() {
        double[] k = new double[Household.ROWS];
        for (Household c : cells) {
            if (!c.isEmpty() && c.row() < Household.RETIRED_ROW) {
                k[c.row()] += c.households * Math.min(c.cars, c.grownUps());
            }
        }
        return k;
    }

    /** The share of those commuters with no car of their own; 1 with no commuters. */
    public double captiveShare() {
        double[] w = commuteWorkersByRow(), k = commuteCarsByRow();
        double workers = 0, cars = 0;
        for (int r = 0; r < w.length; r++) { workers += w[r]; cars += k[r]; }
        return workers > 0 ? Math.max(0, workers - cars) / workers : 1;
    }

    /** Cars per household, 0 to 1 - what the road reads. */
    public double carsPerHousehold() {
        double homes = sum(Household::households);
        return homes > 0 ? Math.min(1, totalCars() / homes) : 0;
    }

    /**
     * Fifteen years on, every car in the city is scrapped.
     *
     * Runs whether or not anything can be bought to replace it, because that
     * is what makes ownership something a city can LOSE: a crash that empties
     * the savings does not take the cars away this month, it takes them away
     * over the fifteen years nobody can replace one.
     *
     * @return cars scrapped
     */
    public double wearOutCars() {
        double gone = 0;
        for (int i = 0; i < cells.length; i++) {
            Household c = cells[i];
            double worn = c.cars > 0 ? c.cars / CAR_LIFE_MONTHS : 0;
            carsToReplace[i] = worn;
            if (worn <= 0) continue;
            c.cars = Math.max(0, c.cars - worn);
            gone += worn * c.households;
        }
        return gone;
    }

    /**
     * What the households would buy this month at this price, before the
     * market says how many there are.
     *
     * THE SAME FOUR GATES THE SHARE OFFER USES - no debt, not locked out, not
     * going short, and a household that can hold anything at all - and the
     * same cushion, which was Jerus's call the day the shares went in: one
     * rule for idle money, and the rich still buy more because they have more
     * past it.
     *
     * AFFORDABILITY IS A FRACTION RATHER THAN A CLIFF. A cell is an average of
     * thousands of households, so "this cell can afford four tenths of a car
     * each" is the honest reading of "two fifths of these households can
     * afford one" - and it is the reading that makes a poor city motorise
     * slowly instead of all at once on the month its savings cross a line.
     *
     * @param price   what one car costs here
     * @param ceiling cars per household this city will own at all: 1 where
     *                nobody has a tram - see TRANSIT_DETERRENT
     * @return cars, city-wide
     */
    public double carsWanted(double price, double ceiling) {
        if (!(price > 0)) return 0;
        double total = 0;
        for (int i = 0; i < cells.length; i++) total += wantOf(i, price, ceiling);
        return total;
    }

    /* =====================================================================
       WHOLE CARS, AND WHY THE FLOOR IS LOAD-BEARING (2026-09-16)

       The affordability test is a MONEY RATIO - what a household has spare,
       over what a car costs - and it comes out of this method as a PHYSICAL
       QUANTITY that the road, the goods market and the trade balance all then
       read. Nothing else in this file does that. Every other household
       decision multiplies money by a scale-free fraction and stays money.

       A currency reform divides every amount by a hundred, and (a/100)/(b/100)
       is not a/b - it is a/b give or take a unit in the last place. So a
       reformed city wanted an ulp more or less of a car than the plain one,
       bought it from a different place, and the two cities' trade balances
       parted company: DenominationCheck went red on sixteen assertions, the
       first of them the exchange rate four decimals in, one month after the
       reform.

       THIS IS THE MONEY-CONSTANT FAMILY WEARING A NEW COAT. The other
       twenty-three are absolute amounts that a reform walks past a threshold;
       this one is scale-INVARIANT in arithmetic and not in floating point, and
       it bites for the same reason: a quantity crossing from the money world
       into the physical one has to cross at a grain coarser than the dust.

       So a cell buys WHOLE CARS. It is also the truer statement - a cell is
       thousands of households and "four hundred and seven cars" is what
       happens - and the grain is far coarser than any rounding: a cell that
       wants 407.0000000000001 cars and one that wants 406.9999999999999 both
       buy 406, which is the same answer the shops reach by flooring a basket
       count (see Retail.sellOwnPriced) and for exactly the same reason.
       ===================================================================== */

    /** What one cell would buy this month, in whole cars. */
    private double wantOf(int i, double price, double ceiling) {
        Household c = cells[i];
        /*
         * THE DEBT GATE IS GONE and the lockout is not. Owing money is no bar
         * to buying a car - see CAR_DEPOSIT - but having been DISCHARGED is,
         * because a discharged household cannot borrow at all for a year, and
         * creditRoom() below already returns zero for one. Going short still
         * bars it: a family that cannot buy its groceries this month is not
         * signing a finance agreement this month either.
         */
        if (c.isEmpty() || !c.canInvest() || c.lockout > 0 || c.isGoingShort()) return 0;
        double spare = (c.savings - SHARE_CUSHION_MONTHS * Math.max(0, c.disposable)) * c.households;
        if (spare <= 0) return 0;
        /*
         * THE ROOM IS MEASURED TO THE CEILING, which is what makes a tram
         * something other than a delay - and it is also what lets a fleet
         * SHRINK. A city that motorised and then built a metro has cars above
         * its new ceiling: room is zero, so the month's scrapped cars are not
         * replaced and the fleet walks down to the ceiling over the life of a
         * car. Nothing special had to be written for that; it falls out of
         * replacement being room-limited like everything else.
         */
        double room = Math.max(0, Math.max(0, Math.min(1, ceiling)) - c.cars) * c.households;
        double want = carsToReplace[i] * c.households + room * CAR_ADOPTION;
        /*
         * CASH PLUS WHAT A LENDER WILL FIND, AND A DEPOSIT TEST ON TOP - and
         * the first draft of this was a fixed fifth down and the rest borrowed,
         * which MADE THINGS WORSE and was caught by the ensemble. This model's
         * households are cash-rich and income-poor: they are sitting on a
         * hundred and sixty months of take-home and their credit line is six.
         * Replacing "have the price in savings" with "have a fifth of it and
         * borrow four fifths against income" moved the binding constraint from
         * the thing they have to the thing they have not, and car ownership at
         * month 266 went from 42% to 11%. Jerus asked for the requirement to be
         * LOWERED.
         *
         * So a household pays what it has and borrows the difference. The two
         * limits are what the money stretches to at all, and the deposit test
         * that stops a family borrowing a car into existence with nothing down.
         * With no credit line the first reduces to spare/price, which is
         * exactly the old rule - so this can never refuse a purchase the cash
         * test alone would have allowed.
         */
        double credit = CAR_DEPOSIT >= 1 ? 0
                : c.lendableRoom(c.disposable) * CAR_CREDIT_SHARE * c.households;
        double onMoney = (spare + credit) / price;
        double onDeposit = spare / (price * CAR_DEPOSIT);
        return Math.floor(Math.min(Math.min(want, room), Math.min(onMoney, onDeposit)));
    }

    /**
     * Hands out the cars the market actually had, pro rata over who wanted
     * them, and takes the money out of savings.
     *
     * OUT OF SAVINGS AND NOT OFF THE INCOME STATEMENT, which is the same
     * treatment a cell's share purchase on the book (Exchange) and
     * investAbroad() give: a household turning money
     * into a thing it owns is a portfolio move, not consumption. The month's
     * books do not see it and the balance sheet does - savings down, a car up
     * - which is what happened.
     *
     * @return cash spent
     */
    public double takeCars(double units, double price, double ceiling) {
        if (!(units > 0) || !(price > 0)) return 0;
        lastCarsBought = 0;
        lastCarsFinanced = 0;
        lastCarLoanFees = 0;
        double bought = 0, financed = 0, carFees = 0;
        double[] want = new double[cells.length];
        double total = 0;
        for (int i = 0; i < cells.length; i++) {
            want[i] = wantOf(i, price, ceiling);
            total += want[i];
        }
        if (total <= 0) return 0;
        /*
         * ONE IN THE ORDINARY CASE, and that is worth saying out loud. Cars are
         * importable, so Markets.draw() always returns the units it was asked
         * for - the shelf for what the shelf holds and the world for the rest -
         * and the ratio below is exactly 1. It is here for the day something
         * stops that being true, not for today.
         */
        double scale = Math.min(1, units / total);
        double spent = 0;
        for (int i = 0; i < cells.length; i++) {
            if (want[i] <= 0) continue;
            Household c = cells[i];
            double got = want[i] * scale / c.households;
            // A position, and a position cannot be negative or past its
            // ceiling - the clamp every stock in this file carries, and for
            // the reason HouseholdBalance.moveStock's note gives.
            c.cars = Math.max(0, Math.min(1, c.cars + got));
            /*
             * THE SELLER IS PAID IN FULL; THE HOUSEHOLD PAYS WHAT IT HAS AND
             * BORROWS THE DIFFERENCE. A family that can buy the car outright
             * does, and owes nothing - which is why this change cannot make
             * anybody worse off than the cash rule it replaced. The rest is a
             * loan: the bank's cash goes out of the door the same month
             * (Motoring.month tells it so), the debt sits in the same ledger the
             * grocery borrowing does, and the existing waterfall charges the
             * interest and takes the repayments without knowing what the money
             * was for.
             */
            double bill = got * price;
            double inHand = Math.max(0,
                    c.savings - SHARE_CUSHION_MONTHS * Math.max(0, c.disposable));
            double cash = Math.min(bill, inHand);
            double lent = bill - cash;
            c.savings = Math.max(0, c.savings - cash);
            // ...and the bank's loan fee added to what is owed (0.7.7), as on
            // the credit line. See Household.fundShortfall().
            c.debt += lent * (1 + Bank.LOAN_FEE);
            financed += lent * c.households;
            carFees += lent * Bank.LOAN_FEE * c.households;
            spent += got * price * c.households;
            bought += got * c.households;
        }
        lastCarsBought = bought;
        lastCarsFinanced = financed;
        lastCarLoanFees = carFees;
        return spent;
    }

    /* ---------------------- the second-hand market ---------------------- */

    /**
     * How far ahead a household looks before it decides the car has to go.
     *
     * SIX MONTHS, WHICH IS CREDIT_LIMIT_MONTHS, and the two being the same
     * number is the point rather than a coincidence: a household looks as far
     * ahead as its bank does. A family whose wage no longer covers the food
     * does not sell the car on the first thin month - it eats the savings, and
     * it draws the credit line, exactly as the settle waterfall says. What
     * makes it sell is arithmetic it can do itself: this gap, every month, for
     * half a year, against everything it has and everything it can borrow.
     *
     * AND THE FIRST VERSION OF THIS LOOKED ONE MONTH AHEAD, which sounded
     * strict and honest and was neither. Measured over twelve hundred months of
     * a city played from new: a car-owning cell was SHORT OF THE SHOP in 520 of
     * them and a discharge fired in 513, while the one-month test found only 40
     * - so households went bankrupt with the car still in the drive, thirteen
     * times for every one that sold it. The whole point of the asset is that it
     * is there to be sold BEFORE the crash, and a test that only fires in the
     * month the money actually runs out cannot do that.
     */
    public static final double CAR_SALE_HORIZON_MONTHS = CREDIT_LIMIT_MONTHS;

    /**
     * What one cell would put up for sale this month, in whole cars.
     *
     * THE TEST IS THE MODEL'S OWN WORDS FOR TROUBLE. "Short of the shop" -
     * afterFixed below subsistence - is the same condition discharge() uses,
     * and it means the wage, after the rent and the fees and the interest, no
     * longer buys the food. A household there is living on its savings and its
     * credit line and has a countable number of months before both are gone.
     *
     * JERUS'S ORDERING SURVIVES, AND THIS IS WHERE IT LIVES: savings, then the
     * paper, then the shares, then credit, and the car after all of them. It is
     * in the second line rather than the first - the need is what half a year of
     * the gap comes to LESS everything saved and everything borrowable, so a
     * household that can ride it out on what it has offers nothing at all, and
     * only one that cannot offers anything.
     *
     * AND IT SELLS WHAT IT NEEDS, NOT WHAT IT HAS. The need valued at the FLOOR
     * - what a scrapper would pay - because a family deciding whether to put the
     * car up does not know what it will fetch and will not bet the half-year on
     * the optimistic answer. One car at the floor is many months of food, so a
     * cell a little short offers a FRACTION of its fleet: the share of its
     * households who cannot manage. A city does not dump its cars on one bad
     * month, which it would if this offered the lot.
     *
     * A PURE NUMBER, TWICE OVER: money over a price in money, and a share of a
     * fleet. Neither moves when the currency does.
     */
    private double offerOf(int i, double floorPrice) {
        Household c = cells[i];
        if (c.isEmpty() || !(c.cars > 0) || !(floorPrice > 0)) return 0;
        double gap = c.subsistence - Math.max(0, c.afterFixed);
        if (gap <= 0) return 0;
        double need = CAR_SALE_HORIZON_MONTHS * gap
                - Math.max(0, c.savings) - c.lendableRoom(c.disposable);
        if (need <= 0) return 0;
        // Whole cars, for the reason the note above wantOf() gives: a quantity
        // crossing from the money world into the physical one crosses at a
        // grain coarser than the dust.
        return Math.floor(Math.min(c.cars, need / floorPrice) * c.households);
    }

    /* =====================================================================
       GROCERIES AT A PRICE, AND FOOD ASSISTANCE (0.7.43)

       The project's spec-inflation.md 2.6 and 2.9. The grocer used to be
       handed `want` in money - subsistence and most of what was left over,
       the wealth term included - so the city asked for fourteen to seventeen
       times the baskets it could eat, and the shelf's price answered a head
       count capped by the shops' coverage rather than anybody's money. A
       household now asks for what it eats, at a price:

           q(p) = min( need x min(1, (p_sat / p) ^ GROCERY_ELASTICITY),
                       foodMoney / p )

       a basket a head at most (Engel's law by construction: the richer
       shelf is Consumption's composition, not a second stomach), all of it
       up to the satiation price - Retail's SATIATION_MULTIPLE over its floor
       - and a little less above it, and never more than its money buys. The
       city's demand is the cells' sum, and it falls as the price rises, so
       there is one price at which it meets what the shops can hand over
       (Retail.sellOwnPriced()).

       FOOD ASSISTANCE is the treasury's voucher toward a household's
       groceries (TaxPolicy.getFoodAssistance(), 0 by default): the dial's
       share of its baskets at the shelf price, for a household whose baskets
       would take more than FOOD_ASSISTANCE_MEANS_SHARE of what it has after
       its fixed bills and its investment income (smoothed over a year since
       0.7.45, MEANS_INCOME_MONTHS). It is added to the money
       the household bids with, and paid only on the baskets it actually got
       - into its savings at the till, by the treasury in the same month
       (Game, TreasuryLine.FOOD_ASSISTANCE).
       ===================================================================== */

    /**
     * A household is eligible for food assistance when a basket a head would
     * take more than this share of what it has after its fixed bills and its
     * investment income over the year: half. Targets those priced out first (spec star 8),
     * and takes in everybody with nothing after their fixed bills - the
     * unemployed off EI, the orphans, students without grant cover.
     */
    public static final double FOOD_ASSISTANCE_MEANS_SHARE = .5;

    /**
     * Months the means test's investment income is smoothed over, as an
     * exponential average - a twelfth of the gap a month, the year
     * Expectations smooths inflation over (0.7.45; the UI spec's B16). A
     * coupon or a dividend lands in one month, and a test that read that
     * month alone took a whole row in and out of assistance: the unemployed
     * of the 2,400-month research city at a half dial were 11,203-14,172
     * eligible, then none for seven months, then 13,691 again - $3.2M a month
     * paid, then $3k, then $3.2M. Read only by the test: the plan's own
     * reading of the month's income is untouched, and at a dial of 0 nothing
     * reads it at all.
     */
    public static final int MEANS_INCOME_MONTHS = 12;

    /** The price a full basket is still wanted at, in today's money: told by Retail at its sale and by Game where the households plan (Retail.getSatiationPrice()). */
    private double satiationPrice;

    /** The food assistance dial, 0 to 1: the share of an eligible household's baskets the treasury's voucher covers. Told by Game where the households plan. */
    private double foodAssistance;

    /** What the treasury paid toward the households' groceries at the last sale, and the baskets that bought. */
    private double lastFoodAssistancePaid, lastFedByAssistance;

    public void setSatiationPrice(double price) { if (price > 0 && Double.isFinite(price)) satiationPrice = price; }
    public double getSatiationPrice() { return satiationPrice; }

    public void setFoodAssistance(double share) {
        foodAssistance = Double.isFinite(share) ? Math.max(0, Math.min(1, share)) : 0;
    }
    public double getFoodAssistance() { return foodAssistance; }

    /** What the treasury paid toward the groceries at the last sale: every voucher, up to the baskets got at the price charged. Game pays it. */
    public double getFoodAssistancePaid() { return lastFoodAssistancePaid; }

    /** ...and the baskets that bought, at the price charged. */
    public double getFedByAssistance() { return lastFedByAssistance; }

    /**
     * What one of these households would buy at this price, in baskets: the
     * curve in the banner. Nothing for an empty cell, a household that needs
     * nothing, or no price.
     */
    public double groceryDemandOf(Household c, double price) {
        if (c.isEmpty() || !(price > 0) || !(c.need > 0)) return 0;
        double appetite = satiationPrice > 0
                ? Math.min(1, Math.pow(satiationPrice / price,
                        ham.citybuildersim.sectors.Retail.GROCERY_ELASTICITY))
                : 1;
        return Math.min(c.need * appetite, Math.max(0, c.foodMoney) / price);
    }

    /** What the city's households would buy at this price, in baskets: every cell's demand times its households. Falls as the price rises. */
    public double groceriesWanted(double price) {
        double total = 0;
        for (Household c : cells) total += groceryDemandOf(c, price) * c.households;
        return total;
    }

    /** The baskets the city's households need, one a head: what the demand is a share of. */
    public double groceriesNeeded() {
        double total = 0;
        for (Household c : cells) if (!c.isEmpty()) total += c.need * c.households;
        return total;
    }

    /**
     * Hands out the baskets the shops sold, and pays the vouchers on them.
     *
     * THE POOREST ARE PRICED OUT FIRST. Each cell gets its demand at the
     * ALLOCATION price, scaled so the cells add up to what was sold: at the
     * clearing price when the shelf charged less than it (a shortage), so the
     * households whose money runs out first are the ones who go without -
     * which is what a price does and a queue does not - and at the price
     * charged otherwise. Every basket is paid for at the price charged.
     *
     * @param sold     baskets the shops handed over
     * @param pAlloc   the price the shortage is shared out at: the larger of
     *                 the clearing price and the price charged
     * @param pCharged what a basket cost at the till
     */
    public void allocateGroceries(double sold, double pAlloc, double pCharged) {
        lastFoodAssistancePaid = 0;
        lastFedByAssistance = 0;
        double total = groceriesWanted(pAlloc);
        double scale = total > 0 && sold > 0 ? sold / total : 0;
        for (Household c : cells) {
            c.groceriesGot = groceryDemandOf(c, pAlloc) * scale;
            c.groceriesAsked = groceryDemandOf(c, pCharged);
            c.groceriesNeed = c.isEmpty() ? 0 : c.need;
            c.assistance = 0;
            if (!(c.voucher > 0) || !(c.groceriesGot > 0) || !(pCharged > 0)) continue;
            double aid = Math.min(c.voucher, c.groceriesGot * pCharged);
            c.assistance = aid;
            c.savings += aid;
            lastFoodAssistancePaid += aid * c.households;
            lastFedByAssistance += aid / pCharged * c.households;
        }
    }

    /**
     * The voucher one of these households holds at this shelf price: the
     * dial's share of its baskets at the price, when they would take more
     * than FOOD_ASSISTANCE_MEANS_SHARE of what it has after its fixed bills
     * and its investment income; nothing otherwise, or at a dial of 0.
     */
    public double foodAssistanceFor(Household c, double price) {
        return foodAssistanceFor(c, price, foodAssistance);
    }

    /** ...at a dial of the caller's: the Policy tab's preview (PolicyPreview.foodAssistanceAt()). */
    double foodAssistanceFor(Household c, double price, double share) {
        if (!(share > 0) || c.isEmpty() || !(price > 0)) return 0;
        double basket = c.baskets() * price;
        // The investment income smoothed over the year, not the month's (0.7.45, MEANS_INCOME_MONTHS).
        double means = c.afterFixed + Math.max(0, c.meansIncome);
        if (basket <= FOOD_ASSISTANCE_MEANS_SHARE * means) return 0;
        return share * basket;
    }

    /**
     * What the vouchers would have paid at the last sale at another dial: each
     * eligible household's voucher at that share, up to the baskets it got at
     * the price - the same rule allocateGroceries() pays by, against the
     * baskets of the sale that has happened. A preview, not a forecast: a
     * voucher bids, so the baskets would have moved too.
     */
    public double foodAssistanceAt(double share, double price) {
        double total = 0;
        for (Household c : cells) {
            double voucher = foodAssistanceFor(c, price, share);
            if (voucher > 0) total += Math.min(voucher, c.groceriesGot * price) * c.households;
        }
        return total;
    }

    /** Households whose baskets would take more than FOOD_ASSISTANCE_MEANS_SHARE of their means at this price: who a voucher would go to. */
    public double householdsEligibleForFoodAssistance(double price) {
        double total = 0;
        for (Household c : cells) if (foodAssistanceFor(c, price, 1) > 0) total += c.households;
        return total;
    }

    /** What the treasury paid toward each row's groceries at the last sale, row by row: the cells that were paid, summed. The household books' line. */
    public double[] foodAssistanceByRow() {
        double[] out = new double[ROWS];
        for (Household c : cells) out[c.row()] += c.assistance * c.households;
        return out;
    }

    /* ----------------- who goes without, read for the screens (0.7.45) -----------------
       Pure reads of the last sale's positions, which add up to the city's
       own figures: the rows' baskets to what Retail sold, the rows' vouchers
       to what the treasury paid. */

    /** The baskets one row of households needed at the last sale, asked for at the price, and got; its households, those a voucher would go to at a price, and those a voucher was paid to. */
    public record GroceryRow(int row, double need, double asked, double got,
                             double households, double eligible, double aided) {
        /** Baskets got per basket needed: 1 is fed. */
        public double gotShare()   { return need > 0 ? got / need : 1; }
        /** Baskets asked for at the price per basket needed: under 1 is priced out. */
        public double askedShare() { return need > 0 ? asked / need : 1; }
    }

    /** Every row's groceries at the last sale, with who a voucher would go to at this price (ROWS order). */
    public GroceryRow[] groceriesByRow(double price) {
        double[] need = new double[ROWS], asked = new double[ROWS], got = new double[ROWS];
        double[] households = new double[ROWS], eligible = new double[ROWS], aided = new double[ROWS];
        for (Household c : cells) {
            if (c.isEmpty()) continue;
            int r = c.row();
            need[r] += c.groceriesNeed * c.households;
            asked[r] += c.groceriesAsked * c.households;
            got[r] += c.groceriesGot * c.households;
            households[r] += c.households;
            if (foodAssistanceFor(c, price, 1) > 0) eligible[r] += c.households;
            if (c.assistance > 0) aided[r] += c.households;
        }
        GroceryRow[] out = new GroceryRow[ROWS];
        for (int r = 0; r < ROWS; r++) out[r] = new GroceryRow(r, need[r], asked[r], got[r], households[r], eligible[r], aided[r]);
        return out;
    }

    /** The households a voucher was paid to at the last sale. */
    public double getHouseholdsAssisted() {
        double total = 0;
        for (Household c : cells) if (c.assistance > 0) total += c.households;
        return total;
    }

    /** The baskets the vouchers would have paid for at the last sale at another dial: foodAssistanceAt() at the price, in baskets. */
    public double foodAssistanceBasketsAt(double share, double price) {
        return price > 0 ? foodAssistanceAt(share, price) / price : 0;
    }

    /* =====================================================================
       THE LUXURY COUNTER (2026-09-17)

       The same three-step every household purchase in this file uses - ask
       what they want at a price, hand out what the seller had, take the money
       - and the third one written, after the shares and the cars. See
       LuxuryRetail for why the good exists at all.
       ===================================================================== */

    /**
     * What the city's households would buy at this price, in whole pieces.
     *
     * THE MONEY IS ADDED UP FIRST AND THE FLOOR HAPPENS ONCE, which is the
     * twenty-sixth sighting of the money-constant family and the subtlest one
     * yet. The first draft floored each CELL's budget over the price - sixty-
     * eight crossings from the money world into the physical one every month -
     * and DenominationCheck came apart 6e-05 at a time. The arithmetic is
     * scale-invariant and the floating point is not: (a/100)/(b/100) differs
     * from a/b in the last bit, and a floor turns a last-bit difference into a
     * whole piece whenever the quotient lands near an integer. Sixty-eight
     * chances a month for four thousand months is not a small number.
     *
     * One crossing for the whole city is the same construction
     * Retail.sellOwnPriced() uses on the grocery basket, and for the same
     * reason. The cells still get their share: takeLuxuries() splits what was
     * bought pro rata over the BUDGETS, which are money and stay money.
     */
    public double luxuriesWanted(double price) {
        if (!(price > 0)) return 0;
        return Math.floor(luxuryBudget() / price);
    }

    /** What the city's households would put over a counter, in money. */
    private double luxuryBudget() {
        double total = 0;
        for (Household c : cells) total += luxuryBudgetOf(c);
        return total;
    }

    /**
     * What one cell would buy, in whole pieces.
     *
     * THE GATES ARE THE CAR'S, LESS THE CAR'S CEILING. Not locked out, not
     * going short, able to hold anything at all, and money past the cushion -
     * a household that cannot buy its groceries this month is not buying a
     * watch this month either. What it does NOT have is a room-left term: a
     * fleet has a ceiling of one car per household and a collection has none,
     * which is the whole reason this good is here.
     */
    private double luxuryBudgetOf(Household c) {
        if (c.isEmpty() || !c.canInvest() || c.lockout > 0 || c.isGoingShort()) return 0;
        if (!(c.luxuryWant > 0)) return 0;
        double spare = (c.savings - SHARE_CUSHION_MONTHS * Math.max(0, c.disposable)) * c.households;
        if (spare <= 0) return 0;
        return Math.min(c.luxuryWant * c.households, spare);
    }

    /**
     * Hands out the pieces the shops actually had, pro rata over who wanted
     * them, and takes the money out of savings.
     *
     * OUT OF SAVINGS AND NOT OFF THE INCOME STATEMENT, the same treatment the
     * shares and the cars get - except that unlike a car, a watch is not an
     * asset this model tracks. It is bought, the money is gone, and what the
     * household has instead is not written down anywhere. That is a deliberate
     * simplification and it is the honest one for a consumption good: the
     * point of buying it was to have spent the money.
     *
     * @return cash spent
     */
    public double takeLuxuries(double units, double price) {
        lastLuxuriesBought = 0;
        lastLuxurySpend = 0;
        if (!(units > 0) || !(price > 0)) return 0;

        double[] budget = new double[cells.length];
        double total = 0;
        for (int i = 0; i < cells.length; i++) {
            budget[i] = luxuryBudgetOf(cells[i]);
            total += budget[i];
        }
        if (total <= 0) return 0;

        // Pro rata over the BUDGETS. What each cell gets is its share of the
        // pieces the shops had, which is money over money and needs no floor
        // of its own - see luxuriesWanted().
        double spent = 0, bought = 0;
        for (int i = 0; i < cells.length; i++) {
            if (budget[i] <= 0) continue;
            Household c = cells[i];
            double got = units * (budget[i] / total) / c.households;
            double bill = got * price;
            c.savings = Math.max(0, c.savings - bill);
            spent += bill * c.households;
            bought += got * c.households;
        }
        lastLuxuriesBought = bought;
        lastLuxurySpend = spent;
        return spent;
    }

    /* =====================================================================
       THE TABLE (2026-09-18)

       The luxury counter's three-step, one sector later: ask what the city
       wants at a price, hand out what the kitchens could serve, take the
       money. What is different is the third line of it - see the hunger
       measure in advanceMonth(), where a meal counts as food.
       ===================================================================== */

    /**
     * What the city's households would eat out at this price, in whole meals.
     *
     * ONE FLOOR FOR THE CITY, for the reason written in full above
     * luxuriesWanted(): a floor on a ratio of two money quantities is the
     * money-constant family's quietest coat, and doing it per cell gives a
     * reform sixty-eight chances a month to turn a last-bit difference into a
     * whole meal.
     */
    public double mealsWanted(double price) {
        if (!(price > 0)) return 0;
        /*
         * MONEY FIRST, THEN APPETITE, AND ONE FLOOR OVER BOTH. What a city can
         * pay for divided by what a meal costs, capped at a third of the meals
         * its people eat at all - see MOST_MEALS_EATEN_OUT. The cap is struck
         * for the CITY rather than per cell, like the floor and for the same
         * reason: sixty-eight crossings from money into meals a month is
         * sixty-eight chances for a reform to move one of them.
         */
        double appetite = 0;
        for (Household c : cells) {
            appetite += c.people() * ham.citybuildersim.sectors.Restaurants.MEALS_A_PERSON_MONTH;
        }
        return Math.floor(Math.min(mealBudget() / price, appetite * MOST_MEALS_EATEN_OUT));
    }

    /** What the city's households would put on a table, in money. */
    private double mealBudget() {
        double total = 0;
        for (Household c : cells) total += mealBudgetOf(c);
        return total;
    }

    /**
     * What one cell would spend eating out.
     *
     * THE SAME GATES AS THE COUNTER, and the awkward one is deliberate: a
     * household that is `isGoingShort()` - that could not fund its own plan
     * this month - does not go out to dinner. It is tempting to argue the
     * opposite, that a household which could not get groceries is exactly the
     * one that would eat out, and in a city at the supply wall that is a real
     * story. It is not this one: `isGoingShort()` is about MONEY, not about
     * shelves, and a household short of money is short of it at a restaurant
     * too. The shelf story belongs in what the shops could deliver, and that
     * is measured elsewhere.
     */
    private double mealBudgetOf(Household c) {
        if (c.isEmpty() || !c.canInvest() || c.lockout > 0 || c.isGoingShort()) return 0;
        if (!(c.mealWant > 0)) return 0;
        double spare = (c.savings - SHARE_CUSHION_MONTHS * Math.max(0, c.disposable)) * c.households;
        if (spare <= 0) return 0;
        return Math.min(c.mealWant * c.households, spare);
    }

    /**
     * Hands out the meals the kitchens actually served, pro rata over who
     * wanted them, takes the money out of savings and REMEMBERS THE MEALS.
     *
     * The remembering is what makes this different from the counter. A watch
     * is bought and gone; a dinner was eaten, and next month's hunger measure
     * has to know it - see advanceMonth(), and Household.mealsEaten for why it
     * is a month late and why that is the honest side of the boundary.
     *
     * @return cash spent
     */
    public double takeMeals(double meals, double price) {
        lastMealsBought = 0;
        lastMealSpend = 0;
        if (!(meals > 0) || !(price > 0)) return 0;

        double[] budget = new double[cells.length];
        double total = 0;
        for (int i = 0; i < cells.length; i++) {
            budget[i] = mealBudgetOf(cells[i]);
            total += budget[i];
        }
        if (total <= 0) return 0;

        double spent = 0, eaten = 0;
        for (int i = 0; i < cells.length; i++) {
            if (budget[i] <= 0) continue;
            Household c = cells[i];
            double got = meals * (budget[i] / total) / c.households;
            double bill = got * price;
            c.savings = Math.max(0, c.savings - bill);
            c.mealsEaten += got;
            spent += bill * c.households;
            eaten += got * c.households;
        }
        lastMealsBought = eaten;
        lastMealSpend = spent;
        return spent;
    }

    private double lastMealsBought, lastMealSpend, lastMealsEaten;

    /** Meals the city ate out in the month the hunger measure just read. */
    public double getMealsEaten() { return lastMealsEaten; }

    /** Meals the households ate out this month. */
    public double getMealsBought() { return lastMealsBought; }

    /** ...and what they paid for them. */
    public double getMealSpend() { return lastMealSpend; }

    private double lastLuxuriesBought, lastLuxurySpend;

    /** Pieces the households took this month. */
    public double getLuxuriesBought() { return lastLuxuriesBought; }

    /** ...and what they paid for them. */
    public double getLuxurySpend()    { return lastLuxurySpend; }

    /** What every household in the city would like to put over a counter this month. */
    public double getLuxuryWant() { return sum(c -> c.luxuryWant); }

    /** What the city's households would put up for sale at this floor. */
    public double carsOffered(double floorPrice) {
        double total = 0;
        for (int i = 0; i < cells.length; i++) total += offerOf(i, floorPrice);
        return total;
    }

    /**
     * Clears the month's second-hand market: strikes a price, moves the cars
     * that find a buyer, and pays the households that sold them.
     *
     * THE TWO-PASS SHAPE IS Motoring.month()'s OWN, and deliberately so. Demand
     * depends on the price and the price depends on demand, which is a circle
     * every market in this game has had to break: GoodsMarket strikes off an
     * intended demand and then sells at the struck price, and the new-car path
     * three lines below quotes, re-asks at the quote, and then draws. This does
     * the same - probe the middle of the band, strike, then ask again at what
     * was struck - so a reader who understands one understands all three.
     *
     * THE MONEY IS A TRANSFER AND THE AUDIT SHOULD SEE NOTHING. Buyers' savings
     * fall and sellers' rise by the same figure, both inside the household
     * pool; the only cash that crosses a boundary is what a buyer BORROWED,
     * which leaves the bank and is declared the way a new car's finance already
     * is. See Motoring.month().
     *
     * @param newPrice what a new car costs this month
     * @param ceiling  cars per household this city will own at all
     * @return cars that changed hands
     */
    public double clearUsedCars(double newPrice, double ceiling) {
        lastUsedOffered = 0;
        lastUsedTraded = 0;
        lastUsedSpend = 0;
        lastUsedFinanced = 0;
        lastUsedLoanFees = 0;
        lastUsedPrice = 0;
        lastUsedNewPrice = 0;
        // Only the sellers are written to below, so the rest have to be told
        // that this month they sold nothing.
        for (Household c : cells) c.carsSold = 0;
        if (!(newPrice > 0)) return 0;

        lastUsedNewPrice = newPrice;
        double lo = newPrice * USED_CAR_FLOOR, hi = newPrice * USED_CAR_CEILING;

        double[] offer = new double[cells.length];
        double supply = 0;
        for (int i = 0; i < cells.length; i++) {
            offer[i] = offerOf(i, lo);
            supply += offer[i];
        }
        lastUsedOffered = supply;
        if (supply <= 0) return 0;

        /*
         * THE POSITION, ON GoodsMarket.strike()'s OWN TERMS, special cases and
         * all. There is always supply here - the guard above saw to it - so the
         * no-makers branch cannot fire, and the one that matters is the other:
         * a city where everybody is selling and nobody is buying puts the
         * position at zero and the price at the floor. That is the crash.
         */
        double demand = carsWanted((lo + hi) / 2, ceiling);
        double position = demand <= 0 ? 0 : demand / (demand + supply);
        double price = lo + (hi - lo) * position;
        lastUsedPrice = price;

        double taken = Math.min(supply, carsWanted(price, ceiling));
        if (taken <= 0) return 0;

        /*
         * THE BUYERS FIRST, through the same takeCars() a new car goes through:
         * the same whole-car floor, the same cushion, the same deposit test,
         * and the same lender finding the difference. A used car is a car.
         */
        double spent = takeCars(taken, price, ceiling);
        double traded = lastCarsBought;
        if (!(traded > 0)) return 0;

        /*
         * ...AND THE SELLERS ARE PAID, pro rata over what each offered, into
         * savings - which is where a sale of anything a household owns lands.
         * It is the same treatment the shares get: turning a thing you own back
         * into money is a balance-sheet move and the month's income statement
         * does not see it.
         */
        double scale = traded / supply;
        for (int i = 0; i < cells.length; i++) {
            if (offer[i] <= 0) continue;
            Household c = cells[i];
            double sold = offer[i] * scale / c.households;
            c.cars = Math.max(0, c.cars - sold);
            c.savings += sold * price;
            c.carsSold = sold * c.households;
        }

        lastUsedTraded = traded;
        lastUsedSpend = spent;
        lastUsedFinanced = lastCarsFinanced;
        lastUsedLoanFees = lastCarLoanFees;
        return traded;
    }

    private double lastUsedOffered, lastUsedTraded, lastUsedSpend,
            lastUsedFinanced, lastUsedPrice, lastUsedNewPrice;

    /** Cars put up for sale this month, whether or not anybody took them. */
    public double getUsedCarsOffered() { return lastUsedOffered; }

    /** ...and the ones that found a buyer. */
    public double getUsedCarsTraded() { return lastUsedTraded; }

    /** What they went for. Zero in a month with no market at all. */
    public double getUsedCarPrice() { return lastUsedPrice; }

    /**
     * ...as a share of what a NEW one cost the month it was struck, which is
     * the only honest denominator and is between USED_CAR_FLOOR and
     * USED_CAR_CEILING by construction.
     *
     * A READER WHO DIVIDES BY TODAY'S SHOWROOM PRICE GETS A LIE, and it was
     * printed once: the playtest read the CARS market AFTER motoring had
     * finished with it, the new price had moved underneath, and the summary
     * announced a used car going for 74% of a new one against a ceiling of 70%.
     * The band was never breached; the division was.
     */
    public double getUsedCarShare() {
        return lastUsedNewPrice > 0 ? lastUsedPrice / lastUsedNewPrice : 0;
    }

    /** What the buyers paid, all in. */
    public double getUsedCarSpend() { return lastUsedSpend; }

    /**
     * ...and what of that a lender advanced, which the bank has to be told
     * about in the same month. See Motoring.month().
     */
    public double getUsedCarsFinanced() { return lastUsedFinanced; }

    /** ...and the bank's fee on that, added to what the buyers owe (0.7.7). */
    public double getUsedCarLoanFees() { return lastUsedLoanFees; }
    private double lastUsedLoanFees;

    private double lastCarsBought;
    private double lastCarsFinanced;

    /** Cars the households actually took this month. See takeCars(). */
    public double getCarsBought() { return lastCarsBought; }

    /**
     * ...and what of that a lender advanced, which the bank has to be told
     * about in the same month or the money audit sees a pool fall for no
     * reason. See Motoring.month().
     */
    public double getCarsFinanced() { return lastCarsFinanced; }

    /** ...and the bank's fee on it, added to what the buyers owe rather than paid (0.7.7). The bank books it with the lending - see Motoring.month(). */
    public double getCarLoanFees() { return lastCarLoanFees; }
    private double lastCarLoanFees;


    /* =====================================================================
       THE MARKET

       Where a household's shares can be sold and bought. Set by Game once
       the exchange exists; null in a fixture with no market, in which case
       the waterfall goes from savings straight to credit as it did before.
       ===================================================================== */

    private Exchange exchange;
    private Equity register;
    private Bank bank;
    private Household.Liquidity liquidity;

    public void setMarket(Exchange exchange, Equity register, Bank bank) {
        this.exchange = exchange;
        this.register = register;
        this.bank = bank;
        rebuildLiquidity();
    }

    /**
     * The waterfall's two sales, in one object: the city's paper to the bank's
     * desk first (0.7.1), then shares on the exchange. Null with neither, in
     * which case the waterfall goes from savings to credit as it always did.
     */
    private void rebuildLiquidity() {
        boolean shares = exchange != null && register != null && bank != null;
        if (!shares && paperDesk == null && bondMarket == null) { liquidity = null; return; }
        liquidity = new Household.Liquidity() {
            @Override public double sell(Household cell, double needPer) {
                return shares ? exchange.sellForHousehold(register, bank, HouseholdBalance.this, cell, needPer) : 0;
            }
            @Override public double sellPaper(Household cell, double needPer) {
                return sellPaperToDesk(cell, needPer);
            }
            @Override public double sellBonds(Household cell, double needPer) {
                return bondMarket == null ? 0 : bondMarket.sellForCell(cell, needPer, cell.rate);
            }
        };
    }

    /**
     * The cells, for the exchange and the bond market to post their orders
     * from (0.7.12 round 2: each household type is its own participant).
     * The array itself, in the census order the saves name them in; a market
     * reads and settles against them, and adds or removes none.
     */
    Household[] cellsForMarket() { return cells; }

    /** A split or consolidation: every household's count of the company by the factor. */
    public void splitShares(int company, double k) {
        if (!(k > 0) || k == 1) return;
        for (Household c : cells) c.shares[company] *= k;
        lastSharesTakenAway[company] *= k;
    }

    /** What the households' shares are worth at the exchange's price - the last trade on each book, or fair value before one. */
    public double marketValueOfShares() {
        if (exchange == null || register == null) return 0;
        return exchange.marketValueOfHouseholds(register, this);
    }

    /** What the households raised this month selling shares to cover the shop. */
    public double totalSold() {
        double total = 0;
        for (Household c : cells) total += c.sold * c.households;
        return total;
    }

    /* =====================================================================
       THE WORLD'S PAPER

       The households' savings follow the sectors' rule (OutwardInvestment):
       money at a counter paying nothing, while the world pays two percent,
       buys the world's paper, and comes home when the bank pays better or
       the household needs it. The same dials, deliberately - one rule for
       idle money, wherever it sits.

       WHY, measured: the exchange returned the sectors' hoard to the
       households - $16-28bn of dividends and buybacks a run - and the
       households kept it at the bank, so the surplus the sectors had been
       recycling abroad sat at home, and the currency did what it does with a
       surplus nobody recycles: eight seeds went from 10% off parity to 31%
       past it, exports halved, unemployment 11% -> 18%. The money changed
       hands and lost its door. This is the door.
       ===================================================================== */

    /* =====================================================================
       THE ROUNDING FLOOR, AND WHY IT IS SEEDED (2026-09-16)

       A household move smaller than a trillionth of a dollar is the
       arithmetic's own dust, and moving it writes a line into the balance of
       payments for nothing. So it is swept to zero - and it was swept at a
       FIXED 1e-12, which makes it a money constant that a currency reform
       never reseeded. That is the FOURTH of these the project has found, after
       Equity.FOUNDING_PRICE, Exchange.MIN_FAIR and OutwardInvestment.MIN_MOVE,
       whose note describes this exact symptom - and this is the sector rule's
       own twin, on the households, written the day the households were given
       the same door and given a bare literal instead of the seeded field
       sitting twenty lines away in OutwardInvestment.

       WHAT IT WOULD COST, and an honest note about how it was found. After a
       hundred-to-one reform every amount is a hundred times smaller, so a
       household move the plain city makes is swept away in the reformed one:
       that cell's savings and its dollars abroad differ from then on. THIS IS
       NOT WHAT BROKE DenominationCheck ON 2026-09-16 - it was found while
       chasing that, seeded, and the divergence did not move by a digit. The
       cause was the cancellation dust in moveStock() above. It is fixed here
       anyway because it is unambiguously the same bug as the seeded field
       twenty lines away in OutwardInvestment, and leaving a known-wrong
       constant in because today's harness cannot see it is how the other four
       survived as long as they did.

       THE DOLLAR FLOOR BELOW IS NOT THIS BUG. `abroad` is in dollars and a
       reform does not move dollars - see Household.redenominate(), whose note
       says so - so 1e-15 there is scale-invariant and stays a literal.
       ===================================================================== */
    public static final double MIN_MOVE = 1e-12;

    /** The same floor in today's money. See MIN_MOVE. */
    private double minMove = MIN_MOVE;

    /** Re-seeds the floor at a given unit. See Denomination. */
    public void seedConstants(double unit) {
        minMove = MIN_MOVE / (unit > 0 ? unit : 1);
    }

    /**
     * WHETHER A CELL OWES ANYTHING, READ AT THE SAME FLOOR (0.7.12 round 6).
     *
     * Three doors ask it - money abroad (investAbroad()), the city's paper
     * and the businesses' bonds (mayBuyPaper()), and a share offer
     * (subscribe()) - and each asked `c.debt <= 0`: zero, which is a money
     * threshold like any other and the one a residue lands either side of.
     * Round 5 found a retired cell owing 8.8e-17 of a dollar in
     * DenominationCheck's reformed city from month 131 and nothing in the
     * plain one; barred from the bonds in one twin only, it moved the cells'
     * bond weights and the two cities parted. Jerus, 2026-09-25: "Make both
     * scale with the currency, the way the tree's other money thresholds do."
     * So a debt no larger than the rounding floor above - MIN_MOVE of a
     * founding dollar, seeded with the unit - is the arithmetic's dust and
     * not a debt, at every denomination.
     */
    private boolean owes(Household c) { return c.debt > minMove; }

    /** Local currency per dollar, this month: what the paper abroad is worth here. Set by Game before the strike. */
    private double localPerUsd = ForeignAccounts.OPENING_RATE;

    public void setExchangeRate(double localPerUsd) {
        if (localPerUsd > 0) this.localPerUsd = localPerUsd;
    }

    public double getExchangeRate() { return localPerUsd; }

    /** Dollars the households that left this month took with them. Nothing crosses the border. */
    private double lastAbroadTakenAway;

    /**
     * Every household decides where to keep its idle money: what is past the
     * cushion goes abroad towards the target share, a little a month; what
     * is abroad comes home when the target falls. A household in debt, locked
     * out or going short holds nothing abroad. The coupon is rolled where it
     * is earned. Called once a month, after the shares have traded and before
     * the audit strikes.
     *
     * @param depositRate what the bank pays savers, annual
     * @param worldRate   what the world pays, annual
     * @param rate        local currency per dollar, this month
     */
    public void investAbroad(double depositRate, double worldRate, double rate) {
        if (!(rate > 0)) return;
        localPerUsd = rate;
        double spread = Math.max(0, worldRate - Math.max(0, depositRate));
        double targetShare = Math.min(OutwardInvestment.MAX_SHARE, spread * OutwardInvestment.APPETITE);
        for (Household c : cells) {
            if (c.isEmpty()) continue;

            /* =============================================================
               THE COUPON IS PAID HOME, NOT ROLLED (2026-09-17)

               Jerus, on being shown where the money went: "pay it home as
               income."

               WHAT ROLLING IT COST, measured over one four-thousand-month run.
               Cumulative foreign coupons came to $2,649bn against $584bn of
               every wage the city ever paid - four and a half times the entire
               wage bill, twenty times the dividends, and seven times everything
               ever spent in the shops. It overtook wages around month 2,400 and
               ran away afterwards. Household net worth, which sat at a
               textbook-perfect 45 months of GDP at month 480, was at 5,072 by
               month 3,840 and still climbing. Past about two centuries the city
               stopped being an economy and became a rentier fund with a town
               attached.

               THE ENGINE WAS THIS LINE. Households hold about 79% of their
               wealth abroad at the world's 2%, and the coupon was added to the
               pile where it was earned. That is wealth compounding at 1.58% a
               year MECHANICALLY - independent of the city, of the player, of
               whether anybody works. Over 333 years, 193 times, which is
               exactly the curve that was measured.

               AND PAYING IT HOME DOES NOT ON ITS OWN STOP THE COMPOUNDING, so
               this is honest about what it is: the coupon lands in savings,
               savings past the cushion go abroad again at OUT_SPEED, and the
               same loop turns a little slower. What it BUYS is that the money
               is now somewhere a household can spend it, somewhere the
               statement shows it, and somewhere the plan can see it. It is the
               change the other two need to exist. A coupon is income, not a
               bigger bond.
               ============================================================= */
            double earnedUsd = c.abroad * Math.max(0, worldRate) / 12;
            c.foreignInterest = earnedUsd * rate;
            c.savings += c.foreignInterest;
            c.investmentIncome += c.foreignInterest;

            // A prisoner's money is held where it is. See PrisonerHousehold.
            if (!c.canInvest()) continue;

            double held = c.abroad * rate;
            boolean eligible = !owes(c) && c.lockout <= 0 && !c.isGoingShort();

            double cushion = SHARE_CUSHION_MONTHS * Math.max(0, c.disposable);
            double spare = c.savings - cushion;
            double target = eligible && spare + held > 0 ? (spare + held) * targetShare : 0;
            double gap = target - held;
            double move;
            if (gap > 0) {
                move = Math.min(gap * OutwardInvestment.OUT_SPEED, Math.max(0, spare));
            } else {
                move = Math.max(gap * OutwardInvestment.HOME_SPEED, -held);
            }
            if (Math.abs(move) < minMove) continue;
            c.savings -= move;
            c.abroad += move / rate;
            if (c.abroad < 1e-15) c.abroad = 0;
            if (move > 0) c.sentAbroad += move; else c.broughtHome += -move;

        }
    }

    /** Dollars every household holds abroad. */
    public double totalAbroadUsd() {
        double total = 0;
        for (Household c : cells) total += c.abroad * c.households;
        return total;
    }

    /** ...worth this much at home, at the month's rate. */
    public double totalAbroadValue() { return totalAbroadUsd() * localPerUsd; }

    /** Sent abroad this month, all households, local money. For MoneyAudit. */
    public double getSentAbroad() {
        double total = 0;
        for (Household c : cells) total += c.sentAbroad * c.households;
        return total;
    }

    /** Brought home this month - to keep to the target or to eat - all households, local money. For MoneyAudit. */
    public double getBroughtHome() {
        double total = 0;
        for (Household c : cells) total += c.broughtHome * c.households;
        return total;
    }

    /** What the world paid the households this month, rolled abroad. For MoneyAudit, twice. */
    public double getForeignInterest() {
        double total = 0;
        for (Household c : cells) total += c.foreignInterest * c.households;
        return total;
    }

    /** Dollars that left with the households that left this month. */
    public double getAbroadTakenAway() { return lastAbroadTakenAway; }

    /* =====================================================================
       THE CITY'S PAPER, AT HOME (0.7.1)

       Jerus, on who holds the city's bonds: "yes households should be able to
       hold." The fourth thing a household keeps its money in, beside the
       bank balance, the shares and the dollars abroad - and the one that
       makes the city's borrowing a bond market rather than a loan from its
       own bank.

       AT ISSUE. The treasury sells between two presses and the paper settles
       at the next month; the households take their share there, before the
       bank pays (Game, THE HOUSEHOLDS TAKE THEIR SHARE). How much: a share of
       the issue rising with the spread between the paper's yield and what the
       bank pays savers - the shape investAbroad() gives the world's paper,
       with its own two dials below - and only what each cell's savings past
       the cushion can pay, pro rata. The COMMERCIAL BANK IS THE RESIDUAL
       BUYER, at the quoted yield, as it always was.

       ON THE WAY BACK. The bank's desk buys it back at the month's market
       value - one ratio, the households' book at the curve over its face
       (setPaperRatio()), plain, no half-spread: the desk earns or loses the
       difference against what its book carries the paper at, which is its
       spread. Three callers: the waterfall, where a household short of money
       sells its paper BEFORE its shares (paper is the nearer thing to cash);
       the portfolio choice, where a spread that has gone - the paper yielding
       no more than the bank pays - sends it home at OutwardInvestment's
       HOME_SPEED, the pace the dollars come home at; and a household leaving
       the city, which sells on the way out rather than carrying the city's
       paper off to wherever it went. And since 0.7.15 the central bank,
       whose holdings dial reaches past what the bank holds: what the bank
       cannot sell it, the households do, pro rata across the cells at the
       curve's market value, by the path a buyback takes
       (creditPaperBuyback()).

       THE SUM OF EVERY CELL'S PAPER IS DebtManager.householdPrincipal(),
       exactly: every one of these moves the cells and the paper by the same
       face, and HoldersCheck and LongPlaytest assert it.
       ===================================================================== */

    /** The share of an issue the households take, per unit of spread between its yield and the deposit rate: 20 - a fifth of an issue for each point - so two and a half points of spread would take half an issue. */
    public static final double HOUSEHOLD_PAPER_APPETITE = 20;

    /** ...and never more than this share of one issue: half, because a bond market with no bank in it is no longer the city's bank's market. */
    public static final double MAX_HOUSEHOLD_PAPER_SHARE = .5;

    /**
     * Where the households' paper is sold, for what, and what it does to the
     * paper on the other side. Game's desk books the bank's end and takes the
     * face off every piece of paper's household share pro rata.
     */
    public interface PaperDesk {
        /** The desk buys this much face of the households' paper for this much cash. */
        void buy(double face, double cash);
    }

    private PaperDesk paperDesk;

    public void setPaperDesk(PaperDesk desk) {
        this.paperDesk = desk;
        rebuildLiquidity();
    }

    /**
     * What a dollar of face of the households' paper is worth this month: the
     * households' book at the curve over its face (DebtManager
     * .householdBookRatio()), struck once a month by Game before the
     * households' strike and SAVED, because the plan reads it and the load
     * path must re-strike the plan the live path struck. 1 - at face - with
     * nothing held and on an old save.
     */
    private double paperRatio = 1;

    public void setPaperRatio(double ratio) {
        paperRatio = Double.isFinite(ratio) && ratio > 0 ? ratio : 1;
    }

    public double getPaperRatio() { return paperRatio; }

    /**
     * The month's spend factor (0.7.3): what share of its spending above
     * subsistence every household plans, struck by Game once a month on the
     * real deposit rate (Game.spendFactor()) before the households plan -
     * see the banner AND WHAT IT SPENDS ANSWERS THE REAL RATE. NOT saved:
     * the load path strikes it again from the deposit rate and the price
     * index the save restores. 1 - the plan as it was - for a caller that
     * hands nothing.
     */
    private double spendFactor = 1;

    public void setSpendFactor(double factor) {
        spendFactor = Double.isFinite(factor) && factor > 0 ? factor : 1;
    }

    /** The factor the last plan was struck at. */
    public double getSpendFactor() { return spendFactor; }

    /** Every cell's paper, at face - DebtManager.householdPrincipal() from the other side. */
    public double totalPaper() { return sum(Household::totalPaper); }

    /** ...at this month's market value. The neighbour of marketValueOfShares() and totalAbroadValue(). */
    public double marketValueOfPaper() { return totalPaper() * paperRatio; }

    /** Sold to the desk this month, all households, in cash. */
    public double totalPaperSold() {
        double total = 0;
        for (Household c : cells) total += c.paperSold * c.households;
        return total;
    }

    /** Coupons and principal the city paid the households on their paper this month. */
    public double totalPaperIncome() {
        double total = 0;
        for (Household c : cells) total += c.paperIncome * c.households;
        return total;
    }

    private boolean mayBuyPaper(Household c) {
        return !c.isEmpty() && c.canInvest() && !owes(c) && c.lockout <= 0 && !c.isGoingShort();
    }

    private double spareFor(Household c) {
        return Math.max(0, c.savings - SHARE_CUSHION_MONTHS * Math.max(0, c.disposable));
    }

    /** The share of an issue yielding this much the households would take, before asking whether they can pay. */
    public static double paperShareAt(double yield, double depositRate) {
        double spread = Math.max(0, yield - Math.max(0, depositRate));
        return Math.min(MAX_HOUSEHOLD_PAPER_SHARE, spread * HOUSEHOLD_PAPER_APPETITE);
    }

    /** What every eligible household could put into paper: savings past the cushion, in total. */
    public double spareForPaper() {
        double total = 0;
        for (Household c : cells) if (mayBuyPaper(c)) total += spareFor(c) * c.households;
        return total;
    }

    /**
     * The households buy at issue: this much cash in total, from each eligible
     * cell pro rata to what is past its cushion, for this much face per dollar.
     *
     * @return the cash paid, which is what the bank does not have to pay
     */
    public double buyAtIssue(double cash, double facePerCash) {
        if (!(cash > 0) || !(facePerCash > 0)) return 0;
        double spare = spareForPaper();
        if (spare <= 0) return 0;
        double take = Math.min(cash, spare);
        double paid = 0;
        for (Household c : cells) {
            if (!mayBuyPaper(c)) continue;
            double share = spareFor(c) * c.households;
            if (share <= 0) continue;
            double each = take * share / spare / c.households;
            c.savings -= each;
            c.paper += each * facePerCash;
            paid += each * c.households;
        }
        return paid;
    }

    /** Pro rata to the paper held: what a dollar of face in the households' book is spread as, cell by cell. */
    private double paperWeight(Household c, double total) {
        return total > 0 && !c.isEmpty() ? c.paper * c.households / total : 0;
    }

    /** A coupon on the households' share, into savings and the month's investment income, pro rata to the paper. Untaxed, as the foreign coupon is. */
    public void creditPaperCoupon(double total) {
        if (!(total > 0)) return;
        double held = totalPaper();
        if (held <= 0) return;
        for (Household c : cells) {
            double w = paperWeight(c, held);
            if (w <= 0) continue;
            double each = total * w / c.households;
            c.savings += each;
            c.investmentIncome += each;
            c.paperIncome += each;
        }
    }

    /** Principal on their share, into savings with the paper down by the same, pro rata. */
    public void creditPaperPrincipal(double face) {
        if (!(face > 0)) return;
        double held = totalPaper();
        if (held <= 0) return;
        for (Household c : cells) {
            double w = paperWeight(c, held);
            if (w <= 0) continue;
            double each = face * w / c.households;
            c.paper = Math.max(0, c.paper - each);
            c.savings += each;
            c.paperIncome += each;
        }
    }

    /**
     * A bond bought back: this much of their face off the paper, this much of
     * the price into savings, pro rata. Since 0.7.15 also the central bank's
     * purchase of their term paper once the bank has none left to sell it
     * (Game.buyPaperFromHouseholds()): a sale of theirs, pro rata across the
     * cells, at the curve's market value - the same move, so there is one.
     */
    public void creditPaperBuyback(double face, double price) {
        double held = totalPaper();
        if (held <= 0 || !(face > 0)) return;
        for (Household c : cells) {
            double w = paperWeight(c, held);
            if (w <= 0) continue;
            c.paper = Math.max(0, c.paper - face * w / c.households);
            c.savings += Math.max(0, price) * w / c.households;
        }
    }

    /** One cell sells to the desk for up to needPer a household. @return cash raised, per household */
    private double sellPaperToDesk(Household c, double needPer) {
        if (paperDesk == null || !(needPer > 0) || c.paper <= 0 || c.isEmpty()) return 0;
        double cashPer = Math.min(needPer, c.paper * paperRatio);
        double facePer = Math.min(c.paper, cashPer / paperRatio);
        cashPer = facePer * paperRatio;
        c.paper -= facePer;
        paperDesk.buy(facePer * c.households, cashPer * c.households);
        return cashPer;
    }

    /**
     * THE SPREAD HAS GONE: when the households' paper yields no more than the
     * bank pays savers, the target for it is nothing, and they sell a little a
     * month - HOME_SPEED of it, the pace the dollars abroad come home at -
     * into savings. A prisoner's money stays where it is. While the spread
     * lasts they hold what they bought; they buy only at issue.
     *
     * @return cash raised
     */
    public double sellPaperForSpread(double bookYield, double depositRate) {
        if (paperDesk == null || bookYield > Math.max(0, depositRate)) return 0;
        double raised = 0;
        for (Household c : cells) {
            if (c.isEmpty() || !c.canInvest() || c.paper <= 0) continue;
            double facePer = c.paper * OutwardInvestment.HOME_SPEED;
            if (facePer * paperRatio < minMove) continue;
            double cashPer = facePer * paperRatio;
            c.paper -= facePer;
            c.savings += cashPer;
            c.paperSold += cashPer;
            paperDesk.buy(facePer * c.households, cashPer * c.households);
            raised += cashPer * c.households;
        }
        return raised;
    }

    /* =====================================================================
       THE BUSINESSES' BONDS, AT HOME (0.7.12)

       The fifth thing a household keeps its money in, and SINCE ROUND 2 THE
       CELL'S OWN (Jerus: "Each household type trades"): every cell holds each
       bond itself, per household (Household.bondFace), and the market's
       record of the households' face in a bond (CorporateBond.households) is
       always the sum of the cells'. What a cell buys at issue is paid out of
       its own savings past the cushion; on the order book it posts its own
       bids and asks (BondMarket, THE PARTICIPANTS); and a coupon, a principal
       and a default land on what each cell itself holds. Round 1 kept one
       pool with a claim per cell on it; an old save's pool is handed to the
       cells by those claims when it loads (claimPooledBonds()).
       ===================================================================== */

    private BondMarket bondMarket;

    public void setBondMarket(BondMarket market) {
        this.bondMarket = market;
        rebuildLiquidity();
    }

    /**
     * What a dollar of face of the households' bonds is worth this month:
     * every cell's holdings at the bonds' value over their face, struck by the
     * market at its step and SAVED, because the plan reads it and the load
     * path must re-strike the plan the live path struck. 1 with nothing held.
     */
    private double bondRatio = 1;

    public void setBondRatio(double ratio) {
        bondRatio = Double.isFinite(ratio) && ratio > 0 ? ratio : 1;
    }

    public double getBondRatio() { return bondRatio; }

    /** The face that left the city this month with its holders, every bond together. */
    private double lastBondsTakenAway;
    public double getBondsTakenAway() { return lastBondsTakenAway; }

    /** Every cell's bonds, at face: the households' face in every bond. */
    public double totalBonds() { return sum(Household::totalBonds); }

    /** ...at this month's value. */
    public double marketValueOfBonds() { return totalBonds() * bondRatio; }

    /** Sold this month, in cash, and the coupons and principal received. */
    public double totalBondsSold() {
        double total = 0;
        for (Household c : cells) total += c.bondsSold * c.households;
        return total;
    }

    public double totalBondIncome() {
        double total = 0;
        for (Household c : cells) total += c.bondIncome * c.households;
        return total;
    }

    /** One row's bonds, per household of the row. */
    public double getBonds(int row) { return perHousehold(row, Household::bonds); }

    /** Every cell's face in one bond, together. */
    public double bondFaceHeld(int id) {
        double t = 0;
        for (Household c : cells) t += c.bondFace(id) * c.households;
        return t;
    }

    /** The cell with this key, or null - from an index built once, because the markets ask on every fill. */
    public Household cellByKey(String key) {
        if (cellIndex == null) {
            cellIndex = new java.util.HashMap<>();
            for (Household c : cells) cellIndex.put(c.key(), c);
        }
        return key == null ? null : cellIndex.get(key);
    }
    private java.util.Map<String, Household> cellIndex;

    /** What every eligible household could put into bonds: savings past the cushion - the city's paper's rule. */
    public double bondSpare() { return spareForPaper(); }

    /** ...one cell's, every household of it: nothing for a cell that may not buy (the city's paper's eligibility). */
    public double bondSpare(Household c) { return mayBuyPaper(c) ? spareFor(c) * c.households : 0; }

    /**
     * A new issue's households' part, at issue: this much cash out of every
     * eligible cell's savings past its cushion, pro rata, for this much face
     * of the bond, which each cell holds in the same proportion.
     *
     * @return the cash paid - `cash`, unless the households have less
     */
    public double payForBonds(int id, double cash, double face) {
        if (!(cash > 0) || !(face > 0)) return 0;
        double spare = spareForPaper();
        if (spare <= 0) return 0;
        double take = Math.min(cash, spare);
        double facePerCash = face / cash;
        double paid = 0;
        for (Household c : cells) {
            if (!mayBuyPaper(c)) continue;
            double share = spareFor(c) * c.households;
            if (share <= 0) continue;
            double each = take * share / spare / c.households;
            c.savings -= each;
            c.putBondFace(id, c.bondFace(id) + each * facePerCash);
            c.recountBonds();
            paid += each * c.households;
        }
        return paid;
    }

    /**
     * THE MONTH'S COUPONS, to the cells that held the bonds at the record
     * date (BondMarket.strikeCoupons()): into savings and the month's
     * investment income. A cell the census emptied since holds nothing to be
     * paid in: its coupons are spread over the cells that are left, by
     * households, as a folded cell's stocks are. Untaxed, as the city's
     * paper's coupon is.
     */
    public void creditBondCoupons(java.util.Map<String, Double> dueByCell) {
        if (dueByCell == null || dueByCell.isEmpty()) return;
        double orphaned = 0;
        for (java.util.Map.Entry<String, Double> e : dueByCell.entrySet()) {
            double v = e.getValue() == null ? 0 : e.getValue();
            if (!(v > 0)) continue;
            Household c = cellByKey(e.getKey());
            if (c == null || c.isEmpty()) { orphaned += v; continue; }
            double each = v / c.households;
            c.savings += each;
            c.investmentIncome += each;
            c.bondIncome += each;
        }
        if (orphaned > 0) {
            double live = 0;
            for (Household c : cells) if (!c.isEmpty()) live += c.households;
            if (live <= 0) return;
            for (Household c : cells) {
                if (c.isEmpty()) continue;
                double each = orphaned / live;
                c.savings += each;
                c.investmentIncome += each;
                c.bondIncome += each;
            }
        }
    }

    /** One bond's principal at maturity: every cell paid its own face of it, into savings, and the bond gone from it. @return what the cells were paid in all */
    public double creditBondPrincipal(int id) {
        double paid = 0;
        for (Household c : cells) {
            double each = c.bondFace(id);
            if (!(each > 0)) continue;
            c.putBondFace(id, 0);
            c.recountBonds();
            c.savings += each;
            c.bondIncome += each;
            paid += each * c.households;
        }
        return paid;
    }

    /**
     * A default on one issuer's bonds together: every cell's face of each down
     * to this share, and its total recounted once - a slice writes an issuer's
     * bonds down every month it is past the curve's floor, and a recount per
     * bond per cell was a quarter of the playtest's time. No cash moves.
     */
    public void writeDownBonds(java.util.Collection<Integer> ids, double keep) {
        double k = Math.max(0, Math.min(1, keep));
        for (Household c : cells) {
            if (c.bondFace.isEmpty()) continue;
            boolean touched = false;
            for (int id : ids) {
                double f = c.bondFace(id);
                if (!(f > 0)) continue;
                c.putBondFace(id, f * k);
                touched = true;
            }
            if (touched) c.recountBonds();
        }
    }

    /** A default on one bond: every cell's face of it down to this share. No cash moves. @return the face the cells lost */
    public double writeDownBonds(int id, double keep) {
        double lost = 0;
        double k = Math.max(0, Math.min(1, keep));
        for (Household c : cells) {
            double f = c.bondFace(id);
            if (!(f > 0)) continue;
            c.putBondFace(id, f * k);
            c.recountBonds();
            lost += f * (1 - k) * c.households;
        }
        return lost;
    }

    /* ---- the cells' bonds in a save, by the cell's name ---- */

    /** Every cell's bonds, per household, by the cell's key and the bond's id: the save's (0.7.12 round 2). */
    public java.util.Map<String, java.util.Map<String, Double>> bondsByCellToSave() {
        java.util.Map<String, java.util.Map<String, Double>> out = new java.util.LinkedHashMap<>();
        for (Household c : cells) {
            if (c.bondFace.isEmpty()) continue;
            java.util.Map<String, Double> m = new java.util.LinkedHashMap<>();
            for (java.util.Map.Entry<Integer, Double> e : c.bondFace.entrySet()) m.put(String.valueOf(e.getKey()), e.getValue());
            out.put(c.key(), m);
        }
        return out;
    }

    /**
     * ...back, by name: a cell this build does not have is dropped, as the
     * cell arrays' rule is, and a bond id that does not parse is skipped.
     * Every cell's total is recounted from what came back.
     */
    public void restoreBondsByCell(java.util.Map<String, java.util.Map<String, Double>> saved) {
        for (Household c : cells) c.bondFace.clear();
        if (saved != null) {
            for (java.util.Map.Entry<String, java.util.Map<String, Double>> e : saved.entrySet()) {
                Household c = cellByKey(e.getKey());
                if (c == null || e.getValue() == null) continue;
                for (java.util.Map.Entry<String, Double> f : e.getValue().entrySet()) {
                    try {
                        double v = f.getValue() == null ? 0 : f.getValue();
                        if (v > 0) c.bondFace.put(Integer.parseInt(f.getKey()), v);
                    } catch (NumberFormatException ignored) { }
                }
            }
        }
        for (Household c : cells) c.recountBonds();
    }

    /**
     * A SAVE FROM ROUND 1 held the households' bonds as one pool, each cell
     * with a claim on it at face (Household.bonds): the pool is handed to the
     * cells by those claims - every bond's households' face split across the
     * cells in proportion to each cell's claim - so a cell holds a share of
     * every bond that its claim was a share of the pool. Nothing moves in
     * money; each cell's total is what its claim was.
     *
     * @param poolById the households' face in each bond, by its id
     */
    public void claimPooledBonds(java.util.Map<Integer, Double> poolById) {
        double claims = 0;
        for (Household c : cells) claims += Math.max(0, c.bonds) * c.households;
        for (Household c : cells) c.bondFace.clear();
        if (poolById == null || !(claims > 0)) { for (Household c : cells) c.recountBonds(); return; }
        for (Household c : cells) {
            double claim = Math.max(0, c.bonds);
            if (!(claim > 0) || c.households <= 0) continue;
            for (java.util.Map.Entry<Integer, Double> e : poolById.entrySet()) {
                double pool = e.getValue() == null ? 0 : e.getValue();
                if (pool > 0) c.bondFace.put(e.getKey(), pool * claim / claims);
            }
        }
        for (Household c : cells) c.recountBonds();
    }

    /* ------------------------ the people outside the families ------------------------ */

    /** Out-of-work households that lost their home this month. Unemployment moves them. */
    public double getEvicted() { return lastEvicted; }

    /** Student loans drawn this month, all students - the treasury's money out. */
    public double totalStudentBorrowed() { return sum(c -> c.studentBorrowed * c.households); }

    /** ...and repaid by graduates, the treasury's money back: principal, which is what the journal's line carries. */
    public double totalStudentRepaid()   { return sum(c -> c.studentRepaid * c.households); }

    /** ...and the interest the graduates paid on top of it this month: the treasury's revenue. See setStudentLoanRate(). */
    public double totalStudentInterest() { return sum(c -> c.studentInterest * c.households); }

    /** What a month's interest would come to at an annual rate, on the balances that are charged it - for a screen previewing a rate. */
    public double studentInterestAt(double annualRate) {
        return sum(c -> c.studentInterestAt(annualRate) * c.households);
    }

    /** What every household owes the treasury in student loans. */
    public double totalStudentDebt()     { return sum(Household::totalStudentDebt); }

    /** ...and the part of it that is in repayment: the graduates' balances, which the rate is charged on. */
    public double totalGraduateDebt() {
        return sum(c -> c instanceof WorkingHousehold ? c.totalStudentDebt() : 0);
    }

    /** Student loans that left the city with graduates who left. The treasury's loss. */
    public double getStudentDebtTakenAway() { return lastStudentDebtTakenAway; }

    /**
     * THE GRADUATES LEAVE THE STUDENT BODY WITH THEIR LOANS.
     *
     * followThePeople() moves money on the NET change in each cell, which is
     * right for a family whose child turned thirteen and wrong for a college.
     * A college that takes in forty a month and lets forty out has a student
     * body that never changes size, so on the net rule nothing ever left it:
     * measured on OutsideCheck's college city, 7,530 lent over fifteen years
     * and 1 repaid, because the loans never reached a household that repays.
     *
     * So the loans take the GROSS flow: each month the ones who finished carry
     * their share of the students' loans to the working families, who repay a
     * 114th a month, and the census moves only what is left - the loans of
     * the students who stayed - on the net change as before.
     *
     * @param people who finished a course, and so left the students cell,
     *               since the census it was struck against. Used once, by the
     *               next advanceMonth().
     */
    public void setGraduates(double people) { graduating = Math.max(0, people); }

    /** Students who left the student body with what they carried, at the last month's census. */
    public double getLastGraduated() { return lastGraduated; }

    /** The students who finished and wait for the next census to carry their loans (setGraduates()). */
    public double getGraduating() { return graduating; }

    /**
     * ...AND BOTH ACROSS A SAVE (0.7.63). The month sets the first at its
     * demographics and the next month's census reads it, so every save is
     * taken holding one, and the load left it at nothing: the graduates'
     * loans stayed with the students for the first month back and the
     * working families repaid that much less - 0.93% of Jerus's repayments
     * and interest, his treasury 7,447 units short a month after a reload
     * (batch L; the second is the record the census leaves, for the screens).
     */
    public double[] graduatesToSave() { return new double[] { graduating, lastGraduated }; }

    /** ...and back; null, a save from before 0.7.63, leaves both at nothing, as every load until then did. */
    public void restoreGraduates(double[] saved) {
        if (saved == null || saved.length < 2) return;
        graduating = Math.max(0, saved[0]);
        lastGraduated = Math.max(0, saved[1]);
    }

    /* ------------------------- what the bank is owed ------------------------- */

    /** Written off this month, which is the bank's loss. */
    public double getWrittenOff()      { return lastWrittenOff; }

    /** Savings that left the city with the households that left. Not a loss to anybody here. */
    public double getTakenAway()       { return lastTakenAway; }

    /** Households discharged this month, and the share of them leaving the city. */
    public double getBankrupt(int row) { return sumRow(row, Household::bankrupt); }
    public double getLeavingCity()     { return lastLeaving; }

    /** True when any cell of the row the bank has stopped lending to is still locked out. */
    public boolean isLockedOut(int row){ return getLockout(row) > 0; }

    /** The longest lockout standing in the row. */
    public int getLockout(int row) {
        int longest = 0;
        for (Household c : cells) {
            if (c.row() == row && !c.isEmpty()) longest = Math.max(longest, c.lockout);
        }
        return longest;
    }

    /** Everything the households owe the bank. */
    public double bookOwed() { return totalDebt(); }

    /**
     * The plan alone, without settling a month.
     *
     * FOR THE LOAD PATH, and it is not a nicety. Savings and debt are saved;
     * the plan is a flow and is not, so a reloaded city had lastPlanned all
     * zeros - which meant HouseholdAccounts.updateByTier() fell back to
     * splitting the shopping by HEADCOUNT for exactly one month, the tiers'
     * books came out different from the live city's, and everything downstream
     * of them differed with it. Caught by SaveFileCheck to the cent once rent
     * started depending on the household mix. The seventh time this codebase
     * has been bitten by rebuilding a flow instead of re-striking it.
     *
     * Calling advanceMonth() here instead would settle a month that has already
     * been settled - a second draw on the same savings - and would move the
     * stock with a census the save was not struck against.
     */
    public void planOnly(ToDoubleBiFunction<FamilyStructure, PayTier> census,
                         double[] rowDisposable, double rentPerHousehold,
                         double[] rowFees, double foodPricePerHead, double riskFreeAnnual) {

        rowDisposable = padRows(rowDisposable);
        rowFees = padRows(rowFees);
        if (census == null || rowDisposable == null || rowDisposable.length != ROWS) {
            return;
        }

        double[] fresh = takeCensus(census);
        double[] disposablePer = splitIncome(fresh, rowDisposable);
        double[] feesPer = splitByPeople(fresh, rowFees);

        // Every count first, then the fold, then the plan - the month's own
        // order (followThePeople() before the strike). On a city saved by this
        // build the fold finds nothing; on an older save it empties the ghosts.
        for (int i = 0; i < cells.length; i++) cells[i].households = fresh[i];
        foldEmptyCells();

        plannedSpend = 0;
        for (int i = 0; i < cells.length; i++) {
            Household c = cells[i];
            if (c.isEmpty()) { c.clearWorking(); continue; }
            c.rentShare = Math.max(0, rentShares.applyAsDouble(c));
            c.studentLoanRate = studentLoanRate;
            c.restrike(disposablePer[i], rentPerHousehold * c.rentShare,
                    feesPer[i] + accountFeeFor(c, c.households),
                    foodPricePerHead, riskFreeAnnual);
            c.voucher = foodAssistanceFor(c, foodPricePerHead);
            plannedSpend += c.plan(localPerUsd, paperRatio, spendFactor, bondRatio) * c.households;
        }
    }

    /* ------------------------------- reading ------------------------------- */

    /** What the shops can sell next month, in money. The budget constraint itself. */
    public double getSpendingCapacity() { return plannedSpend; }

    /** What they would spend if money were no object - the demand behind the cap. */
    public double getWantedSpend() { return sum(Household::totalWant); }

    /** One basket a head, per household of the row: what going short is measured against. */
    public double getSubsistence(int row) { return perHousehold(row, Household::subsistence); }

    /**
     * The share of each row's groceries, for splitting what retail actually
     * sold back across the rows.
     *
     * This is what makes the tier table honest: the shops' takings are divided
     * by who could afford to shop, not by headcount, so a tier that cannot pay
     * shows up as buying less rather than as an unexplained deficit. By the
     * baskets each row was handed at the last sale since 0.7.43 - every basket
     * went at one price, so that is each row's share of the takings exactly;
     * by the plan until then.
     */
    public double[] plannedShare() {
        double[] out = new double[ROWS];
        double total = 0;
        for (Household c : cells) {
            double got = c.groceriesGot * c.households;
            out[c.row()] += got;
            total += got;
        }
        if (total > 0) for (int r = 0; r < ROWS; r++) out[r] /= total;
        else java.util.Arrays.fill(out, 0);
        return out;
    }

    /** Share of the city going short of food, 0-1. What the health service reads. */
    public double getHungerRate() {
        return totalPeople > 0 ? Math.min(1, hungryPeople / totalPeople) : 0;
    }

    public double getHungryPeople()          { return hungryPeople; }

    /**
     * Of getHungerRate(), the share of the city short of a basket that could
     * not afford one at the price - the money half, at full shelves - and the
     * share the shelves left short (0.7.45): the two add to the rate. Struck
     * where the rate is, at the top of the month on the last sale.
     */
    public double getHungerPricedOut() {
        return totalPeople > 0 ? Math.min(getHungerRate(), Math.min(hungryAtFullShelves, hungryPeople) / totalPeople) : 0;
    }

    /** ...and the rest of it: the shelves ran short. */
    public double getHungerShortOfStock() { return Math.max(0, getHungerRate() - getHungerPricedOut()); }

    /**
     * Of getHungryPeople(), the ones who would have gone hungry even with
     * the shelves full: the baskets they asked for at the price (0.7.43;
     * their own plan until then), every one handed over, came up short of a
     * basket - the money half of the hunger (0.7.27), priced out. The rest
     * went short because the shops could not hand over what was asked for
     * (getDeliveredShare()). Counted the same way, people times how far
     * short, and saved with it.
     */
    public double getHungryAtFullShelves()  { return hungryAtFullShelves; }

    /**
     * The share of what households asked for at the price (0.7.43; what they
     * planned to buy until then) that the shops could hand over - and
     * therefore which of the two hungers is biting.
     *
     * A household short of money and a city short of stock both come out as
     * hunger, and a player who fixes the wrong one gets nowhere. This is the
     * figure that tells them apart: at 1.0 the shelves were full and anybody
     * still hungry could not afford to eat.
     */
    public double getDeliveredShare() { return lastDelivered; }

    /**
     * Interest the bank paid on what these households have saved.
     *
     * Credited straight to the accounts, in proportion to what is in them, which
     * is what "interest on your savings" means. It is not spending money and it
     * is not counted as income in the month's waterfall: it accrues, and it is
     * there next month when the family needs it.
     *
     * Small, and compounding, and the only thing in this model that ever made
     * saving worth doing on its own.
     */
    public void creditDepositInterest(double total) {
        if (total <= 0) return;
        double base = totalSavings();
        if (base <= 0) return;
        for (Household c : cells) {
            if (c.savings <= 0 || c.isEmpty()) continue;
            double share = c.totalSavings() / base;
            c.savings += total * share / c.households;
        }
        lastDepositInterest = total;
    }

    /* =====================================================================
       THEFT (2026-09-11)

       Jerus: crime is "theft, people leaving, violence", and the stolen money
       "goes to the offenders". Two halves, both here because both are cells'
       savings: what is taken, from every household in proportion to what it
       has saved, and what the offenders' households are handed, in proportion
       to how much of the crime is theirs. Every dollar stays on the books - a
       theft moves money, it does not destroy it. See Crime.
       ===================================================================== */

    /**
     * Takes up to `total` from the households' savings, each cell in
     * proportion to what it has saved. A prisoner's savings are held in the
     * ledger and are not there to take.
     *
     * @return what was actually taken, which is less than asked when the city
     *         has less saved than that
     */
    public double takeFromSavings(double total) {
        if (!(total > 0)) return 0;
        double base = 0;
        for (Household c : cells) {
            if (!c.canInvest() || c.isEmpty() || c.savings <= 0) continue;
            base += c.savings * c.households;
        }
        if (base <= 0) return 0;
        double taken = Math.min(total, base);
        double share = taken / base;
        for (Household c : cells) {
            if (!c.canInvest() || c.isEmpty() || c.savings <= 0) continue;
            c.savings -= c.savings * share;
        }
        return taken;
    }

    /**
     * Credits `total` to the cells in proportion to a weight per cell, in the
     * cells' order - what the offenders' households took home.
     *
     * @return what was credited: all of it, or nothing if no cell has weight
     */
    public double creditByWeight(double total, double[] weight) {
        if (!(total > 0) || weight == null || weight.length != cells.length) return 0;
        double sum = 0;
        for (int i = 0; i < cells.length; i++) {
            if (!cells[i].isEmpty() && weight[i] > 0) sum += weight[i];
        }
        if (sum <= 0) return 0;
        for (int i = 0; i < cells.length; i++) {
            Household c = cells[i];
            if (c.isEmpty() || !(weight[i] > 0)) continue;
            c.savings += total * weight[i] / sum / c.households;
        }
        return total;
    }

    /** What the bank paid the city's savers this month. */
    public double getDepositInterest() { return lastDepositInterest; }

    /* =====================================================================
       THE OFFER

       Jerus: "each household type gets the offer and based on their situation
       and their cash available they accept or decline, or put how much."

       The situation: no debt, not locked out, not going short, and savings
       past a cushion. The cash available: what is past the cushion. Every
       household uses the same rule - one cushion, one fraction, the retired
       included - which was Jerus's call against a keener rich; the rich still
       buy more because they have more past the cushion.
       ===================================================================== */

    /** Months of take-home a household keeps in the bank before it buys a share. */
    public static final double SHARE_CUSHION_MONTHS = 3;

    /** The share of what is past the cushion it puts into one offering. */
    public static final double SHARE_OF_EXCESS = .30;

    /**
     * Puts an offering to every household, and takes up what they will buy.
     *
     * Pro rata when they would buy more than is offered, so a small offering
     * is not taken entirely by whichever cell the loop reached first. Savings
     * go down by what was paid and the shares go up by what it bought; net
     * worth does not move.
     *
     * @param company  Equity.COMPANIES index
     * @param offered  the money the company is asking for
     * @param price    per share
     * @return the money taken up
     */
    public double subscribe(int company, double offered, double price) {
        if (offered <= 0 || !(price > 0)) return 0;

        double[] want = new double[cells.length];
        double total = 0;
        for (int i = 0; i < cells.length; i++) {
            Household c = cells[i];
            if (c.isEmpty() || !c.canInvest() || owes(c) || c.lockout > 0 || c.isGoingShort()) continue;
            double cushion = SHARE_CUSHION_MONTHS * Math.max(0, c.disposable);
            double excess = c.savings - cushion;
            if (excess <= 0) continue;
            want[i] = excess * SHARE_OF_EXCESS * c.households;
            total += want[i];
        }
        if (total <= 0) return 0;

        double scale = Math.min(1, offered / total);
        double taken = 0;
        for (int i = 0; i < cells.length; i++) {
            if (want[i] <= 0) continue;
            Household c = cells[i];
            double paidPer = want[i] * scale / c.households;
            c.savings -= paidPer;
            c.shares[company] += paidPer / price;
            taken += paidPer * c.households;
        }
        return taken;
    }

    /**
     * Hands out a company's founding shares to the people who founded it.
     *
     * A company's first offering finds equity already on its books - the
     * stores and homes the founding endowment built - and owned by nobody.
     * Somebody has to own it or the first buyer is handed it for free, so it
     * goes to the city's households, by grown-ups: the founders own what
     * they founded. Nothing is paid; net worth rises by what was always
     * theirs and was never written down. See Equity.offer().
     */
    public void grantFounders(int company, double shares) {
        if (!(shares > 0)) return;
        double weight = 0;
        for (Household c : cells) if (!c.isEmpty()) weight += c.households * c.grownUps();
        if (weight <= 0) return;
        for (Household c : cells) {
            if (c.isEmpty()) continue;
            c.shares[company] += shares * c.grownUps() / weight;
        }
    }

    /**
     * Pays every household its dividend, straight into its savings.
     *
     * @return what the city's households received in total
     */
    public double creditDividend(int company, double perShare) {
        if (!(perShare > 0)) return 0;
        double paid = 0;
        for (Household c : cells) {
            if (c.isEmpty() || c.shares[company] <= 0) continue;
            double each = c.shares[company] * perShare;
            c.savings += each;
            c.dividends += each;
            // ...and the household knows it has it, next time it plans a month.
            // See Household.investmentIncome.
            c.investmentIncome += each;
            paid += each * c.households;
        }
        return paid;
    }

    /**
     * EVERY CELL GIVES UP ITS SHARES OF ONE COMPANY, for nothing: a failed
     * bank's resolution (0.7.14; Equity.takeAllForCity() - the old owners
     * are wiped out, CDIC). Nothing is paid, so no cash moves: the loss is a
     * valuation, and the households are outside the audited pools, so the
     * audit has nothing to see. What this month's leavers took with them is
     * the world's now, and goes with the world's.
     *
     * @return the shares the households held, all cells together
     */
    public double surrenderShares(int company) {
        double gone = sharesHeld(company);
        for (Household c : cells) c.shares[company] = 0;
        lastSharesTakenAway[company] = 0;
        return gone;
    }

    /** Shares of this company the city's households hold between them. */
    public double sharesHeld(int company) {
        double total = 0;
        for (Household c : cells) total += c.shares[company] * c.households;
        return total;
    }

    /** What the households were paid in dividends this month. */
    public double totalDividends() {
        double total = 0;
        for (Household c : cells) total += c.dividends * c.households;
        return total;
    }

    /* ---- the row, per household of it: what the screens and the fixtures read ---- */

    public double getSavings(int row)        { return perHousehold(row, Household::savings); }

    /** Households this row was struck for - the multiplier on every per-row figure. */
    public double getHouseholds(int row)     { return rowHouseholds(row); }
    public double getDebt(int row)           { return perHousehold(row, Household::debt); }
    public double getAfterFixed(int row)     { return perHousehold(row, Household::afterFixed); }
    /** What one household of the row had to spend this month, from its own ledger (0.7.27: Policy's pension lines foot on it). */
    public double getDisposable(int row)     { return perHousehold(row, Household::disposable); }
    /** ...and its rent, fees and interest: what came off that before the shop - the ledger's own, so the three foot. */
    public double getFixedCosts(int row)     { return perHousehold(row, c -> c.disposable() - c.afterFixed()); }
    public double getInterest(int row)       { return perHousehold(row, Household::interest); }

    /**
     * What one household of a row would have had to spend with the row's
     * income moved by `rowChange` (0.7.36, the Policy spec's M11): the move
     * split across the row's cells by advanceMonth()'s own rule - splitIncome(),
     * by each cell's earning weight over the whole row's, nothing to a cell
     * too small to strike - on the households as the month counted them, and
     * averaged per household as getDisposable() is. At no move it IS
     * getDisposable(row). The Policy tab asks it of the retired row with the
     * pension bill moved, which is the whole of that row's income
     * (HouseholdAccounts: rowPensions[RETIRED], no wage). Only what the
     * household has: what it then has left after rent and bills is not
     * projected, because its interest is struck on its income
     * (Household.settle()). Pure.
     */
    public double disposableWithRowMoved(int row, double rowChange) {
        double homes = rowHouseholds(row);
        if (homes <= 0) return 0;
        double weight = 0;
        for (Household c : cells) if (c.row() == row) weight += c.households * c.earningWeight();
        double total = 0;
        for (Household c : cells) {
            if (c.row() != row) continue;
            double per = c.disposable();
            if (!c.isEmpty() && weight > 0) per += rowChange * c.earningWeight() / weight;
            total += per * c.households;
        }
        return total / homes;
    }
    public double getDrawn(int row)          { return perHousehold(row, Household::drawn); }

    /** What this row wanted, could not fund, and did not get. See Household.unfunded. */
    public double getUnfunded(int row)       { return perHousehold(row, Household::unfunded); }

    /** True when the bank has stopped lending to any cell of this row - ceiling or lockout. */
    public boolean isCutOff(int row) {
        for (Household c : cells) if (c.row() == row && c.isCutOff()) return true;
        return false;
    }
    public double getBorrowed(int row)       { return perHousehold(row, Household::borrowed); }
    public double getRepaid(int row)         { return perHousehold(row, Household::repaid); }
    public double getBanked(int row)         { return perHousehold(row, Household::banked); }
    public double getWant(int row)           { return perHousehold(row, Household::want); }
    public double getPlanned(int row)        { return perHousehold(row, Household::planned); }
    public double getRate(int row)           { return perHousehold(row, Household::rate); }

    /** True when this row is buying less food than it wants. */
    public boolean isGoingShort(int row) {
        double want = sumRow(row, Household::totalWant);
        return want > 0 && sumRow(row, Household::totalPlanned) < want - 1e-9;
    }

    /** City totals, for the headline lines on the screen. */
    public double totalSavings()  { return sum(Household::totalSavings); }
    public double totalDebt()     { return sum(Household::totalDebt); }
    public double totalInterest() { return sum(Household::totalInterest); }

    /**
     * What the families' credit lines cost them this month on average: each
     * cell's rate weighted by what it owes - the bank's household rate plus
     * RISK_SLOPE for every month of income owed, capped at MAX_RATE
     * (Household.settle()). The Bank tab's rung for the families. Nothing
     * with nobody owing.
     */
    public double averageRate() {
        double owed = totalDebt();
        return owed > 0 ? sum(c -> c.rate() * c.totalDebt()) / owed : 0;
    }

    /** New lending to families this month - the bank's money out the door. */
    public double totalBorrowed() { return sum(Household::totalBorrowed); }

    /** ...and what came back. */
    public double totalRepaid()   { return sum(Household::totalRepaid); }

    /** What every household in the city has, less what it owes. */
    public double totalNetWorth() { return totalSavings() - totalDebt(); }

    /* ------------------------------- saving -------------------------------
     *
     * A STOCK, so it has to be carried. Savings and debt are the two things on
     * this screen that are not derived from the month - rebuilding them from
     * the state a month ended in is exactly the reconstruction this codebase
     * has been caught by six times. Most of the last-month working is NOT
     * saved: it is a flow, it is recomputed on the first tick, and carrying it
     * would be carrying an answer nobody would re-ask.
     *
     * TWO ARRAYS. The cells are the state now and go under their own key,
     * named cell by cell (see cellKeys()), so a shape added to the enum or
     * moved within it cannot read one cell's money into another's. The row
     * array is still written, as the SUM of the cells, for one reason: a build
     * from before the cells reads it and restores the rows it knows, so an old
     * build opening a new save loses nothing it can hold. A new build opening
     * an old save seeds every cell of a row with the row's position - see
     * restore(). Neither direction moves SAVE_FORMAT.
     */

    /** The row array an older build reads: ROWS*8+5 since 0.7.27 (ROWS*8+3 before), per household of the row. */
    public double[] toSaveArray() {
        double[] out = new double[ROWS * 8 + 5];
        for (int r = 0; r < ROWS; r++) {
            out[r]            = getSavings(r);
            out[ROWS + r]     = getDebt(r);
            // The lockout is a countdown, which is a STOCK: a tier discharged
            // last month is eleven months from borrowing again, and a save
            // that forgot it would hand that tier a fresh line of credit.
            out[ROWS * 2 + r] = getLockout(r);
            /*
             * ...AND THE HOUSEHOLD COUNTS THE STOCKS ARE PER. The per-household
             * figures times this array are the city's whole stock of household
             * money, and unsaved it read a third out for one month after every
             * load - $1.29M against $966k - which came out as a wrong bank
             * profit, a wrong bank tax and $13 of treasury a month later. What
             * SaveFileCheck caught.
             */
            out[ROWS * 3 + r] = rowHouseholds(r);
            /*
             * ...AND THE WORKING THE NEXT MONTH IS READ AGAINST. The shops size
             * their month against getSpendingCapacity() and getWantedSpend(),
             * the advisor against the same two, all before the tick that would
             * recompute them; a reloaded city planned its twelfth month against
             * a rebuilt eleventh and came out $13 adrift on a $690.7M treasury.
             * Small, and it compounds.
             */
            out[ROWS * 4 + r] = getWant(r);
            out[ROWS * 5 + r] = getPlanned(r);
            out[ROWS * 6 + r] = getInterest(r);
            out[ROWS * 7 + r] = getSubsistence(r);
        }
        out[ROWS * 8]     = plannedSpend;
        out[ROWS * 8 + 1] = hungryPeople;
        out[ROWS * 8 + 2] = totalPeople;
        /*
         * ...AND THE TWO HALVES OF THE HUNGER (0.7.27, SAVE_FORMAT 30): the
         * share the shops handed over, which read 1 after every load until a
         * month ran, and the hungry at full shelves. The cells' array does
         * not carry them; this one is restored on every load.
         */
        out[ROWS * 8 + 3] = lastDelivered;
        out[ROWS * 8 + 4] = hungryAtFullShelves;
        return out;
    }

    /** Figures carried per cell before the shares were appended (2026-09-10, evening). */
    public static final int CELL_SLOTS_BEFORE_SHARES = 8;

    /** ...and before the dollars abroad were (2026-09-11). */
    public static final int CELL_SLOTS_BEFORE_ABROAD = CELL_SLOTS_BEFORE_SHARES + Equity.COMPANIES.length;

    /** ...and before the student loans were (2026-09-11, afternoon). */
    public static final int CELL_SLOTS_BEFORE_STUDENT_DEBT = CELL_SLOTS_BEFORE_ABROAD + 1;

    /** ...and before the cars were (2026-09-16). */
    public static final int CELL_SLOTS_BEFORE_CARS = CELL_SLOTS_BEFORE_STUDENT_DEBT + 1;

    /** ...and before the month's investment income was (2026-09-17). */
    public static final int CELL_SLOTS_BEFORE_INVESTMENT_INCOME = CELL_SLOTS_BEFORE_CARS + 1;

    /**
     * ...and the dinners, appended 2026-09-18.
     *
     * A save from before the kitchens existed has households that ate out
     * nothing last month, which is exactly true of that city. The reader
     * checks the width, so SAVE_FORMAT does not move - the same tail-append
     * the cars and the investment income got.
     */
    public static final int CELL_SLOTS_BEFORE_MEALS = CELL_SLOTS_BEFORE_INVESTMENT_INCOME + 1;

    /**
     * ...and the share of the cell's people who paid for care, appended
     * 2026-09-19.
     *
     * A save from before the clinic had a price has households that all
     * paid, which is exactly true of that city; the reader checks the width
     * and reads 1 for them, so SAVE_FORMAT does not move.
     */
    public static final int CELL_SLOTS_BEFORE_CARE = CELL_SLOTS_BEFORE_MEALS + 1;

    /**
     * ...and the city's paper, appended 2026-09-22 (0.7.1).
     *
     * A save from before the households could hold the city's paper has
     * households that hold none, which is exactly true of that city: the
     * reader checks the width and reads 0, so SAVE_FORMAT does not move.
     */
    public static final int CELL_SLOTS_BEFORE_PAPER = CELL_SLOTS_BEFORE_CARE + 1;

    /**
     * ...and the cell's bonds at face, all together, appended 0.7.12: since
     * round 2 the sum of what it holds bond by bond (saved under its own key,
     * householdBondsByCell), and in a round-1 save its claim on the
     * households' one pool, which the load hands out by (claimPooledBonds()).
     *
     * A save from before the businesses issued bonds has households that
     * hold none, which is exactly true of that city: the reader checks the
     * width and reads 0, so SAVE_FORMAT does not move.
     */
    public static final int CELL_SLOTS_BEFORE_BONDS = CELL_SLOTS_BEFORE_PAPER + 1;

    /**
     * ...and the last sale's groceries, appended 0.7.43: the baskets each
     * household got, the baskets it asked for at the price, the baskets it
     * needed, and the food assistance paid on them - written at the bottom of
     * the month and read at the next one's top (the hunger, the shop split),
     * so they cross a save.
     *
     * A save from before has none; the reader checks the width and seeds
     * the baskets from the measure that save's hunger was struck on
     * (seedGroceries()), so its first month eats as it did - no SAVE_FORMAT
     * bump.
     */
    public static final int CELL_SLOTS_BEFORE_GROCERIES = CELL_SLOTS_BEFORE_BONDS + 1;

    /**
     * ...and the investment income the food assistance means test reads,
     * smoothed over MEANS_INCOME_MONTHS, appended 0.7.45. A save from before
     * has none, and seeds it at the month's investment income it carries -
     * the figure that save's test read - so its first month tests as it did.
     */
    public static final int CELL_SLOTS_BEFORE_MEANS_INCOME = CELL_SLOTS_BEFORE_GROCERIES + 4;

    /**
     * ...and before each cell's income after its fixed bills was carried (A4).
     * Struck by the month (Household.settle()) from that month's
     * disposable income, rent and fees, and read between presses by the food
     * assistance's means test; a reload struck it again from the moment of
     * loading (Household.restrike(), on the rebuild's planOnly()), which is
     * not the month's. A save from before keeps that re-strike, as it always did.
     */
    public static final int CELL_SLOTS_BEFORE_AFTER_FIXED = CELL_SLOTS_BEFORE_MEANS_INCOME + 1;

    /** Figures carried per cell, in the order toCellSaveArray() writes them: the eight, a share count per company, the dollars abroad, the student loan, the cars, the month's investment income, the month's meals eaten out, the share who paid for care, the city's paper, its bonds, the last sale's baskets got, asked and needed and its food assistance, the means test's smoothed investment income, and the month's income after its fixed bills. */
    public static final int CELL_SLOTS = CELL_SLOTS_BEFORE_AFTER_FIXED + 1;

    /** The name of every cell, in the order toCellSaveArray() writes them. */
    public String[] cellKeys() {
        String[] keys = new String[cells.length];
        for (int i = 0; i < cells.length; i++) keys[i] = cells[i].key();
        return keys;
    }

    /** CELL_SLOTS per cell, in cellKeys() order, then the three city figures. */
    public double[] toCellSaveArray() {
        double[] out = new double[cells.length * CELL_SLOTS + 3];
        int i = 0;
        for (Household c : cells) {
            out[i++] = c.savings;
            out[i++] = c.debt;
            out[i++] = c.lockout;
            out[i++] = c.households;
            out[i++] = c.want;
            out[i++] = c.planned;
            out[i++] = c.interest;
            out[i++] = c.subsistence;
            for (double held : c.shares) out[i++] = held;
            out[i++] = c.abroad;
            out[i++] = c.studentDebt;
            out[i++] = c.cars;
            out[i++] = c.investmentIncome;
            out[i++] = c.mealsEaten;
            out[i++] = c.carePaid;
            out[i++] = c.paper;
            out[i++] = c.bonds;
            out[i++] = c.groceriesGot;
            out[i++] = c.groceriesAsked;
            out[i++] = c.groceriesNeed;
            out[i++] = c.assistance;
            out[i++] = c.meansIncome;
            out[i++] = c.afterFixed;
        }
        out[i++] = plannedSpend;
        out[i++] = hungryPeople;
        out[i]   = totalPeople;
        return out;
    }

    /**
     * Puts the cells back, by name.
     *
     * A key this build has no cell for is skipped - a shape that no longer
     * exists - and a cell the save does not name keeps whatever restore() put
     * in it from the rows, which for a save from this build is nothing: an
     * empty cell, filled by the first census as an arrival. Refused whole when
     * the array is not the keys' length.
     *
     * @return false if nothing was restored
     */
    public boolean restoreCells(String[] keys, double[] saved, String[] savedCompanies) {
        if (keys == null || saved == null || keys.length == 0) return false;
        /* =====================================================================
           THE SLOT COUNT ALONE DOES NOT SAY WHAT THE SLOTS ARE (2026-09-12)

           Eight a cell from the morning the cells went in, eight plus a share
           per company from the evening, those plus the dollars abroad from the
           next day, and those plus the student debt. Any of them restores what
           it carries; a save without shares has households that own none.

           But the share block is as wide as Equity.COMPANIES, which is the
           SECTORS PLUS THE BANK - so adding a sector moves every width after
           it. Eighteen slots meant "the full array" while there were seven
           sectors and means "the array before student debt" now there are
           eight, and the old reading of a format-21 save would have taken its
           eight holdings plus its dollars abroad as nine holdings, and its
           student debt as its dollars abroad. Silent corruption of every
           household's portfolio, with no refusal - and bumping SAVE_FORMAT
           would not have caught it, because older saves always load.

           So the widths are computed from the company list THE SAVE WAS WRITTEN
           WITH, which the save already carries (DataSave.getEquityKeys), and
           the holdings are mapped BY NAME rather than by position. A save from
           before the eighth sector restores its eight holdings correctly and
           owns none of the ninth company, which is exactly true of that city.
           ===================================================================== */
        int savedShares = savedCompanies == null ? Equity.COMPANIES.length : savedCompanies.length;
        final int wasBeforeShares  = CELL_SLOTS_BEFORE_SHARES;
        final int wasBeforeAbroad  = wasBeforeShares + savedShares;
        final int wasBeforeStudent = wasBeforeAbroad + 1;
        final int wasBeforeCars    = wasBeforeStudent + 1;
        final int wasBeforeIncome  = wasBeforeCars + 1;
        final int wasBeforeMeals   = wasBeforeIncome + 1;
        final int wasBeforeCare    = wasBeforeMeals + 1;
        final int wasBeforePaper   = wasBeforeCare + 1;
        final int wasBeforeBonds   = wasBeforePaper + 1;
        final int wasBeforeGroceries = wasBeforeBonds + 1;
        final int wasBeforeMeans   = wasBeforeGroceries + 4;
        final int wasBeforeAfterFixed = wasBeforeMeans + 1;
        final int wasFull          = wasBeforeAfterFixed + 1;

        int slots = (saved.length - 3) / keys.length;
        if (saved.length != keys.length * slots + 3
                || (slots != wasFull && slots != wasBeforeAfterFixed
                    && slots != wasBeforeMeans && slots != wasBeforeGroceries
                    && slots != wasBeforeBonds && slots != wasBeforePaper
                    && slots != wasBeforeCare && slots != wasBeforeMeals
                    && slots != wasBeforeIncome && slots != wasBeforeCars
                    && slots != wasBeforeStudent && slots != wasBeforeAbroad
                    && slots != wasBeforeShares)) {
            return false;
        }

        // Where each saved holding belongs in today's register, by name. -1 is
        // a company this build no longer lists: that holding is dropped, the
        // same way a cell key this build has no cell for is skipped.
        int[] shareSlot = new int[savedShares];
        for (int k = 0; k < savedShares; k++) {
            shareSlot[k] = -1;
            String name = savedCompanies == null || k >= savedCompanies.length
                    ? (k < Equity.COMPANIES.length ? Equity.COMPANIES[k] : null)
                    : savedCompanies[k];
            if (name == null) continue;
            for (int c = 0; c < Equity.COMPANIES.length; c++) {
                if (Equity.COMPANIES[c].equals(name)) { shareSlot[k] = c; break; }
            }
        }
        java.util.Map<String, Household> byKey = new java.util.HashMap<>();
        for (Household c : cells) byKey.put(c.key(), c);

        int i = 0;
        for (String key : keys) {
            Household c = byKey.get(key);
            if (c == null) { i += slots; continue; }
            c.savings     = saved[i++];
            c.debt        = saved[i++];
            c.lockout     = (int) Math.round(saved[i++]);
            c.households  = saved[i++];
            c.want        = saved[i++];
            c.planned     = saved[i++];
            c.interest    = saved[i++];
            c.subsistence = saved[i++];
            java.util.Arrays.fill(c.shares, 0);
            c.abroad = 0;
            c.studentDebt = 0;
            /*
             * A CITY FROM BEFORE CARS EXISTED OWNS NONE, and that zero is the
             * whole of why this batch could be measured at all: the road
             * multiplier and the transit rule below are both exactly 1 at zero
             * ownership, so an old save reloads into a city that behaves to
             * the bit as it did the day it was written, and then starts buying.
             */
            c.cars = 0;
            if (slots >= wasBeforeAbroad) {
                for (int k = 0; k < savedShares; k++) {
                    double held = saved[i++];
                    if (shareSlot[k] >= 0) c.shares[shareSlot[k]] = held;
                }
            }
            if (slots >= wasBeforeStudent) c.abroad = Math.max(0, saved[i++]);
            if (slots >= wasBeforeCars) c.studentDebt = Math.max(0, saved[i++]);
            if (slots >= wasBeforeIncome) c.cars = Math.max(0, saved[i++]);
            // A save from before this field has households that received no
            // investment income last month, which is exactly true of that city
            // - nothing in it was ever going to spend any.
            if (slots >= wasBeforeMeals) c.investmentIncome = Math.max(0, saved[i++]);
            // ...and a city from before the kitchens ate out nothing.
            c.mealsEaten = 0;
            if (slots >= wasBeforeCare) c.mealsEaten = Math.max(0, saved[i++]);
            // ...and one from before the clinic had a price paid for all of
            // its care: 1, which is exactly what that city did.
            c.carePaid = 1;
            if (slots >= wasBeforePaper) c.carePaid = Math.max(0, Math.min(1, saved[i++]));
            // ...and one from before the city's paper could be held at home
            // holds none of it: the bank held everything (0.7.1).
            c.paper = 0;
            if (slots >= wasBeforeBonds) c.paper = Math.max(0, saved[i++]);
            // ...and one from before the businesses' bonds holds none (0.7.12).
            c.bonds = 0;
            if (slots >= wasBeforeGroceries) c.bonds = Math.max(0, saved[i++]);
            // ...and one from before groceries had a price ate what its own
            // hunger measure said (0.7.43; see seedGroceries()).
            if (slots >= wasBeforeMeans) {
                c.groceriesGot   = Math.max(0, saved[i++]);
                c.groceriesAsked = Math.max(0, saved[i++]);
                c.groceriesNeed  = Math.max(0, saved[i++]);
                c.assistance     = Math.max(0, saved[i++]);
            } else {
                seedGroceries(c);
            }
            // ...and one from before 0.7.45 tested its means on the month's
            // investment income alone: seeded at that, so it tests as it did.
            c.meansIncome = slots >= wasBeforeAfterFixed ? Math.max(0, saved[i++]) : Math.max(0, c.investmentIncome);
            // ...and the month's income after its fixed bills (A4, 0.7.46),
            // over the rebuild's re-strike from the moment of loading - this
            // runs after it. One from before keeps the re-strike, as it did.
            if (slots >= wasFull) c.afterFixed = saved[i++];
        }
        plannedSpend = saved[i++];
        hungryPeople = saved[i++];
        totalPeople  = saved[i];
        return true;
    }

    /**
     * Puts a ROW array back, seeding every cell of the row with the row's
     * position: the save from a build that kept the stocks per tier.
     *
     * @param saved  ROWS*8+5 from this build (0.7.27: the two halves of the
     *               hunger after the working), ROWS*8+3 from a build with the
     *               row working, or ROWS*3 from
     *               one before the household counts and the working were
     *               appended. A short array restores what it carries and
     *               leaves the rest to the rebuild.
     * @param census the household counts to seed the cells with, or null to
     *               leave them empty for the plan to fill - see Game's load
     *               path, which restores once before the family model is back
     *               and once after.
     */
    public void restore(double[] saved, ToDoubleBiFunction<FamilyStructure, PayTier> census) {
        if (saved == null) return;
        /*
         * THE ROW ARRAY FROM TODAY'S BUILD, OR FROM ONE BEFORE THE PEOPLE
         * OUTSIDE THE FAMILIES had rows (seven: the tiers and the retired).
         * A seven-row array restores the rows it knows; the new rows wait for
         * the census, as arrivals.
         */
        int rows;
        boolean current;
        int beforePrison = Household.ROWS_BEFORE_PRISON;
        // ...and since 0.7.27 the two halves of the hunger after the working.
        boolean halves = saved.length == ROWS * 8 + 5;
        if (halves)                                           { rows = ROWS; current = true; }
        else if (saved.length == ROWS * 8 + 3)                { rows = ROWS; current = true; }
        else if (saved.length == ROWS * 3)                    { rows = ROWS; current = false; }
        // ...or from the day before the prisons, with no prisoners' row.
        else if (saved.length == beforePrison * 8 + 3)        { rows = beforePrison; current = true; }
        else if (saved.length == beforePrison * 3)            { rows = beforePrison; current = false; }
        else if (saved.length == ROWS_BEFORE_OUTSIDE * 8 + 3) { rows = ROWS_BEFORE_OUTSIDE; current = true; }
        else if (saved.length == ROWS_BEFORE_OUTSIDE * 3)     { rows = ROWS_BEFORE_OUTSIDE; current = false; }
        else return;   // refused whole
        double[] fresh = census == null ? new double[cells.length] : takeCensus(census);
        for (int i = 0; i < cells.length; i++) {
            Household c = cells[i];
            int r = c.row();
            c.households = fresh[i];
            if (r >= rows) continue;
            // Clamped on the way back in, for the reason every other write to
             // a position is: a saved dust is still a dust. See moveStock().
            c.savings = Math.max(0, saved[r]);
            c.debt = Math.max(0, saved[rows + r]);
            c.lockout = (int) Math.round(saved[rows * 2 + r]);
            if (current) {
                c.want        = saved[rows * 4 + r];
                c.planned     = saved[rows * 5 + r];
                c.interest    = saved[rows * 6 + r];
                c.subsistence = saved[rows * 7 + r];
            }
        }
        if (current) {
            plannedSpend = saved[rows * 8];
            hungryPeople = saved[rows * 8 + 1];
            totalPeople  = saved[rows * 8 + 2];
        }
        if (halves) {
            lastDelivered       = Math.max(0, Math.min(1, saved[rows * 8 + 3]));
            hungryAtFullShelves = Math.max(0, saved[rows * 8 + 4]);
        }
        // The last sale's baskets, from the measure this save's hunger was
        // struck on; restoreCells() overrides them where the save has them.
        for (Household c : cells) seedGroceries(c);
    }

    /**
     * The last sale's baskets for a household from a save before 0.7.43,
     * which carries the money measure its hunger was struck on: its plan
     * times the share the shops handed over, against subsistence - turned
     * into baskets by the same price on both sides. So the first month after
     * the load counts the hunger that save would have counted; the sale at
     * its bottom is the first at a price. No voucher was ever paid.
     */
    private void seedGroceries(Household c) {
        double n = c.subsistence > 0 ? c.baskets() : 0;
        double planned = c.subsistence > 0 ? c.planned / c.subsistence : 1;
        c.groceriesGot   = n * Math.max(0, Math.min(1, planned * lastDelivered));
        c.groceriesAsked = n * Math.max(0, Math.min(1, planned));
        c.groceriesNeed  = n;
        c.assistance     = 0;
    }

    /** The row array alone, with no census: the cells wait for the plan to count them. */
    public void restore(double[] saved) { restore(saved, null); }

    public void reset() {
        for (Household c : cells) c.clearAll();
        java.util.Arrays.fill(lastSharesTakenAway, 0);
        lastWrittenOff = 0;
        lastLeaving = 0;
        lastEvicted = 0;
        lastStudentDebtTakenAway = 0;
        lastTakenAway = 0;
        graduating = 0;
        lastGraduated = 0;
        lastAbroadTakenAway = 0;
        lastDepositInterest = 0;
        paperRatio = 1;
        bondRatio = 1;
        lastBondsTakenAway = 0;
        spendFactor = 1;
        lastDelivered = 1;
        lastCareSkipped = 0;
        careBillByRow = null;
        careBillFullByRow = null;
        plannedSpend = 0;
        hungryPeople = 0;
        totalPeople = 0;
        hungryAtFullShelves = 0;
        satiationPrice = 0;
        foodAssistance = 0;
        lastFoodAssistancePaid = 0;
        lastFedByAssistance = 0;
    }

    /**
     * The households' stocks and this month's working, in the new unit.
     *
     * Rates, lockouts, household counts and headcounts do not move; the
     * delivered share is a share.
     */
    public void redenominate(double scale) {
        minMove *= scale;
        lastWrittenOff *= scale;
        lastTakenAway *= scale;
        lastStudentDebtTakenAway *= scale;
        lastBondsTakenAway *= scale;
        localPerUsd *= scale;
        plannedSpend *= scale;
        lastDepositInterest *= scale;
        lastCareSkipped *= scale;
        // The grocer's prices and the vouchers paid are money (0.7.43); the
        // baskets they bought are not.
        satiationPrice *= scale;
        lastFoodAssistancePaid *= scale;
        forEach(c -> c.redenominate(scale));
    }

}
