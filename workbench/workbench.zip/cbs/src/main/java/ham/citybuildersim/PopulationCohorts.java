package ham.citybuildersim;

/**
 * The city's age pyramid, and since the switch, the city's POPULATION.
 *
 * ==================== THIS IS NOW LOAD-BEARING ====================
 *
 * It was a placeholder for two batches, asserted inert by a harness that played
 * two identical cities and required every figure to match. That assertion is
 * gone, on purpose: `total()` IS the population now, and everything downstream -
 * the workforce, the job fill rate, every sector's output, the wage bill, the
 * wage tax, GDP - keys off it.
 *
 * WHAT CHANGED, AND WHY IT MATTERS MORE THAN IT LOOKS
 *
 * The population used to be `min(housing, jobs * 2.25)`: derived fresh every
 * month from nothing, with no memory. A finished tower filled instantly, a
 * demolished one erased its residents, and a city could double in a month.
 *
 * Now it is a STOCK. Births and deaths move it, `Migration` moves it far more,
 * and housing and jobs set a TARGET that migration chases rather than a ceiling
 * the city snaps to. That is where the city's inertia comes from, and it is the
 * whole point: a tower fills over months, a closed plant does not evaporate its
 * workers, and a bust takes a year to begin.
 *
 * =================================================================
 *
 * THE MECHANIC
 *
 * Every month each band gives up `1/spanMonths` of itself to the next one, and
 * seniors give theirs up to nothing. Births arrive at the bottom. That is a
 * compartment model, and its known cost is that residence time is exponential
 * rather than fixed - see AgeBand.monthlyOutflowRate(), where the numbers are.
 *
 * Held as doubles, not ints. Rounding 1/444 of an adult population to a whole
 * person every month would round almost every transfer to zero in a small city
 * and leak people steadily in a large one; the pyramid is a distribution and it
 * is allowed to hold fractions. Only the DISPLAY rounds.
 */
public class PopulationCohorts {

    /**
     * Births per thousand residents per year.
     *
     * PLACEHOLDER, at 1.5% a year on Jerus's call, standing in for what will
     * eventually depend on healthcare, housing and prosperity.
     *
     * Slightly above the rate that would hold the population exactly steady
     * against the mortality in AgeBand - which works out near 1.4% - so a city
     * left alone grows very slowly rather than shrinking.
     *
     * THIS IS THE FLOOR NOW, not the rate. Childcare multiplies it, up to
     * double at full coverage, so fifteen per thousand is what a city with
     * nowhere to leave a child manages and thirty is what one that has solved
     * the problem does. See Healthcare.birthFactor(). (The note that used to sit
     * here said scaleTo() overrode the total anyway; that stopped being true the
     * day the pyramid became the population.)
     */
    public static final double BIRTHS_PER_1000_PER_YEAR = 15.0;

    private final double[] band = new double[AgeBand.values().length];

    /** Everything that happened last month, for the screen. */
    private double lastBirths;
    private double lastDeaths;
    private double lastMigration;
    private final double[] lastPromoted = new double[AgeBand.values().length];
    private final double[] lastDeathsByBand = new double[AgeBand.values().length];
    /** ...of which sickness: the share of each band's deaths its extra rate carried. */
    private final double[] lastIllnessDeathsByBand = new double[AgeBand.values().length];
    /** ...and of which the band's mortality at all, as opposed to ageing out of the top at 120. */
    private final double[] lastDyingByBand = new double[AgeBand.values().length];
    /** ...and of which violence: the killed. See Crime. */
    private final double[] lastKilledByBand = new double[AgeBand.values().length];

    /*
     * THE MONTH'S DEAD BY CAUSE, SUMMED AND SAVED (0.7.27). The by-band
     * arrays above are the month's working and are not saved, so after a
     * load the deaths read their total with nothing under it. These three
     * are what the People page's waterfall splits the dead into, with the
     * illness deaths Sickness keeps: the killed, the rest of the dying - of
     * age, the band's own mortality - and the ones who aged out of the top
     * of the pyramid at 120. Struck where the month books the dead, so the
     * four add up to getLastDeaths(); nothing in the month reads them.
     */
    private double lastKilled;
    private double lastDeathsOfAge;
    private double lastAgedOut;

    public PopulationCohorts() { }

    /* ----------------------------- reading ----------------------------- */

    public double get(AgeBand b)      { return band[b.ordinal()]; }
    public double getLastBirths()     { return lastBirths; }
    public double getLastDeaths()     { return lastDeaths; }
    public double getLastMigration()  { return lastMigration; }
    public double getPromoted(AgeBand b) { return lastPromoted[b.ordinal()]; }
    public double getDeaths(AgeBand b)   { return lastDeathsByBand[b.ordinal()]; }
    /** Last month's deaths in a band that sickness caused. See Sickness. */
    public double getIllnessDeaths(AgeBand b) { return lastIllnessDeathsByBand[b.ordinal()]; }
    public double[] getIllnessDeaths()   { return lastIllnessDeathsByBand.clone(); }
    /** Last month's deaths in a band from its mortality - everything but the seniors who aged out at 120. */
    public double getDying(AgeBand b)    { return lastDyingByBand[b.ordinal()]; }
    /** Last month's deaths in a band that were killings. See Crime. */
    public double getKilled(AgeBand b)   { return lastKilledByBand[b.ordinal()]; }
    public double[] getKilled()          { return lastKilledByBand.clone(); }
    /** Last month's killings, every band together - saved, unlike the bands (0.7.27). */
    public double getLastKilled()        { return lastKilled; }
    /** Last month's deaths of the bands' own mortality: the dying, less illness and violence (0.7.27). */
    public double getLastDeathsOfAge()   { return lastDeathsOfAge; }
    /** Last month's deaths out of the top of the pyramid at 120: the deaths that are not dying (0.7.27). */
    public double getLastAgedOut()       { return lastAgedOut; }

    public double total() {
        double sum = 0;
        for (double v : band) sum += v;
        return sum;
    }

    /** Share of the city in this band, 0-1. */
    public double share(AgeBand b) {
        double t = total();
        return t > 0 ? band[b.ordinal()] / t : 0;
    }

    /** Everyone of working age. Not the workforce - see the note below. */
    public double workingAge() {
        double sum = 0;
        for (AgeBand b : AgeBand.values()) {
            if (b.isWorkingAge()) sum += band[b.ordinal()];
        }
        return sum;
    }

    /**
     * Children and seniors per hundred working-age adults.
     *
     * The number that will eventually matter most: it is what decides how many
     * earners a household has against how many mouths, and therefore what the
     * city can actually tax. Reported now purely so the shape can be judged.
     */
    public double dependencyRatio() {
        double working = workingAge();
        if (working <= 0) return 0;
        return (total() - working) / working * 100;
    }

    /* ----------------------------- ageing ----------------------------- */

    /**
     * One month of ageing. Called from the monthly tick; reads nothing else.
     *
     * WORKED FROM THE TOP DOWN, which is not cosmetic. Going upward would let a
     * baby promoted this month be promoted again out of the child band in the
     * same tick, and again out of teens - a newborn could reach the workforce in
     * three months. Draining seniors first and babies last means every transfer
     * lands in a band that has already been processed.
     *
     * An empty city stays empty until somebody moves in - see migrate(), which
     * is where a city with no residents gets its first ones. There is nothing to
     * age here and nobody to give birth.
     */
    public void advanceMonth() {
        advanceMonth(null);
    }

    /**
     * The same month, with healthcare's hand on the death rate.
     *
     * @param mortalityFactor one multiplier per band, in band order, or null for
     *                        a city where nothing modifies mortality. A wrong-
     *                        length array is refused whole and treated as null,
     *                        per the standing rule - a pyramid that applied a
     *                        childcare multiplier to seniors because the array
     *                        was read at an offset would be far worse than one
     *                        that applied nothing.
     *
     * The multiplier goes through AgeBand.monthlyFromAnnual() rather than
     * multiplying monthlyMortality() directly, which is not the same thing and
     * is the whole reason that method is public. Scaling the ANNUAL rate and
     * re-compounding is the honest conversion, and it is what keeps the figure
     * checkable against a life table; scaling the monthly rate would drift, and
     * would skip the MAX_MONTHLY_MORTALITY cap that stops an unreviewed factor
     * emptying a band in a month.
     */
    public void advanceMonth(double[] mortalityFactor) {
        advanceMonth(mortalityFactor, 1);
    }

    /**
     * The same month, with healthcare's hand on BOTH ends of a life.
     *
     * @param birthFactor what the birth rate is multiplied by - somewhere to
     *                    leave a child is the difference between one and two,
     *                    and until this existed births were a flat fifteen per
     *                    thousand a year whatever the player did. See
     *                    Healthcare.birthFactor().
     */
    public void advanceMonth(double[] mortalityFactor, double birthFactor) {
        advanceMonth(mortalityFactor, null, birthFactor);
    }

    /**
     * The same month, with the people who stayed sick dying as well.
     *
     * @param illness each band's extra MONTHLY chance of dying from sickness,
     *                in band order - Sickness.deathRates() - or null for none.
     *                Added to the band's base rate after care has scaled it,
     *                off the same opening balance, so ageing, ordinary deaths
     *                and sickness deaths stay competing risks. Monthly and not
     *                annual because the ring already works a month at a time;
     *                re-compounding it would be converting a rate that was
     *                never annual. Capped with the rest at
     *                AgeBand.MAX_MONTHLY_MORTALITY.
     */
    public void advanceMonth(double[] mortalityFactor, double[] illness, double birthFactor) {
        advanceMonth(mortalityFactor, illness, null, birthFactor);
    }

    /**
     * ...and the people violence killed (2026-09-11).
     *
     * @param violence each band's MONTHLY chance of being killed, in band
     *                 order, or null for none - Crime's killings over the
     *                 adults, last month's. The same competing risk as
     *                 sickness, off the same opening balance, capped with the
     *                 rest.
     */
    public void advanceMonth(double[] mortalityFactor, double[] illness, double[] violence,
                             double birthFactor) {

        double[] factor = (mortalityFactor != null
                && mortalityFactor.length == AgeBand.values().length)
                ? mortalityFactor : null;
        double[] sick = (illness != null && illness.length == AgeBand.values().length)
                ? illness : null;
        double[] killing = (violence != null && violence.length == AgeBand.values().length)
                ? violence : null;

        java.util.Arrays.fill(lastPromoted, 0);
        java.util.Arrays.fill(lastDeathsByBand, 0);
        java.util.Arrays.fill(lastIllnessDeathsByBand, 0);
        java.util.Arrays.fill(lastDyingByBand, 0);
        java.util.Arrays.fill(lastKilledByBand, 0);
        lastBirths = 0;
        lastDeaths = 0;
        lastMigration = 0;
        lastKilled = 0;
        lastDeathsOfAge = 0;
        lastAgedOut = 0;

        if (total() <= 0) {
            return;
        }

        /*
         * AGEING AND DYING ARE COMPETING RISKS, both taken as a share of the
         * balance the band STARTED the month with rather than one applied after
         * the other. Sequential application would make the second risk depend on
         * the first - deaths-then-ageing and ageing-then-deaths give different
         * answers, and neither is more defensible than the other. Computing both
         * off the same opening balance keeps them independent, which is what
         * they are.
         */
        for (int i = AgeBand.values().length - 1; i >= 0; i--) {

            AgeBand b = AgeBand.values()[i];
            double opening = band[i];
            if (opening <= 0) continue;

            double rate = factor == null
                    ? b.monthlyMortality()
                    : AgeBand.monthlyFromAnnual(b.getAnnualMortality() * Math.max(0, factor[i]));
            double ill = sick == null ? 0 : Math.max(0, sick[i]);
            double kill = killing == null ? 0 : Math.max(0, killing[i]);
            double all = rate + ill + kill;
            double both = Math.min(AgeBand.MAX_MONTHLY_MORTALITY, all);
            // The cap scales every part alike, so sickness and violence keep their shares of the dead.
            double illShare = all > 0 ? ill / all : 0;
            double killShare = all > 0 ? kill / all : 0;
            rate = both;

            double dying  = opening * rate;
            double ageing = opening * b.monthlyOutflowRate();

            // Belt and braces. The rates are far below this and the cap in
            // AgeBand keeps a modifier from getting near it, but a band losing
            // more people than it has would be a negative population, and this
            // pyramid is about to become the population.
            double total = dying + ageing;
            if (total > opening) {
                double scale = opening / total;
                dying *= scale;
                ageing *= scale;
            }

            band[i] -= (dying + ageing);
            lastPromoted[i] = ageing;
            lastDeathsByBand[i] = dying;
            lastDyingByBand[i] = dying;
            lastIllnessDeathsByBand[i] = dying * illShare;
            lastKilledByBand[i] = dying * killShare;
            lastDeaths += dying;
            lastKilled += lastKilledByBand[i];
            lastDeathsOfAge += dying - lastIllnessDeathsByBand[i] - lastKilledByBand[i];

            AgeBand next = b.next();
            if (next != null) {
                band[next.ordinal()] += ageing;
            } else {
                // Out of the top of the pyramid at 120, which is also a death.
                lastDeathsByBand[i] += ageing;
                lastDeaths += ageing;
                lastAgedOut += ageing;
            }
        }

        lastBirths = total() * (BIRTHS_PER_1000_PER_YEAR / 1000.0) / 12.0
                * Math.max(0, birthFactor);
        band[AgeBand.BABY.ordinal()] += lastBirths;
    }

    /**
     * People moving in, or out. This is now the city's main source of residents.
     *
     * Migrants arrive in the city's own proportions, per Jerus - if 30% of the
     * city is adults then 30% of the arrivals are adults. Crude, and known to be:
     * real migration skews heavily toward working age, which is why a city here
     * imports its own dependency ratio rather than improving it. Worth fixing
     * once there is a reason to; it is on the screen's own list of omissions.
     *
     * THE FIRST ARRIVALS ARE THE EXCEPTION. An empty city has no proportions to
     * copy, so the first people through the door get the shape a settled
     * population of that size would have - see seedFrom(). Without this a new
     * game can never start: an empty pyramid has nothing to scale, so nobody
     * would ever arrive and the city would sit at zero residents forever with
     * every job going begging.
     */
    public void migrate(double netArrivals) {

        double t = total();

        if (t <= 0) {
            if (netArrivals > 0) {
                seedFrom(Math.round(netArrivals));
                lastMigration = netArrivals;
            }
            return;
        }

        lastMigration = netArrivals;
        if (netArrivals == 0) return;

        for (int i = 0; i < band.length; i++) {
            band[i] = Math.max(0, band[i] + netArrivals * (band[i] / t));
        }
    }

    /**
     * People of one band leaving the city on their own account - not the
     * proportional migration above. The evicted who give up on the city are
     * adults, and taking them out of every band would have sent babies away
     * for their parents' rent (2026-09-11).
     *
     * @return how many actually left: no more than the band holds
     */
    public double leave(AgeBand of, double people) {
        if (!(people > 0)) return 0;
        int i = of.ordinal();
        double gone = Math.min(people, band[i]);
        band[i] -= gone;
        lastMigration -= gone;
        return gone;
    }

    /**
     * Gives an empty pyramid the shape a settled population of this size has.
     *
     * WHY NOT JUST SPANS. The first version shared the bands out in proportion
     * to how long people stay in each - a real property of a compartment model,
     * and true only if nobody ever dies. They do now, and it broke the shape
     * badly: seniors span fifty of the hundred and twenty years, so a brand-new
     * frontier town was founded **41.7% pensioners**, with barely two fifths of
     * it of working age. Harmless while the pyramid was a display; not harmless
     * at all now that it is the population and the workforce is drawn from it.
     *
     * The honest version solves the steady state of the chain the model actually
     * runs. A band is in balance when what arrives equals what leaves, and what
     * leaves is ageing AND dying:
     *
     *     n(i) * (outflow(i) + mortality(i))  =  n(i-1) * outflow(i-1)
     *
     * Walk that down from the babies and the weights fall out. Nothing is typed
     * in, so the seed follows the rates automatically - change a mortality
     * figure, or add healthcare that scales one, and the shape a new city starts
     * with moves with it rather than quietly disagreeing with the shape it
     * converges to.
     *
     * Gives roughly 8% babies, 10% children, 7% teens, 58% adults, 17% seniors,
     * against the 8.9/10.2/7.2/57.3/16.4 a played city actually settles at. The
     * small gap is growth: a city whose births exceed its deaths runs slightly
     * younger than a perfectly stationary one.
     */
    private void seedFrom(long livePopulation) {
        if (livePopulation <= 0) return;

        for (AgeBand b : AgeBand.values()) {
            band[b.ordinal()] = livePopulation * equilibriumShare(b);
        }
    }

    /**
     * What share of a settled city sits in this band, solved from the rates.
     *
     * Public and static because two other things need it and neither should
     * work it out again. `seedFrom()` uses it to found a city, and `Migration`
     * uses the ADULT share as the fallback for how many residents a job needs
     * when there is nobody here yet to measure. A second copy of this
     * derivation is exactly the bug this codebase keeps finding: the copy is
     * right the day it is written and wrong the first time a mortality figure
     * moves.
     */
    public static double equilibriumShare(AgeBand of) {
        double[] weight = equilibriumWeights();
        double sum = 0;
        for (double w : weight) sum += w;
        return sum > 0 ? weight[of.ordinal()] / sum : 0;
    }

    private static double[] equilibriumWeights() {
        AgeBand[] bands = AgeBand.values();
        double[] weight = new double[bands.length];

        // One unit of births enters the bottom; everything else is what survives
        // the band below it.
        double arriving = 1;
        for (int i = 0; i < bands.length; i++) {
            double leaving = bands[i].monthlyOutflowRate() + bands[i].monthlyMortality();
            weight[i] = leaving > 0 ? arriving / leaving : 0;
            arriving = weight[i] * bands[i].monthlyOutflowRate();
        }
        return weight;
    }

    /* ----------------------------- saving -----------------------------

       THE BANDS ARE SAVED BY NAME, since 2026-09-15.

       WHAT WENT WRONG WITH POSITION. This array is the population. It was
       written as the bands in order followed by three scalars, and read back
       by taking the width from AgeBand.values().length - which is fine right
       up to the day somebody adds a band, and is a disaster on that day.

       The sixth band was being designed (seniors split at 85) when the
       arithmetic was worked out. With five bands the reader accepts a length
       of 8 or 7. With six it accepts 9 or 8 - and every save ever written is
       8. So an old city would have passed the guard as though it were "six
       bands, births, deaths, no migration", and last month's BIRTHS would
       have been copied into the new band, deaths read as births, migration
       read as deaths. No exception. No refusal. Every saved city in the world
       slightly wrong, for ever, and nothing to say so.

       The permissiveness right below is what made it silent: the guard was
       deliberately widened once so that an older save would not be refused,
       because "this array IS the population" - and that kindness is exactly
       what let a wrong width through.

       SO THE WIDTH NOW COMES FROM THE SAVE, NOT FROM THIS BUILD. The names
       the pyramid was written with travel beside it, the values are mapped by
       name, and the scalars - three, six since 0.7.27 - sit after however many bands the SAVE had.
       A file written by a five-band build stays a five-band file no matter
       how many bands this build has. It is the same fix Equity and the
       household cells already carry - restore(keys, state) - for the same
       reason: the eighth, ninth and tenth sectors did not corrupt anybody's
       shareholdings, because nothing there was positional either.
       ------------------------------------------------------------------- */

    /**
     * The bands a save written before names existed must be read with.
     *
     * A LITERAL LIST, NOT AgeBand.values(). That is the whole point: this is
     * the shape of a file already on somebody's disk, and it cannot change
     * when this build's bands change. If a band is ever added, these five
     * still describe every save written before it, and PopulationCheck
     * asserts exactly that.
     */
    public static final String[] LEGACY_BANDS = { "BABY", "CHILD", "TEEN", "ADULT", "SENIOR" };

    /** The names this build would write beside the pyramid. */
    public static String[] saveBands() {
        AgeBand[] all = AgeBand.values();
        String[] names = new String[all.length];
        for (int i = 0; i < all.length; i++) names[i] = all[i].name();
        return names;
    }

    public double[] toSaveArray() {
        double[] out = new double[band.length + 6];
        System.arraycopy(band, 0, out, 0, band.length);
        out[band.length]     = lastBirths;
        out[band.length + 1] = lastDeaths;
        out[band.length + 2] = lastMigration;
        // ...and the dead by cause (0.7.27, SAVE_FORMAT 30).
        out[band.length + 3] = lastKilled;
        out[band.length + 4] = lastDeathsOfAge;
        out[band.length + 5] = lastAgedOut;
        return out;
    }

    /** A pyramid saved before the names travelled with it. Read as five bands. */
    public void restore(double[] saved) {
        restore(null, saved);
    }

    /**
     * Puts a saved pyramid back, each band found BY NAME.
     *
     * @param bands the names the save was written with; null or empty means a
     *              file from before they travelled, which is always LEGACY_BANDS
     * @param saved those bands in that order, then births, deaths and migration
     *              - and since 0.7.27 the killed, the dead of age and the aged out
     *
     * Refused whole on a length mismatch rather than padded, which is this
     * codebase's standing rule for state arrays: a pyramid read at the wrong
     * offsets is worse than no pyramid, because it looks like data.
     */
    public void restore(String[] bands, double[] saved) {
        if (saved == null) return;

        String[] names = (bands == null || bands.length == 0) ? LEGACY_BANDS : bands;

        /*
         * TWO LENGTHS ACCEPTED, and only these two - now measured against the
         * SAVE's band count.
         *
         * lastMigration was appended after the fact: the array carried births
         * and deaths but not the third flow beside them, so a reloaded People
         * screen showed the saved month's births and deaths next to a migration
         * of zero. Refusing those saves outright is far worse than the missing
         * figure, because this array IS the population.
         */
        /*
         * ...AND A THIRD SINCE 0.7.27: the dead by cause after the three
         * flows (SAVE_FORMAT 30). A save from before them reads its causes
         * as 0, which is what a reloaded People page showed before.
         */
        boolean withCauses = saved.length == names.length + 6;
        boolean withMigration = withCauses || saved.length == names.length + 3;
        if (!withMigration && saved.length != names.length + 2) {
            return;   // any other shape is refused whole, per the standing rule
        }

        /*
         * CLEARED FIRST, so a band the save has never heard of holds nobody
         * rather than whatever was in this object before.
         *
         * A band in the SAVE that this build does not know is dropped on the
         * floor, deliberately: those people cannot be put anywhere honest, and
         * GameVersion.SAVE_FORMAT already refuses a save from a newer build,
         * so this is the second lock on a door that should not open.
         *
         * WHEN A BAND IS ADDED, note that an old city's people are all in the
         * band they were saved in - splitting SENIOR at 85 leaves every one of
         * them in SENIOR and none in the new band, and they age across over the
         * following years. Whether that is the wanted behaviour or whether the
         * old headcount should be divided between the two at load is a decision
         * for the batch that adds the band, not something to be settled quietly
         * here.
         */
        java.util.Arrays.fill(band, 0);
        for (int i = 0; i < names.length; i++) {
            AgeBand target = bandNamed(names[i]);
            if (target != null) band[target.ordinal()] = saved[i];
        }
        lastBirths    = saved[names.length];
        lastDeaths    = saved[names.length + 1];
        lastMigration = withMigration ? saved[names.length + 2] : 0;
        lastKilled      = withCauses ? saved[names.length + 3] : 0;
        lastDeathsOfAge = withCauses ? saved[names.length + 4] : 0;
        lastAgedOut     = withCauses ? saved[names.length + 5] : 0;
    }

    /** The band of that name, or null if this build has no such band. */
    private static AgeBand bandNamed(String name) {
        if (name == null) return null;
        for (AgeBand b : AgeBand.values()) if (b.name().equals(name)) return b;
        return null;
    }

    public void reset() {
        java.util.Arrays.fill(band, 0);
        java.util.Arrays.fill(lastPromoted, 0);
        java.util.Arrays.fill(lastDeathsByBand, 0);
        java.util.Arrays.fill(lastIllnessDeathsByBand, 0);
        java.util.Arrays.fill(lastDyingByBand, 0);
        java.util.Arrays.fill(lastKilledByBand, 0);
        lastBirths = 0;
        lastDeaths = 0;
        lastKilled = 0;
        lastDeathsOfAge = 0;
        lastAgedOut = 0;
    }
}
