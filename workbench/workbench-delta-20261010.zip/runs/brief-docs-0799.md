# Brief: the docs pass for 0.7.70 to 0.7.99, in three parts. 2026-10-10

You are a docs pass, on Opus with a fresh context. Your job is prose: comments, javadoc, banners, `docs/*.md` (not `docs/manual.*`), `CLAUDE.md`, `README.md`, and the strings the player sees. They must say what the code **now** does (the tree is 0.7.99). **Change no behaviour,** constant, assertion or tolerance; a bug is a finding for your notes.

Read first, in this order:
1. `/home/claude/runs/brief-shared-git.md` - the rules for every implementer: the Git paragraph, your worktree as the tree, the standing rules (no `rm`, never `/dev` in any form), the gate, the notes. Its rules hold here; where this brief differs, this brief wins.
2. `docs/docs-pass.md` in your worktree - the house brief for a docs pass. **Skip its steps 4 and 6** (the project's records and the manual's line): the orchestrator runs the records separately. Put what they need in your notes §7 instead.
3. `CLAUDE.md` in your worktree, for the conventions the indexes rely on.

## Three parts, one after another

No docs pass has run since 0.7.69. Thirty versions are split three ways by the commits GitHub holds. Your launch prompt names your part. Each part starts from `main` after the one before it has merged, so you see its edits.

| part | branch | versions | the range to read (`git diff <a> <b> -- src`) | batches (notes `runs/fix<batch>-notes.md`, files `runs/fix<batch>-changed.txt`) |
|---|---|---|---|---|
| 1 | `batch/docs-0779` | 0.7.70-0.7.79 | `d6f1512 f85bcfa` (0.7.68 to 0.7.79; 0.7.69 already had its pass) | N1, N2, N3, N4, S1, S2, O1, N5, O2, O3 |
| 2 | `batch/docs-0792` | 0.7.80-0.7.92 | `f85bcfa 712baa2` | O4, N6, O5, O6, O7, O8, O9, RD1, RD2, RD3, RD5, O10, RD6 (RD4 was never shipped; its notes describe nothing in the tree) |
| 3 | `batch/docs-0799` | 0.7.93-0.7.99 | `712baa2 4074708` | O10b, RD7, O11, O12, O13, O14, W1 |

Your range says **where to look**; the truth is today's code. A sentence your range made false, which a later version changed again, must be true of the code as it is now. Don't chase prose outside your range except where a sentence in your files is plainly false; leave the rest to the next part and list it in §7.

Each batch's notes §7 ("for the next batch") lists the docs it left: dials without a sentence, harness sections, month-order, `CLAUDE.md`'s indexes and counts, banners. Work through those for your batches first, then the diffs. The project's `claude/todo.md` item "THE DOCS PASS FOR 0.7.70 TO 0.7.92" (readable through the Projects tool, or `runs/records/todo.md` line 522 on) collects many of them.

## Do
1. **Read your batches' notes §7 and your range's diff**, file by file (the map `docs/map/<File>.md` for where a member is; `tools.Where` to find what moved). Fix every comment, javadoc, banner, header and player string that is now false, in the file's own voice. The `GameVersion` entries of your versions must agree with each other and with the code.
2. **Dials:** every `static final` your batches added has one sentence above it (`docs/dials.md` shows a blank where it hasn't). The fix is in the source.
3. **Harnesses:** every harness section your batches added prints `--- title ---` and labels its assertions (`docs/harnesses.md` reads both). Fix labels only where they are false; never an assertion.
4. **Player strings** your versions added must fit at 1,389 x 868 by the screens' width helpers; change only false words.
5. **`tools.Stale`:** firm must stay 0. Work its soft list for your files (it read 415 soft at 0.7.99); say in your notes how many you closed.
6. **Part 3 only:** `CLAUDE.md` and `README.md` counts and the tree's shape, `grep -c`ed (harnesses 91, buildings 101, sectors, files), and the Inbox notice list if `CLAUDE.md` keeps one.
7. **Regenerate the indexes last** with `tools.Maps`, run from your worktree's root against your built classes. Commit them with your prose. If Maps rewrites a file only for its date line, put the old one back with `git -C <path> show HEAD:<file> > <file>` (allowed: it writes your worktree).

## The gate (your tree, your scripts)
Copy `/home/claude/scratch-gate/{build,suite,pt,bmc}.sh` into your scratch and change every `/home/claude/scratch-gate` to your scratch and every `/home/claude/git/CityBuilderSim` to your worktree. They contain no `rm`. Then:
- both builds silent (`build.sh model <wt>`, `build.sh ui <wt>`);
- the suite: 90 of 91, HealthCheck the known red;
- BuildMenuCheck PASS, 101 of 101;
- `tools.Stale` 0 firm;
- the playtest **byte-identical** to `/home/claude/scratch-ui1/orch-gate/pt0799/` (`pt.sh <name> /home/claude/scratch-ui1/orch-gate/pt0799`): a docs pass moves no trace;
- `git -C <wt> ls-files --eol`: no `w/crlf` but the `.bat` files.

Then commit your final state, the message starting "0.7.99 docs-07xx:" (your part's id).

## Notes: `/home/claude/runs/docs-07xx.md` (your part's id), at most 100 lines
§0 progress (a line per step, as you go); §1 files changed, a line each; §2 player strings changed; §3 flags (a comment you couldn't settle: the code is right for now, you left a `TODO(docs):` and say why); §4 Stale firm/soft before and after; §5 the gate and your final commit's hash; §7 for the next part and for the records (manual-facing numbers that moved: save format, buildings, harnesses); §9 outside your files (if any).

Reply with a short summary: files changed, flags, the gate, the commit hash.
