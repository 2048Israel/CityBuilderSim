# Brief: P2b, a smarter budget for automatic building. 2026-10-10

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## Jerus's decision (2026-10-10 09:47, on P2's kept revenue budget, verbatim)
> "P2's budget: don't keep it as is, and don't remove it. Make it smarter.
> 1. Essential services (death care, health, water, power) skip the revenue budget. Only the debt limit applies to them, and running a deficit to have them is fine.
> 2. For everything else, replace "can this year's revenue run it" with payback: its running cost against the extra tax revenue from the residents and workers it lets the city add, over the building's life, consistent with P2's long-run ranking."

## Where it stands (read first)
`/home/claude/runs/fixP2-notes.md` whole (130 lines): P2 (0.7.101) removed the revenue checks, found 7 of 8 auto-built seeds stalled with the first-of-a-kind rule, then kept the 0.7.100 budget (`AutoBuilder.budgetRoom()` and its kin: a staffed order within what a year's revenue leaves, walked past like the money and the ground) as departure 4 / ★ P2-3, with the two readings (a first of a kind from cash after the reserve; the limit counts everything owed over the recorded year). Its §4 table holds the seeds' figures for every variant. Then `docs/map/AutoBuilder.md` and `docs/map/BuildAdvice.md` (its `lifePerServed()` over 20 years), `docs/harnesses.md` (AutoBuildCheck, BuildAdviceCheck).

Also read `/home/claude/runs/fixP3-notes.md` §7: since 0.7.102 (P3) the budget's totals carry the city's repairs, arrears paid down and the strategic reserve's crude bought and sold, so P2's `runningSpend()` and `monthRevenue()` now see them. Repairs are running costs; the reserve's crude is an asset bought or sold (like land, which they leave out) and arrears are a past month's bill. Decide what the new rule reads, ★.

## Do
1. **Essential services skip the budget:** death care (cemeteries, crematoria), health (clinics, hospitals, care), water and power. ★ the exact list by `BuildingType`/category, and say any you left out. They are gated by the debt limit (as P2 made it) and the money and ground; a deficit to run them is fine.
2. **Everything else: payback.** Replace "can this year's revenue run it" with: the building's running cost over its life against the extra tax revenue from the residents and workers it lets the city add over that life, on the same footing as P2's `lifePerServed()` (20 years, the city's growth as P2-2 reads it). Every term from the model's own taxes and rates (income, sales, property and whatever the city levies), no invented coefficients (Jerus dislikes "modifiers"). ★ how "the residents and workers it lets the city add" is measured for each kind (a school's places, a police station's cover, a road's capacity), and how a building that unlocks growth only together with others is read.
3. **Keep P2's rules:** the walk, a first of a kind from cash after the reserve, the limit counting everything owed over the recorded year, only the order's own ground.
4. **Measure** the 8 auto-built seeds (0-7, as P2 did, people at month 4005) and add a row to P2's table; the default playtest must stay byte-identical to `/home/claude/scratch-ui1/orch-gate/pt0799/` unless the test player's own works read this rule (say so if they do). If a seed stalls, find why and say what would keep it alive; don't ship a stall without saying so plainly at the top of your reply.
5. **Words:** the auto-build card and its notices say why an order waits (the debt limit; the payback, with its figure); every string fits at 1,389 x 868.
6. **Harnesses:** AutoBuildCheck's budget premises become the new rule's (list before -> after in §3); a fixture for each half (an essential service ordered on a deficit; a non-essential one held, and one let through, by payback).

## Batch
Version, worktree, branch and base commit are named in the launch prompt. Scratch `/home/claude/scratch-p2b`; notes `/home/claude/runs/fixP2b-notes.md` (at most 130 lines) and `fixP2b-changed.txt`.

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** Suite 90 of 91: HealthCheck stays the known red (by 0.4 points since 0.7.100, a call for Jerus); every other harness green. BuildMenuCheck 101. If PlanCheck's 40 ms wall-clock bound fails under load, run it alone up to 10 times and report each.

Reply with: a short summary; the essential list; the payback rule as built and one worked example from a seed; the seeds' new row; the default playtest; the gate and your final commit; your ★ calls.
