# Z1 notes - 0.7.107 zoning: the model (worktree /home/claude/git/wt-Z1, branch batch/Z1)

## 0. Progress (a line per step)
- tree clean at 8237323; scratch /home/claude/scratch-z1 with build/suite/pt/bmc/gate scripts pointed at wt-Z1
- read brief, shared rules, CLAUDE.md, spec-materials 2.15/3/4/5; baseline model build silent, LandCheck+PolicyPreviewCheck OK
- FOUND: forest is dry ground a building can take (World.FOREST "dry and buildable"; ownedSqFt = the land's DRY km2, forest inside it); nothing clears it (extract(FOREST) has no caller in the game, only endMonth's regrowth; TileRaster paints a building on forest as grass, the map's only)
- 2b53df1 model; pt1 (nothing set): all 8 traces byte-identical to pt07106
- fae40dd ZoningCheck (9 sections, 3.7 s); 25c17d8 LandCheck 25, PolicyPreviewCheck 9; 864fdb6 GameVersion 0.7.107, counts
- probe on copies (autosave slot only; scratch-z1/probe1.txt), see 4
- gate 20:50-21:04 (scratch-z1/gate.log), suite rerun green; de7f762 final; see 5

## 1. What I built
- **`Zoning`** (new): zones by sector key {Size SHARE (default, a share of the dry ground, read live so 2% stays 2%) or KM2, size, price share 0-1, usedSqFt}; the law {protectedShare p, keptShare k >= p}, default 0/0; `Tax` {PROFIT, SALES, PROPERTY}; copy(); State/ZoneState for the save.
- **`LandManager`, ZONES AND THE FOREST LAW**: D = B + F; buildable = D - kF; free = buildable - allocated; each zone holds min(size - used, free), short zones each the same share of their want (Z10); `freeForAnyone()` (= `getAvailableSqFt()`), `freeFor(sector)`, `heldBy`, `usedBy`, `zoneSizeOf`, `heldByZones`; `allocate/canAllocate/release(sqFt, sector)` (zone's held first -> used; release from used first -> held again); `priceFor(sqFt, sector)`, `buybackPriceFor`, `groundPriceFor(sector)`, `recordSale/recordBuyback(sqFt, price)`; forest kinds (`getProtected/Working/OpenForestSqFt`, `getBuildableSqFt`, `getFreeSqFt`); `getProtectedWood()` = min(p x O, remaining); `cuttableForest()` = remaining - protected wood, and extract(FOREST) cuts only it; clearing (Z7) at allocate - zones hold bare ground first, each its share, others on the rest, past it open forest: cut-over first (E -> C), then standing wood (-> C; `getForestClearedThisMonth()`, I9's salvage, lost until then) - plus a floor in endMonth for ground set by hand; remaining = O - E - C, getExtracted(FOREST) = E + C; `zoneLand()` for the investors; `groundUnder(Zoning)`/`heldUnder` for the preview; `zoningState()/restoreZoning()`.
- **The roll** (Z4): `EconomyManager.assessedLandValueOf(s)` (the zone's used ground at its price) in `getAssessedValue()` and `propertyTaxUnder()`; `groundPriceFor(t)` (the zone's price while the zone holds the plot) in `housingCarry()`, `repriceHousingCosts()` and `BusinessInvestment.standingCostOf()`.
- **The investors**: `BusinessInvestment.setZoneLand()` (Game.refreshLand()), `plotsAvailableFor()` on anyone's + its zone's, `getCostOf()`'s ground at the zone's price for the zone's part, `landReason()` "...; X is zoned for others".
- **Game**: wiring; buildFor/processBuildOrder/buildStack/runAhead by the template's sector; retire and buy-out at `buybackPriceFor`; a demolition's ground back to its `from` sector's zone; save/load (`DataSave.zoning`, after the allocation); the doors `setZone`, `removeZone`, `setForestLaw`, `setZoneTax`, `zoneTaxRate` (each a decision-log line).
- **Agriculture** (Z11): short of homes, the fields plan only if their zone holds ground, the order capped to what it holds.
- **PolicyPreview** ZONING: `zoneAt()` (size, used, held, held at the going price, price given up, tax relief), `zoningTaxChange()`, `forestAt()` (three kinds, free for anyone, protected and cuttable wood, standsForEver).
- No SAVE_FORMAT bump: an older save reads no key -> nothing set, nothing cleared, loads as today (all five probe cities load).

## 2. Departures, with reasons
- None from what Jerus decided. Where the study left it open: the stars in 6.

## 3. Premises changed (before -> after) and new assertions
- No premise moved. `getAvailableSqFt()` now means "free for anyone" (== owned - allocated with nothing set, to the bit: ZoningCheck 1).
- New: ZoningCheck 1-9 (the brief's list: nothing set, nothing moves - incl. a set-then-undone twin playing a year identically; a zone's ground its sector's alone, held ground leaving the others' free ground; the city paid the zone's price, booked; roll and standing cost at it; one dial two doors; short zones fill; protected forest never cut or built on; clearing cut-over first, W holds; zoned fields do not yield; saved and reloaded identical a month on). LandCheck 25 (the ledger closes with zones and a law; a sector with no zone allocates as anyone). PolicyPreviewCheck 9 (the staged copy detached; applied = the preview; relief = the tax un-zoning raises).

## 4. Trace movement
- None: pt1 byte-identical to pt07106 on all 8 traces (the gate's pt-main in 5). The clearing rule moves only the forest's C and E, which nothing priced and no trace reads; the test player sets no zone. Not re-baselined; no ensemble.
- Probe (copies, 12 months each): forest/bare/built km2 - city600 1.04/1.99/2.98 (cleared 0.996 km2 in month 1, 13,647 of 14,216 m3); city2400 0/33.29/33.26; jerus-1007a 0/7.35/7.87 (built past its dry ground already, no forest); jerus-1008 376.6/1005.4/981.5 (none cleared); jerus-old 11.83/77.8/97.5 (all cleared in month 1). W - (unowned + remaining + taken out) = 0 in all five.

## 5. The gate, and the final commit
- Both builds silent. Suite (scratch-z1/suite.txt) 91 of 92: PlanCheck's timing bound only ("a district's plan, the dense screen's slowest, in no more than 40 ms": 42.54 ms) - DistrictPlan untouched; alone 3 times: 28.1, 20.5, 22.4 ms, all OK. Rerun of the whole suite (suite2.txt): 92 of 92, HealthCheck and MapCheck too.
- BuildMenuCheck PASS, 101 of 101. tools.Stale: 1 firm (CLAUDE.md "41 banner sections" in Game.java: ZONING is the 42nd) -> fixed in de7f762, then 0 firm, 421 soft. Playtest pt-main 8 of 8 traces identical to pt07106. No w/crlf outside .bat.
- Final commit: de7f762 (on 2b53df1, fae40dd, 25c17d8, 864fdb6). Tree clean.

## 6. Star calls
- ★1 The books keep the going price; only the roll reads the zone's (assessedLandValueOf), as FARMLAND_RELIEF does. Spec 2.15 put it in landValueOf, which is also the sheet and SectorStatements' land revaluation (valuedAt); the brief scopes "the assessment". Flip: landValueOf -> assessedLandValueOf, and valuedAt's price -> the effective one.
- ★2 Zoned ground trades at the zone's price both ways: a plot given back (retire, buy-out) is bought back at it for the part out of the zone's used ground, which release takes first so the zone holds it again (spec 2.15).
- ★3 Short zones share the free ground in proportion to their wants (each the same share), not first-come in Sectors.KEYS order.
- ★4 Clearing happens at allocate (the zones hold bare ground first, each its share, so others go onto forest sooner: "less the bare ground zones hold for others"), with endMonth's floor max(C, min(open, allocated - B)) for ground set by hand; CLEARING_ROUNDING (a billionth of the dry ground) keeps the floor from clearing an ulp a month.
- ★5 C is kept in square feet (the ledger's unit) and cubic metres, so a save round-trips to the bit; the study's km2 is a reading.
- ★6 Un-zoning drops the zone's used record: that ground is assessed at the going price from then on; a new zone's used starts at 0.
- ★7 The city's own works build only on ground free for anyone; a sector's template built through processBuildOrder (fixtures) takes its zone first; the founding bank as before.
- ★8 Zoning's decisions are logged under DecisionLog.TAX (the farmland relief's kind): a kind of its own needs an icon and a colour (Icons, TimeChart) - Z2's.
- ★9 A new building reads the zone's price (cost, standing cost, the landlords' carry, the marginal home's land) only while the zone holds its whole plot.
- ★10 Protected wood = min(p x O, remaining) (the fullest forest first); clearing never takes standing wood past cuttableForest(): the protected wood stands on ground nothing builds on.
- ★11 Z11: short of homes, the fields' order is capped at floor(held / plot) and refused under one plot ("the fields' zone holds too little for a ...").
- ★12 The preview's price given up is on the held ground (what selling it at the zone's share forgoes); its relief is on the ground built in the zone, at the roll's price, the sector's rate and roll share.
- ★13 zoningState() is null with nothing set and nothing cleared: such a save has no key, as an older save.

## 7. For the next batch
- Z2 reads: Game.getZoning/setZone/removeZone/setForestLaw/setZoneTax/zoneTaxRate; LandManager heldBy/usedBy/zoneSizeOf/heldByZones/freeFor/freeForAnyone/getForest*SqFt/getBuildableSqFt/cuttableForest/getProtectedWood; PolicyPreview.zoneAt/forestAt/zoningTaxChange; landReason's "is zoned for others".
- LandMarket's going price still reads allocated/owned: ground the zones hold does not make it dearer for everyone else. A question for Jerus if zones grow large.
- I9: the salvage is getForestClearedThisMonth(), cleared by clearMonth(); Forestry reads it within the month (allocate clears as the investors build); endMonth's floor only matters for ground set by hand.
- Docs pass: regenerate the maps (Zoning.md; ZoningCheck in docs/harnesses.md).

## 8. For Jerus to check on the PC
- Nothing shows until Z2. Load jerus-1008 and play a month: nothing should look different.

## 9. Outside my files
- None (AllChecks, CLAUDE.md, README.md, GameVersion, DataSave, Game's load path and Agriculture are the brief's).
