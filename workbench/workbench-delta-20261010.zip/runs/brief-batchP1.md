# Brief: P1, the checks. 0.7.100. 2026-10-10

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## Jerus's decisions (2026-10-10, `claude/decisions-2026-10-10.md`, "all rec")
- **A14, HealthCheck red since 0.7.12:** "O1: stand one depot with the fixture (gap 40.0 -> 1.0, nothing loosened)".
- **A27, ensemble S1 (0% in a takeoff city) and H1 (asks for acceleration the model rules out):** "Rewrite both premises; watch A2".
- **A28, MapCheck's 5 ms month bound fails about 1 run in 10 on wall clock:** "Time it as thread CPU (not a loosening)".
- A1 closed W1's calls as intended: ensemble A2's two red seeds (8 and 13) stand; you only **watch** A2 and report it.

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| P1 | 0.7.100 | `/home/claude/git/wt-P1`, `batch/P1` (from the commit the launch prompt names) | `/home/claude/scratch-p1` | **byte-identical** to `/home/claude/scratch-ui1/orch-gate/pt0799/` - nothing here touches the model |

## Do
1. **HealthCheck, O1.** The trace is the project doc `claude/why-the-dear-city-is-hungrier.md` (Projects tool) and the todo item "AFTER 0.7.17: HEALTHCHECK SHIPS RED" (`/home/claude/runs/records/todo.md`, grep it): 0.7.17's crews by size^0.7 leave the fixture's first depot on site when the fee is set, so the dear twin's sickness stalls its builders for good. O1 stands one depot with the fixture, as round 1 did for eight fixtures (find how those fixtures stand theirs and do the same). **The premise and the tolerance do not move.** Report the gap before and after (40.0 at 0.7.23; measure it now) and the suite 91 of 91.
2. **The ensemble's S1 and H1** (`/home/claude/runs/ensemble/score.py`, its driver `src/ham/citybuildersim/Ensemble.java`, `run.sh`; the reasons in `records/todo.md` - grep "S1's window is a city at takeoff" and "H1 asks for accelerating inflation" - and the project doc `claude/spec-inflation.md` ★1 and ★14):
   - **S1:** its window is a city at takeoff, not a slack one. ★ Move the 0% hold to a mature city (a scratch variant held from month 1800 on 0.7.43 ran 3.16% [2.62 to 5.58], +1.07 over its twin) and restate what "little inflation" asks there.
   - **H1:** the model's Phillips curve is the level wage curve plus expectations, with KMIN .25, so a held 0% gives a persistent burst, not a rising rate. ★ Rewrite the premise to what the model claims (a burst that persists above its twin, not acceleration), and make H2 (vacuous today) mean something or say why not.
   - Write each new premise's reason beside it in `score.py`, sourced to the spec. Don't touch any other criterion; A2 stays as written.
   - These files are the workbench's, not the repo's: list each change under "Outside my files" in your notes, with its before and after.
   - Run the ensemble on a copy of your tree without `.git`, built into `<copy>/build/classes`: `bash /home/claude/runs/ensemble/run.sh <copy> 07100`, with `BASELINE=/home/claude/runs/ensemble/out/0799/summary.json` if that file exists (else say what it compared with). About 21 minutes alone. Report the score against 0799's 22/25, S1 and H1 under the new premises, and A2's two seeds.
3. **MapCheck's month bound, A28:** time the month the bound reads as the main thread's CPU time (`ThreadMXBean.getCurrentThreadCpuTime()`, with a check that the JVM supports it, else wall clock and say so in the output), the bound still **5 ms**. Say in the harness's header why: the spikes were the compiler threads taking the main thread's core (`runs/fixRD7-notes.md` §4 ★4 and §7, `runs/fixO11-notes.md` §5). Then MapCheck alone 10 times: each run's worst month, CPU and wall.
4. **GameVersion** 0.7.100 with an entry in the house shape (harnesses only; no model change; save format stays 36). Counts in `CLAUDE.md`/`README.md` only if one moves.

## Read first
`docs/harnesses.md` (HealthCheck, MapCheck), the maps of `HealthCheck`, `MapCheck` and the eight fixtures round 1 mended (grep the old notes one file at a time if you need them), `/home/claude/runs/ensemble/score.py` whole (404 lines).

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full** (git, your tree, standing rules, the gate, notes). The gate's suite line here is **91 of 91**: HealthCheck green. BuildMenuCheck 101. The playtest line is the row above. Other batches share the two cores: if PlanCheck's 40 ms dense-screen bound (wall clock, not yours to change) fails, run it alone up to 10 times and report each.

Reply with: a short summary; HealthCheck's gap before and after; the new S1 and H1 premises and their readings; A2; the ensemble's score; MapCheck's 10 runs; the gate and your final commit; your ★ calls.
