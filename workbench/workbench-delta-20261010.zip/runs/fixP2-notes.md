# fixP2 notes: 0.7.101 - automatic building and the build advice. Implementer (Opus), 2026-10-10
Worktree `/home/claude/git/wt-P2` (batch/P2 from e859997). Scratch `/home/claude/scratch-p2` (probes `probe-src*/`, `probe-tools/`; variant
copies `probe-var/`, `probe-v2/`, `probe-v3/`, -Dp2.* toggles; runs `var/`, `var2/`, `ab2/`, `ab3/`). Changed: fixP2-changed.txt (10).

## 0. Steps
- Round 1: brief, rules, CLAUDE.md, maps, fixN4/N5/N6/RD4, todo; base auto-built seeds 0-7; the spiral's mechanism (4.); commits
  9b88426 .. 10240e4; variants (4.); harnesses; ensemble 07101 (5b); gate2.log on 10240e4.
- Round 2 (orchestrator: two readings; "don't ship a stall"): a first of a kind from the cash alone, the limit counting what it should
  (072a597); seeds re-measured (ab2/): three still stall; variants on the readings (var2/); the budget kept (cd39673); harnesses;
  seeds on the final code (ab3/); GameVersion, CLAUDE.md (0b4f19a, 39d3bb8); gate3.log on 39d3bb8, the final commit (5).

## 1. What I built
- **BuildAdvice, A BUILDING OVER ITS LIFE** (A4, A19): every candidate ranks by `lifePerServed()` - its order over its life (`orderLife()`:
  quote + ground + count x running() x lifeFactor()) over what it serves a month over LIFE_MONTHS (`servedOverLife()`; power, water, roads,
  care read year by year on the city's own trend, `lifeTrend()`, `shortfall()`). The count is unchanged; only the choice reads the life.
- **Power** (thousands a kW over life): playtest m250 **wind** 7.70 vs coal 10.81; m1000 **wind**; m2000 **coal**; m3000 **wind**; m4000
  **coal**. **jerus-1008**: **coal**, 923 vs 2,063. **jerus-1007a** (m416): **wind**, 42.7 vs 84.7 (coal 62% idle on his trend).
- **AutoBuilder** (A4-A6). `kept()`: a first basic school (any child or teen), station, prison where there is none (FIRST_SHARE gone;
  higher schools keep NEEDS YOU's row), **paid from the cash over the reserve alone, never on a bond** (round 2: `firstOfAKind()`,
  `pays()`, Cut.CASH, `firstWords()`). **The budget kept** (round 2, star P2-3, departure 4): 0.7.100's - a staffed order within what a
  year's revenue leaves (`budgetRoom()`, `revenue()`, State.recent) - unchanged but walked. `step()` walks the ranking (suggestFor's skip;
  new noPaving) past a card the budget, the ground or the money will not run or pay for one of; holds only when none is left, in the first
  card's words (Cut.BUDGET's among them); over the limit, toggle off, at once; the log's why says it walked. `lacks()` = the order's own
  ground less free; `overFull()`: a city over its ground buys none and holds GROUND. DEFAULT_DEBT_LIMIT 2.40, DEBT_LIMIT_MOST 6.0,
  DEBT_STEP .10, OLD_DEFAULT_DEBT_LIMIT .60.
- **The limit counts what it should** (round 2, star P2-9): `debt()` = all the city owes - bonds and bills, the overdraft, the central
  bank's advances (DebtManager.getPricedDebt()'s three, read live); `debtAfter()` adds a bond's face and takes off the overdraft its cash
  clears; `annualGdp()` = the last twelve months as recorded (a young city at what it has produced, no longer scaled up to a year).
- **Iron pay-back** (B): `BuildAdvice.ironPayback()` (LongPlaytest's 0.7.67 test moved whole), said under the no-deposit page's Buy.
- **Words**: AUTO_INFO, the limit card ("All the city owes - bonds and bills, its overdraft, its central bank's advances - at most X of
  what it produced in the last year"), the advice card, over-full, walked and first-from-cash words, the pay-back line (P2Words, 5).
  GameVersion 0.7.101; CLAUDE.md's two rows. No new harness or building; no save format change (State.recent is 0.7.100's).

## 2. Departures, with reasons
1. **The default playtest does not move** (the brief expected it to): its player builds its own works by its own rules; auto-build is off.
2. **An over-full city builds nothing that needs ground** (A5 read literally): an order on its own ground cannot be placed there
   (canAllocate reads free = owned - used, held at 0). His m416 city (0.525 km2 over) holds every order for ground at any limit.
3. **Build's cards keep a unit's bars** (BuildCard): only the advice's choice reads the life.
4. **The budget stays** (brief 3, A4's "the real thing is only debt to gdp ratio"; the orchestrator's round 2: "don't ship a stall ...
   leave the branch at your best variant that keeps every seed alive"). With both readings and no budget, seeds 0, 2 and 7 stood at
   400-1,800 people for 600-1,000 months and more (4.); the old first rule instead of the budget left seed 0 at 23,225; with the budget
   all eight end at 1.73M-2.17M. No variant without a revenue check kept every seed alive. For Jerus (8.1).

## 3. Premises changed (before -> after); each rule moved by Jerus's decisions
- AutoBuildCheck 1: default 60% -> 240%; ends 300% in 5% steps -> 600% in 10% (3.456 -> 350%); new: a 0.7.81-0.7.100 save at 60% reads
  240%, 150% stays, 275% -> 280%. The budget's premises (2's fixture, 3's room, 4's revenue, 5's held clinic) stand as 0.7.100's. 3: a hold
  for the money, the ground or the budget is true only if no building in the ranking is run and paid for one of (noneOtherPays(),
  paysForOne()). 5: "a first police station waits for half a station's worth" -> "kept where there is none"; new: a first school held for
  the budget where it cannot run one (the town takes $4.0M a month and spends $14.9M), ordered in a twin with room (withRoom(): its health
  and education bills cleared, $50M more property tax), held for the cash in a twin with none over a month's tax at a 600% limit; the walk
  (Community Health Centre $19.1M refused, Walk-in Clinic ordered, the log says so) under a limit no bond fits (nearTheLimit(); 0% until
  the town's advances counted), with room, the cash for one and a half clinics; an over-full town. THE LIMIT: "the debt is the bonds and
  bills, the overdraft the central bank's page's" -> "the bond's cash clears the overdraft: all owed after it"; "the ratio is the left
  panel's Debt/GDP, annualised" -> "all owed over the twelve months as recorded"; new: a town overdrawn owes it, and a month on its
  advances; a young city's year (3 months: $323,340, not $1.3M); "at 0% ... the ground's price in it" -> "the town over 0%, owing its
  advances: held for the limit" (the ground's price stays in the 200% fixture); limit fixtures brought just under (nearTheLimit()).
- BuildAdviceCheck 7, RoadCheck 2/8, ChildcareCheck 2: a card's figure -> its order over its life over what it will serve, recomputed;
  ChildcareCheck's "short of a few, the Small Centre" -> "the least count that closes it" (1 Large, 332.0 a place, against 2 Small, 361.0).

## 4. Trace movement and the measurements
- **pt07101 = pt0799**: all eight traces byte-identical (round 1 and on the final commit, 5).
- **The spiral** (round 1, `pb/`): (M1) a card the money could not pay for held its measure for good (seed 1's coal plant, m422-m4002,
  power to 36%): the walk. (M2) a young town over a 60% limit on debt the pass did not take (seeds 2, 4): 240%.
- **What the limit missed** (round 2; seed 6 of round 1's build, a village of 18 that borrowed $38M in month 3): (a) **a young city's
  year scaled up** - two months recorded (nothing, then $8.57M of founding building) read as $51.4M a year, so 240% of it let a $38.2M
  bond (face $62.1M) through at 121%; on the year as recorded it reads 7.2 years of output. (b) **The overdraft and the central bank's
  advances outside the debt** - its schools' wages overdrew the treasury from m84, $14.9M advanced by then, none of it in the ratio until
  the next order's bond made it paper. **Now**: the limit reads all owed over the recorded year before every order, and binds as soon as
  the debt is there - seed 0 (both readings) went over at m100 (2.03) and ordered nothing for 500 months. **What it still cannot do**: see
  a staffed building's deficit before the order - seed 0's Elementary School, paid in month 3 from the founding $39.7M, spent $0.5M a
  month against $0.3M of revenue; all owed rose from 1.3 to 13 years of output under the binding limit, the deficit going on.
- **Auto-built playtest** (`-Dplaytest.autobuild`, people at m4005; variant rows are -Dp2.* toggles - round 1's probe-var on its code,
  round 2's probe-v2/v3 on 072a597):
  | seeds | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
  |---|---|---|---|---|---|---|---|---|
  | 0.7.100 | 1,842,897 | 48,256 | 1,453 | 701,621 | 1,789 | 47,783 | 1,351,398 | 43,411 |
  | the walk alone | 2.13M | 2.15M | 1,453 | 1,736 | 1,789 | 1.98M | 1.22M | 1.89M |
  | + limit 240% | 2.00M | 1.50M | 2.27M | 2.20M | 1.67M | 2.08M | 1.98M | 1.78M |
  | + the long run's ranking | 1.92M | 1.70M | 2.21M | 2.08M | 2.26M | 1.81M | 1.84M | 1.97M |
  | + first of a kind (budget kept) | 1.67M | 1.89M | 2.23M | 2.18M | 1.92M | 1.78M | 1.76M | 1.78M |
  | + no revenue gate (first waits) | 23,225 | 1.37M | 1.55M | 1.68M | 1.94M | 1.68M | 1.34M | 1.46M |
  | 0.7.101 round 1 as built (both rules) | 718,063 | 17,844 | 21,190 | 35,455 | 36,662 | 2,404 | 17,913 | 17,777 |
  | round 1 + a first from the cash alone | 1.58M | 1.67M | 1.43M | 499 | 1.16M | 24,915 | 1.34M | 1.15M |
  | **0.7.101 as built after these two** | 57,162 | 1,374,560 | 632,753 | 1,395,568 | 1,371,214 | 1,610,459 | 1,282,827 | 304,263 |
  | **0.7.101 final: + the budget kept** | 1,859,455 | 1,771,157 | 2,172,183 | 2,115,031 | 2,056,040 | 2,037,532 | 1,995,804 | 1,732,861 |
  After these two, seed 0 sat near 400 people m30-m590 and at 19k m1600-m3300 (over 240%, the deficit growing it); seed 2 at 400-1,300
  to m1200, seed 7 at 1,400-1,800 to m1000; with the old first rule instead, seed 0 23,225. The final code is probe-v3's budget variant
  seed for seed; its first schools come from cash at m291 (3,934 people, seed 0), m150 (2,407, seed 3), m349 (4,351, seed 5).
- **His cities' limit** (P2Limit, copies): jerus-1008 37.6% either way (no advances; his 300% limit); jerus-1007a (m416) 273.6% all owed
  against 250.5% bonds and bills ($451M advances, $421M overdrawn) - over 240% either way.
- AutoBuildCheck 3's decades city (600 months): 13,483 people and 73 orders at 0.7.100 -> 10,824 and 71 (2,970 holds for the budget).

## 5. The gate (gate3.log, on 39d3bb8 - the final commit; nothing in the tree changed after it)
- Builds silent (model, ui). Suite (suite-3): 91 in 1,235 s, 89 passed: HealthCheck the known red; PlanCheck's one timing line (the
  dense screen's slowest plan <= 40 ms; 58-65 ms here, load average ~4) - 0.7.100's classes fail it too (1 of 3 runs, 63.6 ms), and its
  output is 0.7.100's but for the timings. BuildMenuCheck PASS 101/101. Stale 0 firm, 414 soft. pt07101g: 8 traces identical to pt0799.
  No w/crlf but .bat. Seed 5 auto-built on the gate's classes: identical to ab3's. P2Words (words-5.txt): 35 measured, 0 over -
  AUTO_INFO 11 lines of the 360 px popover, the limit card 3 of 3 lines at 395 px, "now 274%" 51 of 99 px, tooltips <= 1,285 of 1,349.
- 5b. Ensemble 07101 (round 1, 10240e4): 24/26, A2 and S1 red as at 0.7.100, all 80 runs byte-identical; not rerun (auto-build off).

## 6. Star calls
- P2-1 **First of a kind**: a basic stage with any child or teen, police, cells; higher schools keep NEEDS YOU's row. From the cash over
  the reserve alone, never a bond (round 2, the orchestrator's reading of "even tho it has the money"); the budget runs it first (P2-3).
- P2-2 **The life's demand**: the city's own population trend over the last LIFE_MONTHS of its history, linear, no housing ceiling.
- P2-3 **The budget kept** (round 2): Jerus asked for the debt limit alone. Without the budget nothing stops a staffed service the city
  cannot run but the limit, and the limit acts late: it binds on debt already there, the deficit goes on under it. No reading of his
  words without a revenue check kept every seed alive (4.), so the branch keeps 0.7.100's budget, walked like the money. reserve() kept.
- P2-4 **The dial**: 0-600% in 10% steps. P2-5 **An older save's limit**: exactly 60% reads 240%; any other stands, on the nearest step.
- P2-6 **The walk**: the budget, the ground or the money short of one -> the next card; over the limit with the toggle off, no walk.
- P2-7 **Over-full**: buy none, hold GROUND (departure 2). P2-8 **Overshoot priced** for power, water, roads, care; the rest a unit.
- P2-9 **The limit's debt and year** (round 2): all owed - bonds and bills, overdraft, advances, the market's priced debt - over the last
  twelve months as recorded. The left panel's Debt/GDP stays bonds and bills over a scaled year; the limit card says what it reads.

## 7. For the next batch
- Jerus's call on the budget (8.1); if it goes, something must see a staffed building's running before the order, or the stall returns.
- The left panel's Debt/GDP and the limit read different debts now (his m416: 250% and 274%): one figure, or both? BuildCard's bars over
  life. Docs pass: maps, dials (AutoBuilder's, LIFE_YEARS, PAYBACK_LINE, OVER_SQ_FT, ROOM), harnesses.md, the manual's Build page.

## 8. For Jerus to check on the PC
1. **The budget is still there.** You said the real check is debt to GDP alone. Without it - even with the limit counting all the city
   owes and a first school only from cash - a village builds its first school from its founding cash, cannot pay the wages, and sits at
   a few hundred people for decades (3 of 8 test cities). With it all 8 pass 1.7M, the first school at 2,400-4,400 people. Keep it?
2. The debt limit now counts everything the city owes - bonds, overdraft and central bank advances - over what it actually produced in
   the last year. Your m416 city reads 274% (its Debt/GDP 250%), over the 240% default; your 1008 city 37.6% of your 300%. Right?
3. Your m416 city builds nothing that needs ground (its buildings stand on 0.525 km2 more than it owns): buy that once, or new ground?
4. Build > Overview, a power card: "cheapest per kW used, over its life"; your 1008 city ranks coal first, m416 wind. Right?
5. Industry > Mining > Iron Mine with no deposit: the line under the Buy says whether the cheapest field pays back here.

## 9. Outside my files
- LongPlaytest: fieldEarnings()/fieldPayment() delegate to BuildAdvice (the playtest byte-identical). Inbox: as 0.7.100 again.
