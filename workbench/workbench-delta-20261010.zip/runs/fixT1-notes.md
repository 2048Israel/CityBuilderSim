# fixT1 notes: why Jerus's city is construction-bound. Read-only trace (Opus), 2026-10-10. Tree wt-T1 @ 4074708 (0.7.99)

## 0. Progress
- Read brief, shared rules, CLAUDE.md, O10b §5c/§8. Worktree clean at 4074708, nothing changed in it. Scratch /home/claude/scratch-t1; model built silent.
- Probe `scratch-t1/probe/ham/citybuildersim/TProbe.java` (run-probe.sh <copy> 120 0 <out> <mode>): a line a month (months.csv), the sites (sites.txt),
  the builders' and every sector's gate counts (gates.txt), the oil and depot sites (oil-sites.csv). Modes use only Game's public player actions.
- Runs, each on its own copy of jerus-1008 (m8473 -> m8593): out-j120-base, -dc (death care first), -deathcareRush, -depots-60, -deathcareDepots-60.
  city2400 copy: out-c2400-b. Default playtest: read scratch-gate/pt-main/t-build.csv (0.7.99 gate). Base run deterministic (rerun identical).
- DONE. Note written; nothing left running.

## 1. The answer in five lines
1. His builders can do 145,600 points a month (363 depots x 400 + the works' 400); the standing city's repairs take 117,700 of them (1% a year of 141M points).
2. Since m7839 his cemeteries are full and he has no crematorium: 97,000 dead lie unburied, which adds the capped 15 points to the sick rate (18.8%, not 3.5%).
   145,600 x 0.81 = 118,250, less 117,700 of repairs: ~420 points a month reach all 26 sites (none in 17 of 120 months). That is the whole of it.
3. The builders want to grow but cannot: their one depot order on site gets its crew share, 0.07% of ~420 = 0.4 points a month, and holds every next one.
4. The cemetery that would end it gets 0.31% of those points (1.4 a month, ~1,000 months), so the dead stay, so the crews stay sick: a closed loop.
5. Put death care first in the city's order and the loop breaks in 24 months: sick 3.5%, the sites get 22,600 a month, the jacket opens at m8544.

## 2. The month's points: where they come from (lines as of 4074708)
- Nameplate: `BuildingManager.getTotalConstructionCapacity()` L5010 = BASE_CONSTRUCTION 400 (L4985) + every depot's BUILDING_WORK (Construction Depot: 400
  points, 50 posts, 400 points to build; buildings.json id 4). His: 362 standing at load, 363 from m8512.
- Crews: `Game.strikeBuildersCrews()` L5262 -> `Construction.strikeCrews()` L152: posts offered = need / fill, floored at IDLE_PAYROLL_FLOOR .25. His need
  is 25x the depots (repairs + 2.79M owed), so every post is offered (1.0) and filled (fill 1.0; 614k out of work). Staffing is never short.
- Output: `Game.getConstructionOutput()` L5203 = capacity worked x fill x roadRatio x `Health.getWorkRatio()` (1 - sick). His: 145,600 x 1 x 1 x 0.812.
- Repairs: `EconomyManager.maintenancePointsTotal()` L849 = every standing building's points x RealEstate.MAINTENANCE_PER_YEAR .01 / 12. His 117,497 -> 117,744.
- Sites: `Game.getBuildingOutput()` L5337 = max(0, output - repairs), read once at SimulationEngine L66 and handed to `BuildingManager.advanceConstruction()` L3981.
- The split: `siteShares()` L3769 -> `waterFill()` L3827: one rate per unit of weight, `weightOf()` L3854 = buildings on site x points^CREW_SCALE_EXPONENT .70
  (L3753), each capped at what it owes. No order among owners: every site gets the same rate a unit of weight (his: ~420 / 90,640 = 0.0046).
- The player's hand: `BuildingManager.plan()` L4141 / `applyPriority()` L4195, only when an order or a rush is set (his save: none). The city's sites' rule
  shares are pooled and handed top down in his order (`Game.moveSite()` L6684); a rush (`Game.rushSite()` L6672) is x1.14 of the share in month 1, x0.94 from 3.
- Sickness: `Health.advanceMonth()` L222 = 0.03 well served + unburied/pop x UNBURIED_WEIGHT 20, capped at MAX_UNBURIED_SICKNESS .15, + hunger + outbreak + ...
  His month: 0.03 + 0.15 + ~0.006 hunger + 0.0016 unhoused + 0.0006 injured = 0.188. `Healthcare.settleDeaths()` L563 caps the unburied at 24 months of
  deaths (MAX_BACKLOG_MONTHS L265): ~4,050 a month x 24 = 97,200, where it sits. Plots built 8,678,500, all used; cremation capacity 0.
- The builders' growth: `Construction.plan()` L585, in order: "already building" if a depot of theirs is on site (BusinessInvestment.MAX_CONCURRENT_ORDERS 1,
  L61) -> months queued >= BACKLOG_MONTHS_BEFORE_EXPANDING 9 (L111) -> `Sector.staffing()` >= .80 -> plots -> ONE depot; then `Game.consider()` L4344, the
  money (the largest slice that carries its interest, PROFIT_OVER_INTEREST 1.25). The depot then waits in the same queue at its weight, 400^.7 = 66.3.

## 3. His city over 120 months (base run, m8474-m8593)
- Points to the sites: 50,337 in all, 419 a month (max 591; 0 in 17 months: 6 outbreak, 5 hunger, 6 while the sick rate settled). Work ratio 0.730-0.812.
- The builders' gate (their own reason, Game.getLastInvestment): **already building 119, Built 1** (m8513, after the old depot's last 8.1 points took 39
  months). Each other gate tested on its own every month: queue >= 9 months 120/120 (4,690 months to endless); staffing passes 120/120 (share 1.0);
  ground 120/120 (71,847 depots' worth); a depot's estimated profit > 0 120/120 (88k-108k a month); the money passed the one month it was asked.
  Their price for a point's non-material work rose 285 -> 347 (+22%); it gates nothing. The new depot: 31.4 of its 400 points in 80 months.
- Every sector: Automotive, Business Services, Food Processing, Heavy Industry, Manufacturing, Mining, Rail, Refining, Retail "already building" 120/120;
  Oil 119 + the jacket; Real Estate held by its months of work 120/120; Agriculture, Industry, Materials "would take N months to build" 103, + 17.
- Repairs over nameplate 0.809 at both ends. History: plots ran out m7839, the unburied at the cap by m7862, capacity flat at 145,200 since m7832.
  The same trap ran m4037-m5823 (1,786 months, sick 0.197 mean). The builders grew 4.3-4.6 depots per 100 months in EVERY era, healthy or not
  (m2517-4037 49,600 -> 76,000; m5823-7839 108,400 -> 145,200 while people went 3.18M -> 5.94M): repairs caught up with them, and the dead took the rest.
- **The 26 sites (m8473): 2,786,054 points owed** (3,118,816 is their whole orders, progress in: O10b's "3.1M"). By owner, owed / share of the crews:
  City 14 sites, 2,689,033 / 88.7% - of it the player's **14 Crude Units, 2,607,490 (93.6% of all owed) / 79.6%** (weight 71,920; 336 points a month);
  Penitentiary 55,419, Police HQ 19,328, Municipal Cemetery 1,393 (1.4 a month), 3 schools, 4 care, a road, a wind farm, a desalination plant (690, done).
  Real Estate 2 sites (22 Low-Rise, 13 Studio), 59,617 / 7.0%. Nine sectors one site each, 37,404 / 3.5% (Rail Spur 10,460, Assembly Plant 10,028, Steel
  Mini-Mill 8,086, Fabrication Works 5,130, Contact Centre 3,158, Iron Mine 421, Snack plant 55, two shops 58, the builders' depot 8.1).
- **The jacket** (Oil's Offshore Platform, ordered m8474, 3,600 points): weight 3,600^.7 = 308.6 of 90,640 = 0.34% -> 184 points in 120 months (1.5 a
  month, none in 17). Nobody is served before it; it is small beside the 14 Crude Units, which take four-fifths of a month that is only ~420 points.

## 4. Against cities that are not construction-bound
- Default playtest (0.7.99 gate, t-build): 545k people at m4002, 111 depots, repairs 0.32 of nameplate (mean after m2000), queue median 3.6 months of site
  output; the builders lay crews off to the need. city2400 copy (113k, a 0.7.38 save), 120 months: 46 depots, repairs 0.16 of nameplate, queue 0 in 120/120,
  the builders' gate "under 9 months queued" 120/120; it is land-bound. It runs out of plots too (m~2512; unburied 6,505, sick 0.36 at m2532), but at 0.16
  the builders still out-do their repairs 4x. Neither city reaches his size. What differs is the ratio: his repairs are 0.81 of nameplate (16,500 people
  a depot, against 4,900 in the playtest), so a 15-point sickness that the others absorb takes his whole margin.

## 5. The options (none applied). Measured = a probe run on a copy; arithmetic = the model's figures, not run.
A. **Jerus, today: death care to the top of the city's order** (the construction page; the probe did Game.moveSite each month for any cemetery or
   crematorium of the city's). Measured: the cemetery opens m~8485; the autobuilder orders 1 + 1 + 27 more (D$340M); unburied 0 and sick 0.035 from m8497;
   sites 22,635 a month (last 12; 45x); the builders order 5 depots, not 1; queue at m8593 1.61M (base 2.74M); the jacket opens m8544; people 5.985M ->
   6.019M; the autobuilder places 33 orders, D$971M (schools and clinics it had held), against 1 in the base run. Cost: no code; he must move each new
   death-care site up (a city site placed while an order is set joins it at the bottom). Rushing too (deathcareRush): the same month to 3.5%.
B. **Model: death care first while the dead wait** - A done by the rule (the city's own death-care sites served first while Healthcare.getUnburied() > 0, or
   the autobuilder setting that order). Breaks the loop by itself; only the city's sites move, as with A. Cost: a small rule and a harness that causes the
   trap (no plots, repairs near nameplate). ★ The loop (dead -> sick -> no site output -> no cemetery) is the bug: Health's header calls the cap "alarming
   and survivable", and in a city whose margin over its repairs is under 15 points it is neither.
C. **Model: the builders' own depot off the top** (before the crew rule) and/or Construction past MAX_CONCURRENT_ORDERS, sized to the gap. Arithmetic: a
   depot gets 0.07% of the sites today (0.12% healthy); first, it would take 400 of the ~420 -> at most a depot a month (the planner orders one) -> +325
   points a month each at 0.81 (+386 at 0.965), up to +48,000 nameplate in 120 months. Their history (4.5 depots per 100 months in every era) is why repairs
   reached 0.81. Cost: a rule in Construction.plan / BuildingManager; 0.7.17 measured a "small orders first" hybrid: depots bought for rushes then laid off,
   13 bank failures in 8 cities against 4 - so it needs the ensemble, with retirement (RETIREMENT_SLACK .25) watched. ★ The structural fix; its own batch.
D. **Jerus, today: buy depots** (Build > Industrial, the city pays). Measured 60 for D$18.6M (city cash D$82.4B). The stack is shared with the builders' own
   order, so it is not a city site and cannot be put first; by the crew rule alone +31 depots in 120 months, sites 7,640 a month at the end, sick unchanged.
   With A: +67 depots, sites 44,400 a month at the end, queue 0.76M, the jacket opens m8522, people 6.047M. ★ The cheapest companion to A.
E. Model: the investors hold an order the builders cannot hand inside MAX_ORDER_MONTHS 12 (as the landlords and the autobuilder already do). The jacket
   (2,496 months) and the nine sectors' starved orders would not be placed: no new point, but their money and their one slot freed. Honest, small; not the fix.
F. Model: a floor for the sites under the repairs (repairs deferred). A new mechanic (a repair backlog), and the repairs are the stock's own. Not recommended.
G. Model: the share a site gets (CREW_SCALE_EXPONENT, a crew per order first). 0.7.17 measured these and chose .70; the trouble here is the size of the
   month, not its split. Not recommended.
H. Jerus: his 14 Crude Units (2.61M, 93.6% of what is owed). Last in the city's order: the city's pool (88.7% of the sites' points) goes to its 13 other
   sites first. Cancelled: every other site's share x4.8 (the jacket 0.34% -> 1.65%), the month still ~420. His call; with A they move anyway.

## 6. For Jerus, in plain words
Your builders spend 81% of their hours on repairs, and since your cemeteries filled (m7839) 19% of all workers are off sick from the unburied dead, which
is the rest. Today: move the cemetery (and each new death-care site) to the top of the construction order, and buy depots - on a copy that gave the sites
22,600 points a month within two years (44,400 with 60 depots for D$18.6M). The choice for the code: B (death care jumps the queue while the dead wait)
now, and C (the builders build their own depots first) as its own batch, with the ensemble.
