# E1, Earth's reader, pure (0.7.111): notes

Progress (a line per step, for a restart):
- 5d36cc1: E0's tooling copied to tools/earth/ verbatim (14 files, LF), with FORMAT.txt, ATTRIBUTION.txt, earth-1.sha256.

## 1. What I built
(in progress)
