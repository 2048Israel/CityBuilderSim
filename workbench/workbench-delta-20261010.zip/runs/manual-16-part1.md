# Manual 16 part 1: 0.7.78 -> 0.7.92 (oil chain's first half, auto-build's limit, streets by need), 2026-10-10, manual writer 16a

Backup `runs/manual/index.before-0778.html` (802,954 B = index.html at start). Edited `runs/manual/index.html` (now 870,926 B; 53 hunks,
66 lines -> 108) by byte-safe unique-span edits: `scratch-manual-16a/py/ed.py` (asserts each old span once, ASCII, LF, `&mp;` once),
scripts e01-e25.py in order; `py/check.py` after each: p/tr/td/div/table/h3/strong/em/code/a/b/span... all open = close, every
`href="#..."` resolves, no new entity. Masthead, edition line, footer, publish file, tree copies: untouched (part 2's).

Progress: DONE - 15 notes and GameVersion 0.7.78-0.7.106 read; edits 01 02 07 08 12 15 16 18-25 (e01-e25); dry run clean.
## Sections changed (false or missing -> now)
- 01 Month: step 5 the ports' share before the railway (0.7.86); step 6 `settleReserve()` after the strike, step 7 `setCityCrude()`
  first (0.7.85, both new statements); step 9 worn-out wells and decommissioning in the retirements (0.7.84/0.7.91); step 11 the
  journey's fuel at wholesale/pump, the forecourts draw the drivers' petrol (0.7.83), ports' crews in transit's bill; step 13 vans'
  diesel and the reserve in the clearing, the refiners' mix/crude on hand and Oil's vintages/platforms at month end. Standing-rule
  note: nine saved items 0.7.79-0.7.91. "What moved" paragraph NOT touched (part 2).
- 07 table: Crude (grades, stock); Petrol/Diesel at the ladder $0.61/0.52/0.034, $0.69/0.59/0.038 (history kept); Fuel oil;
  Lubricants (lube plant, factories' 10/2/8 L); Bitumen (asphalt unit, 64.25/151.75 t); Coke (coker, no buyer).
- 08: table rows Retail (stations' question), Oil (decline, dry sites, the sea), Refining (spread planner; K's gate as history);
  0.7.62 para (one post, worn out); 0.7.76 para re-said past ("two things ... both came"). New h3s: "Wholesale, three grades, and
  the units behind the crude unit" (0.7.78-0.7.80), "The spread planner" (0.7.82), "The forecourts, the vans, the factories and the
  roads" (0.7.83), "Wells that wear out, and crude kept in tanks" (0.7.84-0.7.85), "The oil at sea" (0.7.91).
- 02: car's fuel at wholesale ($0.73 a journey at par) and the pump (~$0.97). 16: the fuel door (ladder, pump, vans). 22: Trade's
  buyers (forecourts, vans, reserve); 08's consumption sentence (the forecourts'). 25: "A car's loan is a bridge" fuel clause.
- 12 GDP: crude the thirteenth good held (0.7.85). 15: loose band over the target only; new para "Since 0.7.81 a loose bank minds
  low inflation" (1.50% at 1% inflation; words "acts only past 4.0% (or under 2.0%)"; CBC 21's per-month assertion, 1.553 v 1.590%).
- 18: new para depth/shelf/dry-sea sites/grades (0.7.79); oil a well a dry site / platform slot; opening zoom (OPENING_OFFER_PX 12,
  2.74 -> 3.0 px); map para's painter history; the network para re-said in past tense as 0.7.72-0.7.87 (names gone noted); legend,
  hover, 48 MB (PAINTED_KEPT 1, 47.6), screen 24-30 ms; new h3 "Streets by need" (4 paras: plan, painter/R7/bands, runs, estate
  lines + sharing) with dated packed/road-not-drawn figures.
- 19: kicker 101 buildings, next 101, the 25 added; Commercial 4, Heavy industry 23, Mining 5, new Ports row 4; Build groups
  (Industry thirteen, Shops three, ports in Industry); cards 101. 20: posts range (one post); paving's bitumen.
- 21: owners' fuel (wholesale/pump; none on cost alone, 36-46% before); cars' fuel; vans' diesel; railway's 18 L literal; new h3
  "The ports" (terminals, wedge formula, 5,000 km, crude needs room, boats, playtest 23 GCTs, +38%).
- 22 Automatic building: remit and money sentences re-said (limit history), the card's dial ranges and toggle row; new para "Since
  0.7.81 the limit is the city's debt over a year of its GDP" written AS IT NOW READS (0.7.101: all owed / 12 months recorded /
  240% / 600% in 10% steps) with N6's measurements (40,797 / 42,542 / 48,030; 10,150 / 10,740 / 11,725).
- 23: new para "From 0.7.78 to 0.7.92 nothing needed a bump" (keys, sidecar 5 then 6 at 0.7.97, the save proofs).
- 24 rows: MoneyCheck, ForeignCheck, CentralBankCheck (21 twice restated), TradeCostCheck/RailCheck, CarCheck/VanCheck, OilCheck (to
  16 sections), WorldCheck 7, NewGameCheck/LandCheck 10, MapCheck rewritten (raster since 0.7.88, runs 0.7.89, history), SaveFileCheck/
  ReadPathCheck/BuildingDataCheck (91..101), InvestCheck/InfrastructureCheck 10, RoadCheck 4, BuildCardCheck, BuildAdviceCheck 1,
  AutoBuildCheck (0.7.81 limit), BuildMenuCheck (bitumen; 101 of 101); BMC pass counts sentence. New rows RefineryCheck (14 sect.),
  WellCheck (12), PortCheck (9), PlanCheck (9). Named 81 + "eight more" = 89 = Check files at tag 0.7.92 (checked).
- 25: rewritten rows A refinery that loses money, Automatic building's calls, The map's loose ends, One car a household, What no
  harness looks at; new rows The money gate, A city with no filling station, A well's second life, How far the world is (76 -> 80
  rows); Answered note: half of the map's loose ends (0.7.88), and raised-and-answered: very loose (0.7.81), opening zoom (0.7.79),
  auto-build's revenue limit (0.7.81). Kicker NOT touched.

## Figures checked against main (0.7.106; code wins)
Good (ladder prices, cargo()), buildings.json ids 74-100 (cash, posts, land, feed, pump, stock, port, offshore) and category counts
(also at tag 0.7.92: same 101), Refining (CUTS, LIGHT/HEAVY_VOL_PCT, CRUDE_COVER_MONTHS, CARGO_KEPT_FREE, PACKAGE_MOST_UNITS, farm
rule), RefineryFlow (kinds' yields, HYDROGEN_MADE/USED, RESIDUE_LITRES_PER_TONNE), SpreadPlanner (cityValue at the margin, FEED_GATE
.60, IDLE_MONTHS 6), Oil (LAND_KEEPS .9, plateau 36, .915, 100/10 b/d, depth 150, PIPE_LIFE 480, PAYBACK 1.25), Retail (PUMP .12,
QUEUE .18, pumpPrice with duty), Sector van diesel 40x50x12/100 = 240, Manufacturing/Automotive lubricants, Game BITUMEN .05 and
bitumenFor, Rail FUEL_LITRES 18, Ports shares .08/.07/.16/.20 and ship classes, StrategicReserve (release stays, 0.7.103),
AutoBuilder (DEFAULT 2.40, OLD .60, MOST 6.0, STEP .10, debt(), annualGdp(), words), DebtManager ruleRate/LOOSEST_*, World SHELF
.0886/140, Deposit GRADE_SHARES, MapFrame OPENING_OFFER_PX 12, DistrictPlan (CELL_ROOM_LEAST 120 of 961, SQUARE 56, BOULEVARD 100,
bridges 6/14, REACH 4), CityRuns (HIGHWAY_AT 16, RAIL_AT 8, TURN 40, JUNCTION 200, RAMP_EVERY 2), CityMap PLANS_KEPT 64, CHAIN_BAND
128, FORMAT 6; TileRaster PACKED_DIM .35; MapTiles PAINTED_KEPT 1; MapView legend words; NationalAccounts.HELD 13.
Month order: tools.MonthOrder (compiled in scratch) on git f85bcfa (0.7.79), tag 0.7.92 and main: 0.7.79->0.7.92 the two reserve
statements in, setCommute without markets, setTransit with portsBill; O2/O3 touched neither Game nor SimulationEngine.
Measurements (playtests, cities, ensembles) are the fix notes', dated in the text, not re-run.

## Record / code disagreements, and calls
1. GameVersion 0.7.89 says the railway runs "a quarter of a district in"; CityRuns: RAIL_AT 8, the line a quarter into a CELL. Manual
   follows the code. For the docs pass.
2. GameVersion 0.7.78 "up to two fifths" took the bus on cost; fixO2 measured 36-46% (Jerus), 29.5% (CarCheck). Manual gives those.
3. Measured map figures (packed 148, road not drawn 183,991, track short 1,863) are 0.7.92's; O13's campus/shore (0.7.97) may move
   them: written "at 0.7.92".
4. Placement: oil chain in 08 (five h3s), ports in 21, streets in 18, limit in 22, loose steps in 15; harness rows to 0.7.92.

## Not settled
- ManualToMarkdown dry run (main's tool compiled into scratch, under flock; output only in scratch/m2md): the backup gives 0.7.77's
  figures exactly (25 sections, 34 tables, 33 formulas, 27 notes, 15 steps, 1,947 lines); the final index.html 25/34/34/27/15,
  2,010 lines, no warning (+1 formula, the ports'). The publish file and the tree were not touched.
- Nothing seen in the game's window; screens from code and the notes' Java2D mirrors. Rules: no rm, no /dev, no <(...), every
  javac/java under flock. Slip, owned: my first `ls` wrote its error to `runs/ls-err-16a.txt` (79 B) before scratch existed; left (no rm).

## For part 2
- Edition-level, untouched: masthead edition line and standfirst/vitals, footer, 24 kicker (harness counts: 89 at 0.7.92; main has
  91 with OilViewCheck and RefineryViewCheck, which need rows; "eight more" still the same eight), "The tree" para counts, 25 kicker
  (76 rows at 0.7.77 -> 80 at 0.7.92: +4 new, 5 rewritten, 3 raised-and-answered, half of one answered), 23's format para ("at 34").
- 01 "what moved": mine adds two statements (0.7.85) + the inside changes above; part 2's `deferBorrowingCosts()`, `monthRun = true`.
- Hooks I wrote as today's rule, one clause each, for part 2 to explain in full and not contradict: fuel duty on the pump (0.7.103,
  08 forecourts); the run's share (0.7.105, 08 flow), cargo kept free (0.7.105, 08 storage), cityValue at the margin (0.7.105, 08
  planner); reserve release stays, budget lines, Oil page levers (0.7.103/0.7.102/0.7.96, 08 storage); two pools and the map at sea
  (0.7.93/0.7.97, 08 oil at sea; 21 ports' boats); NO_FEED and "dry" card words (0.7.103); station estimate less wages (0.7.106);
  PlanCheck's bound steadied (0.7.94, 25 map loose ends). Auto-build's limit is fully 0.7.101's in 22 - part 2 need only add P2/P2b's
  other changes (first buildings, ranking, payback) and move AutoBuildCheck's row past 0.7.81.
- Left wholly to part 2: lubricants' 1% world share (07 Lubricants row and 08 "6.0% ... against 1%" sentence want it), OilCheck 6
  ships the slate (0.7.98; 08 0.7.76 para still says products are shipped - true again), OilCheck 17, RefineryCheck 15-19, WellCheck
  13, PortCheck 7's cargo room, MapCheck 9 and 0.7.98/0.7.100 changes, the refinery picture/oil screen, W1's deposits (18 table).
