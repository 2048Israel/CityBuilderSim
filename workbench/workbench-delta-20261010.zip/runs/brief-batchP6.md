# Brief: P6, the refinery's run. 0.7.105. 2026-10-10

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## Jerus's decision (2026-10-10 01:09, on the project doc `claude/why-the-refinery-loses.md`: "as for the decision go for the recommended")
The study (read-only, on 0.7.99; you cannot reach the project, so its findings are summarised here) found his refinery, a 500,000 b/d topping plant on imported crude shipping by rail, loses about US$15M a month for four reasons in the code:
1. **It runs flat out whatever the barrel pays:** `Sector.getOperatingRate()` is staffing x energy x water x roads x health x vans; none is price, so the crude units buy their full crude every month at a loss on every tonne.
2. **It has almost no conversion:** `Refining.plan()` returns "already building" while any refiners' building is on site (`MAX_CONCURRENT_ORDERS` 1); his 14 Crude Units on site freeze the planner, so no Cracking Unit is ordered whatever its spread.
3. **The Tank Farm trap:** tanker crude lands only while the farms have room for an MR's 37,500 t (`Ports.freeCrudeRoom()`), but the refiners keep a month of their crude units' run on hand as far as the room holds (`Refining.crudeKept()`), so one Crude Unit with one farm leaves 14,185 t free (429,185 room, 415,000 kept): no tanker ever lands; and the investors order a farm only while none stands (`Refining.farmCandidate()`). Read from the arithmetic, not a run: check it in PortCheck with a Crude Unit in place of the fixture's refinery.
4. **The exits are shut:** the distress rule (`BusinessInvestment.planDistressRetirement()`) needs 24 loss months, negative cash and nothing on site; every opening resets the clock (`noteOpened()`); the spare-capacity rule (`Refining.retirementDemandAndCapacity()`) offers only idle conversion units, never crude units.

The margins (a share of crude's world middle; a topping barrel of medium crude): imported crude, all exported: lorry -10.0%, rail at .60 -4.7%, rail at .30 -0.7%, tanker +2.3%; with conversion (2 Cracking, 2 Alkylation, 2 Reformers, a Hydrocracker) tanker +9.3%. Petrol and diesel are only 20% of a topping barrel. The planner (`SpreadPlanner.cityValue()`) values an untraded product at the band's middle and petrol and diesel at the import price on every litre, so it sees +2.9% where a running unit earns -1.7% to -3.9% (rail .60).

**Decided, to build:**
- **A2 (b), the run rule, valued at the margin.** A crude unit runs a barrel only while that barrel's products, at what they would actually fetch, beat its crude and haulage: the city's own take of petrol and diesel at the import price, up to what it imports; everything past that at the net export price; only variable costs count (wages and capital are paid either way). **The pace:** the run moves at most a quarter of nameplate a month (`MAX_RETIREMENT_FRACTION`'s pace, offered as an example, not measured: ★). **The exits:** a crude unit idle by this rule is spare capacity, so the six-month rule can sell it, as it does conversion units.
  Expected: his city as it stands idles its crude units (every topping barrel loses by rail, even those replacing imports: -1.7% at .60) and stays idle; near the rail floor it runs just the home market (+1.4%) and stops short of exporting (-0.7%); on the sea with conversion it runs full.
- **R1, the planner's prices at the margin:** value an untraded product at its net export price, and petrol and diesel at the import price only up to what the city imports; the rest at net export. It stops investors ordering a plant that loses from its first month.
- **R2, the Tank Farm trap:** either keep a month's run less an MR's cargo, or let the investors order farms until a tanker fits (★ which, with a PortCheck fixture showing it).
- **R3, one order in flight:** count against `MAX_CONCURRENT_ORDERS` only the sector's own orders, or let a conversion unit be ordered while only crude units are on site (★ which; say what it does to every other sector, as T1 found nine sectors each held behind one starved site in a construction-bound city: `runs/fixT1-notes.md`).

## Read first
`docs/map/Refining.md`, `RefineryFlow.md`, `SpreadPlanner.md`, `Ports.md`, `BusinessInvestment.md`; `docs/harnesses.md` (RefineryCheck, OilCheck, PortCheck, WellCheck); the notes `runs/fixO14-notes.md` (§1, §7), `fixO13`, `fixO5`, `fixO9`; P4's notes `runs/fixP4-notes.md` (the lubricants cap, which comes first).

## Do
1. The run rule, R1, R2 and R3 in the model; their harnesses (a fixture that causes each condition; assert against the model's constants); every statement identity still closes.
2. Measure on a copy of `jerus-1008`, 24 months: the refiners' run, their profit, what they import and export; and on the playtest.
3. Words where Refining's page, the refinery picture (`RefineryView`) or the oil page (`OilView`) say why a unit runs or idles; every string fits at 1,389 x 868.

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| P6 | 0.7.105 | named in the launch prompt | `/home/claude/scratch-p6` | re-baseline as `pt07105` against the reference the launch prompt names if they move, every move explained; then the ensemble (label `07105`, `BASELINE` the launch prompt names); report, don't tune |

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** The full suite green (HealthCheck green since 0.7.102; if it goes red again, say why). BuildMenuCheck 101. The `MoneyAudit` closes every month. Old saves need not load until the game is published (the shared rules); every `java` run under `flock /home/claude/jvm.lock`.

Reply with: a short summary; the rule as built; R2 and R3 as chosen; his 1008 city before and after; the trace movement explained; the ensemble; the gate and your final commit; your ★ calls.
