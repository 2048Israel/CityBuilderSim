# Brief: E1, Earth's reader, pure. 0.7.111. 2026-10-10

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## What this is
The first game batch of "the world as planet Earth" (`/home/claude/runs/spec-earth.md`; read the summary, §1, §2, §3 and §8's E1 and E2 rows). E0, the data file, was built outside the game on 2026-10-08 (`/home/claude/runs/fixE0-notes.md`, whole, 90 lines): `/home/claude/scratch-earth/e0/out/earth-1.bin` (52,757,374 bytes, SHA-256 in `earth-1.sha256`), its layout in `FORMAT.txt` beside it, and the Python that baked it, with the reference reader `earthread.py`, in `/home/claude/scratch-earth/e0/tools/earth/`. Jerus answered the study's eight questions "all rec" (2026-10-10), so the spec's recommendations stand: Earth for new cities only, the default once E4 ships; real river courses; WorldCover coasts; sea and ice refused, deserts and dry spots warned; no guaranteed iron field; names for search only, no borders; today's river-water rule; no elevation.

**E1 is pure and byte-identical:** nothing in the game reads Earth yet (E2 does). Build:
- **`EarthProj`:** Lambert azimuthal equal-area on the WGS 84 authalic sphere (6,371,007 m), `StrictMath`, centred on a (lat, lon); forward and inverse; plot (x, y) ↔ metres as §2 says; a cell's spherical area.
- **`EarthData`:** the reader of `FORMAT.txt`'s layout, from `earthread.py` (port it; don't retype it from memory): the header and layer table, the tile index, an LRU of inflated tiles (`java.util.zip.Inflater`, no new library), the share layers (sea, lake, landcover, far.land, far.lake), the lists (lakes.small, rivers; a river run stored in every tile its box touches, so say how the reader treats duplicates), geology and provinces, places, meta; and the file's SHA-256 identity `"earth-1:<hash>"`.
- **`EarthCheck`** (new harness), the spec's E1 row: inverse-then-forward ≤ 1e-6 m within 1,050 km (the study measured 2.4e-7); a 61.44 km cell's spherical area 3,774.87 km² to 1e-9; bilinear blending across a tile edge ≤ 0.1 m at 10,000 km (measured 0.054); the data hash matches; a tile inflates in ≤ 1 ms (measured 0.13; wall clock, so under the JVM lock as every timing check); and the reader's figures equal `earthread.py`'s on the same tiles (a few cells of each layer, the three windows: Rotterdam, Perth, Paris as the study drew them).

**The Java prototype is gone** (the study's `proto/src/ham/citybuildersim/Earth*.java` did not survive the workspace's restart on 2026-10-09). Port from `earthread.py`, `FORMAT.txt` and the spec's formulas; every figure the spec measured is your target.

## The data file and the repo (★, decide by these limits)
- **The 52 MB `earth-1.bin` does not go into git in this batch.** A file in git history stays there for good (the repo is public, and GitHub warns over 50 MB and refuses over 100 MB); how the data ships (one file a layer, Git LFS, a download, or in git) is Jerus's call, wanted by E4, not now. Say in your notes §8 what you recommend and why, with sizes.
- **So `EarthCheck` runs on a small fixture** you cut from `earth-1.bin`: a file in the same layout holding only the tiles the checks need (the three windows'), with its own hash, committed in the repo (★ where: e.g. beside the sources as a resource; keep it under about 2 MB and say its size). The checks on the full file (its hash, `earthread.py` agreement on wider areas) run when the full file is named (★ how: a system property, e.g. `-Dcbs.earth=<path>`), and print one plain line when it is not; the orchestrator's gate will name it. ★ where the game will look for the full file later (E2/E4 decide; leave a constant and one sentence).
- **E0's tooling goes into the repo:** copy `/home/claude/scratch-earth/e0/tools/earth/*.py` and `run.sh` (not `__pycache__`) to `tools/earth/` in your worktree, with `FORMAT.txt` and `ATTRIBUTION.txt`, so the data can be rebuilt from GitHub. LF line endings; no edits beyond a header line naming where it came from if you want one.

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| E1 | 0.7.111 | named in the launch prompt | `/home/claude/scratch-e1` | **byte-identical** to `/home/claude/scratch-ui1/orch-gate/pt07106/` |

Your files: `EarthProj`, `EarthData`, `EarthCheck` (new), its line in `AllChecks`, the fixture, `tools/earth/`, `GameVersion` (your entry), the counts in `CLAUDE.md`/`README.md` (93 harnesses with yours; a row for each new class in CLAUDE.md's map if it has one), `docs/harnesses.md`'s entry for EarthCheck. Nothing else: **beside you, I1 (0.7.110, fields by type) works in `Deposit`, `Resource`, `World`, `LandManager`, `CityLand`, `DataSave`, `Game`, the building template and `WorldCheck`/`LandCheck`/`BuildingDataCheck`/`SaveFileCheck`/`ReadPathCheck`.** Don't touch those; both of you add a `GameVersion` entry, and the orchestrator resolves that at the merge.

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** The full suite green (93 harnesses with EarthCheck); BuildMenuCheck 101. Run `EarthCheck` at your gate with the full file named, and once without it.

Reply with: a short summary; EarthCheck's figures against the spec's; the fixture's size and where it lives; how the full file is found; your recommendation on shipping the data; the gate and your final commit; your ★ calls.
