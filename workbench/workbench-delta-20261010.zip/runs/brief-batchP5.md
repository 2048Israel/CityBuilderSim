# Brief: P5, prices and rules. 0.7.104. 2026-10-10

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## Jerus's decisions (2026-10-10, the project doc `claude/decisions-2026-10-10.md`, "all rec"; quoted here, as you cannot reach the project)
- **A18:** grocers at their floor lose money; their investment test counts no wages (Q1) -> **count wages in the investment test** (moves the traces).
- **A20:** NEEDS YOU's care rows and Build's rings read beds, not beds less the priced out (0.7.27's D16) -> **switch** (read beds less the priced out).
- **A23:** demolition salvage at the full market price (a school: $12.2M against a $1.05M demolition) -> **discount it, with a sourced figure.**
- **A24:** a new city owns 0.011 km² of lake; its first water plant idles about 98% -> **found with fresh water for one plant.**
- **B:** Insane's land bond charged for the plots a new city owns, not the 3,000,000 sq ft figure.

## Where each was found (`/home/claude/runs/records/todo.md` line numbers as of 01:50)
- A18: line 2354 ("Not built, from the triage: Q1, the grocers at their floor"; `Retail.estimatedMonthlyProfit()`); count wages **in the investment test only**, as the triage recommended.
- A20: line 933 and around ("priced out (D16, CONFIRM below)"); the 0.7.27 People spec `runs/spec-people-0727.md` D16 if present; `CityNeeds`, `BuildAdvice`'s rings.
- A23: line 5703 ("DECIDE (from 0.7.22): salvage at the full market price is generous"); `ConstructionControl`'s demolition and salvage. ★ the discount and its source (a published recovery or scrap value of demolished buildings).
- A24: line 1860 ("A new city's first water plant is about 98% idle"; `runs/fixJ2-notes.md` §8.4). ★ how a founding takes the fresh water one plant needs (lake or river ground in its centre), on the land grid, with the world's deposits and its totals untouched.
- B: line 1779 ("Insane's land bond still charges for the old figure"; `runs/fixM3-notes.md` §2 item 6; `Founding.landBondUsd()`).

## Do
1. Each decision as stated, in the model first, then the screens' words (every string fits at 1,389 x 868).
2. A24 changes a founding: the default playtest's city is founded again, so the traces move from month 0. ★ say what a founding now owns and why.
3. **Harnesses:** each change asserted; a premise moves only where a decision changes the rule it asserts (list before -> after in §3). A24 is a founding rule: no conversion of older saves (they need not load until the game is published).

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| P5 | 0.7.104 | named in the launch prompt | `/home/claude/scratch-p5` | **moves them**: re-baseline as `pt07104` against the reference the launch prompt names, every move explained; then the ensemble (label `07104`, `BASELINE` the launch prompt names); report, don't tune |

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** The full suite green (HealthCheck green since 0.7.102; if it goes red again, say why). BuildMenuCheck 101. The `MoneyAudit` closes every month. Old saves need not load until the game is published (the shared rules); every `java` run under `flock /home/claude/jvm.lock`.

Reply with: a short summary; the salvage discount and its source; what a founding owns now; the trace movement explained; the ensemble; the gate and your final commit; your ★ calls.
