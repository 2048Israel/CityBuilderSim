# Brief: P3, the budget and the books. 0.7.102. 2026-10-10

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## Jerus's decisions (2026-10-10, the project doc `claude/decisions-2026-10-10.md`, "all rec"; quoted here, as you cannot reach the project)
- **A15:** repairs and transit fares sit outside the budget's totals (0.7.31's D4) -> **yes, plus maintenance**. Jerus: "rec plus maintence, idk if its the case but i see maintencne is out of the budget even tho its a monthly thing". **Every monthly treasury flow inside the budget's totals;** the batch lists anything else that sits outside, and why.
- **A16, the statements:** a sector's debt read at the month's close (F-S1-2), and fees, insurance premiums and bond costs taxed or expensed (fixS2 F1, F2) -> **debt at the close; the three deductible expenses.**
- **A17:** arrears the treasury pays down for a sector miss its cash-flow statement -> **add the line.**
- **A21:** the fund's forced sale (a withdrawal over the default) asks at fair value where nobody bids -> **sell at the desk's bid.**
- **A22:** the investors' last word (`Game.lastInvestment`) is not saved -> **save it.**
- **B:** the fund summary neutral, not amber, while the dial sells.

## Where each was found (read these; `/home/claude/runs/records/todo.md` line numbers as of 01:45)
- A15: todo line 2807 ("**D4,** repairs and the fares..."), the Finances/Government screens' "Outside the budget's total" (grep that phrase in the todo and in `ui/`), `the-debt-at-a-glance` and `earned-surplus-banked` (0.7.31, 0.7.32) in the notes `runs/ui12-notes.md` and the Finances spec `runs/spec-finances-0732.md`, `runs/spec-government-0731.md` if present.
- A16: todo line 1698 and 3700-3710 ("Two sheets that read stale"); `runs/fixS1-notes.md` §7 F-S1-2 and §8.4; `runs/fixS2-notes.md` §2 item 1 and §7 (F1, F2).
- A17: todo line 1933; `runs/fixH2-notes.md` §5; `Game.payDownArrears`.
- A21: todo line 2263 and around ("Selling at the desk's bid would be C3's..."); `FundLedger`, `TreasuryFund`, the fund's withdrawal (0.7.48).
- A22: todo line 3053 and 10036-10040 (`Game.lastInvestment`).
- B: todo line 774; the fund summary's colour (`ui/FundScreen` or `FinancesScreen`).

## Do
1. **The budget's totals (A15):** find every monthly treasury flow the budget's totals leave out (repairs, fares, maintenance, and any other), put each inside, the budget's lines and the treasury's journal agreeing to the cent with `MoneyAudit` closing every month. List in your notes each flow that still sits outside and why (a flow that is not monthly, or not the treasury's).
2. **The statements (A16, A17):** debt read at the month's close; fees, insurance premiums and bond costs as deductible expenses for profit tax (★ how each is booked, sourced); the arrears line on the cash-flow statement. Every statement identity still closes to the cent (`SectorStatementCheck`).
3. **The fund (A21, B):** the forced sale at the desk's bid; the summary neutral while the dial sells.
4. **A22:** save `lastInvestment` (`DataSave`, the load path, `SaveFileCheck`/`ReadPathCheck`); `SAVE_FORMAT` 37 only if an old save would load wrongly without it (CLAUDE.md's rule).
5. **Words** where the screens say "outside the budget" or explain these lines; every string fits at 1,389 x 868.
6. **Harnesses:** each change asserted (the flows inside the totals; the deductions; the arrears line; the bid; the saved word). A premise moves only where a decision changes the rule it asserts; list each before -> after in your notes §3.

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| P3 | 0.7.102 | named in the launch prompt | `/home/claude/scratch-p3` | **moves them**: re-baseline the playtest as `pt07102` in your scratch against the reference the launch prompt names, every move explained; then the ensemble (label `07102`, `BASELINE` the launch prompt names); report, don't tune |

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** Suite 90 of 91: HealthCheck stays the known red (by 0.4 points since 0.7.100, a call for Jerus); every other harness green. BuildMenuCheck 101. Old saves must load and the `MoneyAudit` close every month: load copies of `/home/claude/cities/city600`, `city2400`, `jerus-1007a`, `jerus-1008`, `jerus-old` for 24 months each.

Reply with: a short summary; the flows now inside the totals and any left outside; the statements' changes; the trace movement explained; the ensemble; the gate and your final commit; your ★ calls.
