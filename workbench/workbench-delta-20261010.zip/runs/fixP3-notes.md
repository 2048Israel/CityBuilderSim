# fixP3 notes - 0.7.102 "the budget and the books": A15, A16, A17, A21, A22, B. Implementer (Opus), 2026-10-10
Worktree `/home/claude/git/wt-P3`, branch `batch/P3` from e859997 (clean at start). Scratch `scratch-p3/` (no rm, no /dev).

## 0. Steps (a line per step)
- s1-s2 scratch made, scripts copied; A22 (DataSave/Game/SaveFileCheck), B (FundScreen), A21 (Exchange, FundCheck premise); FundCheck, SaveFileCheck green; committed.
- s3 A15: NationalAccounts' four lines (slots 30-33), journal records out, Government lists; four harnesses' premises; committed.
- s4 A16a: Game.recordMonth pushes the sheet at the close; SectorStatementCheck 3 and 8; committed.
- s5 A16b: Sector's borrowing-cost clock (60 months, ITA), statements' lines, BooksCheck section; committed.
- s6 GameVersion 0.7.102, A17 row asserted, CentralBankCheck 19's dial (fixture), words measured (17, 0 over); committed.
- s7-s8 suite-1: MortgageCheck 12, AutoBuildCheck 3/4 (never borrows), BuildCardCheck and SectorFlowCheck (A22 broke the counted proxy -> Game.hasMonthRun).
- s9 A16b re-booked over each debt's life (the 60-month trial measured, §2); fixtures re-made (CB 21 seed 8; AutoBuildCheck 3 caused); committed.
- s10 gate-1 (07:39-08:04): suite 88/91 (SaveFileCheck fixture -> half shelf; MapCheck, PlanCheck wall-clock under load), Stale 1 firm (mine, fixed); committed.
- s11-s13 MapCheck, PlanCheck alone x10 (§5); every commit played (§4); five old saves (copies) 24 months each, all load and close (§5).
- s14 final gate 08:34-08:56 green (§5); d07f9c5 rewords comments and two labels (rebuilt silent, both harnesses green). Slip: one `diff <(...)` (process substitution, against the rules) checking the changed list; not repeated.
- s15 ensemble 07102 (56.2 min, machine loaded): 23 of 26 against 0.7.100's 24; A2 and S1 red as before, HIGH R2 newly red (§5).
- s16 round 2: main (0.7.101, P2) merged by the orchestrator (8e7656e); AutoBuildCheck 4 and 5's walk fixtures re-caused (§3), 28462c3; gate on it 10:30-10:56 (§5); PlanCheck alone x10.

## 1. What I built
- **A15.** `NationalAccounts` gains `cityRepairs` (`chargeBuildingMaintenance()`), `arrearsPaid` (`payDownArrears()` to the
  businesses' tills; the students' were already on the grant line), `reserveCrudeBought`/`Sold` (`settleReserve()`), relayed by
  `EconomyManager` at both strikes, saved at the government block's end (length 33; older read 0). Expenses take three, revenue one;
  the four journal records gone; `getEarnedToBudget()` four more steps. Government lists Repairs, Arrears paid down, Crude for the
  reserve, Crude sold from the reserve, with icons and doors; both "outside the total" doors gone; BRIDGE_INFO, Oil's (i) reworded.
- **A16, debt at the close (F-S1-2).** `Game.recordMonth()` pushes the sheets before the books take the month: debt, land and
  buildings as they stand at the close; the debt schedule close to close; SCHEDULE_INFO reworded.
- **A16, the three deductible expenses.** A loan's fee, a mortgage's premium and fee, a bond's issuing costs expensed over each
  debt's life (36, 480, 120 months) before the profit tax, carried as an asset meanwhile: `Sector`'s clock (`borrowingChargesLeft`,
  `BORROWING_COST_MOST_MONTHS`), `Game.deferBorrowingCosts()` at the close, `Statement.borrowingCosts`, `bank()` adds it back (cash
  moves by the tax saved); saved, scaled, reset. Statements: "Borrowing costs, over each debt's life", "...still to expense",
  "...paid when it borrowed"; `outside()` drops the three on a deferred month; the Sectors waterfall and dollar bar.
- **A17** built in 0.7.55 ("Arrears the city paid"); CentralBankCheck 6 asserts the row. **A21** `Exchange.postFund()`: the
  withdrawal's part, when the largest sale, asks the desk's bid, fair x (1 - RULE_PREMIUM). **B** FundScreen amber only when the
  short is not being sold for. **A22** `DataSave.lastInvestment`; `Game.hasMonthRun()` is the not-counted rule (BuildCard, SectorFlow).
- GameVersion 0.7.102. SAVE_FORMAT stays 36: every new field reads as nothing in an older save (five cities measured, §5).

## 2. Departures, with reasons
- **A15 took four flows**: "maintenance" is the repairs (one bill); by the rule the arrears paid down (spending paid late) and the
  reserve's crude (monthly while a fill stands) went in too. **Debt at the close reads land and buildings too** (else a loan shows
  without its building). **A17** asserted only. **A21** shares only (no bond desk). **B** drops a figure rather than adding one.
- **Each debt's life, not five years.** ITA s.20(1)(e)'s fifth a year was built first and measured: the landlords ran a loss for a
  year and a half; AutoBuildCheck's decades city ended at 3,022 people (13,483 at 0.7.100); MortgageCheck 12 found no paying month.

## 3. Premises changed (before -> after), fixtures re-made, new assertions
- **OilCheck 16** (A15): "...and the bridge names it" -> "...and the budget carries it" (`getReserveCrudeBought()`, journal none);
  "...ReserveSales, TRADE, journalled" -> "...on the budget's line".
- **CentralBankCheck 6** (A15): "...in that order" (journal positions) -> fixture, cash for half the advances: "the cash repays the
  central bank first, and nothing is paid down while it is owed"; new: "...on the budget's own line", "...the journal names none";
  A17's row. Fixtures, no premise moved: 19's dial .5 -> (1 - MAX_HOUSEHOLD_PAPER_SHARE) x .8 (households take up to half an
  issue; .5 left the bank none); 21's probe city seed 11's shape -> seed 8's (seed 11's twins trusted alike, 0.942153; 16 shapes
  probed, 11 hold every premise; seed 8: twins 9,194-9,196, 2.567 < 2.838 < 3.323%, trust 0.753 against 0.932).
- **SaveFileCheck**: the journal fixture now buys a thousand of reserves before each waited month; the shops' shortfall caused with a
  half shelf. New: the repairs line round-trips and is what was paid; the investors' last word. 10% town late $112.18k -> $131.19k.
- **TreasuryCheck** (new): repairs inside the budget as paid, the journal naming none; the walk's Repairs step.
- **FundCheck 9b** (A21): "...asked at fair value" -> "...at the desk's bid, fair value less RULE_PREMIUM"; new "...the desk's bid
  meets it at the step" (69.4% of each holding sold).
- **BuildCardCheck 5** (A22): "loaded, no market card has a word until a month runs" -> "every market card has the word it had"
  (59) and "...while no month has run since the load". **SectorBooksCheck**: pre-tax less borrowing costs too.
- **SectorStatementCheck** (A16): 1 "the total result is the profit and the outside lines" took the three fees off every month ->
  only before 0.7.102; 8 "lent after a sheet was read" (> 0) -> "nothing is lent after it" (0 of 8,194). New: the borrowing line is
  the month's charges; still-to-expense rolls (8,177, 0 off); 3 debt, buildings, land at the close (8,211); expensed in 2,391.
- **BooksCheck** (new): a fee and a premium expensed over their lives before the tax; cash moves by the tax only; across a save.
- **AutoBuildCheck 3** (fixture): the decades city borrowed in 8 passes at 0.7.100, none now (ends at 10,366 people, 13,483 then).
  A copy at its end (cash at the reserve, limit DEBT_LIMIT_MOST) runs one pass, read by the same look(): borrows $574.5M; the limit
  label names the worst pass's (300%). **MortgageCheck** untouched (the trial's widened window reverted).
- **AutoBuildCheck 4 and 5's walk, merged with P2 (fixtures, no premise moved, nobody's rule):** P2's budget gate reads A15's lines.
  4: the decades city ends spending past its revenue ($73,708k against $59,907k, repairs $4,816k): 0 orders in 36 months -> both
  cities given withRoom() too, as they are given ground (2 orders). 5: the walk's town paid down $97,246k of arrears the month
  before, past ROOM (room -$58,386k) -> withRoom() clears the arrears paid down with the bills. 3 on the merge: 14 passes borrowed.

## 4. Trace movement (pt07102 against pt0799; each commit played)
- **A21, A22, B (5b672ba): identical**: the playtest never withdraws over the default; the word is read, not acted on.
- **A15 (4ddf962): first m601.** The four lines lower the budget's balance; the rollover nets the surplus against what falls due,
  so it nets less and rolls more (city debt 108,601 against 84,608 that month).
- **Debt at the close (0be083d): first m10** (t-bank capitalRatio, capacity), t-month m13. The books' equity and assets are the
  close's, and the exchange reads them (a listing's book, a buyback's assets and equity).
- **Borrowing costs (376eea2): first m4** (t-house reCash, reAssets: the landlords' costs expensed save tax; t-bank, t-bonds),
  t-month m5 (cash, taxIncome, revenue, sectorsPreTax), t-build m12, t-pop m13, t-labour m21, t-borrow m122; chaos carries it.
- **m4005:** pop 545,179 -> 544,232 (-0.17%; the five-year trial -2.3%); index 844.9 -> 1,294.5, inflation 1.89% -> 2.10%; GDP
  $1.854B -> $3.140B (+10.5% deflated); the fund $99.8M -> $22.1M. Findings: "Nothing. Every month passed the audit..."

## 5. Gate and final commit
- ce09432's classes, 08:34-08:56: builds silent; **suite 91 of 91** (HealthCheck green, not the known red); BMC PASS 101; Stale 0
  firm (415 soft, 304 the maps); pt07102 8 traces moved, findings none; eol 0 w/crlf. d07f9c5: comments and two labels.
- Gate-1, alone x10 at load ~4: MapCheck's CPU bound 10/10, its wall screen-ratio label failed 3 (0.7.100's 1 of 3); PlanCheck's
  slowest 20.78, 53.77 F, 31.21, 17.37, 33.93, 23.75, 19.91, 16.94, 28.92, 51.00 F ms. Both passed in the final suite.
- Old saves, copies, 24 months (P3Cities): all five load; worst audit 5.12e-14; books' debt off the close 0 of 408 sector-months
  each; repairs on the line from the first month; residual/closing at most 6.6e-3 (jerus-1007a's first month, 0.7.100's to the cent).
- **Ensemble 07102: 23 of 26** (0.7.100: 24; 0.7.101: 24). A2 red as before, milder (longest spell median 7 -> 6, worst 16 -> 13);
  S1 red as before, milder (1.41% -> 1.26%, longest spell 13 -> 10). **New red: HIGH R2**, unemployment at 15% minus the twin,
  median +1.49 -> -0.46 points (needs +0.50); seed by seed it swings both ways in both runs (my read of the CSVs, m600-720: 11 of
  16 seeds above the twin then, 7 now; seed 0 -0.14 -> +5.33, seed 6 +5.62 -> -2.97). Not tuned or diagnosed. T1, T2,
  M1, F1 (0 findings), pairing 64/64 pass; AUTO2 final pop median 230,564 -> 226,599. Not rerun on the merge.
- **Round 2, merged tree (28462c3), 10:30-10:56:** builds silent; suite 90 of 91, PlanCheck's 40 ms line alone red (61.23 ms);
  AutoBuildCheck, HealthCheck green; BMC 101; Stale 0 firm; pt 8 of 8 identical to orch-gate/pt07102, findings none; eol 0.
  PlanCheck alone x10 (load 3.7-4.5 on 2 cores): 40.18 F, 50.50 F, 37.65, 61.91 F, 58.57 F, 61.04 F, 47.31 F, 37.57, 55.95 F, 47.49 F
  ms; 0.7.100's classes x3 beside them: 60.13, 54.76, 51.08 ms, all F. The plan code is 0.7.100's. **Final commit: 28462c3.**

## 6. Star calls
1. **A budget flow**: revenue, spending, a real thing bought or sold (land, buildings, crude), cash basis; outside, a claim or debt
   changing hands (Canada's non-budgetary "loans, investments and advances") or what is not monthly. **Left outside** (TreasuryJournal):
   students' loans (interest inside), the fund's pay-ins and draws (the transfer inside), reserves, the bank's resolution capital and
   preferred, buybacks, central bank advances and repayments (borrowing), a demolition's salvage (once), land from the vault (no cash).
2. **Arrears paid down a line of their own**, not folded into what they were owed under. 3. **EARNED unchanged**: the four are steps.
4. **Old saves read the four lines as zero** for their saved month, so the bridge closes. 5. **The whole sheet at the close.**
6. **Each debt's life, straight line, book = tax** (IFRS 9 5.1.1, App. A, B5.4.1-3): premium and fee over the amortization (480),
   a loan's fee over its term (36), issuing costs over the bond's (120); an asset, not netted off the debt (the schedule rolls the
   principal); from the strike after they are paid; older saves carry none (their costs moved equity already).
7. **A21: the desk's bid only when the withdrawal's part is the largest sale**; an excess or a rebalance stays at fair value.
8. **Fixtures caused, no premise moved**: CB 19's dial from the constant; CB 21 seed 8; AutoBuildCheck 3's pass; SaveFileCheck's shelf.
9. **`Game.hasMonthRun()`** for "not counted until a month has run" (A22 saved the word the old proxy read).

## 7. For the next batch
- **P2's budget gate reads the four lines** (it kept `revenue()`/`runningSpend()`, star P2-3): the repairs are running spend, but
  the reserve's crude is an asset bought (as land, which it leaves out), the arrears paid down a past month's bill, and
  `monthRevenue()` counts crude sold (as land sales, left out). Whether to leave those out too: P2's rule's call; AutoBuilder untouched.
- **NationalAccounts' transit pair** is neither saved in the government block nor scaled in `redenominate()`; not touched.
  **todo line 1933 (A17)** is stale. **jerus-1007a** loses 535.74 to "Not accounted for" its first month after a load, as before.
- **Docs pass:** harnesses.md (§3), dials.md (`BORROWING_COST_MOST_MONTHS`, RULE_PREMIUM), maps, the manual's Government, Sectors, Fund.

## 8. For Jerus to check on the PC
1. Government > Spending: Repairs, Arrears paid down, Crude for the reserve are lines; no "Outside the budget's total"; EARNED as was.
2. A landlord with a new mortgage: Income shows "Borrowing costs, over each debt's life", the sheet "...still to expense". Forty
   years for a mortgage's premium: right for you?
3. Over the default withdrawal the fund's shares sell at the step, at the desk's bid; the fund summary stays neutral.
4. Load a save, open Sectors > a business: the investors' line is there before you press the arrow.

## 9. Outside my files
- `AutoBuildCheck.java` (P2's): 3's borrowing caused on a copy (`passReader`, `worstLimit`); round 2: 4's room, `withRoom()`'s arrears.
- `BuildCard.java`, `SectorFlow.java`, `BuildCardCheck.java`: the counted rule reads `Game.hasMonthRun()` (A22's consequence).
- `BusinessDebtManager.java`: `getMortgageFeesThisMonth(sector)`. AutoBuilder and BuildAdvice untouched.
