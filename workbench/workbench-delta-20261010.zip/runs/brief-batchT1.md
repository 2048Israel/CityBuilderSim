# Brief: T1, why Jerus's city is construction-bound. Read-only. 2026-10-10

You are an investigator, on Opus with a fresh context. **You change no source.** You trace, measure and write a note. Mark judgement calls ★ with reasons.

## Jerus's decision (2026-10-10, `claude/decisions-2026-10-10.md` A3)
"His city is construction-bound, about 500 points a month against 3.1M owed (O10b)" -> **"A read-only trace first."** The fix, if any, is his call after your note.

## What is known (`/home/claude/runs/fixO10b-notes.md` §5c and §8.1)
On a copy of `jerus-1008` (month 8473, format 34, now loaded by 0.7.99), with the investors free, a jacket ordered at month 8474 was still on site at month 8594: the city's builders hand its sites about 400 to 570 points a month, 26 sites owe 3.1M, the jacket gets 1 to 1.5 of its 3,600 a month ("2,496 month(s)"). The sector's one order in flight holds every other order of its sector.

## Find out
1. **Where a month's construction points come from**, in the model's own terms: the Construction sector and its builders, crews by size^0.7 (0.7.17), staffing, the builders' prices, their investment test, `BuildingManager`'s handing of points to sites, the player's queue (`ConstructionControl`: order, rushes, overtime). Navigate by `docs/map/`, `docs/month-order.md`, `tools.Where`; don't read `Game.java` whole.
2. **Why it doesn't grow toward the work owed** in his city: which gate holds the builders back (demand they see, staff, money, ground, price), month by month over 120 months. Count how often each fires. Is it the same in the playtest city at a similar size (the default playtest, or `city2400`)?
3. **Who the 3.1M belongs to:** the 26 sites by kind, owner (city, sector, investors), points owed and points received a month; which order the points go in, and why the jacket gets so few.
4. **The options**, none applied: e.g. the builders' growth rule, the share a site gets, rushing, more builders by policy, the investors not ordering past what the builders can hand. For each, what it would change and what it would cost, with the model's numbers. ★ your recommendation.

## Your tree and the rules
- **Worktree (read and build only):** `/home/claude/git/wt-T1`, branch `batch/T1`, from `origin/main` 4074708 (0.7.99). It is never merged. You make **no commits** and edit nothing in it.
- **Scratch:** `/home/claude/scratch-t1` (your first command creates it). Probes are Java classes you write in your scratch and compile against your built classes. Build the tree into your scratch with copies of `/home/claude/scratch-gate/build.sh` (change every `/home/claude/scratch-gate` to your scratch, every `/home/claude/git/CityBuilderSim` to your worktree; it has no `rm`).
- **Cities:** copy `/home/claude/cities/jerus-1008` (and any other) into your scratch and load only the copy: a game run autosaves into any city it loads. Save slots 1-9 are Jerus's; never write them.
- Follow the standing rules of `/home/claude/runs/brief-shared-git.md`: no `rm`; never touch `/dev` in any form (no `2>/dev/null`, `> /dev/null`, `/dev/stdout`, `<(...)`, also inside scripts and heredocs); no network; at most one JVM at a time, `-Djava.io.tmpdir` in your scratch; scratch under about 2 GB. Another batch's gate may share the two cores: be patient with long runs.
- **Write only to:** your scratch, and your note `/home/claude/runs/fixT1-notes.md`.
- No invented numbers: every figure from a run, the code or a named constant.

## Note: `/home/claude/runs/fixT1-notes.md`, at most 130 lines
0. Progress, a line per step, as you go (the workspace can restart).
1. The answer in five lines, plain words.
2. The month's points: where they come from, with the code's names and lines.
3. His city over 120 months: the builders, their gates and how often each fired; the 26 sites.
4. Against a city that is not construction-bound.
5. The options, each with what it changes and costs. ★ calls.
6. For Jerus, in plain words: the choice to make, at most 4 lines.

Reply with a short summary: the answer, the options and your recommendation.
