# Brief: Z2, zoning: the screens. 0.7.109. 2026-10-10

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## What Z1 built (0.7.107; read `/home/claude/runs/fixZ1-notes.md` whole, 63 lines)
The model of Samuel's zoning (2026-10-08, the project's `claude/spec-zoning.md`): one zone per sector, a share of dry ground (default) or km², at a price share of the going business price; only its sector builds there; held ground leaves others' free ground; zoned ground priced, bought back and assessed at the zone's price; the zone's taxes are the sector's own offsets (one dial, two doors); the forest law's protected and kept-from-building shares (0/0); building on open forest clears it. Its API for you is in its notes §7 (`Game.getZoning/setZone/removeZone/setForestLaw/setZoneTax/zoneTaxRate`; `LandManager.heldBy/usedBy/zoneSizeOf/heldByZones/freeFor/freeForAnyone/getForest*SqFt/getBuildableSqFt/cuttableForest/getProtectedWood`; `PolicyPreview.zoneAt/forestAt/zoningTaxChange`; the investors' "is zoned for others").

## The screens, as the study drew them (its §4; the mockups artifact "Zoning Study" you cannot open, so this is the spec)
**Zoning is a fifth Policy area,** beside Taxes, Wages, Money and Promises, in Policy's own style (the area chips, the dial cards and the tray as built in 0.7.36).

**Board 1: Policy › Zoning, the hub.**
- Head: the money-blue swatch, Policy's five area chips (Zoning lit), the breadcrumb.
- Four figures: ZONED (km², its share of dry ground, the number of zones); HELD FOR THEM (free ground no other business may take); PRICE GIVEN UP (on ground sold in zones, and the tax relief a month); FOREST KEPT ("none" with the law at 0/0, the default).
- THE CITY'S GROUND: one bar of the dry ground: built, each zone (used solid, held hatched), bare ground free for anyone, and the forest (by its three kinds once a law is set); under it a closer bar of the zones and the bare ground.
- THE ZONES: a row each: the sector's icon and name, size and share, used against held, its price, its three rates as chips (an offset marked), the month's tax relief, a door to its page.
- THE FOREST LAW: the bar and what it means, with a door.
- A "Zone ground for an industry" button.

**Board 2: Policy › Zoning › <a sector>.** Dial cards, as Policy's:
- HOW MUCH GROUND (km² or a share; staged before -> after): what it can carry; the bare ground left free for anyone; the zone's ground at the going price.
- ITS PRICE: 0-100% of the going price a m², with what it gives up (a plot's ground at the zone's price against the going price; property tax on the zone's ground).
- ITS TAXES: profit, sales and property as city rate + offset -> rate, each with its last month in money; and the line "The same dials as Policy › Taxes: a move here moves it for every <sector> building".
- The tray: "Apply N" and "Leave it as it is".

**Board 3: Policy › Zoning › The forest law.** The bar with two thumbs (protected; kept from building), staged; WHAT IT WOULD DO in the long run (forest standing, the most the crews can cut, forest a building may take) from the model's own reads (`cuttableForest()`, `getProtectedWood()`; Forestry's crews do not exist until I9, so say what the law holds now, not crews).

**Elsewhere:** the land office's THE CITY line adds "N km² zoned"; Build › LAND FREE reads "free for anyone X · zoned for <sector> Y ›"; the investors' word "no land: X is zoned for others" when that is why (Z1 built the words; show them where the investors' word shows); NEEDS YOU's GROUND row names what zones hold when homes are short of ground. The map's tint of a zone's districts is later (zones are amounts, not places).

## Also
- **A decision kind for zoning** in `DecisionLog` with its own icon and colour (`Icons`, `TimeChart`'s flags), where Z1 logged under TAX (Z1 ★8).
- **Words:** every string fits at 1,389 x 868 (a words probe by the screens' width helpers, as earlier UI batches did; `runs/` has their probes, e.g. grep "words probe" in a `fixO11-notes.md`).
- **Harnesses:** the screens' figures read the model's getters, never recomputed in the screen (CLAUDE.md); extend `PolicyPreviewCheck` or add a view-model check if you build a pure view class (as `OilView`/`OilViewCheck`), and BuildMenuCheck if you add to the build menu. The playtest stays byte-identical (the test player sets no zone).

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| Z2 | 0.7.109 | named in the launch prompt | `/home/claude/scratch-z2` | byte-identical to `/home/claude/scratch-ui1/orch-gate/pt07106/` |

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** The full suite green (92 harnesses since 0.7.107); BuildMenuCheck 101. Notes §8: what Jerus should look at on the PC (at most 4 items).

Reply with: a short summary; the screens as built; the words probe; the gate and your final commit; your ★ calls.
