# Brief: P7, an old save refused cleanly. 0.7.108. 2026-10-10

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## Why
Jerus, 2026-10-10: "old saves do not matter, only once we publish to old saves matter". The rule written for it (CLAUDE.md's standing rules, README's save paragraph, and the agents' shared rules): write no conversion code for an older save; if a change would make one load *wrongly*, bump `SAVE_FORMAT` so it is refused cleanly. The docs pass for 0.7.100-0.7.106 found the mechanism missing (`/home/claude/runs/docs-07106.md` §3, flag 1): the loader refuses only a format newer than `SAVE_FORMAT` (`isFromNewerBuild()`) or older than `FIRST_SECTOR_FORMAT` (21), so a bump alone refuses no older save; it added that fact beside the rule.

## Do
1. **A minimum loadable format:** a constant in `GameVersion` (★ its name; e.g. `OLDEST_LOADABLE_FORMAT`), with one sentence above it saying the rule: a batch that bumps `SAVE_FORMAT` because an older save would load wrongly raises it to the new format in the same batch. Its value today is **21** (`FIRST_SECTOR_FORMAT`'s): nothing that loads today is refused by this batch. ★ whether `FIRST_SECTOR_FORMAT` becomes it or reads it.
2. **The load refuses below it, cleanly,** the same way it refuses a save from a newer build: the save file untouched, the player told in plain words on the load screen and in the log which build the save needs (★ the words: e.g. "This city was saved by build X, which this build can no longer read."), and the slot list marking such a slot. Find the newer-build path (`isFromNewerBuild()`, the load screen) and mirror it.
3. **Harness:** `SaveFileCheck` (or `ReadPathCheck`) asserts a save at the minimum loads; one below it (a fixture that writes the format number down) is refused with the message and its file byte-identical after; one from a newer build is still refused as before.
4. **The words of the rule:** `CLAUDE.md`'s standing rule and "a saved field" line, and `README.md`'s save paragraph, now say how the refusal works: bump `SAVE_FORMAT` *and* raise the minimum to it. Remove the docs pass's caveat that a bump refuses nothing (it is no longer true). `GameVersion` 0.7.108 entry in the house shape.

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| P7 | 0.7.108 | named in the launch prompt | `/home/claude/scratch-p7` | byte-identical to `/home/claude/scratch-ui1/orch-gate/pt07106/` |

Beside you, Z2 (zoning's screens) works in `ui/PolicyScreen`, the land office, Build and NEEDS YOU. Your files are `GameVersion`, the load path in `Game`/`SaveManager` (whichever holds it), the load screen's refusal, the harness, and the rule's words in `CLAUDE.md` and `README.md`. Leave the rest alone.

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** The full suite green (92 harnesses); BuildMenuCheck 101.

Reply with: a short summary; the constant and the refusal's words; the harness; the gate and your final commit; your ★ calls.
