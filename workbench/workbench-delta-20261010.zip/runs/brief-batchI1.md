# Brief: I1, fields by type. 0.7.110. 2026-10-10

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## What this is
The first batch of the materials chains (I1 to I14; I14 is the release 0.8.0), from the build spec `/home/claude/runs/spec-materials.md` (Jerus decided its questions on 2026-10-08; it is on disk, read §1, §2.4, §2.5, §3, §4 and §5's I1 row). **I1 is pure plumbing and byte-identical:** each deposit field gets a type, the ground counts sites and remaining tonnes by type, and the templates can name the type of site they need. No sector, good or building changes behaviour yet (id 14, the Iron Mine, stands on ANY until I5).

Read §2.4 whole. In short: `Deposit.FieldType` (HEMATITE, MAGNETITE, THERMAL, COKING, SULPHIDE, OXIDE, LIMESTONE, HARD_ROCK, NONE); `Deposit.type()` drawn as `grade()` is, against `TYPE_SHARES`, pure, nothing stored, no tonne moved; `Resource.typesOf()` and `goodOf(type)`; the template's `site` = {resource, type or ANY, sites, dig} with `Game.siteOf()` and `committedOn(r, type)` counting sites; `LandManager.fits(r, type, standing, extra)` (first fit decreasing, in acquisition order, typed before ANY), pure; `LandManager`'s `extractedByType`, `getSites/getRemaining/extract(r, type)` with W = unowned + Σ remaining + Σ E exact; `CityLand.sitesByType`; `DataSave.depletionByType`.

## What changed since the spec was written (read first)
- **0.7.99 (W1), fewer and bigger deposits** (`/home/claude/runs/fixW1-notes.md` §7 and the write-up `/home/claude/runs/records/fewer-and-bigger-deposits.md`): fields are drawn a pool of cells at a time, ten old draws' sites to a field, in clusters, numbered from `World.FIELD_INDEX_FROM`; an older save's ground keeps the old world's fields (`legacyFieldsInCell()`, `CityLand.oldWorldHoldings()`). So:
  - the spec's "types sum to the cell's total" check runs **per pool** (`World.poolFields()`), and on the old world's fields per cell;
  - `type()` draws from (cell, index, kind) as `grade()` does, on both worlds' fields;
  - re-measure the spec's "near a founding site" figures on today's world (W1 measured, default world within 50 km: iron 357 -> 36 fields, oil 31 -> 19, stone 15 -> 0, copper 2 -> 0, coal 0);
  - a city's ore is one type more often (a 25-site field is all hematite or all magnetite): measure how often, and say what it means for `fits()` and the chains (they lean on imports more).
  - I3's iron in-ground reference was "the founding field's US$180M", which is gone: leave I3's number to I3, but say in §7 what reference I3 should use.
- **0.7.107 (Z1) zoning** is in; I9 (Forestry) reads its forest law. Nothing for I1 beyond not breaking `LandManager`'s zoning reads.
- **Old saves need not load until the game is published** (the shared rules; since 0.7.108 `GameVersion.OLDEST_LOADABLE_FORMAT`). The spec's `typeRuns()` (splitting an older save's depletion by type, O3's `oilRuns()` made general) is conversion code. ★ Decide by the rule: if an older save without `depletionByType` would load *wrongly*, either the split is a reading the model already makes (not conversion), or bump `SAVE_FORMAT` and raise `OLDEST_LOADABLE_FORMAT` to it so older saves are refused cleanly, and probe on a city founded on your own build. Say plainly in your reply which you did and that it would stop Jerus's current saves loading, if so.

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| I1 | 0.7.110 | named in the launch prompt | `/home/claude/scratch-i1` | **byte-identical** to `/home/claude/scratch-ui1/orch-gate/pt07106/` |

Harnesses: WorldCheck (a section for types: shares within the spec's tolerance, every pool's types summing to its total exactly, pure draws), LandCheck (sites and remaining by type; `fits`; W exact), `BuildingDataCheck` if the template gains `site` (json against the twin), `SaveFileCheck`/`ReadPathCheck` for `depletionByType`. Every figure from the spec, its sources or a named constant.

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** The full suite green (92 harnesses); BuildMenuCheck 101.

Reply with: a short summary; the type shares measured; how often a city's ore is one type; the near-founding figures; the old-save decision; the gate and your final commit; your ★ calls.
