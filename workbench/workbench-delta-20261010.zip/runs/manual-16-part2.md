# Manual 16 part 2: 0.7.93 -> 0.7.106 and the edition, 2026-10-10, manual writer 16b

Backup `runs/manual/index.before-0793.html` (870,926 B = index.html at start, part 1's end). Edited `runs/manual/index.html` (now 951,956 B;
86 hunks over part 1, 116 lines -> 141) by byte-safe unique-span edits: `scratch-manual-16b/py/ed.py` (part 1's: each old span once,
ASCII, LF, `&mp;` once), scripts e01-e17 in order, `py/check.py` after each (tags balance, every `href="#..."` resolves, no new entity).
Progress: DONE - notes, edits, publish file, tree copies, commit.

## Sections changed (false or missing -> now)
- Masthead "Build 0.7.106 · Save format 36 · 10 October 2026"; standfirst (oil on land and at sea, the run that pays, few big clustered
  fields, streets and ships on the map, works only as far as they pay back, a pump the city may tax); vitals 304 / ~306,000 / 101 / 17 /
  91 / 4,005; footer 0.7.106/36/10 Oct, 304 files, 306,164 lines, 101 templates, 91 harnesses, 711 s at 0.7.106 (all 91 green).
- 01 Month: step 1 (payback, own ground), 2 (Arrears paid down a budget line), 5 (roads' own repairs), 11 (duty), 13 (two pools, the
  slate ships, the month's flow kept, the run struck), 15 (deferBorrowingCosts, the sheet at the close, monthRun). What moved: rewritten
  lead - FIVE statements since 0.7.69 (pass 0.7.73; settleReserve, setCityCrude 0.7.85; deferBorrowingCosts, monthRun 0.7.102), "bar those
  seven lines and two calls" (commute w/o markets 0.7.83, portsBill 0.7.86), inside-statement changes 0.7.78-0.7.92 and 0.7.93-0.7.106.
  Standing rule: + nine saved items 0.7.93-0.7.105.
- 04: care the beds less the priced out (0.7.106); HealthCheck's depot (0.7.100), passes since 0.7.102 (-1.8 at 0.7.103). 06: Refining's
  seventh throttle. 07: lubricants' 1% world share. 09: demolition a quarter (row, measured row, note "A demolition paid, until 0.7.106").
- 08: Retail row (A18 test less wages), Oil row (two pools), Refining row (margin, run); investors' word saved (A22, hasMonthRun); flow
  para lubricants cap; spread planner at the margin (R1), the spare from the run, one order with crude units on site aside (R3); oil at
  sea: new para "two pools" (O10b); new h3 "The slate ships, and the run pays its way" (0.7.98, 0.7.103, 0.7.105 run, words, RefineryCheck
  16 margins, Jerus 1008 24 months); retired plant sold at a quarter.
- 12: Beside-them list + new para "The fuel duty"; EARNED steps 11 -> 15; new para "every monthly flow inside the budget" (A15, journal's
  outside list, traces from m601); fund's sale at the desk's bid (A21) and neutral summary (B). 14: borrowing costs expensed (A16).
- 15: anchor para + S1/H1 restated (P1), ensemble 24/24/23/22/22. 17: Insane row and para (bond on the plots, US$3,811.4k), founding asks
  no iron, founded with its lake.
- 18: kicker; founding site's tests (three since 0.7.99); "fewer and bigger" in the seven-resources para (pools, clusters, dials, old
  saves' holdings); table caption; centre pointer; NEW h3 "A city founded with its lake"; whole fields (old world's founding field past
  tense, 12 km lake iron, world 35, playtest finds none, ironPayback on Build); iron para (two pools); on-screen para (legend 33, hover
  words, 47.7 MB, mirrors); ramps reach the screen (0.7.98); plan speed (RD7); NEW h3 "The map at the water" (O13); offers 19 -> 20.
- 19 Infrastructure repairs. 20: life formula repairs; gravel para past tense + roads' own repairs + test player's roads by need
  (617,942 at 0.7.103); paving in the playtest (87 in 14 at 0.7.99, 10 in 2 at 0.7.106); founding lake in fresh water. 21: duty and
  the fare; routes; MR's room kept free (R2).
- 22: NEW para "every building over its life" (0.7.101); auto-build: first of a kind, budget -> payback wording, own ground and
  over-full, NEW paras "walks the ranking" (0.7.101, seeds) and "what the treasury runs must pay back" (0.7.104, worked example);
  statements: sheet at the close + borrowing-cost lines; NEW h3 "The refinery as a picture, and the oil on one page" (O11, O12).
- 23: format 36; 35 and 36 described; 0.7.70-0.7.77 para's 0.7.69 sentence past; NEW para 0.7.93-0.7.106 (no-bump items, two load
  fixes, old saves, a 0.7.69 save opens, the git-era save rule with the docs pass's flag 1).
- 24: kicker (91 harnesses, AllChecks 92, 711 s at 0.7.106, all green; twenty-five since 0.7.23; HealthCheck passes; timing labels;
  passages struck at 0.7.106; trace moves 0.7.78-0.7.106; test player's rules; city sizes; ensemble); 30 rows extended; NEW rows
  RefineryViewCheck, OilViewCheck; tree para 304 files, 306,164 lines, Game 16,081 lines/41 banners, 2,600 dials, 8,897 assertions in
  92 harness files, Stale 0 firm (114 soft). Named 83 + "eight more" = 91 Check files (checked against the tree).
- 25: kicker (68 at 0.7.69 -> 82: 2 answered outright, 12 moved (3 renamed), 16 opened since). Removed: A new city's lake, Insane owes
  for the figure. Renamed+rewritten: A demolition's edges, The fund's two marks, The playtest's city never finds iron, A road's life
  and the lines'. Rewritten/extended: statements found, auto-build's calls, dear-care, refinery, outgrow ground, price model, grocers,
  one car, reloaded month, newer save, filling station, small things (stack answered), no harness looks at, map's loose ends. New:
  Care on a deficit, The run swings, Two pools one field, Roads by need and a young town. Answered note rewritten (2 outright, parts,
  ten raised-and-answered 0.7.93-0.7.106). Two stale "this edition" references re-dated.

## Figures checked (code wins), and how
GameVersion 0.7.93-0.7.106 and SAVE_FORMAT 36 notes 35/36; Refining (RUN_PACE = MAX_RETIREMENT_FRACTION, runRule stops, runWords,
LUBRICANTS_WORLD_SHARE .01, CARGO_KEPT_FREE = MR, R3 plan()); Oil.groundLimit/extractOilAtSea; TaxPolicy DEFAULT/MAX_FUEL_DUTY (.001 =
$1/L), PolicyScreen FUEL_DUTY_STEP; TreasuryFund.RULE_PREMIUM = SPREAD/2 (1%); Game.getEarnedToBudget (15 steps); ConstructionControl
SALVAGE_SHARE .25; World FIELD_SCALE 10, CLUSTER_FIELDS 10, POOL_CLUSTERS 10, FIELD_INDEX_FROM 65,536, searchSites/legacyFieldsInCell;
LandManager FOUNDING_FRESH_UNITS/KM2; CityLand FRESH_REACH; buildings.json roads' repairs .03/.02/.0125; AutoBuilder header, debt(),
PAID_MONTHS, paybackWords; BuildScreen ironPaybackWords; LandMap QUAY/JACKET/RING/PIPE words; CityShore QUAY_PLOTS; Motoring
journeyFuel(Game) since 0.7.83; Good count 41; harness sections from the sources (OilCheck 17, RefineryCheck 19, WellCheck 13, MapCheck
9, BuildAdviceCheck 14); docs/map README, dials.md, harnesses.md headers for the tree counts; month-order.md for the two 0.7.102
statements (part 1's MonthOrder diff 0.7.92 -> main). Probe (scratch/probe LakeProbe, my classes, under flock): default world's rings
21 blocks, fresh 0.0189 km2 = 2,298 units; with the lake 54 blocks, 0.4941 km2 = 60,083; Insane's bond US$3,811.409k. Measurements
(playtests, seeds, Jerus's cities, ensembles) are the fix notes', dated in the text, not re-run.

## Record / code disagreements, and calls
1. GameVersion 0.7.106, CityLand.found()'s javadoc and fixP5 say a new city's rings held "0.011 km2 ... 1,324 units ... 98% idle"
   before the lake. The probe gives 0.0189 km2, 2,298 units (96% idle) at 0.7.67-0.7.105; 0.011 is the pre-0.7.67 centre. Manual
   follows the code (and its own 0.7.67 text). For the docs pass.
2. Lubricants: 0.7.80's "6.0% of the crude's litres" (one Small Lube Plant) and GameVersion 0.7.103's "9.6% of its crude" are different
   measurements; both kept, dated. RD7's slowest district written "17 to 26 ms" (GameVersion); the notes' final ten 17.8-23.1.
3. The playtest at 0.7.106 ends at month 4,003 (P5's figure); vitals and footer keep "4,005 months", the run's length.
4. Placement calls: two pools and the run in 08; screens (refinery picture, oil page) in 22; the lake and the map at the water in 18;
   fuel duty and the budget's lines in 12; borrowing costs in 14 and 22; payback in 22; saves in 23. A link in a numbered step made
   ManualToMarkdown warn (#advisor 13 vs 8): replaced by "(see the private sector, section 8)", as step 1's "(see the screen, section 22)".

## Publish file and tree copies
- `tools/publish.py` first rebuilt the old `manual-publish.html` from `index.before-0778.html` byte for byte (old file kept as
  scratch-manual-16b/manual-publish.before-0793.html); the new one (951,402 B) differs from the old in exactly the 102 hunks index.html
  differs from 0.7.77's source (both parts' edits), and is index.html's body.
- My classes (wt-manual16 at 8237323, non-ui, javac under flock, silent): the old publish file regenerated the tree's docs/manual.html
  and .md byte for byte; then `--wrap` -> docs/manual.html (2,178 lines) and .md (25 sections, 34 tables, 34 formulas, 27 notes, 15
  steps, 2,048 lines), no warning. Committed 583d554 on batch/manual16 (those two files only; LF). Not pushed, not published.

## Not settled
- Nothing seen in the game's window; screens described from code and the batches' Java2D mirrors.
- For Jerus (in 25): HealthCheck's shelf half; S1's slack city; care on a deficit; lifeTrend for a young city; two debts on two
  screens; the run's damping; a field keeps no oil / the old save's floor; roads by need's young town; the EPA citation (from memory).
- Rules kept: no rm; nothing on /dev; no <(...); every javac/java under flock; only index.html, manual-publish.html, the worktree's two
  files, my scratch and this record written. No slips.
