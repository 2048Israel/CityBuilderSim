# fixP2b notes: 0.7.104 - a smarter budget for automatic building. Implementer (Opus), 2026-10-10
Worktree `/home/claude/git/wt-P2b` (batch/P2b from b327419, clean at start). Scratch `/home/claude/scratch-p2b`: scripts from
scratch-p2 (build, suite, pt [ref pt07102], h, abseeds, bmc), abvar.sh + mkprobe.py (probe copy: log, care toggle), reach.sh
(month a city first holds 1k/10k/100k/1M), gate.sh, words-src (P2bWords). Changed: fixP2b-changed.txt.

## 0. Steps
- s1 read brief, rules, CLAUDE.md, fixP2, fixP3 s7, AutoBuilder, BuildAdvice's life. s2 base seeds on b327419 (abase/).
- s3 payback written (J2 reading first); probe toggles. s4-s7 readings measured on all seeds (var/j2, var/j3, var/j3log).
- s8 care diagnostic (var/j3narrow), seed 0's budget lines (var/j3book). s9 code to J3; AutoBuildCheck green; 93b494a.
- s10 seeds on 93b494a (ab1/): all eight identical to the J3 runs (t-month cmp). GameVersion, CLAUDE.md, comments: 2ac226e.
- s11 gate1 on 2ac226e: builds silent, suite 91/91, BMC 101, Stale 0 firm, pt 8/8 identical, eol 0; words 1 over (the hold
  line at the widest figures, 1,502 of 1,349 px) -> reworded (1,308 px), 80d27dd. s12 gate2 on 80d27dd green (5). s13 205b7d8.

## 1. What I built (AutoBuilder; Jerus's decision of 2026-10-10 on P2's budget)
- **Essential services skip the budget** (`essential(m)`: POWER, WATER, CARE - general, childcare, senior - DEATH, PLOTS): held by
  the debt limit, the money and the ground alone; a deficit to run them is the city's.
- **Everything else the treasury runs pays back** (`paysBackFirst(m, t)` = `staffedBuilding(t) && !essential(m)`: schools,
  police, prisons, transit lines). `payback(game, m, s, n)` -> `Payback(runs, covered, paid, costs)`, a month on average over
  LIFE_MONTHS at today's prices; pays back where `covered x (paid - costs) >= runs`:
  - `runs` = n x `running()` (BuildAdvice.running: posts, upkeep, repairs, power, water, less a line's fares), read once a month.
  - `covered` = `coveredOverLife()`: each of LIFE_YEARS years at its middle month from the opening, demand x lifeTrend() with the
    margin (servedOverLife()'s footing): share of the measure's need taken off the shortfall (`need()`: supplyDemand's demand,
    roads the effective load and its over-STRAINED line) x people x trend; weighted by lifeFactor()'s discounting.
  - `paid` = the city's recurring revenue a resident (total revenue less land sales, builders' sales + profit tax, reserve crude
    sold), lesser of month and the last PAID_MONTHS passes' average (saved, State.paid; State.recent no longer written or read).
  - `costs` = running spend a resident (expenses less capital, land, arrears paid, reserve crude bought) + staffed works on site
    but the measure's own - the measure's own standing running().
  - The count cut to what pays back (Cut.PAYBACK, binary search); none of a card -> the next in the ranking (the budget's walk);
    held only when none is left, the inbox line with its figure (`paybackWords()`); Step and the walk carry the weighed Payback.
- Words: AUTO_INFO, the hold line, cutWords ("n pay back"), the walk's why ("which would not pay back"). GameVersion 0.7.104,
  CLAUDE.md row. No save format change; no new harness or building.

## 2. Departures, with reasons
1. **"Extra tax revenue" read as all the city takes in a resident, past all it spends a resident** (star P2b-3). The tax lines
   against the other services' running (J2) let a village of ~310 order its school from the founding cash (seeds 0, 1, 6, 7 at m19-m20)
   and stand under 1,000 people for ~500 months (1k at m545-m564 against the base's m91-m131). A resident's pensions, EI, debt
   and care are in what each costs; their contributions, premiums and fees in what each pays.
2. **A plateau ships** (rule 1 as written): see 4. Care, essential now, runs four villages into deficit for ~400 months.

## 3. Premises changed (before -> after) and new assertions (AutoBuildCheck)
- 2: "fixture: a building the budget does not run" -> "a building the payback does not hold (an essential service, or one the
  treasury does not run)".
- 3: "a pass's staffed orders leave the budget's room at nothing or more" -> "every order of a building the payback holds paid
  back at the count placed, as the pass weighed it" (runs re-read after the pass); new fixture "it ordered a building the payback
  holds": a second copy of the decades' end given room (withRoom(), its year of `paid` cleared) and WEALTHY_CASH - the decades
  order none (3,401 people at m600, every one held for the payback), and each is a first of its kind (cash only); 5 orders, 0 not.
  Holds: Cut.BUDGET's truth (running > budgetRoom()) -> Cut.PAYBACK's (the weighed payback fails, and one of the card read again
  after the pass fails); the walk's `paysForOne()`: the budget clause -> the payback's.
- 4: "the revenue it reads the budget against" (cents) -> "what a resident pays the city, as the payback reads it" (cents).
- 5: "a staffed service the budget cannot run is held (general care), the inbox naming the Policy tab" -> **an essential service
  ordered on a deficit**: the town spending past its revenue (-$18.8M a month), within the limit, orders a Community Health
  Centre, no payback weighed. "A first school the budget cannot run is held for the budget" -> **held for the payback**: $383,052
  a month to run, 6,722 residents covered, $924.20 a month each against the $3,821 each already costs it; figures read as the
  pass left the town; the inbox says "would not pay back" with its figure. "With the budget to run one ... ordered" -> **where
  one pays back** (withRoom()): 18,784% of its running, ordered at 0% served. The cash fixture unchanged.

## 4. Trace movement and the measurements
- **Default playtest**: pt07104 = pt07102, all eight traces byte-identical (gates 1 and 2), findings "Nothing". Its player
  builds its own works; AutoBuilder is read only with -Dplaytest.autobuild. (The brief's pt0799 predates P3, whose books moved
  every trace; the launch prompt's reference, pt07102, is the one compared.) No ensemble: nothing to re-baseline.
- **Auto-built seeds 0-7** (people at m4005; P2's table, its columns; reach.sh's month of 10k people under it):
  | seeds | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
  |---|---|---|---|---|---|---|---|---|
  | 0.7.102 (P2's budget, P3's lines) | 2,008,108* | 1,571,815 | 1,719,922 | 2,035,846 | 1,747,415 | 2,189,868 | 1,976,758 | 1,903,621 |
  | ...10k people at | m418 | m425 | m416 | m396 | m387 | m445 | m377 | m409 |
  | J2: tax lines vs other services | 1,678,575 | 1,619,214 | 1,898,136 | 1,848,159 | 1,627,397 | 1,564,665 | 1,194,719 | 1,578,559 |
  | ...10k at (1k at) | m828 (562) | m1080 (564) | m479 | m370 | m428 | m792 | m1418 (563) | m1145 (545) |
  | **0.7.104 final (93b494a, J3)** | 1,524,255 | 1,924,631 | 2,005,841 | 2,110,396 | 1,953,971 | 1,967,292 | 2,006,844 | 1,747,759 |
  | ...10k people at | m814 | m795 | m396 | m398 | m434 | m785 | m345 | m824 |
  | diagnostic: care weighed too | 2,097,779 | 2,270,028 | - | - | - | 2,324,461 | - | 1,678,877** |
  | ...10k people at | m676 | m598 | - | - | - | m424 | - | m673 |
  *m4003, the run's last checkpoint. **m3944.
- **The plateau** (seeds 0, 1, 5, 7: 2,000-3,600 people from ~m150 to ~m700): care, essential, is built ahead of a village's
  revenue. Seed 0 at m200 (var/j3book): health 1,947k a month against 2,118k of tax; pensions + EI 1,506k against 383k of
  contributions and premiums; a deficit of ~1.24M a month, the treasury at or under nothing m200-m600, homes at 539 then 728
  for 300 months (the path from the deficit to the homes not traced: the test player built 58 houses all run against the
  base's 73, refused for money 3 houses and 10 foundries). No school or station pays back while each resident costs more than
  it pays (seed 0, m200: 1.11k paid, 1.67k cost), so none is built until ~m700.
  What would keep them moving: care weighed for its payback as well (the diagnostic row), or a rule that holds an essential
  service's count while the city spends past what it takes in. Neither built: rule 1 is Jerus's.
- **Worked example** (seed 0, m595, 3,364 people; var/j3log, the final code's arithmetic): one Elementary School runs
  $1,515.9k a month; it would cover 3,778 residents a month on average over its 20 years (its places of the elementary
  children, on the city's trend); each pays the city $4,086 a month and already costs it $3,643, so they bring $1,675k past
  their cost: 110% of its running - it pays back.

## 5. The gate (gate2.log, on 80d27dd; 205b7d8 after it is a comment only)
- Builds silent (model, ui). Suite (suite-g2.txt): 91 of 91 passed in 1,142 s - HealthCheck green this run (the known red's
  0.4 points), PlanCheck's 40 ms bound and MapCheck's 5 ms passed; gate1 likewise 91/91. BuildMenuCheck PASS 101/101.
  Stale 0 firm, 415 soft. pt07104g2: 8 traces identical to pt07102, findings "Nothing". No w/crlf but .bat.
- Words (P2bWords, words-g2.txt): 10 measured, 0 over - AUTO_INFO 14 lines of the 360 px popover; the hold line 1,258 px
  (the school town), 1,309 at the widest figures, of a tooltip line's 1,349. Seed 5 auto-built on the gate's classes:
  identical to ab1.
- **Final commit 205b7d8** (the payback comment's line on P3's budget lines corrected; rebuilt silent, AutoBuildCheck green, Stale 0
  firm, no CRLF). Branch batch/P2b: 93b494a, 2ac226e, 80d27dd, 205b7d8.

## 6. Star calls
- P2b-1 **The essential list**: Power, Water, General care (clinics, hospitals), Childcare (in the model it is the babies' and
  children's mortality, CHILDCARE_SWING), Senior care, Death care with its plots - the Utilities category and all of Healthcare.
  Left out (not essential): schools, police, prisons, transit lines. Roads are neither: no staff, never held by the budget.
- P2b-2 **"The residents and workers it lets the city add"** = the residents it covers: its share of its measure's need (a
  school's places of the children or teens, or of the students the city would get and hire; a station's officers of
  FULL_OFFICERS_PER_100K; a prison's cells of the caught's sentences; a line's trips of the trips on the road) times the city's
  people, year by year on lifeTrend(); the margin in the need; a first one covers everyone its need comes from.
- P2b-3 **Together with others**: what each covered resident pays the city less what each already costs it (2.1).
- P2b-4 **P3's lines**: repairs are running (in running() and the spend); arrears paid down (a past month's bill) and the
  reserve's crude bought and sold (an asset, as land) left out of both sides.
- P2b-5 **The year**: the lesser of the month's and the last 12 passes' (the budget's rule), saved as State.paid.
- P2b-6 **Capital not in the payback** ("its running cost"): the money rule and the debt limit hold it, as before.
- P2b-7 **Young cities**: lifeTrend() as P2-2 reads it - a city months old reads its founding growth as a life's (a town of
  31 at m4: 789 residents covered), so a first school can pay back in a founding month and is bought from the founding cash,
  as Jerus's A4 asked ("even tho it has the money"): seed 6 at m4 (31 people), seed 4 at m8 (85), both on time to 10k (m345,
  m434); what each then costs holds the next ones back. Under J2 the same early school was followed by more and stalled.

## 7. For the next batch
- Docs pass: maps, dials (PAID_MONTHS; REVENUE_MONTHS gone), harnesses.md (AutoBuildCheck 2-5), manual's Build page;
  BuildAdvice.suggestFor()'s javadoc still says "for one its budget cannot run one of" (left: P4 edits BuildAdvice).
- lifeTrend() from month 1 for a young city (P2b-7): Jerus's call whether a founding month's growth should read as a life's.

## 8. For Jerus to check on the PC
1. **Care on a deficit**: in four of eight test cities care, essential now, costs the village most of its tax and it stands at
   2-3.6k people for ~400 months (all end 1.5-2.1M). Keep care essential, or weigh childcare and senior care for payback too?
2. The payback counts what each resident pays the city and what each already costs it, not the tax lines alone (those built a
   school from a village's founding cash and stalled it for 500 months). Right?
3. Build > automatic building, a held school: the inbox line gives its running, the residents it would cover and the share.

## 9. Outside my files
- GameVersion (0.7.104 entry), CLAUDE.md (AutoBuilder's row). BuildScreen.AUTO_INFO is the auto-build card's words.
