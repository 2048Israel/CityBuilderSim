# fixP4 notes - 0.7.103 "oil and roads": A7, A8, A9, A11, B; round 2 the roads by need. Implementer (Opus), 2026-10-10
Worktree `/home/claude/git/wt-P4`, branch `batch/P4` from 9bb7be3. Brief `runs/brief-batchP4.md`. Changed: fixP4-changed.txt (38 against main).
Scratch `scratch-p4/` (no rm, no /dev): build/bmc/pt/suite/pc10/gate*/mktree* scripts; `probe/src` P4City, P4Words, P4Auto,
P4Strict; `var/` the decomposition (pt-V0, pt-V1, classes-r1m, lp-old); `scan2/`, cb16.out the fixture scans; gate3.log.

## 0. Steps (a line per step)
- Round 1 (to b7029d7): A8 38b3d0a; B 728fb32; A11 e75ed08/162fde1; A9 201ad86; A7 05f182f; GameVersion d6ccefa; fixtures
  A11 moved 7f16350/0fadc36; 589e312; HealthCheck 13's read b7029d7. Gate green (suite 91/91 on b7029d7); ensemble 07103 20/26.
  One slip in round 1: a grep given /dev/null as a file to read (nothing written).
- r1 the orchestrator's merge of main (0.7.102, P3) left six conflicts: resolved (1.), comments made true for both; 0706f02.
- r2 the road rule (LongPlaytest.roadsByNeed()); playtest 2m31s; a finding: the map's sum counted an Offshore Platform (4.).
- r3 decomposition: V0 (old player, repairs out) = pt07102 byte for byte; V1 (rule, repairs out); final (rule + repairs).
- r4 suite: AutoBuildCheck 4 (a save/reload drift: an empty stack, P4Auto), CentralBankCheck 21 (shape 0), OrderSearchCheck.
- r5 load path fix + SaveFileCheck 8b; 16 shapes scanned (cb16.out): P3's seed 8 holds; SaveFileCheck/OrderSearchCheck back to
  main's (scan2.out); ScaleCheck scanned (scan2-scale.out): 595; RoadCheck 9 asserts the rule; GameVersion; citations.
- r6 gate3 (13:26-13:47) + ensemble 07103b; PlanCheck alone x10; commit (5.).

## 1. What I built
- Round 1. **A7** fuel duty dial (TaxPolicy, THE FUEL DUTY; default 0, real, cap $1/L, a cent a step), the pump dearer by it
  (Retail), its own budget line (NationalAccounts.getFuelDuty(), Government "Fuel duty"), "+ e FuelDuty", PolicyPreview, Policy >
  Taxes > Fuel. **A8** a release the refiners do not take stays in the tanks (Markets). **A9** LUBRICANTS_WORLD_SHARE .01 [R37] on
  the export line and the planner (Refining). **A11** each road its own repairs (Gravel 3%, Paved 2%, Elevated Highway 1.25% of
  price a year; json "repairs"; EconomyManager.repaired(); BuildAdvice.running()). **B** "dry" and "no feed" (BuildCard).
- **The merge (0706f02).** NationalAccounts: P3's four lines, then fuelDuty (revenue after "Crude sold from the reserve", and
  redenominate()). GovernmentScreen: "Fuel duty" after P3's rows (names, amounts, icon). SectorScreen OIL_RESERVE_INFO: P3's text
  with "what they do not take stays in the tanks". OilCheck 16: settled on the budget's line (P3) and nothing as + city
  ReserveSales (A8). CentralBankCheck 19 the same dial in both (P3's comment). GameVersion: 0.7.102's entry, then 0.7.103's,
  VERSION "0.7.103". Made true for both: Game's THE STRATEGIC RESERVE banner and settleReserve(), Sectors.tradeByGood()'s note.
  EconomyManager auto-merged: the duty in the tax take (so in EARNED and the budget alike - no walk step needed).
- **The roads by need (LongPlaytest.addRoadThrottle(), roadsByNeed()).** The advice's card for the road (BuildAdvice.suggestFor(),
  no NEEDS YOU row, the cash and free ground as they stand, SLACK), every building but the three roads skipped (the lines are the
  player's own moves), the gravel paved among them: its road and its count; after it the next in its ranking, then the next (for
  money or ground short), at the best road's key among the lines as before. None when on site keeps the road ahead. The dead
  addPaving() removed. Every other rule of the player kept: nothing forced one (4.).
- **A stack emptied keeps its place across a save (Game's load path).** A stack whose last unit went (every gravel road paved,
  the last one retired) stays in the live list; the load made stacks only for buildings standing or on site, so a loaded city
  shared crews over a different list: AutoBuildCheck 4's decades city (it paves all its gravel since A11) parted at the low bits
  at m602, the cent at m606. The load adds an empty stack for every id the save's stack order (0.7.43) names: P4Auto, the
  empty stack dropped from the live copy, 0 differ for 12 months. BuildingManager.retire()'s note made true.
- **LongPlaytest's map sum leaves out the buildings at sea** (BuildingVisual.Type.sea(): in no district since 0.7.91). The road
  rule's run built the first Offshore Platform any run had (m3911): 95 months flagged; the map holds it by design.

## 2. Departures, with reasons
1. A11's figures are shares of a road's price (the model's road has no length). 2. A11's shares moved once (5/2.5 -> 3/2).
3. A7 petrol only (no driver burns diesel, O6-4); Jerus: "petrol only, as built". 4. The road rule leaves the transit lines out
of the advice's ranking (the advice ranks them for the road too): "keep the test player's other rules" - its lines stay its own.

## 3. Premises changed (before -> after), new assertions, fixtures
- **OilCheck 16** (A8 + P3): "...ships the rest at the export price" -> "...the rest stays in the reserve's tanks - none shipped";
  "the strike after settles what shipped as + city ReserveSales, TRADE, on the budget's line" (P3's) -> "...settles what the
  refiners took: the treasury takes in the reserve's sale to the bit, on the budget's line, and nothing as + city ReserveSales".
- **RoadCheck 9** (round 2; header "...which road and how many"): new: the paving move paves the advice's card's count (4 of 4);
  the paved town at ground free: the move orders the advice's road and count (2 Gravel Roads; the old rule 3); sixty Paved Roads:
  no road move (the old rule 3). All three FAIL on the old player (h-RoadCheck-oldplayer.txt).
- **SaveFileCheck 8b** new: an emptied Gravel Road stack, saved and loaded, stands in its place, empty; FAILs on 0706f02's Game.
- Round 1 (kept): RefineryCheck 14 fixture and 15 new; OilCheck 5 spurs' ground, 17 new; RoadCheck 1; BuildingDataCheck;
  BuildCardCheck 6; PolicyPreviewCheck 3; ReadPathCheck; HealthCheck 13 reads every month the fee turned somebody away (93 of 93
  merged; the last month turned 527 away now, none before the merge). Its hunger line passes: -1.8 (3.2 priced out, -5.0 shelf).
- **Fixtures, merged tree** (no premise moved): CentralBankCheck 21 back to P3's seed 8 (my shape parameter gone): 11 of 16 shapes
  hold every premise (0, 6, 11, 12, 13 fail), seed 8's twins 4,156-4,157, 2.213 < 2.531 < 2.930%, trust 0.806 against 0.948.
  SaveFileCheck's withdrawal back to 12 months and OrderSearchCheck back to month 400 (main's): both cause their conditions again
  (400: 23 judged on interest, 5 trimmed past the slices). ScaleCheck 6: 545 fails (the larger copy builds no homes, as at every
  month 510-575 and 615); holds at 500, 580-610 (583, 585, 587, 590, 593, 595, 597, 600, 605) and 620: **595** (4,303 people).

## 4. The playtest: pt07102 -> pt07103 (8 traces differ; findings none in both)
- **V0** (0.7.103's code with the roads' repairs out and 0706f02's player) = pt07102, all 8, byte for byte: the merge, A7 (dial
  0), A8, A9 and B move nothing. **V1** (the road rule, repairs out): every trace from m32 (t-borrow m122). **pt07103** (the rule
  and the repairs): from V1 at m37 (t-build: the roads' repairs), m38 (t-month, t-bank, t-house), m39 bonds, m42 labour, m51 pop.
- m32: the old rule ordered ten Gravel Roads ($56.5M of $71M, cash $71.1M -> $14.6M); the advice's card $2.7M (-> $68.4M).
- Population (pt07102 / V1 / pt07103): m611-617 12,188 / 7,749 / 4,294; m1068-73 29,840 / 28,784 / 17,276; m2019-24
  176,778 / 146,393 / 115,268; m3075-80 361,738 / 435,804 / 366,660; end 544,232 / 674,737 (m4000) / **617,942** (m4005).
- Roads standing at the end 683 gravel, 56 paved, 0 highways -> 230, 291, 161; orders 118 + 8 (and 3 "no money") -> 13 gravel,
  6 paved, 3 highways; buses 22 -> 32 orders. Road throughput at the checkpoints after m1,700: 74-78% -> 86-100% (end 77% -> 90%).
  End: GDP $3.1T -> $5.1T a month; power 79% -> 92%; "no money" refusals 7 -> 0; crime 2.48x -> 1.57x Canada's.
- Early the rule's town is smaller: roads at 70-73% at m265-617 in V1 (the old rule's oversized orders kept them at 100%): the
  card is sized for the advice's horizon and slack, this player looks every 6 to 120 months. Not changed: no other rule is
  forced by it (the town grows and ends larger); a slack for the absence would be Jerus's (8.1).
- jerus-1008 and the four other cities (P4City, 24 months): audit closed 24/24 each on the merged tree (5.).

## 5. The gate, and the final commit
- gate3 on the merged tree with round 2 (13:26-13:47): builds silent; words 25, 0 over; suite **90/91**, PlanCheck alone red
  (timing); BMC PASS 101/101; Stale 0 firm (418 soft); pt07103 exit 0, "Nothing" found, 8 differ from pt07102, = ptR1 8/8
  (the stack fix and the map's sum move no trace); cities audit 24/24 each: city600 (m636, 6,184), city2400 (m2436, 109,744),
  jerus-1007a (m440, 34,239), jerus-1008 (m8497, 5,984,721), jerus-old (m1875, 644,330); eol crlf 0.
- PlanCheck alone x10 after (load 4.2-4.7, P2b beside): 3/10 (54.6, 50.6, 43.5, 38.4, 47.2, 56.2, 35.0, 43.5, 33.9, 84.6 ms
  against 40); untouched by P4 (P3 saw 0.7.100's classes fail the same at load ~4). Round 1's two runs: 6/10 and 9/10.
- Commits: merge 0706f02; round 2 **009781a** (tree clean). The whole gate ran on exactly the tree committed.

## 5b. The ensemble 07103b (BASELINE out/07100/summary.json)
- **22/26** against 0.7.100's 24 (round 1's 07103: 20; P3's 07102: 23). Red: A2 (as 0.7.100's: longest spell 10 [3-19], 7 then),
  S1 (as 0.7.100's: spell 19, 13 then), and new: **ZERO_HOT H2** (10/16 below the second half, needs 12; median 3.27% <= 4.00%)
  and **HIGH T2** (final 6,616 against 75% of 10,202). Back to green: F1 x4 (no finding in any run: seed 9's is gone), R2 (+0.84).
- The young towns are smaller, the old ones larger: AUTO2's median population m600 5,118 (07100 6,609; 07103 7,544), m720
  7,112 (10,406), m1,200 44,552 (55,736), m2,400 **257,632** (230,564). HIGH ends at m720, so its T2 reads the young town (86% of
  its AUTO2 twin, as before). As in the playtest (4.): the road card is sized for the advice's horizon, the player looks every 6 to
  120 months, and the young town runs short of road between looks. H2 is the ZERO_HOT window (m42-402): not diagnosed further.

## 6. Star calls
- P4-1 duty after the sales tax; P4-2 petrol only (confirmed by Jerus); P4-3 the dial real, cap $1/L, a cent a step; P4-4 its cash
  with the tax take, read off Retail's month; P4-5 a Fuel tab under Taxes; P4-6 "+ city ReserveSales" kept for a save's month in
  flight; P4-7 the cap's form (1% of the crude run, exports only, the planner reads it); P4-8 RefineryCheck 14's fixture; P4-9 the
  road shares, CIRC 2016 Key Messages Figure 4 (roads and sidewalks 2.0-3.0%, bridges 1.0-1.5%, "informative only": checked by
  Jerus, cited so in BuildingsTemplate, buildings.json, GameVersion); P4-10 only roads own a share; P4-11 "no feed"/"dry" rules;
  P4-12 HealthCheck 13's read.
- P4-13 **The road rule's form**: the advice's card and count; the lines out of its ranking; the next card when money or ground
  fails (as AutoBuilder since 0.7.101); offered at the best road's key among the lines, as the roads were.
- P4-14 **The load stands empty stacks the order names** (rather than dropping empty stacks live: the live list is the model's).
- P4-15 **The map's sum leaves the sea out** (rather than the map counting them: they are in no district by design, 0.7.91).
- P4-16 **CentralBankCheck 21 kept P3's seed 8** (it holds on the merged tree) rather than my shape 0 (fails: very loose -5.14%).

## 7. For the next batch and the docs pass
- Docs pass: maps; dials (TaxPolicy DEFAULT/MAX_FUEL_DUTY, STATE_BEFORE_FUEL_DUTY; Refining LUBRICANTS_WORLD_SHARE; PolicyScreen
  FUEL_DUTY, FUEL_DUTY_STEP; OilCheck DUTY); harnesses.md (OilCheck 16/17, RefineryCheck 14/15, RoadCheck 1/9, BuildingDataCheck,
  BuildCardCheck 6, PolicyPreviewCheck 3, HealthCheck 13, SaveFileCheck 8b, ScaleCheck's month); the manual (the duty, the
  reserve, the lubricants, the roads' repairs, the card words); CLAUDE.md's LongPlaytest row (roads by need) and BuildAdvice row.
- AutoBuilder untouched (P2b). AutoBuildCheck untouched: its section 4 is green again by the load fix.
- OrderSearchCheck's note ("28 orders judged ... 22 trimmed") is main's; at 0.7.103 it reads 23 and 5 - left to the docs pass.

## 8. For Jerus to check on the PC
1. The young town under the roads by need: roads at 70-73% in its first 600 months (4.), the ensemble's HIGH T2 red (5b) - size
   the card for the player's absence (a slack past the advice's), or leave it: the towns end larger (617,942; 257,632)?
2. Policy > Taxes > Fuel at 21.5 cents: the pump dearer by it, Government's "Fuel duty" row after the reserve's.
3. Build > Oil Well: "the city owns N dry"; a conversion unit's card with no crude unit: "no feed".
4. Oil > the reserve: a release with no refinery to take it keeps its crude; Government shows what the refiners paid.
5. HealthCheck green on the hunger line on the shelves' timing: the 0.4-point call stands open, not answered.
6. A city whose every gravel road is paved: save, load, play on - it should play as the one saved (it parted before 0.7.103).

## 9. Outside my files
LongPlaytest (the player's road rule; the map's sum), Game's load path, BuildingManager.retire()'s note, Sectors' note,
CentralBankCheck/ScaleCheck/OrderSearchCheck/SaveFileCheck/HealthCheck fixtures; the merge's six files as in 1.
