# fixP5 notes - 0.7.106 P5, prices and rules (A18, A20, A23, A24, B). Implementer (Opus), 2026-10-10
Worktree `wt-P5`, branch `batch/P5` from e097c0f; 0.7.106 (the brief's 0.7.104 was P2b's). Scratch `scratch-p5/`: gate scripts,
var.sh (the decomposition), tools/cmp.py, firstdiff.py, probe/src (Fresh, Found, Offer, Lake, Plan, Map, Auto probes).

## 0. Steps (a line per step)
- clean at e097c0f; FreshProbe (13 worlds) before A24 (6. P5-4); all five drafted (A24 v1, the river); pt-r1; premises (3.)
- gate 1 (12792c6): 86/91 - OilCheck (A18, premise); RoadCheck 9, MonetaryCheck, PlanCheck 6, ScaleCheck (A24 v1). v2 (rings
  trimmed): PlanCheck 6 split on world 35. v3 (the lake): those green; MapCheck 2 red (3.); LandCheck main's but for 1 and 5
- gate 2: 89/91 - AutoBuildCheck, FundLedgerCheck, both A23 alone (3.: a fixture each, a latent load bug); fixed
- gate 3 on 73c7daf; Stale's one firm fixed, a777bf3; pt07106; ensemble 07106 (5.). One slip: a no-op `diff <(echo) <(echo)`
  (process substitution) after the ensemble build; nothing read or written by it.

## 1. What I built
- **A18** `sectors.Retail.estimatedMonthlyProfit()`: a shop's margin (coverage x hand-over rate x shelf over food) and a Filling
  Station's (stationEarns()) each less `plans.wageBillFor(t)`, its posts at today's wages - the figure Game.consider()'s interest
  test reads. The test only: the shelf floor, plan()'s ranking (margin over cost) and planStations()'s own gate are unchanged.
  Inside Retail's own path: BusinessInvestment untouched (wageBillFor() was public already).
- **A20** `CityNeeds.careHave()` = staffed beds - Healthcare.getPricedOut(care), floored at 0; careCover() and careServed() read
  it, so NEEDS YOU's rows (their a(), the served share, the level) do. `BuildAdvice.carePlaces()` the same with an order's places
  added, for figure() and supplyDemand() (Build's rings, the advice's after, AutoBuilder's ranking). Build's care ring line says
  "N people without, M priced out". The model's own coverage (Game.careCoverage(), x affordability) untouched.
- **A23** `ConstructionControl.SALVAGE_SHARE = 0.25` (source: 6. P5-3): Game.quoteDemolition(), quoteShellDemolition() and
  sellMaterialToTheBuilders() (a sector's plant retired, the 0.7.8 rule) recover that share of the units, bought at the market's
  price as before; the demolition card says "25% of its material comes back", its (i) cites the source.
- **A24** `CityLand.found(world, x, y, dryKm2, freshKm2)`: the rings, then takeFresh(): whole blocks from the fresh block nearest
  the founding lake's centre (World.river()), each next the one edge to edge with them holding the most fresh plots (ties: nearer
  the lake's centre, north, west), a step toward the nearest fresh block when none beside holds any, within FRESH_REACH (107
  plots), until fresh >= freshKm2 - on along the river where the lake is small. 4-argument found() = the rings (GridCheck 4).
  `LandManager.FOUNDING_FRESH_UNITS` 60,000 (the plant's production1, WaterCheck), `FOUNDING_FRESH_KM2` 0.4934, foundingLand().
  Default world: 54 blocks (21 rings + 33 lake, all open water, 2.4 km off), dry 315 plots (3,051,569 sq ft, unchanged), fresh
  549 plots 0.4941 km2 (0.011 before) = 60,083 units. 17 worlds: dry unchanged on 5, +3 to +100% on the others (a small
  lake: the river's banks); world 7 (no lake) only 408 fresh plots within reach.
- **B** `Founding.landBondUsd(CityLand)` = openingUsdPerSqFt x LandMarket.groundKm2(centre) x SQ_FT_PER_KM2, groundKm2() = dry +
  FRESH_PRICE_SHARE x fresh + SEA_PRICE_SHARE x sea (moved out of price(), same expression); `landBondUsd(long seed)` on
  foundingLand(seed). Game.foundTheLandBond() books landBondUsd(worldSeed). Default world US$3,811.4k (US$2,100k before);
  17 worlds US$3.8-6.9M. Founding screen: the Insane card's tooltip prices it on the typed seed when it opens (not per keystroke).
- Words (wrapped labels and (i)s, fit at 1,389 x 868): Build's Water Treatment Plant card and Services' water (i): a new city
  is founded with one plant's water; the Insane tooltip "the plots it is founded on, its lake with them".

## 2. Departures, with reasons
- A18 counts a station's staff too (P5-1); A23 discounts a retired plant's salvage too (P5-3); A20's order holds the priced out (P5-2).

## 3. Premises changed (before -> after) and the new assertions
- InvestCheck (retail): + the test figure is the margin less wageBillFor(); a loan the margin alone carries is refused; a station's
  likewise. BuildAdviceCheck 12 (new): fixture's month record via Healthcare.advanceMonth() with half priced out; NEEDS YOU's row
  a() = beds - priced out, served share, < the beds alone, = the month's cover x share who pay; Build's ring the same; an order's
  after = beds + its places - priced out; nobody priced out -> the beds.
- ConstructionControlCheck: "all the material the buildings held" -> SALVAGE_SHARE of it (+ less than all of it); the 0.7.8 rule by
  hand and the two-sales fixture on SALVAGE_SHARE's units. BankCheck: the retired shop's units x SALVAGE_SHARE.
- LandCheck 1: kept ("whole blocks holding at least STARTING_SQ_FT, less than a block more": the rings' dry ground is all the
  city's); + the rings are the centre's first blocks in order, the lake's blocks hold no dry plot here, fresh >= FOUNDING_FRESH_KM2
  and < a block more, the lake's blocks whole and edge to edge from the first, one holds the lake's centre, world totals kept.
  LandCheck 5: "nineteen of twenty-four" -> twenty (North 6 now stands against the lake's blocks).
- MapCheck 2 (outside the brief's files): its expectation "the outermost district with room" read hasRoomFor() on the canonical
  map, whose road share is 0 (canonical() strikes none); reconcile() places at the share of the changed counts (.307). On world
  35 the lake's 77 plots of bank in district (0,-1) had room for a Mixed Farm at 0 and none at .307. Now the expectation is
  computed by hasRoomFor()'s rule at that share (MapCheck.roomAt()); the premise is unchanged.
- OilCheck: the station's test figure = its margin on the litres less wageBillFor() (A18).
- AutoBuildCheck 4: a reload drift at m601 - Game's load put back the government block but not EconomyManager's central bank
  lines or fund transfer, so a refresh before the month (withRoom()) struck a loaded city's interest on its advances as 0 and
  its pass read each resident at $594 against $1,241: fixed in Game's load path (Outside, 9.). Its roomy copy now at
  DEBT_LIMIT_MOST as the first copy is (the A23 city ends over its 240%). FundLedgerCheck 8b: on the company the rule bids
  most for when it bids nothing for section 8's (Construction for Industry here; main's is unchanged).
- WaterCheck 11: + FOUNDING_FRESH_UNITS = the plant's production1; a new city's lakes yield it; its first plant not capped, 0 idle.
- FundCheck 12: the bond = STARTING_SQ_FT x opening -> the centre's ground (dry + .45 fresh + .08 sea) x opening; = the founding
  screen's figure for its world; > STARTING_SQ_FT's. ReadPathCheck and LongPlaytest call landBondUsd(city's land).

## 4. Trace movement, explained (reference pt07103; 0.7.104 left it byte-identical)
- All eight traces move, from **m17** (t-bank, t-bonds; t-month m19). Decomposition (var.sh: the tree with three of A18, A20,
  A23, A24 switched off; B is Insane's only and the playtest founds Standard):
  - A23 alone from **m17**: the first plant retired sells a quarter of its material (the bank's equity and the bonds' losses
    move). Over the run 37,071 units sold to the builders for $200B, not 151,711 for $987B. Ends 506,261.
  - A18 alone from **m75**: the first Filling Station (3 posts) fails the test on a loan at m75 and is built at m105; 47 at the
    end (42). Ends 688,814.
  - A24 alone from **m484**, its first water shortage (the wells carried it until then), met on the lake: 2 treatment and 8
    desalination plants at the end (1 and 16). Ends 674,618. (v1, the river strip, moved it from m2: its banks' free ground.)
  - A20 alone: byte for byte (the test player reads neither NEEDS YOU's care rows nor the advice's care cards).
- Together (pt-r2 = the gate's pt-main): 492,823 at m4,003 (617,942 at m4,005); m240 2,050 against 1,266, m720 7,767 against
  5,671, m1,000 14,090 against 17,160, m2,000 94,810 against 113,700; the first station m127; 5 treatment plants built, 23
  standing at the end, no desalination (1 and 16); the city borrows from m240. Audit closed, reloads matched, in every run.

## 5. The gate, and the final commit
- Gate 3 on 73c7daf: both builds silent; suite 91/91 (HealthCheck green); BuildMenuCheck PASS, 101 of 101; eol 0 w/crlf; the
  playtest: audit every month, every reload matched, traces as 4. (= pt-r2), copied to `scratch-p5/pt07106/` (t-*.csv, report).
  Stale then read 1 firm (FundLedgerCheck: my helpers between a javadoc and its method); moved, a777bf3: builds silent, Stale 0
  firm, StaleCheck and FundLedgerCheck green. MapCheck's 5 ms bound passed in all three suites. **Final commit a777bf3.**
- Ensemble 07106 (BASELINE 07103b, on a copy of a777bf3): **22/26**, as 07103b. Red: A2 (longest spell 14 [0-29]; 10 [3-19]),
  S1 (spell 17; 19), new HIGH R3 (3 seeds above +1 pt; 1) and SHOCK T2 (13,726 against 13,733, 75% of 18,310: 7 people). Green
  again: ZERO_HOT H2 (12/16 below; 10) and HIGH T2 (6,216 against 4,962). AUTO2 median final 206,974 (257,632); M1 0, F1 0/16.

## 6. Star calls
- **P5-1 (A18) a station's test counts its staff too** (a Filling Station is Retail's; its test read its margin alone). Measured:
  the first station m75 -> m105 in the A18-only playtest. Flip: drop `- staff` from Retail.estimatedMonthlyProfit()'s station.
- **P5-2 (A20) "beds less the priced out" literally**: beds short of the people, the month's cover x affordability (asserted);
  past them spare beds count (the lever is the fee). An order's after holds the priced out at last month's (no forecast).
- **P5-3 (A23) 25%, applied to the 0.7.8 rule whole.** Source: US EPA, "Characterization of Building-Related Construction and
  Demolition Debris in the United States", EPA530-R-98-010 (Franklin Associates, June 1998): of 136 Mt of building-related C&D
  debris in 1996, "an estimated 20 to 30 percent ... was recovered for processing and recycling" - the middle, 25%. Quoted from
  memory, no network here: Jerus to confirm the citation (8.). Recovery by weight, and what comes back is mostly downcycled, so
  by value it is generous still. Also applied to a sector's retired plant (the same rule, "the 0.7.8 rule" the decision named).
  An Elementary School now fetches about $3.05M for its 666 x .25 units against a $1.05M demolition (was $12.2M). Measured:
  AutoBuildCheck's auto-built decades city stands a village, ~1,800 people at m600 (13,581 at 0.7.104), A23 alone doing it.
- **P5-4 (A24) the founding lake, an island of the city's ground.** What a founding owns: its rings as they were (STARTING_SQ_FT
  of dry ground, less than a block more) and the founding lake's blocks from its centre, most water first, until they hold one
  Water Treatment Plant's 60,000 units - on the default world 33 blocks of open lake 2.4 km off and no dry plot. Why the lake:
  fixJ2 8.4 asked "should a city start with lake?", and it is open water, so the city's dry ground, its land prices and its map
  are what they were. Tried first: the river beside the rings (v1: +21% dry ground on the default world from its banks, and
  RoadCheck 9, MonetaryCheck, ScaleCheck and PlanCheck 6 moved by it) and the rings trimmed for the banks (v2: PlanCheck 6's
  river district split in two street pieces on world 35). The cost: a small lake (half the worlds) takes the river leaving it,
  banks and all (+3 to +100% dry ground there). Flip: takeFresh()'s start and frontier (the river from the rings is v1).
- **P5-5 (B)** the plots as the office charges ground (fresh 45%, sea 8%), the fields under them out as always. **P5-6** No
  SAVE_FORMAT bump: an older save keeps its centre, its bond and a quoted demolition; nothing reads wrongly.

## 7. For the next batch
- Docs pass: maps; dials (SALVAGE_SHARE, FOUNDING_FRESH_UNITS/KM2, CityLand.FRESH_REACH); harnesses.md (InvestCheck, BuildAdvice
  Check 12, LandCheck 1/5, MapCheck 2, OilCheck, WaterCheck 11, FundCheck 12, ConstructionControlCheck, BankCheck); the manual's
  section 17 (Insane's bond), land and demolition pages; CLAUDE.md's CityLand/LandManager rows (the founding lake).
- ConstructionScreen's "5%%" (DEMOLITION_SHARE) is a literal. After a load EconomyManager still lacks the city's repairs, arrears
  and reserve crude (0.7.102's lines) until the month: harmless unless something refreshes the books first, as withRoom() did.

## 8. For Jerus to check on the PC
1. The EPA citation behind SALVAGE_SHARE (P5-3): EPA530-R-98-010 (1998), "20 to 30 percent" recovered in 1996.
2. A new city on the default world: the map and the land office show the founding lake as its own (33 blocks, 2.4 km off); its
   first Water Treatment Plant runs without "fresh water limit" in Services.
3. Found a city, Insane: the card's tooltip quotes the bond for the world typed (US$3.81M on 4127).
4. Demolish an Elementary School: "Material back" reads 25% of its material.

## 9. Outside my files
- MapCheck.java (2.'s expectation at the month's road share); Game.java's load path (the central bank lines and the fund's
  transfer back into EconomyManager: a latent bug, not this batch's model); BusinessInvestment untouched (P6's).
