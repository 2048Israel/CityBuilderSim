# fixP6 notes: 0.7.105 P6, the refinery's run (2026-10-10). Implementer (Opus)
Worktree `/home/claude/git/wt-P6`, branch `batch/P6` from bad33d2 (0.7.103). Brief `runs/brief-batchP6.md`. Changed: fixP6-changed.txt.
Scratch `scratch-p6/` (no rm, no /dev): scripts; `probe/src` P6City (a city N months) and ui/P6Words; `classes-base` (bad33d2);
r-j1008-*.txt; h-*.txt; gate.log, gate2.log; sc-probe/ (ScaleCheck instrumented in scratch to find its half cent).

## 0. Steps (a line per step)
- Clean at bad33d2. Slip: my first command wrote an empty /home/claude/scratch-p6-err.txt (no rm by rule: the orchestrator's).
- Baseline (classes-base); P6City on jerus-1008 24 m (r-j1008-base2.txt). Rough run rule probed first (r-j1008-r1.txt).
- Model aa32572 (THE RUN, R1-R3, exits, words); harnesses 11b78b1; GameVersion, banners, CLAUDE.md 3d44a9e. Targeted 11/11;
  pt-a = pt07103 8/8; words 23, 0 over. Gate 1: all but ScaleCheck (a half cent, 3.); its floor fixed; gate 2 green (5.).

## 1. What I built
- **THE RUN** (Refining, banner THE RUN; A2 (b)). `runRule(flow, RunPrices)` (pure): the campus at nameplate a tonne of crude
  (one crew, one rate: every tonne the same products), its barrels in order, each at what its products fetch - the city's take
  of petrol and diesel (BusinessInvestment.forecast()) at the net import price, past it and every other product at the net export
  price, lubricants past the world's share (LUBRICANTS_WORLD_SHARE) and the city's at nothing; crude the wells' (Oil potential)
  at crude's local price, the rest at its net import price; less the vans' diesel a tonne. The run is every barrel up to the first
  that does not beat its crude: stops FIRST / PETROL / DIESEL / WELLS / LUBRICANTS / NAMEPLATE (RunVerdict: share, stop, the
  first, last and next barrel's margin as a share of its crude's cost). `strikeRun()` at endOfMonth: the share the month ran kept
  (6 months), next month's `paced()` toward the verdict by RUN_PACE (= MAX_RETIREMENT_FRACTION .25). `getOperatingRate()` = the
  plant's six throttles x runShare (then the Tank Farm's crude cap); `plantRate()` = the six alone. Saved: extras run.share,
  run.history.<n>; an older save reads 1 (as it ran) - no SAVE_FORMAT bump. A held refiners' run stays (holdSector).
- **The exits.** `retirementDemandAndCapacity()`: the idle kinds first (as before), else {most of nameplate the run used in the last
  IDLE_MONTHS months x nameplate, nameplate} in tonnes; planRetirement then sells crude units (losses >= 6, RETIREMENT_SLACK,
  a quarter at most, never into what was used). `mayRetire(Tank Farm)` false (neither rule ever sold one). spareCrude() at the
  plant's rate (the run's idle share is not the wells' spare). Marginal cost 0 when nothing is made: the tanks still sell.
- **R1** (SpreadPlanner.cityValue(): untraded -> net export price, not local; imported stays net import). Refining.cityValues():
  petrol and diesel at the net import price while `importsOf()` (forecast - nameplate - pipeline) > 0, else net export. Outlook
  gains `away`, `imports`, `run` (the 9- and 10-arg constructors are the prototype's frame: away = values, imports infinite, no
  run - every O5/P4 estimate to the bit). `unitEstimate(o, ...)` and `packageEstimate()`: petrol and diesel past the city's
  imports at net export (`pastImports()`), and every building's gross x the run the campus would take with it standing
  (`runWith()`). SpreadPlanner.city().rate() reads Refining.plantRate().
- **R2** (CARGO_KEPT_FREE = Ports.Ship.MR.tonnes()): crudeKept() = min(a month of nameplate x runShare, the farms' room - an MR's
  cargo). Ports.crudeShipFor() fits a cargo to ROOM_TOLERANCE 1e-9 of the room (the store is floating point).
- **R3** (Refining.plan()): crude units on site (anyone's order) do not count against MAX_CONCURRENT_ORDERS; while any are on site
  no crude unit is weighed (conversion units and the Tank Farm are, one order at a time); BusinessInvestment untouched but a note.
- **Words.** Refining.ownLines(): "The run" head, "Crude run: N% of nameplate" (GOOD/WARN/BAD), runWords() note; the generic
  "Staffed x ... all six multiply" note replaced by the seven. RefineryView.View + runShare, run; emptyWords() says why a stopped
  month ran nothing; the column's cuts' and the units' tips add runTip() while the run is short. OilView: the crude units' pill
  "idle"/"part run" with runShortWords(), their tip the whole. P6Words: every string fits (23 measured, 0 over).

## 1b. Jerus's 1008 city, 24 months (m8474-m8497; r-j1008-base2.txt / r-j1008-p6a.txt; money as the probe reads it, $)
| | crude bought | made | shipped | sales | refiners' net | run |
|---|---|---|---|---|---|---|
| 0.7.103 | 39.70M t, all imported | 46.15B L | 42.55B L | $2,687M | -$370.8M | 0.80 rate every month |
| 0.7.105 | 12.60M t, all imported | 14.65B L | 12.08B L | $965M | -$190.3M | below |
- The month ran 1.0, .75, .50, .25 (m8474-77), nothing (m8478-80: the first barrel, replacing his own petrol and diesel, -2.7% to
  -0.1% of its crude's cost); the railway's freight eased with the refinery stopped and his own diesel's barrels paid (first +0.6%
  to +2.5%): .13-.16 (DIESEL step) m8481-83, .29 (PETROL) m8484-90; in m8490-91 every barrel paid (+0.06%, +0.10% at the last):
  .54, .79 (m8491-92); the freight rose, none paid (m8493): .54, .29, then .14-.15 (DIESEL) to m8497. The study's "stays idle"
  did not hold: the margins sit within 3% of nothing and his own tonnes move the railway's price. Audit 24/24 (worst 1.98e-14).
- His planner (R3): "a Reformer would lose" m8474-78; m8480 a Hydrocracker (earns $24,357.2k a month on $20,507,533k at the run
  with it, 0.12%; bonds $19,607,834k at 2.88%); then "already building". Loss months 0 throughout: Refining is subsidised.

## 2. Departures, with reasons
1. **The planner weighs an order at the run with it standing** (R1 asks prices only): with prices alone his freed planner (R3)
   ordered conversion units behind crude units the run had stopped - a plant losing from its first month, R1's own purpose.
2. **CLAUDE.md** one phrase (sectors row); README untouched (no new harness or building); maps left to the docs pass.

## 3. Premises changed (before -> after) and the new assertions
- **RefineryCheck 9**: "...and one it neither imported nor exported, its local price" -> "...its net export price - where its every
  unit goes (0.7.105, R1)"; new "...and one the world will not buy, its local price" (vans).
- **RefineryCheck 14**: fixture "an Oil Refinery standing on imported crude ... orders within two years" -> "...on its wells' crude
  (TOWN_WELLS 30; on imported crude by lorry the run stops and no unit is ordered behind it)"; "the planner's values are each
  product at the city's own price" -> "...at the margin, petrol and diesel at the net import price only while the city imports
  them, and the run's prices with them". Its order is now a Small Cracking Unit (m18).
- **New RefineryCheck 16** (the run, pure): the study's margins from the model's own prices to its tenth (lorry -9.97%, rail .60
  -4.66%, floor -0.67%, tanker +2.25%; units behind one Crude Unit +9.26%, behind his 2,083,300 t +4.44%; home at the floor
  +1.36%, at .60 -1.66%); none run by lorry/rail, all by tanker; the home market's step; the wells' step; the lubricants' step;
  the pace. **17** (a town, not held): run 1 -> .75 -> .5 -> .25 -> 0; rate = plant x run to the bit; crude and products at it;
  audit; held town stays 1; crosses a save; the page and the picture's words; the spare {6,225, 8,300 t} after six months under
  nameplate and the Oil Refinery sold in month 11 by the spare-capacity rule. **18** (R1): behind a stopped run a unit earns
  -running-standing and is refused; by tanker as the prototype's frame to the bit; petrol past imports at net export to the bit.
  **19** (R3): the city's Crude Unit on site -> the planner weighs units; with a unit on site, "already building".
- **PortCheck 7** +3: the old rule's 14,185 t free under an MR; CARGO_KEPT_FREE leaves 37,500 t and an MR fits; a month on, an MR
  lands (554,457 t), the store kept, nothing held back.
- **ScaleCheck's four HistoryCheck floors** (outside my files): .005 + 1e-9 (.025 + 1e-9 for the sum) -> roundedToTheCent(half,
  size) = half + ULP_STEPS x ulp(size). Why: R1 took one losing refiners' order out of each copy (orders judged 8 -> 7, 9 -> 8),
  and at m605 of the 10-billion copy Retail's net income in its books came to -2,099,835,084.4750001, kept by the history's
  round2() as -.47: half a cent and 1.0e-7, where the double's own step at 2.1e9 is 4.8e-7 - over .005 + 1e-9. Base classes:
  4.996e-3, passing by 4e-6. The premise ("to the cent") stands; the floor is now the rounding's own bound (0.7.63's rule
  that a floor is never under the double's steps, which `max` did not give a half-cent floor). The only tolerance moved.
- No other premise moved (the fixtures that hold Refining keep their runs).
## 4. Trace movement: none
- pt07105 and pt-a = orch-gate/pt07103, all eight traces; report.txt but its run time. Its refiners never build. No ensemble.

## 5. The gate, and the final commit
- Gate 1 (3d44a9e, 16:11-16:28; gate.log): builds silent; words 23 measured, 0 over; suite 90/91, ScaleCheck red (3.);
  BMC PASS 101/101; Stale 0 firm (418 soft); pt07105 = pt07103 8/8, "Nothing" found; five cities 24 months, audit 24/24 each:
  city600 (m636, 6,184, worst 3.0e-14), city2400 (m2436, 109,744), jerus-1007a (m440, 34,239), jerus-1008 (m8497, 5,968,678),
  jerus-old (m1875, 644,330); eol crlf 0. Gate 2 (16:30-16:43, ScaleCheck's floor): builds silent, suite 91/91 (HealthCheck,
  ScaleCheck, MapCheck, PlanCheck OK), BMC PASS 101, eol 0; Stale's 1 firm (my helper split miss()'s javadoc) fixed by moving the
  helper above it: build silent, Stale 0 firm (418 soft), ScaleCheck green again. Final commit 5fd4c9a (tree clean).

## 6. Star calls
- **P6-1 (in place of "the run, valued at the margin" read literally per barrel): the barrel is the campus's average** - one crew,
  one rate (THE FLOW's homogeneous flow), the conversion units at the crude units' run. The alternative keeps the units full at a
  cut run (the flow solved at the run's crude): realer, but every nameplate read (tanks, planner, room) must then split from the
  run's. Flip: flow() at runShare x nameplate, a nameplate flow for the tanks, outlook and pipeline. Not measured.
- P6-2 "the import price" = the net import price, landed and hauled (the study's, cityValue's): reproduces +1.4% and -1.7% to the
  tenth; the band's ceiling (what a seller here is paid) gives +0.9% and -2.6%.
- P6-3 RUN_PACE = MAX_RETIREMENT_FRACTION (the brief's example). P6-4 the spare = the most the run used over IDLE_MONTHS months. P6-5 the planner's rate is the plant's (operatingRateOf(0) reads 1); the run enters through runWith(). P6-6 vans' diesel is the
  run's cost (at diesel's local price), power and water are not (billed at nameplate). P6-7 lubricants at net export, past the
  world's and the city's share at nothing; only petrol and diesel get the import price (the decided rule).
- **P6-8 R2: an MR's cargo kept free**, not farms ordered until one fits: the trap is the count, and a second farm would be capital
  to cure it; kept also follows the run's share; Ports.ROOM_TOLERANCE 1e-9 (a stored cargo's rounding).
- **P6-9 R3: crude units on site aside, the refiners' rule alone.** Every other sector: unchanged. Counting only a sector's own
  orders would change only sectors with a city-ordered stack and free none of T1's nine (their sites are their own).
- P6-10 held refiners hold their run (holdSector). P6-11 marginal cost 0 with nothing made. P6-12 the city's take is forecast(),
  which misses the railway's diesel (O14-4): his diesel step comes early.
- **P6-13 ScaleCheck's half-cent floors made the rounding's own bound** rather than leaving the suite red on a half cent, or
  moving its copy's month: the change that exposed it is R1's, the miss is HistorySave.round2()'s on a negative half cent.

## 7. For the next batch
- Docs pass: maps (Refining, SpreadPlanner, Ports, RefineryView, OilView, BusinessInvestment, RefineryCheck, PortCheck); dials
  (RUN_PACE, CARGO_KEPT_FREE, RUN_KEY/RUN_HISTORY_KEY, Ports.ROOM_TOLERANCE, RefineryCheck STUDY_*, TOWN_WELLS, HIS_CRUDE);
  harnesses.md (RefineryCheck 9, 14, 16-19; PortCheck 7); the manual (the run, the planner's prices, the room, the words).
- The market's tally misses the drivers' and the railway's draws (O5-1, O14-4): forecast() reads diesel short. The run
  oscillates where the railway's freight answers to the refinery's own tonnes (1b.): a damping is Jerus's call, not tuned.

## 8. For Jerus to check on the PC
1. Your 1008 city, Sectors > Refining: "Crude run" and why; the run falls to nothing in four months, then follows the prices -
   mostly the barrels of your own diesel or petrol - and the loss halves. Your refiners are subsidised, so no loss is counted and
   no crude unit is sold; and your 14 Crude Units on site would hold the sale anyway ("building, not shrinking").
2. Freed of those 14 (R3), your refiners ordered a Hydrocracker in a good month (bonds $19.6B): it waits in your starved queue.
3. Oil > THE REFINERY: the crude units' pill "idle" / "part run" and its words; the refinery picture's pointer on a cut.
4. A port city with one Crude Unit and one Tank Farm: tankers (MR) now land its crude.

## 9. Outside my files
- RefineryView, OilView (the brief's "the refinery and oil pages' words"); GameVersion; CLAUDE.md; ScaleCheck's floors (3., P6-13).
