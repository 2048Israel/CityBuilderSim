# fixP7 notes - an old save refused cleanly, 0.7.108 (2026-10-10)

## 0. Status (a line per step)
- Worktree /home/claude/git/wt-P7, branch batch/P7 from 03eb4bd, clean at start. Scratch /home/claude/scratch-p7 (gate scripts copied, paths moved).
- Read: brief, shared rules, CLAUDE.md; the load path (Game.readTheSave), SaveHeader, GameFiles.slotIsLoadable, UserInterface's SAVE SYSTEM and loadSlot(), RobustnessCheck 5/5b, SaveSlotCheck 5.
- Built: GameVersion.OLDEST_LOADABLE_FORMAT (21) + isNoLongerReadable() + noLongerReadable(words); FIRST_SECTOR_FORMAT and isFromBeforeSectors() gone (one floor). Game's load refuses below it; SaveHeader.isNoLongerReadable(); UI slot list line. SaveFileCheck new last section; RobustnessCheck 5b reads the floor. CLAUDE.md, README rule words. Builds silent; SaveFileCheck, RobustnessCheck, SaveSlotCheck green; probe with the floor at SAVE_FORMAT on a copy also green.
- Commit 7980971 (stage 1). Gate 1 started 21:27 on 7980971; green (§5).
- Found while it ran: the slot list's disabled button means a refused save never reaches loadSlot()'s "Could not load" page, so the slot line itself must carry the words. Step 2 (UI only, while the suite ran on 7980971's classes; the gate's BMC and Stale read it): slotSummary() returns noLongerReadable()'s words, slotRow() wraps a refused slot's line at 320, the save page's current-slot line wraps too; the 0.7.108 entry and the words' javadoc say so.
- Final commit 230741e on batch/P7 (on 7980971 on 03eb4bd). Done.

## 1. What I built
- `GameVersion.OLDEST_LOADABLE_FORMAT = 21`, its first sentence the rule: a batch that bumps SAVE_FORMAT because an older
  save would load wrongly raises it to the new format in the same batch. `isNoLongerReadable(int)` (format below it) and
  `noLongerReadable(String savedBy)`, the words. FIRST_SECTOR_FORMAT and isFromBeforeSectors() are gone: the floor is the
  one older-format gate (★1). The class header's "Older saves are still read" paragraph says the floor now.
- Game's load (readTheSave): below the floor -> loadFailure = the words, a log line with the slot, both formats and "its
  file left as it was", return before anything is applied - where the before-sectors check stood, beside the newer one.
- SaveHeader.isNoLongerReadable(); isReadableHere() = neither newer nor below the floor, so GameFiles.slotIsLoadable(),
  Continue's autosave and YOUR CITIES pass such a slot by, as they pass a newer build's.
- UserInterface.slotSummary(): the slot list's line under the slot is the words themselves, wrapped (slotRow()); its
  Load button is off (slotIsLoadable()), so this line is what the load screen says - loadSlot()'s "Could not load" page
  shows the same words should a load ever reach it.
- The words (★2): "This city was saved by build <its build>, and build 0.7.108 can no longer read it. Build <its build>
  still opens it." A save with no stamp: "This city was saved by an older build, and build 0.7.108 can no longer read it."
  The log: "Slot N not loaded (save format F; this build reads formats 21 to 36), its file left as it was. <the words>"
- GameVersion 0.7.108 entry; CLAUDE.md's standing rule, the "Bump SAVE_FORMAT" line and "A saved field", and README's
  save paragraph say: bump SAVE_FORMAT *and* raise OLDEST_LOADABLE_FORMAT to it; the docs pass's caveat is gone.

## 2. Departures
- RobustnessCheck (a harness, not named in the brief) edited: it read FIRST_SECTOR_FORMAT and isFromBeforeSectors().

## 3. Premises changed and new assertions
- RobustnessCheck 5b: "and the loader refuses it with a reason": the reason contains "sector" -> contains "can no longer
  read" (the same premise, a pre-sector save refused with its reason; the reason is the floor's words now). The fixture's
  format FIRST_SECTOR_FORMAT - 1 -> OLDEST_LOADABLE_FORMAT - 1 (20 either way); old4's FIRST_SECTOR_FORMAT -> the floor
  (21 either way); label "a save from before the sectors reads as a file" -> "a save older than this build loads reads as
  a file"; "...and it says so" reads isNoLongerReadable().
- SaveFileCheck, new last section "and a save older than this build loads, refused cleanly" (15 labels): the city saved
  above written at floor-1 with a fixture stamp ("P7-fixture"), the same unstamped, and at SAVE_FORMAT+1; the header says
  no-longer-readable, not newer; there, not damaged, not loadable; the load's failure equals noLongerReadable(stamp),
  names that build twice and this one; the log line (stdout captured) says the slot, the words and both formats; month
  stays 1; the unstamped one says "an older build" and no "null"; the newer one is still marked newer and refused as from
  a newer version; every file in the folder (saves and their histories) byte for byte as it was and nothing added; a save
  at the floor is loadable and loads at its saved month.
- Probe: the same three harnesses with the floor set to SAVE_FORMAT on a copy of the source: all green (36 loads, 35
  refused) - the mechanism works once a batch raises the floor.

## 4. Trace movement
- None expected: nothing that loaded at 0.7.107 is refused, and the playtest's own saves are format 36.

## 5. The gate (gate.sh, 21:27-21:41; model and suite on 7980971's classes, BMC and Stale on the final tree)
- Both builds silent (again on the final tree, after the gate).
- Suite: 92 harnesses, 92 passed, 0 failed (681 s); HealthCheck and MapCheck passed this run.
- BuildMenuCheck PASS, 101 of 101 buildings described.
- tools.Stale: 0 firm (orphaned javadoc 0, missing file 0, stated count 0); unresolved member 101, as at Z1's gate.
- Playtest: 8 traces byte-identical to /home/claude/scratch-ui1/orch-gate/pt07106; 4,003 months, "Nothing. Every month
  passed the audit and every reload matched."
- Line endings: no w/crlf but .bat files.
- After the gate, the final tree's changes since 7980971 are UI words and GameVersion comments only: both builds silent
  again, SaveFileCheck, RobustnessCheck and SaveSlotCheck green on the final classes.
- Final commit: 230741e.

## 6. ★ calls
- No choice made in place of what Jerus asked.
- ★1 FIRST_SECTOR_FORMAT *becomes* the floor (renamed, one gate) rather than staying beside it: two checks below 21 would
  give one save two refusals, and a constant named for the sectors gating the load would be wrong the day the floor rises.
  The sectors' history stays in format 21's entry. Flipping it: keep isFromBeforeSectors() ahead of the floor check.
- ★2 The words name the build that saved the city as the one that still opens it - the one build sure to read its format
  (no format-to-build table exists to name the last build that reads it). "Saved by build X, which this build can no
  longer read" was the brief's example; reworded so "which" cannot point at build X.
- ★3 The name OLDEST_LOADABLE_FORMAT (the brief's) and isNoLongerReadable() (mirrors the words; isFromOlderBuild would
  be true of every loadable older save).

## 7. For the next batch
- Raising the floor: change the one literal (21) to the new SAVE_FORMAT; SaveFileCheck's last section and RobustnessCheck
  5b follow the constant. Harnesses that load a hand-written older format (ConstructionControlCheck 27, ChartCheck 28,
  LandCheck/WaterCheck 30, ConversionCheck 31, SectorStatementCheck 32, OilCheck/WellCheck 33-35...) will then be refused:
  their conversion sections retire with the formats (no conversion code until the game is published).
- A refused load still rebuilds the world first (loadGameSave() calls buildWorld() before reading), as a newer build's
  did: from the pause menu the city in play is replaced by a blank one even though nothing loads. Not reachable from the
  load list today (the button is disabled), only by code.

## 8. For Jerus to check on the PC
- Load a city: a slot holding a save from before the sectors (format < 21), if any, reads the new line and offers no load.

## 9. Outside my files
- None beyond RobustnessCheck (§2).
