# fixI1 notes (0.7.110): fields by type

## 0. Progress (a line per step)
- Read brief, shared rules, spec 1/2.4/2.5/3/4/5, W1 notes 7 and the write-up. Worktree clean at 9ec1d5f.
- Scratch /home/claude/scratch-i1: build/suite/pt/bmc/gate scripts copied, pointed at wt-I1.
- Baseline suite (classes-base, 9ec1d5f): 92 of 92 green, HealthCheck green this time (686 s).
- Model committed 3f0a276; playtest pt1 8 of 8 traces identical to pt07106. Harnesses + version c192da0.
- Probes (scratch-i1/probe): TypeProbe (shares, near, onetype 200 seeds, timing), CityProbe (the five cities, copies).
- Targeted: WorldCheck, LandCheck, BuildingDataCheck, SaveFileCheck, ReadPathCheck green. Gate: see 5.

## 1. What was built
- Deposit.FieldType {HEMATITE, MAGNETITE, THERMAL, COKING, SULPHIDE, OXIDE, LIMESTONE, HARD_ROCK, NONE}; type() drawn as
  grade() is ((cell << 24) ^ (index << 4) ^ kind ^ TYPE_SALT) against TYPE_SHARES (by FieldType: .75/.25, .85/.15,
  .80/.20, .70/.30, NONE 1). Pure, nothing stored, both worlds' fields. Resource.typesOf() (two for iron, coal, copper,
  stone; NONE for oil, uranium, forest), hasTypes(), goodOf(type).
- CityLand.Piece, typedPieces(r) (per holding in acquisition order: its fields as heldFields() lists them, each as far
  as the holding listed, sites and tonnes each; the rest one piece of the first type - fiat or a converted centre's
  legacy field), sitesByType(r).
- LandManager THE GROUND BY TYPE: getSites/getOwnedAmount/getRemaining/getExtracted(r, type) (null = ANY = the whole;
  NONE on a one-type resource = the whole; another resource's type = 0); getExtractedByType(r); typeRuns(r) (the spec's
  typeRuns: runs of one type in the order worked out, cached by the land's stamp and listings); extract(r, type, t);
  extractedByType (null per resource = "the walk's reading of E"); takeInWalkOrder (a dig on ANY once kept: each type's
  next unworked tonne, earliest first); remainingByHolding exact by type once kept; getDepletionByTypeState() /
  restoreDepletionByType(); Claim(type, sites, count) and fits(r, type, standing, extra). install/reset/restoreSites
  return a resource to the walk. Untyped extract() is unchanged while nothing is kept (byte-identical).
- BuildingsTemplate.Site(resource, type|null=ANY, sites, dig), setSite/site(); BuildingCatalog.readSite ("site":
  {"resource","type","sites","dig"}, unknown type -> ANY, unknown resource -> line ignored); buildings.json and the
  BuildingManager twin: 14 Iron Mine {IRON, ANY, 1, 1}, 74 Oil Well and 99 Platform Well {OIL, ANY, 1, 1}, 98 Offshore
  Platform {OIL, ANY, 0, 0}; the readme lines.
- Game.siteOf() reads the site (null without one); committedOn(r) counts sites (one a building today: same numbers),
  committedOn(r, type) the sites on one type (null = those on ANY). DataSave.depletionByType (double[][], a row per
  resource, null rows); Game's save and load lines (after restoreOilPools).
- GameVersion 0.7.110 entry. No SAVE_FORMAT change (36), OLDEST_LOADABLE_FORMAT unchanged (21).

## 2. Departures
- WorldCheck's types are section 9 (W1 took 8); fits() is asserted in LandCheck 26 (it is LandManager's), not WorldCheck.
- TYPE_SHARES is by FieldType (each type's share of its resource's fields; pairs sum to one), as GRADE_SHARES is by Grade.
- goodOf(type) returns the resource's good() for its own types (IRON for both iron types; null for coal, copper and
  stone): THERMAL_COAL, COPPER_CONC/COPPER and LIMESTONE/AGGREGATE do not exist yet (I6-I8 fill it).
- No typeRuns() conversion and no save of E by type until a works digs by type (see ★I1-1); typeRuns(r) exists as the
  reading, public.
- The wells and the jacket got a site too: "a template without one is not a mine" would otherwise have moved siteOf().
- Game: besides siteOf/committedOn, the two save/load lines for depletionByType (a saved field needs them).

## 3. Premises changed (before -> after) and the new assertions
- No premise moved. Game.siteOf(): the good rule -> the template's site; BuildingDataCheck asserts the two agree for
  every building, and that four stand on sites (one site each, ANY, dig 1; the jacket 0 and 0).
- New: WorldCheck 9 (TYPE_SHARES pairs sum to one; oil and uranium NONE; type pure on a world built twice, a record made
  again, both worlds; first type's share of the fields within TYPE_WITHIN 2 points on 4127, 77, 2026 - iron 256 pools
  round the site, stone 256, coal and copper the whole world; every pool's types sum to its total exactly, the old
  world's per cell). LandCheck 26 (world 35, a city buying iron until it holds both types: sites and tonnes by type sum
  exactly and equal the held fields of each type; W by type to the tonne at every step; a dig on ANY takes the walk, keeps
  nothing; a dig by type moves its type's E and the resource's only; an ANY dig after it takes the walk's next unworked
  tonne, first run's then past it the other type's; caps; remainingByHolding; state round trip; a save without it reads
  as the walk; fiat ore all the first type; fits: largest piece and not a site more, 20 sites, 1-site fill, ANY first
  type first, unplaceable standing first, no-site and wrong type, pure; committedOn by sites and type on a Game).
  BuildingDataCheck: site json = twin. SaveFileCheck: depletionByType absent while nothing kept, survives to the bit
  with null rows, back in an office. ReadPathCheck: every typed read moves nothing; a typed dig survives Game's save/load.

## 4. Trace movement
- None: the eight traces are byte-identical to scratch-ui1/orch-gate/pt07106 (pt1 after the model; again at the gate).

## 5. The gate, and the final commit
- (filled at the gate)

## 6. ★ calls
- ★I1-1 OLD SAVES, NO BUMP: E by type is a reading of E while every tonne came out in acquisition order - every dig
  until now - exactly as oil's grades are read (oilRuns); nothing is stored for it and a save writes depletionByType only
  once a works has dug by type (none in I1). A save without the key loads correctly (the walk is what its E was), so no
  conversion code and no SAVE_FORMAT bump. Jerus's saves keep loading (city600, city2400, 1007a, 1008, jerus-old loaded,
  saved to slot 10 of copies and loaded again, E by type the same, no key written). Flip: always write the split
  (spec's wording) - harmless, but every save would carry a reading of E.
- ★I1-2 ANY is null (Site.type(), fits(), getSites(r, null)), not a FieldType: no field is ever ANY.
- ★I1-3 fits(): bins are the typed pieces (a holding's part of a field; a holding's fiat one first-type bin); "counts
  against the free sites first" = an unplaceable standing works' sites taken from its type's pieces (ANY: first type
  first) in acquisition order, split across pieces, before the rest are packed again with the new one (FFD, typed
  before ANY, ties keep the standing first). ANY onto the first type first generalises "ANY quarries onto limestone".
- ★I1-4 uranium is NONE (the study gives no types); the jacket's site is {OIL, ANY, 0, 0}.
- ★I1-5 committedOn(r, null) counts the ANY claims only; committedOn(r) every type's.
- ★I1-6 TYPE_SALT 0x7E1DA5 (any salt; the spec's measured holdings were drawn with another, so the five cities' splits
  below are this salt's).

## 7. For the next batch
- MEASURED (this build): type shares by fields on four worlds (4127, 77, 2026, 35) within 0.63 points (copper 80.63% on
  77), by tonnes within 1.20 (copper 81.20% on 2026); 0 pools (or old-world cells) whose types miss the total. type()
  11.1 ns a draw. Old world's iron per cell 74.8-75.2%.
- NEAR THE FOUNDING SITE (new world, within 50 km; old world in brackets): 4127 iron 23 hem + 13 mag (268+89), oil 19
  (31), stone 0 (8+7), coal 0 (0), copper 0 (1+1); 77 iron 81+23, oil 6, stone 5+1, coal 0, copper 0; 2026 iron 26+7,
  oil 8, stone 0, coal 0, copper 0; 35 iron 34+10, oil 2, stone 1+1, coal 1 thermal, copper 0. Coking coal, copper and
  stone near a founding are rare: I6-I8's ensembles will mostly import.
- ONE TYPE: seeds 1-200, a city holding the nearest iron fields to S sites: S=13 one type 96% (new) vs 20.5% (old);
  S=25 72% vs 6.5%; S=50 53% vs 2%; S=100 27% vs 0.5% (1.1, 1.8, 2.8, 5.0 fields new; 7, 12, 23, 44 old). At S=25, 60%
  hold hematite only and 12% magnetite only: a magnetite works (I5) has no field in most cities, a hematite one in
  about one in eight; the chains lean on imports (PELLETS, coking coal). Fields of 20+ sites: 47.8% new, 1.1% old, so a
  20-site works fits wherever its type is held at all, on the new world.
- THE FIVE CITIES (old-world ground): city600 10 iron sites by fiat, hematite; city2400 64 = 51 hem (42 by fiat) + 13
  mag; 1007a 13 = 8 hem + 5 mag, its 3 mines fit on ANY and on hematite; 1008 1,554 = 1,301 + 253, E read as
  5.16 Gt + 1.98 Gt; jerus-old 155 = 146 (94 fiat) + 9; coal and copper in 1008 and jerus-old typed too.
- I3's iron in-ground reference: pin it to D itself, US$0.40 a tonne in the ground (inGroundShare x IRON's export
  price), checked on LandCheck 19's fixture field (world 35's nearest dry field: 27 sites, 463 Mt, US$185M at
  $0.40) - not the default world's founding field, which no longer exists. A mean new field: 25.2 sites x 15 Mt = 378 Mt
  before richness, US$151M at $0.40.
- I5: Game needs the standing claims by template (site type, sites, quantity + on site + ordered) for fits(); the
  order gate (hasDepositFor, buildRunAhead's `before`) counts buildings - multiply by site.sites() when a works takes
  more than one; remainingFor by type (getRemaining(r, type)); a typed mine digs extract(r, type, t) (extractIron
  assigns ironMinedThisMonth - keep that). The first typed dig makes the save carry depletionByType.
- I13 (the land office's hover): offers are not typed yet; CityLand.fieldsOn() would need a by-type twin.
- Earth (E3): the type odds by geology are not built (generated worlds draw flat), as the spec says.

## 8. For Jerus to check on the PC
1. Load the 1008 city: it loads as before (no new key; nothing in the log about types). Save and load it again.
2. Nothing on screen changes: the Iron Mine, Oil Well and the two offshore buildings build and count sites as before.

## 9. Outside my files
- Game.java: two lines beyond siteOf/committedOn - dataSave.setDepletionByType(...) in the save, and
  landManager.restoreDepletionByType(...) in the load after restoreOilPools.
- BuildingManager.java (the twin): .setSite(...) on ids 14, 74, 98, 99. BuildingCatalog.java: readSite().
