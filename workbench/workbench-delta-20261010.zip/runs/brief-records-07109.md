# Brief: the records for 0.7.107 to 0.7.109, the docs pass and manual 16. 2026-10-10

You write the project's records, on **Sonnet**. The orchestrator checks your figures against the notes. Don't ask anything.

## Standing rules
- No command that could raise a permission prompt. No network.
- **Don't use `rm` at all, and never touch `/dev` in any way:** no `2>/dev/null`, no `> /dev/null`, no `/dev/stdout` or `/dev/fd`, no `<(...)`. That includes text inside heredocs and scripts you write. Use the Write and Edit tools for any text that mentions those strings.
- **Write only in `/home/claude/runs/records/`:**
  - `changelog.md` and `todo.md` (copy each to `<name>.pre07107.md` first);
  - `index.md` (copy to `index.pre07107.md` first);
  - one new write-up, `zoning-and-the-forest-law.md`.

  Edit byte-safely and keep line endings. Don't touch `/home/claude/git` or `/home/claude/cbs*`. Don't grep across `/home/claude/runs` as a whole.
- **No invented numbers.** Every figure comes from a note or from this brief.

## Sources, in `/home/claude/runs/`
- **Notes:**
  - `fixZ1-notes.md` (0.7.107, zoning's model);
  - `fixP7-notes.md` (0.7.108, an old save refused cleanly);
  - `fixZ2-notes.md` (0.7.109, zoning's screens);
  - `docs-07106.md` (the docs pass for 0.7.100 to 0.7.106);
  - `manual-16-part1.md` and `manual-16-part2.md` (the manual's edition 16).
- **The plans:**
  - `brief-batchZ1.md`, `brief-batchP7.md`, `brief-batchZ2.md`;
  - `brief-batchI1.md`, `brief-batchE1.md` and `brief-batchI2.md` (next);
  - `spec-materials.md` §2.15 and §5 (zoning's place in the plan).
- **The research study** that arrived the same evening: `research-design.md`. Read its summary, the boxed decision at the top, §8 and §9. It is a design study by another session, written to the project as `claude/research-design.md` with mockups in `claude/mockups-research/` and its model in `claude/research-model/`.
- **The house shape:** the changelog's top block (THE FIXES FROM THE DECISIONS) and the todo's sections.

## Facts from the orchestrator
**Shipped through GitHub** (`main`, each merged by the orchestrator, gated and pushed; tags exist only in the cloud clone, because the session's git proxy refuses tag pushes):

| commit | what | `SAVE_FORMAT` |
|---|---|---|
| 7b4e86e, 442006a, 8237323 | the docs pass for 0.7.100 to 0.7.106, parts A to C | — |
| 8e90ab7 | manual 16 into `docs/` (the artifact "CityBuilderSim" at version 16) | — |
| 03eb4bd | 0.7.107 Z1, zoning's model | 36 |
| 9ec1d5f | 0.7.108 P7, an old save refused cleanly | 36 |
| 819446b | 0.7.109 Z2, zoning's screens (the merge; the branch's gate 93/93, the playtest byte-identical over 4,003 months) | 36 |

The PC's auto pull last confirmed b327419 (0.7.102) at 11:35. The PC has been offline at every check since.

**Jerus, 2026-10-10:**
- 12:51: "old saves need not load until the game is published" (R1 wrote it into CLAUDE.md; P7 built the floor that refuses them).
- 21:15, on the manual: publishing means releasing the game; the manual is published without asking.
- 21:24, in the research study (its box at the top): "the game starts in 1900, not 1950. I think its a great idea, cause it also slowly introduces mechanics."

**Running now:**
- I1 (0.7.110, fields by type);
- E1 (0.7.111, Earth's reader, pure, on a small fixture of the data).

**Next:**
- I2 (0.7.112, the shared machinery);
- I2b (decision A13: the whole-cost test for `Game.Slices` and the sea's orders);
- then I3 to I14 (0.8.0) and Earth E2 to E5.

**Found while preparing them** (put these under FOUND ON THE WAY or the batches they touch):
- **The materials study's prototypes did not survive** the workspace restart on 2026-10-09: `scratch-materials/` (`balance.py`, `gen_buildings.py`, `buildings-materials.json`, `goods-materials.txt`, `gen.txt`). Only the spec and the study (`claude/materials-chains-research.md`) are left. I3 onward rebuild the building and goods rows from the study's tables and the spec's conventions (§2.2). MaterialsCheck's first section (the four cases equal the study's) lands with I3's rows.
- **The Earth study's Java prototype is gone too.** E0's data (`earth-1.bin`, 52.8 MB) and its Python tooling survive in the workspace only. E1 puts the tooling into the repo under `tools/earth/` and tests on a small fixture.
  - **Jerus's call, wanted by E4:** how the 52 MB file ships. A file in git stays in the public repo's history for good; GitHub warns over 50 MB and refuses over 100 MB. The options are one file a layer, Git LFS, a download, or plain git.
- **The project's knowledge is near its limit:** 1,766,364 of 2,000,000, before tonight's writes. `changelog.md` (about 600 KB) and `todo.md` (about 750 KB) are most of it; the research study also says so.
  - **Recommendation for Jerus:** move the changelog blocks older than a month and the todo's struck-through items into the repo (`docs/notes/`), and keep the live list and the last month in the project.
- **The research study's call that touches the materials batches** (its Q3, not yet decided): write each new building's inputs, outputs and posts as a `recipes` list with `since`, so research later is data.
  - The orchestrator is asking Jerus.
  - **Recommendation:** I3 onward keep today's row shape (the study's §2.1 keeps the top-level fields as the default recipe) and add `since` (the year it first existed) to each new row; the `recipes` list waits for research's R1.

## Do
1. **`changelog.md`:** one block at the top, at most 40 lines, in the house shape, titled `### ZONING, AND AN OLD SAVE REFUSED — 2026-10-10, 0.7.107 to 0.7.109, shipped through GitHub`. Cover:
   - the docs pass and manual 16 first;
   - then Z1, P7 and Z2, each with what ships, its harnesses and its ★ calls that Jerus should know.
2. **`todo.md`:**
   - **The opening paragraph** at 0.7.109, at most 4 lines.
   - **NEXT:**
     - zoning (Z1, Z2), the docs pass and manual 16 struck through as done;
     - P7 added as done;
     - the materials chain's I1 and E1 marked running, with I2 and I2b next;
     - fold the found items above into I3's and E4's entries.
   - **Research:** add an entry after Earth, "NEXT, AFTER EVERY PLANNED BATCH: RESEARCH (`claude/research-design.md`)". Give:
     - the 1900 start, decided;
     - its batches R0 to R5 (§9);
     - the study's open questions (§8), named in one line each.
   - **CONFIRM (from 0.7.107 to 0.7.109):** at most 12 items. Take them from the notes' ★ calls Jerus would want to weigh, and add:
     - the Earth data file;
     - the project's knowledge limit;
     - the recipes question.
   - **CHECK 0.7.107 TO 0.7.109 ON THE PC:** at most 6 items, from the notes' §8.
   - Keep everything else.
3. **The write-up `zoning-and-the-forest-law.md`:** at most 110 lines, for Jerus, in plain words.
   - Zoning end to end:
     - what a zone is and what it does to the ground, the price and the taxes;
     - the forest law;
     - what each of the three screens shows;
     - what the investors and the build cards now say.
   - What P7's floor does.
   - What is open.
4. **`index.md`:** one line for the write-up, one for `research-design.md` (and its mockups and model), and fix any line that still says zoning is to be built.

Reply with what you wrote and the line counts.
