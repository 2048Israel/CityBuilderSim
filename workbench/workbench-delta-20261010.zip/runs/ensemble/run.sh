#!/bin/bash
# The inflation ensemble: 16 seeds x 5 policies on one tree, one JVM at a time, then scored.
#
#   bash /home/claude/runs/ensemble/run.sh <tree> <label>
#   e.g. bash /home/claude/runs/ensemble/run.sh /home/claude/cbs 0743
#
# <tree> must be built (<tree>/build/classes). The driver is compiled against it into
# classes/<label>; the CSVs go to out/<label>/<POLICY>-<seed>.csv, the run times to
# out/<label>/times.txt, the table to out/<label>/score.md and the figures the next
# version is compared with to out/<label>/summary.json.
#
# Environment (all optional):
#   SEEDS="0 1 2"            seeds to run (default 0..15)
#   POLICIES="AUTO2 HIGH"    policies to run (default all five; AUTO2 first - it is every other policy's twin)
#   BASELINE=<summary.json>  what T1/T2/F1 compare with (default out/0741/summary.json; none for label 0741)
#   JAVA_OPTS="-Densemble.extra=expected=getCentralBank.getExpectedInflation"   extra columns, flags
#   RESUME=0                 rerun runs already finished (default 1: a run with a CSV and a times.txt line is kept)
#
# Standing rules: one JVM at a time, -Xmx2g, temp files under tmp/ (the driver deletes its own).
set -u
TREE=${1:?usage: run.sh <tree> <label>}
LABEL=${2:?usage: run.sh <tree> <label>}
E=/home/claude/runs/ensemble
GSON=/opt/apache-maven-3.9.11/lib/gson-2.13.1.jar
CLS=$E/classes/$LABEL
OUT=$E/out/$LABEL
SEEDS=${SEEDS:-$(seq 0 15)}
POLICIES=${POLICIES:-"AUTO2 ZERO_SLACK ZERO_HOT SHOCK HIGH"}
RESUME=${RESUME:-1}
JAVA_OPTS=${JAVA_OPTS:-}
BASELINE=${BASELINE:-$E/out/0741/summary.json}
mkdir -p "$CLS" "$OUT" "$E/tmp"
touch "$OUT/times.txt"

if [ ! -d "$TREE/build/classes/ham/citybuildersim" ]; then
  echo "no build/classes under $TREE - build the tree first" >&2; exit 1
fi
echo "compiling the driver against $TREE/build/classes"
javac -nowarn -d "$CLS" -cp "$TREE/build/classes:$GSON" "$E/src/ham/citybuildersim/Ensemble.java" 2>&1 | grep -v "Picked up"
if [ ! -f "$CLS/ham/citybuildersim/Ensemble.class" ]; then echo "compile failed" >&2; exit 1; fi

for P in $POLICIES; do
  for S in $SEEDS; do
    CSV=$OUT/$P-$S.csv
    if [ "$RESUME" = "1" ] && [ -f "$CSV" ] && grep -q "^$P $S " "$OUT/times.txt"; then continue; fi
    LINE=$(java -Xmx2g -Djava.io.tmpdir=$E/tmp $JAVA_OPTS \
          -cp "$CLS:$TREE/build/classes:$GSON" ham.citybuildersim.Ensemble "$P" "$S" "$CSV" 2>&1 \
          | grep -E "^DONE" | tail -1)
    echo "$LINE"
    # DONE <policy> seed <s> months <m> of <end> in <secs>s ...
    if [ -n "$LINE" ]; then
      grep -v "^$P $S " "$OUT/times.txt" > "$OUT/times.tmp"; mv "$OUT/times.tmp" "$OUT/times.txt"
      echo "$LINE" | awk '{sub(/s$/, "", $10); print $2, $4, $6, $10}' >> "$OUT/times.txt"
    fi
  done
done

BASE_ARG=""
if [ -f "$BASELINE" ] && [ "$BASELINE" != "$OUT/summary.json" ]; then BASE_ARG="--baseline $BASELINE"; fi
python3 "$E/score.py" "$OUT" $BASE_ARG --summary "$OUT/summary.json" | tee "$OUT/score.md"
