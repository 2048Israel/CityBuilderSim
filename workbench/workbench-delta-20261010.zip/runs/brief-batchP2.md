# Brief: P2, automatic building and the build advice. 0.7.101. 2026-10-10

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## Jerus's decisions (2026-10-10, the project doc `claude/decisions-2026-10-10.md` A4, A5, A6, A19 and B, quoted here: you cannot reach the project)
- **A4, automatic building is fragile** (one early refused order spirals into debt): "Fix it", with his diagnosis, verbatim:
  > "also 4 one reason is cause it doesnt actually target the best, it targets the optimal to satisfy the next few points not long run, thus it builds wind farms instead of coal powerplants, and at first it doesnt build schools even tho it has the money purely cause sure its at 0% but building one would put it at 20000%, also for some reason some checks to check revenue, while the real thing is only debt to gdp ratio, and also one should have the option for beyond 300%. and 6, have the default at 240%."
- **A5:** auto-build on an over-full city bought its whole 5.66M sq ft deficit ($432.8M) for a $45.8M road -> **buy only the order's own ground.**
- **A6:** the debt limit -> **default 240% of a year's GDP, and the dial goes past 300%.**
- **A19:** Build's advice prices no overshoot on power, water and roads ($4.95B coal plant: 89% -> 670% served) -> **price it as care does, without stopping a first building where there is none** (his school at 0% -> 20,000%).
- **B:** the build advice says when an iron field won't pay back for a small town.

So P2 must:
1. **Choose by the long run:** each candidate's cost over its life per unit it serves, with its ground, as the roads' 20-year pricing does (`BuildAdvice`, 0.7.70) - not the cheapest way to cover the next few points. Every figure from the model's own constants (prices, upkeep, fuel, life, land); no invented numbers. Show what this picks for power in the playtest city and in a copy of `jerus-1008` (wind or coal, and why).
2. **Build the first of a kind where there is none,** even when one overshoots by far (a school at 0% coverage).
3. **Gate on debt to GDP alone:** remove the revenue checks from the pass (`AutoBuilder.revenue()`, `budgetRoom()`, `REVENUE_MONTHS` and whatever reads them - find them all). ★ what, if anything, stops a city from building staffed services it cannot run, once revenue no longer gates it - say it plainly in your notes; don't add a new gate he didn't ask for.
4. **The limit:** `DEFAULT_DEBT_LIMIT` 240%; the dial past 300% (★ its range and steps). ★ what an older save's stored limit becomes.
5. **Survive an early refused order** (`runs/fixRD4-notes.md` §7: `-Dplaytest.autobuild=true` ended with 2,626 people; at month 60 an order was refused for $0.28M, then the city never gained jobs, ran deficits and passed its limit about month 1000). Find the mechanism that turns one refusal into a spiral and fix that, not the symptom. Measure the auto-built playtest before and after.
6. **Buy only the order's own ground** (A5; `fixN6-notes.md` §6 N6-2 to N6-5, §8).
7. **A19, the advice's overshoot for networks:** price it as care's `perPlaceNeeded()` does for power, water and roads (`fixN4-notes.md` §7; `FinancesScreen.serviceCard()` computes the share itself; `AutoBuilder.annualGdp()` mirrors `ui.Pieces.annualGdp()`), keeping rule 2.
8. **B, iron that won't pay back:** the advice says so for a small town, by the same pay-back test `fixN5`/`fixL` use (grep "pay back" in `/home/claude/runs/records/todo.md` near line 1690).
9. **Words** wherever the advice, the auto-build card, its dial or its notices say what changed; every string fits at 1,389 x 868.

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| P2 | 0.7.101 | named in the launch prompt | `/home/claude/scratch-p2` | **moves them**: re-baseline the playtest as `pt07101` in your scratch against the reference the launch prompt names, explain every move; then the ensemble (label `07101`, `BASELINE` the launch prompt names); report, don't tune |

## Read first
`docs/map/AutoBuilder.md`, `docs/map/BuildAdvice.md`, `docs/harnesses.md` (AutoBuildCheck, BuildAdviceCheck, RoadCheck, ChildcareCheck), the notes `fixN4`, `fixN5`, `fixN6`, `fixRD4` §7 (`/home/claude/runs/`), and the todo items around `/home/claude/runs/records/todo.md` lines 1570-1585, 1690-1700 and 3720-3735.

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** The suite line of the gate is 90 of 91: HealthCheck stays the known red (by 0.4 points since 0.7.100, a call for Jerus); every other harness green. BuildMenuCheck 101. Harness premises may change only where Jerus's decisions change the rule they assert; list each before -> after in your notes §3.

Reply with: a short summary; what the long-run rule picks for power and why; the auto-built playtest before and after; the default playtest's movement; the ensemble; the gate and your final commit; your ★ calls.
