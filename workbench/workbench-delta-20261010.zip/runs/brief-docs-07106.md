# Brief: the docs pass for 0.7.80 to 0.7.106, in three parts. 2026-10-10 evening

You are a docs pass, on Opus with a fresh context. Your job is prose: comments, javadoc, banners, `docs/*.md` (not `docs/manual.*`), `CLAUDE.md`, `README.md`, and the strings the player sees. They must say what the code **now** does (the tree is 0.7.106). **Change no behaviour,** constant, assertion or tolerance; a bug is a finding for your notes.

Read first, in this order:
1. `/home/claude/runs/brief-shared-git.md` - the rules for every implementer: the Git paragraph, your worktree as the tree, the standing rules (no `rm`, never `/dev` in any form, **every `java` run under `flock /home/claude/jvm.lock`**), the gate, the notes. Where this brief differs, this brief wins.
2. `docs/docs-pass.md` in your worktree - the house brief for a docs pass. **Skip its steps 4 and 6** (the project's records and the manual's line): the orchestrator runs the records. Put what they need in your notes §7.
3. `CLAUDE.md` in your worktree.
4. `/home/claude/runs/docs-0779.md` - part 1 of the first docs pass (0.7.70-0.7.79, merged as fb20b5e): how it worked and what it left.

## Three parts, one after another (a docs pass runs alone)
| part | branch | versions | range (`git diff <a> <b> -- src`) | batches (notes `runs/fix<batch>-notes.md` §7 first, files `runs/fix<batch>-changed.txt`) |
|---|---|---|---|---|
| A | `batch/docs-0792` | 0.7.80-0.7.92 | `f85bcfa 712baa2` | O4, N6, O5, O6, O7, O8, O9, RD1, RD2, RD3, RD5, O10, RD6 (RD4 never shipped) |
| B | `batch/docs-0799` | 0.7.93-0.7.99 | `712baa2 4074708` | O10b, RD7, O11, O12, O13, O14, W1 |
| C | `batch/docs-07106` | 0.7.100-0.7.106 | `4074708 75bac03` | P1, P2, P3, P4, P2b, P6, P5 (and R1: CLAUDE.md's save rules) |

Each part starts from `main` after the one before has merged. Your range says **where to look**; the truth is today's code. A sentence your range made false that a later version changed again must be true of the code as it is now. Leave prose outside your range to its own part, unless a sentence in your files is plainly false.

The batches' §7 lists what each left for the docs: dials without a sentence, harness sections and labels, month-order, `CLAUDE.md`'s rows and counts, banners, the Inbox notice list. Work through those first, then the diffs. The todo's docs pass item (`/home/claude/runs/records/todo.md`, grep "THE DOCS PASS FOR 0.7.70") collects many of them.

## Do
1. **Read your batches' notes §7 and your range's diff**, file by file (`docs/map/<File>.md` for where a member is; `tools.Where` for what moved). Fix every comment, javadoc, banner, header and player string that is now false, in the file's own voice. Your versions' `GameVersion` entries must agree with each other and with the code.
2. **Dials:** every `static final` your batches added has one sentence above it.
3. **Harnesses:** every section your batches added prints `--- title ---` and labels its assertions. Fix labels only where false; never an assertion.
4. **Player strings** your versions added fit at 1,389 x 868; change only false words.
5. **`tools.Stale`:** firm stays 0; work its soft list for your files and say how many you closed.
6. **Part C only:** `CLAUDE.md` and `README.md` counts and the tree's shape, `grep -c`ed (harnesses, buildings, sectors, files); `CLAUDE.md`'s rows for the classes 0.7.70-0.7.106 added or reshaped (FuelSplit, StatementView and the others parts A and B list in §7); the Inbox notice list if `CLAUDE.md` keeps one; and its standing rule "Write fixes to the PC without asking ... byte-for-byte", which describes the old file route: say instead that GitHub is the source of truth, the orchestrator pushes and the PC pulls (`claude/git-workflow.md` in the project; you cannot read it, so keep to those words).
7. **Regenerate the indexes last** with `tools.Maps`, from your worktree's root against your built classes (under the lock). Commit them with your prose. If Maps rewrites a file only for its date line, put the old one back with `git -C <path> show HEAD:<file> > <file>`.

## The gate (your tree, your scripts, under the lock)
Copy `/home/claude/scratch-gate/{build,suite,pt,bmc}.sh` into your scratch, changing every `/home/claude/scratch-gate` to your scratch and every `/home/claude/git/CityBuilderSim` to your worktree; run each under `flock /home/claude/jvm.lock`.
- both builds silent;
- the suite: 91 of 91;
- BuildMenuCheck PASS, 101 of 101;
- `tools.Stale` 0 firm;
- the playtest **byte-identical** to `/home/claude/scratch-ui1/orch-gate/pt07106/`: a docs pass moves no trace;
- `git -C <wt> ls-files --eol`: no `w/crlf` but the `.bat` files.

Then commit your final state, the message starting "0.7.106 docs-07xx:" (your part's id).

## Notes: `/home/claude/runs/docs-07xx.md` (your part's id), at most 100 lines
§0 progress (a line per step, as you go); §1 files changed, a line each; §2 player strings changed; §3 flags (a comment you couldn't settle: the code is right for now, you left a `TODO(docs):` and say why); §4 Stale firm/soft before and after; §5 the gate and your final commit's hash; §7 for the next part and for the records (manual-facing numbers that moved: save format, buildings, harnesses, new dials and notices); §9 outside your files (if any).

Reply with a short summary: files changed, flags, Stale before and after, the gate, the commit hash.
