# Why the builders stall (T1)

*2026-10-10. You asked why your city is construction-bound ("about 500 points a month against 3.1M owed", O10b) and answered "A read-only trace first" (decision A3 of `decisions-2026-10-10.md`). Batch T1 (`runs/fixT1-notes.md`, from `runs/brief-batchT1.md`) traced it on copies of your 1008 city, month 8473 to 8593, and changed no source (the tree at 4074708, 0.7.99, never merged). This note is that trace in plain words, for you and for a session starting cold. Nothing was applied. What you can do in your save today is in section 8; the code options that wait for your word are in section 9; the one choice is in section 10.*

## 1. The answer

**The month is small.** Your builders can do 145,600 points a month: 363 Construction Depots at 400 points each, and the works' own 400. The standing city's repairs take 117,700 of them (1% a year of 141M points of buildings). Repairs are 81% of what the builders can do.

**The workers are sick.** Your cemeteries have been full since month 7839 and you have no crematorium, so about 97,200 dead lie unburied (the model caps the unburied at 24 months of deaths, about 4,050 a month). The unburied add the capped 15 points to the sick rate: 18.8%, not the 3.5% of a well-served city. Sickness cuts the builders' output to 0.812 of what they can do. So 145,600 x 0.81 = 118,250 points, less 117,700 of repairs: about 420 points a month reach all 26 sites. In 17 of 120 months none do (6 for an outbreak, 5 for hunger, 6 while the sick rate settled). That is the whole of it.

## 2. What reaches the sites

The month's points go to the sites by one rule. A site's weight is its buildings on site times its points to the power 0.70 (the crew rule of 0.7.17). Every site gets the same rate for a unit of weight, capped at what it owes, and there is no order among owners. Yours is about 420 over a weight of 90,640: 0.0046 a unit. Over 120 months the sites got 50,337 points in all: 419 a month, at most 591. The player's hand (an order or a rush on the construction page) acts only when set, and your save sets none.

**The jacket.** The Offshore Platform the investors ordered at month 8474 (3,600 points) weighs 308.6 of 90,640, 0.34%. It got 184 points in 120 months: 1.5 a month, none in 17 of them. Nobody is served before it. It is small beside your 14 Crude Units, which take four-fifths of a month that is only about 420 points.

## 3. Why the builders do not grow

The builders' plan asks, in order: is a depot of theirs already on site (one order at a time, `MAX_CONCURRENT_ORDERS` 1); has the work queued 9 months or more; is staffing at 80%; is there ground; then it orders one depot, and then the money is asked. In 120 months the first gate said "already building" 119 times and "Built" once (month 8513, after the old depot's last 8.1 points had taken 39 months). Every other gate, tested alone each month, would have passed. The queue was 9 months or more in 120 of 120 (4,690 months to endless). Staffing passed 120 of 120: every post is offered and filled, and 614,000 people are out of work. Ground passed 120 of 120 (71,847 depots' worth). A depot's estimated profit was above zero 120 of 120 (88,000 to 108,000 a month). The money passed the one month it was asked. Their price for a point of non-material work rose from 285 to 347 (+22%) and stops nothing.

The depot they do order waits in the same queue at its own weight, 400 to the power 0.70 = 66.3: 0.07% of the month, 0.4 points a month. The new depot had 31.4 of its 400 points after 80 months. So the one order on site holds every next one. Every other sector is in the same place. Automotive, Business Services, Food Processing, Heavy Industry, Manufacturing, Mining, Rail, Refining and Retail say "already building" in 120 of 120 months; Oil says it 119 times, and has the jacket; Real Estate is held by its months of work in 120 of 120; Agriculture, Industry and Materials "would take N months to build" in 103 months (and 17 more).

## 4. The closed loop

The dead stay because the cemetery that would bury them is a site. The Municipal Cemetery owes 1,393 points and gets 0.31% of the month: 1.4 points a month, about 1,000 months. While the dead stay, the sick rate stays at 18.8%, the month stays near 420 points, and the cemetery stays at 1.4. Dead, sick, no site output, no cemetery: nothing in the model breaks the circle. Health's header calls the cap "alarming and survivable". In a city whose margin over its repairs is under 15 points it is neither.

## 5. The same trap in your history

Your plots ran out at month 7839, the unburied sat at the cap by month 7862, and the builders' capacity has stood at 145,200 since month 7832. The same trap ran from month 4037 to month 5823: 1,786 months with the sick rate at 0.197 on average. The builders grew 4.3 to 4.6 depots per 100 months in every era, healthy or not (months 2517 to 4037: capacity 49,600 to 76,000; months 5823 to 7839: 108,400 to 145,200, while people went from 3.18M to 5.94M). Repairs caught up with them, and the dead took the rest.

## 6. Who the 3.1M belongs to

At month 8473 the 26 sites owed 2,786,054 points (3,118,816 is their whole orders with the progress already in: the 3.1M of O10b). By owner, points owed and share of the crews:

- **The city:** 14 sites, 2,689,033 points, 88.7% of the crews. One of them is **your 14 Crude Units: 2,607,490 points, 93.6% of everything owed**, with 79.6% of the crews (weight 71,920; 336 points a month). The other 13: the Penitentiary 55,419, the Police HQ 19,328, the Municipal Cemetery 1,393, three schools, four care sites, a road, a wind farm and a desalination plant (690 points, done).
- **Real Estate:** 2 sites (22 Low-Rise, 13 Studio), 59,617 points, 7.0%.
- **Nine sectors, one site each:** 37,404 points, 3.5%. Rail Spur 10,460, Assembly Plant 10,028, Steel Mini-Mill 8,086, Fabrication Works 5,130, Contact Centre 3,158, Iron Mine 421, a snack plant 55, two shops 58, and the builders' own depot 8.1.

So the 3.1M is, nearly all, your Crude Units.

## 7. Against cities that are not construction-bound

The default playtest (the 0.7.99 gate): 545,000 people at month 4002, 111 depots, repairs at 0.32 of nameplate (mean after month 2000), a queue with a median of 3.6 months of site output; the builders lay crews off to the need. The city2400 copy (113,000 people, a 0.7.38 save), 120 months: 46 depots, repairs at 0.16 of nameplate, a queue of 0 in 120 of 120 months, the builders' gate "under 9 months queued" passing 120 of 120. It is land-bound. It runs out of plots too (about month 2512; 6,505 unburied and a sick rate of 0.36 at month 2532), but at 0.16 the builders still out-do their repairs four times over. Neither city reaches your size. What differs is the ratio: your repairs are 0.81 of nameplate (16,500 people a depot, against 4,900 in the playtest), so a 15-point sickness that the others absorb takes your whole margin.

## 8. What you can do in your save today

Both are measured on copies of your 1008 city over 120 months, and need no code.

**A. Death care to the top of the city's order** (the construction page). The cemetery opened at about month 8485. The autobuilder ordered 1 + 1 + 27 more (D$340M). The unburied were 0 and the sick rate 0.035 from month 8497. The sites got 22,635 points a month over the last 12 months (45x). The builders ordered 5 depots, not 1. The queue at month 8593 was 1.61M (2.74M in the base run). The jacket opened at month 8544. People went from 5.985M to 6.019M. The autobuilder placed 33 orders, D$971M (the schools and clinics it had held), against 1 in the base run. Rushing too reached 3.5% in the same month. The cost is no code, but you must move each new death-care site up yourself: a city site placed while an order is set joins at the bottom.

**D. Buy depots** (Build > Industrial; the city pays). 60 depots cost D$18.6M (the city's cash is D$82.4B). The stack is shared with the builders' own order, so it is not a city site and cannot be put first. By the crew rule alone it gave +31 depots in 120 months and 7,640 points a month to the sites at the end, with the sick rate unchanged. With A as well: +67 depots, 44,400 points a month at the end, a queue of 0.76M, the jacket open at month 8522, 6.047M people. It is the cheapest companion to A.

**H. Your call, no code: your 14 Crude Units last in the city's order.** The city's pool (88.7% of the sites' points) then goes to its 13 other sites first. If they were cancelled instead, every other site's share is 4.8 times larger (the jacket's 0.34% becomes 1.65%) and the month is still about 420. With A they move anyway.

## 9. The code options, none applied

**B. Death care first while the dead wait.** A done by the rule: the city's own death-care sites served first while `Healthcare.getUnburied()` is above 0, or the autobuilder setting that order. It breaks the loop by itself, and only the city's sites move, as with A. The cost is a small rule and a harness that causes the trap (no plots, repairs near nameplate). The loop is the bug. **T1's recommendation: now.**

**C. The builders' own depot off the top.** Before the crew rule, and/or `Construction` past `MAX_CONCURRENT_ORDERS`, sized to the gap. Arithmetic, not run: a depot gets 0.07% of the sites today (0.12% healthy); first, it would take 400 of the 420, at most a depot a month (the planner orders one), +325 points a month each at 0.81 (+386 at 0.965), up to +48,000 of nameplate in 120 months. Their history (4.5 depots per 100 months in every era) is why repairs reached 0.81. The cost is a rule in `Construction.plan` / `BuildingManager`. 0.7.17 measured a "small orders first" hybrid: depots bought for rushes then laid off, 13 bank failures in 8 cities against 4. So it needs the ensemble, with retirement (`RETIREMENT_SLACK` .25) watched. It is the structural fix, and its own batch. **T1's recommendation: after B.**

**E.** The investors hold an order the builders cannot hand inside `MAX_ORDER_MONTHS` 12, as the landlords and the autobuilder already do. The jacket (2,496 months) and the nine sectors' starved orders would not be placed: no new point, but their money and their one slot freed. Honest, small; not the fix.

**F.** A floor for the sites under the repairs (repairs deferred). A new mechanic, a repair backlog, and the repairs are the stock's own. Not recommended.

**G.** The share a site gets (`CREW_SCALE_EXPONENT`, a crew per order first). 0.7.17 measured these and chose .70; the trouble here is the size of the month, not its split. Not recommended.

## 10. The one choice for you

Should the code do B (death care jumps the queue while the dead wait) now, and C (the builders build their own depots first) as its own batch, with the ensemble? That is T1's recommendation. B and C are code and not decided. In your save, A and then D need no code.

## 11. How it was traced

A probe (`TProbe.java`) wrote a line a month, the sites, every sector's gates and the oil and depot sites, using only `Game`'s public player actions. Five runs on their own copies of jerus-1008 (base, death care first, death care rushed, 60 depots, both): the base run is deterministic (a rerun was identical). One run on a city2400 copy. The default playtest is read from the 0.7.99 gate's `t-build.csv`. The month's points in the code (lines at 4074708): `BuildingManager.getTotalConstructionCapacity()` L5010, `Construction.strikeCrews()` L152, `Game.getConstructionOutput()` L5203, `EconomyManager.maintenancePointsTotal()` L849, `BuildingManager.siteShares()` L3769 and `waterFill()` L3827, `Health.advanceMonth()` L222, `Construction.plan()` L585.
