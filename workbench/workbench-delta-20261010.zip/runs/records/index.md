# The design notes, by subsystem

A map of the `claude/*.md` documents in this project, grouped by what they are about, one line each. Written 2026-09-18 for the structure audit, from the titles and the changelog's blocks; the line is a pointer, not a summary - read the note. Newer notes are usually the truer ones: where two disagree, the later date wins, and the changelog says which shipped.

The three files a session needs first are `todo.md` (what is open), `changelog.md` (what shipped, newest first) and this one. The published manual (artifact "CityBuilderSim") is the model written out as a whole; since 0.7.3 it is also in the repository as `docs/manual.md` and `docs/manual.html`, generated from the page at each publish.

## Start here

What a session reads first, and the records of the whole.

- `todo.md` - the list of what is open, by section: this week, onboarding, the rebalance, what a new player hits, engine truths, healthcare, housekeeping, the store, not doing
- `changelog.md` - every batch as it was written up the day it landed, newest first; the top block is the state of the tree
- `decisions-2026-10-10.md` - Jerus's answers of 2026-10-10 (00:51, "all rec") to 31 decisions, and the plan of fix batches they make: T1, the read-only trace (done), and as launched P1 0.7.100, P2 0.7.101, P3 0.7.102, P4 0.7.103, P2b 0.7.104 (his 09:47 answer on P2's budget), P6 0.7.105 (the refinery's run, after his word at 01:09) and P5 0.7.106; the todo's section 0 carries the plan and each CONFIRM list says which decision answered it
- `the-fixes-from-the-decisions.md` - 0.7.100 to 0.7.106 (2026-10-10), the fixes from Jerus's decisions built in seven batches (P1, P2, P3, P4, P2b, P6, P5) and shipped through GitHub: the checks (HealthCheck's depot, MapCheck on thread CPU, the ensemble's S1 and H1 restated), automatic building and the build advice (the long run, a first of a kind from cash, a 240% limit counting all the city owes), the budget and the books (four more lines inside the budget, statements at the close, borrowing costs over each debt's life, the fund at the desk's bid), oil and roads (a fuel duty, the reserve's tanks, the lubricants cap, each road its own upkeep, the test player's roads by need), a smarter budget for automatic building (essential services skip it, the rest by payback), the refinery's run (a crude unit runs only the barrels that pay, the planner's prices at the margin, an MR's cargo kept free in the Tank Farms, the refiners' building freed of its own crude units) and prices and rules (wages in the grocers' and stations' test, care rows less the priced out, a 25% salvage, a founding lake of fresh water, Insane's bond on the plots owned); what each did to the playtest, the auto-built cities and the ensemble, the ★ calls, and the fifteen calls that are his; not yet seen on the PC
- `splitting-the-interface.md` - the plan for taking UserInterface.java apart into a ui package one screen per class, measured on the file, and the record of each batch as it landed - done 2026-09-18, twelve screen classes and the toolkit; §13 is the docs pass, a fresh-context agent that runs at the end of every batch
- `the-prose-that-stopped-being-true.md` - tools.Stale and StaleCheck, 2026-09-18: the mechanical half of the docs pass as a tool; what is firm, what is soft, the false positives tuned out, and the 84 dead javadocs the first run found
- `splitting-game.md` - four mechanics out of Game.java (Motoring, LuxuryCounter, Offending, CityBasket), 2026-09-18, playtest byte-identical; and the two-agent experiment - implementer and docs pass - with what it cost and what it needs
- `the-ai-ergonomics-audit.md` - 2026-09-18: how the repository and these docs are arranged for an AI to work in, what was changed (the generated indexes, CLAUDE.md, this split) and what is recommended next
- `handoff-after-the-sector-template.md` - the cloud working loop written out for a session that starts cold: staging, build scripts, verify copies, git
- `the-price-at-the-door.md` - healthcare fees as a dial (0-15x) and an insurance premium off wages, 2026-09-19: the household that goes without care rather than without food, the three corners, the eight-seed ensemble, the break-even that founding fees cannot reach
- `the-treasury-bridge-opens.md` - the Government tab's "everything else" row opened into a named journal, the desk's re-mark line and why the desk loses, 2026-09-19; the bank that never pays for the city's paper, found on the way
- `land-in-dollars.md` - 0.7.6 (2026-09-23): land priced in US dollars and paid at the day's rate, by converting cash (the default) or out of the vault, a toggle at the top of the land office; one `ui/Ladder` for every policy dial; a price per kind of school with a row per kind (places, students, cost, revenue); real GDP in layers, C, I and G stacked under the line with net exports the gap; and why converting for land puts no push on the currency - open, Jerus's call
- `financial-crisis-of-2045.md` - 0.7.5 (2026-09-23): Enter builds and Backspace clears on the build rail; the Reports page redrawn — two pinned small charts as a preference, two real axes before the 0–100 squash, a crosshair, recessions shaded, the named episodes (`YearBook.episodes()`, the "little name generator") ticked under the chart and in the year book, the picker folded with a filter, a log switch
- `every-tax-at-once.md` - the housekeeping of 0.7.4 (2026-09-23): the inflation target as a dial, the price of money three ways on the strip, the sector list's sparkline and "show more" on two new history series, and a base rate per income tax with the old city rate as "every tax at once"; the load-path trap that would have merged a split
- `why-the-dear-city-is-hungrier.md` - HealthCheck's red line traced (2026-10-01, made while Jerus slept, nothing changed): 0.7.17's crews by size and the builders reading output after repairs stall the fixture's first depot, the dear twin never grows and its shops end banned; the 0.7.12 "46%" was the hunger line's one city-wide rationing share; the row's care split and care on credit; options O1-O5 for Jerus
- `the-manual-at-0-7-23.md` - the manual artifact brought to 0.7.23 (version 11, 2026-10-01, made while Jerus slept): eight versions at once, a new section for the builders and the player's hand on the queue, the screen split from time, saves and logs, five places version 10 had wrong, how two Opus contexts made it, the quotes checked against the record, nine places the tree's prose disagrees with the code
- `the-manual-at-0-7-15.md` - the manual artifact brought to 0.7.15 (version 10, 2026-09-28): twelve versions at once, "Debt & the bank" split into the city's borrowing and the bank, a new section for founding a city, six places version 9 had wrong, how two Opus contexts made it, eight places the tree and the records disagree with the code, and the GitHub copy regenerated
- `the-manual-at-0-7-3.md` - the manual artifact brought to 0.7.3 (version 8, 2026-09-22): the new central-bank section, eleven stale places reading the page found, how three Opus contexts made it, sixteen places the prose disagrees with the code, and `tools.ManualToMarkdown` — the manual in the repository as `docs/manual.md` and `docs/manual.html`, generated from the published page
- `the-manual-at-0-6-7.md` - the manual artifact brought to 0.6.7 (version 7, 2026-09-18): the new transport section, what reading the published page found stale, how three contexts made it, and twenty places where the tree's prose disagrees with the code
- `the-documentation-catches-up.md` - the manual artifact brought up to 0.5.15; what the manual is and how it is versioned
- `the-year-book-as-csv.md` - 0.7.16 (2026-09-28): the year book's and decade book's tables written again as CSV beside the text from one `YearBook.Table` (four files, RFC 4180, the text's own strings, no BOM), why CSV and not xlsx, YearBookCheck section 15 and its seven-mutation test, and the small items left for Jerus
- `the-year-book.md` - the year book and decade book the game writes so a run can be read without a save: FLOW/LEVEL/RATE rules, columns
- `reading-slot-3.md` - the decade book of Jerus's slot-3 city read end to end: the founding currency collapse, the students' orphaned children, the decade-22 bust, the branch-capped bank
- `reading-the-numbers.md` - how to read a playtest's figures without being misled by them
- `the-whole-codebase-audit.md` - 2026-09-10: every file read for money that leaves a pool without arriving in another
- `audit-2026-09.md` - the earlier conservation audit
- `analysis-2026-09-06.md` - a mid-project reading of what the simulation was doing
- `simulation-findings.md` - findings from the long runs, collected
- `known-bugs-backlog.md` - bugs known and not yet taken
- `design-queue.md` - design items queued before the sector template
- `steam-readiness.md` - what a Steam build needs and what was still missing

## Money, the bank, the currency and the world

The commercial bank, the central bank (built in 0.7.0; the curve, the holders and the holdings dial in 0.7.1; the currency under it in 0.7.2; the demand channel in 0.7.3; the bank as a business from 0.7.7), the float, capital flows and the audit that ties every pool.

- `commercial-bank.md` - the bank as a design: deposits, leverage, branches
- `bank-as-a-bank.md` - the bank made to behave like one: its own cost of money
- `bank-tax.md` - the bank pays profit tax
- `the-bank-prices-its-own-deposits.md` - deposit pricing from the bank's side
- `why-the-bank-kept-failing.md` - the bank's failures traced: construction in progress on nobody's balance sheet, and more
- `the-bond-that-broke-the-bank.md` - part two: the long bond's valuation on the bank's book; fixed 2026-09-14
- `nothing-borrows-below-cost.md` - no lender lends below what its money costs it; the rate floor
- `the-lender-gets-a-gap.md` - the shortfall a lender is allowed before it calls a loan
- `business-credit.md` - private-sector borrowing: loans, restructuring, default
- `the-currency-was-the-bank.md` - how the currency and the bank were one thing, and why they were separated
- `central-bank-research.md` - what a central bank would do here; research
- `central-bank-plan.md` - the plan that came out of it
- `the-reserve-money-printer.md` - reserve money and where it comes from
- `the-vault-and-the-record.md` - the vault (cash) against the record (the books)
- `hot-money.md` - capital that arrives chasing a spread and leaves when it closes
- `the-carry-trade.md` - borrowing abroad to lend at home; the carry borrowers and their risk
- `where-the-dollars-go.md` - the foreign currency's path through the city
- `foreign-debt.md` - the city borrows in somebody else's money
- `exchange-rate-progress.md` - the float, as it was being built
- `foreign-exchange-design.md` - the exchange rate's design: pressure, drift, reversion
- `a-reserve-defends-a-currency.md` - the 0.6.9 year book read (a model with no nominal anchor), the vault kept in dollars, the founding reserve, why a reserve damps only a fall, and prices and the rate on the strip, 2026-09-21, 0.6.10
- `the-central-bank.md` - the design for 7.0: a floor system, households holding the city's paper, QE and QT, the overdraft as advances with a ceiling, M0 and M2 on a page, and the batches A to E, 2026-09-21
- `the-bank-that-never-paid.md` - batch A of 7.0, the ground: the bank never paid for the city's paper (the snapshot taken after the clear), wages held to the index on the two-year lag, what the policy rate does to inflation measured before the central bank, and the emergency note's free money found holding a floor, 2026-09-21, 0.6.11
- `the-central-bank-opens.md` - batch B of 7.0, the books and the floor: the central bank's balance sheet (M0 its liabilities, money made and destroyed only there and declared to the audit), the bank's reserves paid the policy rate and its shortfalls lent at the window, `CITY_DISCOUNT` deleted, advances to the treasury with a ceiling and Jerus's arrears rule ("pay promises first, cut the rest"), the autopilot, the Money page with M0 and M2, and the strain premium found counted twice, 2026-09-21/22, 0.7.0
- `the-curve-and-the-holders.md` - batch C of 7.0, the curve and who holds the paper: a term premium by maturity over the dial (five points, 10 to 50 years) and term loans only at those five, the households, the central bank and the bank as the three holders of the city's paper, the holdings dial (QE and QT) and the compression it buys at the long end, the discount accreted over the paper's life, and batch B's found-on-the-way list closed, 2026-09-22, 0.7.1
- `the-currency-off-its-rule.md` - batch D of 7.0, the currency under a central bank: the inflation drift deleted and the rate moved by the real rate differential instead (`RATE_PULL` 4, the caps turned into guards), a defence that spends the vault as a capital transaction against the world (M0 unmoved, the central bank's equity down), the dial to 100% and the advances ceiling a dial, the world's paper on its own curve and the dollar-quote money pump closed, and empty household cells folded, 2026-09-22, 0.7.2
- `the-demand-channel.md` - batch E of 7.0, the households' response and the harness: what a household spends above a basket a head answers the real deposit rate (`SAVING_RESPONSE` 1.0, held between ½ and 1½), `MonetaryCheck` §6 asserting that inflation falls with the rate (1.032 points from 3% to 40%, most of it still the currency's), the exchange rate's guards moved to a billion either way, EI paid in the month it is credited, the bank's deposit quote capped at its lending rate, and why the channel moves so little — a shelf priced by coverage and its floor rather than by money, 2026-09-22, 0.7.3
- `the-rate-that-stops-the-cranes.md` - Jerus's 0.7.5 year book read against the code (2026-09-23): the autopilot on until about 2050, two inflations that were rent under a labour shortage, the housing stock standing still; eight seeds a setup from a 0% to a 25% dial; the mechanism — a landlord that will not build on credit past a few points, and rent floored on its own interest bill — a loop with a gain above one, which the strain premium deepened; what it means for the outside brief
- `the-bank-as-a-business-plan.md` - the research (Canada's big banks: prime at the dial plus 2.20, a deposit beta of ~0.4, losses ~0.4% of loans, CET1 11–13.5%, the window at the target plus a quarter point, IFRS 9's stages, TARP) and the plan in three batches — pricing and fees, capital and payout, the Bank tab — and the six questions put to Jerus, 2026-09-23; step 1 of the order agreed after the diagnosis (the bank, then housing against the rate, prices that answer spending, a smaller founding treasury, a negative floor only if needed)
- `the-bank-prices-like-a-business.md` - 0.7.7 (2026-09-23), batch 1 of the bank as a business: the strain premium gone and a loan priced from its four costs (the funds-transfer price, running costs, a through-the-cycle expected loss, a capital charge at the owners' 12.5%), prime a sound business's rate; savers paid a share of the dial the bank's funding sets, bounded by the margin after costs and by the savers' share of it; an account fee and a loan fee; the window at the dial plus a quarter point; dividends after tax; why the expected loss is a constant, the held-10% catch, and what the eight seeds and the two stress setups measured
- `a-sector-is-many-firms.md` - 0.7.8 (2026-09-23/24), batch 2 of the bank as a business and the four rounds it took: the loss allowance in two stages, the bank's own capital target capped at the Basel stack (`MAX_BUFFER`), a payout rule and lending that tightens with capital, its own shares booked as capital; 92 failures as first built because a whole sector was one borrower, and Jerus's option C — a sector defaults a slice at a time off Merton's curve (`ASSET_VOLATILITY` 0.25), the whole-sector restructure only the backstop, the allowance staged firm by firm, loans priced by the curve on the last quarter's statements, a failing sector's plant sold to the builders for its material, the buybacks and the desk held to spare capital; syndication tried and deleted; 39 failures, every one a lending loss on a sector holding 30–73% of the book
- `the-bank-tab.md` - 0.7.9 (2026-09-23), batch 3 of the bank as a business: the Bank tab rebuilt — a status sentence, a scorecard of eight and the ladder of its rates from the policy rate to every borrower, then Profit, Lending, Funding, Capital & owners and History; every figure a model getter (`Bank`'s WHAT THE BANK TAB READS), a year of the bank's statements saved, what the old tab worked out wrongly; nothing the bank decides moved
- `founding-a-city.md` - 0.7.10 (2026-09-24): the endowment cut to D$100M and US$25M (the city borrows for its big works; the vault at three months of a young town's imports); the Found a city screen (a name, the money named after the city or typed, four presets priced at invoices, the world's inflation off Settings); the currency a value per city; old saves as Danzik and DZD; the sticker is not the invoice; 42 fixtures that lived on the old treasury
- `the-landlords-take-a-mortgage.md` - 0.7.11 (2026-09-24), the housing-against-the-rate step: the landlords' 3-year bullets replaced by insured CMHC-style mortgages (15% down, 85% loan-to-cost, 1.20× coverage, 40-year amortization fixed for 10), the city as insurer (premiums to the treasury, claims to the bank, 0% risk weight); round 2's Basel leverage ratio, branches that close, and dividends after principal; the bank's failures traced to concentration, `MonetaryCheck`'s allowance re-measured, and the smaller default city traced to crime
- `the-firms-sell-bonds.md` - 0.7.12 (2026-09-25/26), corporate notes and bonds over eight rounds: a 10-year bond bookbuilt beside the bank loan and traded with shares on one order book (the dealer gone, the desk a participant with caps, buybacks as bids, no special dividend), concentration priced by Basel IRB, recoveries by instrument (75% loans, 45% bonds), nothing lent past the default point on the quarter; then how a firm that can't pay ends — the BIA cash-flow test, credit lines that stay open under rationing, interim financing ranked first, and "buy only what it can pay for"; Luxury Retail's swing a price nobody paid; failures 115 → 1 (default); ships with HealthCheck's hunger gap red
- `rolling-what-falls-due.md` - 0.7.13 (2026-09-26), housekeeping: the land office prices in the paying currency and km², buys short on a funding page (local or dollar paper) and N plots at once; new games on the autopilot; the treasury's rollover (by hand / same structure / 12-month notes, net of last year's surplus, sized to the cash - and the Lean seed that spirals, with nothing capping a city's paper at home); the Bank tab's Balance sheet page, a year ago beside, equity as paid-in and retained, deposits a memo
- `the-city-takes-the-shares.md` - 0.7.14 (2026-09-27), the treasury batch: the city's fund (a dial of 0–300% of the year's surplus, Norway's 70/30, 10% cap and 3% transfer, the player's hand), a failed bank resolved for its shares (old owners wiped out, the hole paid by the city with the central bank advancing, nothing from outside; the stake falls only with new issues), TARP preferred for a bank under its minimum (a popup, 5% then 9%, repaid at three years from spare capital and new shares, warrants), the Insane start (D$0, US$0, a US$2.1M 3% dollar land bond, borrow first), and the reload rate fixed
- `the-central-bank-as-backstop.md` - 0.7.15 (2026-09-27/28): Insane runs from day one and the time skip runs on an empty treasury, both on the central bank's advances; the inflation target to 20% and the strip's colours read from it (red at target + 5); the holdings dial to 100% as a backstop — it buys the bank's paper then the households', rolls what it holds at issue par for par as the Fed does, the city's rate floor split by who holds the paper, and last year's surplus paying the market then the central bank
- `balance-of-payments.md` - the current and capital accounts, and that they must sum
- `devaluation-elasticities.md` - how exports and imports answer a weaker currency
- `import-substitution.md` - what the city stops importing as it learns to make it
- `money-creation-does-not-ship.md` - bank money creation built and measured, and held back
- `why-there-is-no-inflation.md` - why the price level does not rise, decomposed; the addenda carry the decomposition
- `why-easy-money-does-not-inflate.md` - 2026-10-04, research only, on 0.7.41: Jerus's question why 100% QE, a 20% target and 0% rates gave almost no inflation, answered with a probe on both research cities - the model made only cost-push inflation, every push a one-off level step, and no price in the index read money; QE bought nothing where no term paper was outstanding, the autopilot sat at the 0% floor until inflation passed 18%, and "the beginning" was a young city's trade deficit; the links ranked by how much each blocks inflation under easy money, and what would have to exist for it to inflate (built in `inflation-that-answers-to-money.md`)
- `spec-inflation.md` - 2026-10-04, the design study for 0.7.42 and 0.7.43 (P1a), measured on a prototype of 0.7.41: expected inflation as the target weighted by credibility plus recent inflation, the money constants drifting at it; wages taking half their indexing from it; the currency drifting at its credible part; groceries clearing on demand at a price capped at 1.5× the cost floor, the poorest priced out of the allocation; the index covering meals, luxury and services with luxury's weight capped at 15%; a food assistance dial defaulting to 0; the two things that failed and were changed, and what stayed open
- `inflation-that-answers-to-money.md` - 0.7.42 to 0.7.45 (2026-10-04/05), Jerus's question answered and built in four versions by fresh Opus implementers: expected inflation anchored on the central bank's credibility (0.7.42); groceries and every other seller's price answering to what people would spend at each price (0.7.43); what the five-policy ensemble found fixed (0.7.44); the whole price model on the screens (0.7.45); the ensemble (16 seeds each) from 8 of 15 criteria at 0.7.41 to 22 of 25 at 0.7.44, with A2, S1 and H1 left failing for his word; deployed and verified as tag 1005a; not yet seen on the PC
- `the-world-a-city-is-founded-into.md` - world prices, world inflation, what the founding year looks like from outside
- `the-two-hundred-year-plateau.md` - why cities stop growing at two centuries
- `deflation-was-not-decline.md` - falling prices read as a crisis that was not one
- `prices-mean-something.md` - prices made to carry information: the first price pass
- `the-price-that-stopped-being-a-price.md` - a price that had become a constant, and its repair
- `a-reform-is-only-a-change-of-units.md` - the currency reform (redenomination) as a change of units and nothing else
- `money-conserved-and-students-in-flight.md` - the conservation audit passes; students in flight between cities
- `conservation-fixes.md` - fixes that closed the money audit
- `the-gap-after-the-audit.md` - a leak that opened after the audit line; fixed 2026-09-12
- `the-sign-of-a-residue.md` - a residue in the books with the wrong sign, 2026-09-16
- `the-figure-that-was-not-a-figure.md` - a displayed figure that was not a measured one, 2026-09-16
- `outward-investment.md` - the city's savings invested abroad
- `the-surplus-has-nowhere-to-go.md` - a surplus with no asset to sit in
- `the-savings-that-cannot-be-spent.md` - household savings that the model would not let households spend, 2026-09-14

## Treasury, debt, taxes and the national accounts

The city's own borrowing, what it taxes, and the books it keeps.

- `treasury-and-debt-service.md` - the treasury and what its debt costs by the paper it is owed on
- `debt-rate-curve.md` - the rate the market quotes the city, by term and by credit
- `debt-system-fixes.md` - fixes to the debt system
- `debt-quotes-on-screen.md` - a loan's cost worked out before the player agrees
- `debt-buyback-and-long-bond-repricing.md` - buying the city's own paper back; the long bond repriced
- `bond-instruments-rebuilt.md` - T-bills, medium and long bonds rebuilt
- `tbill-shortfall.md` - when the bills do not cover the month
- `policy-tab-and-vat.md` - the policy tab and the sales tax (VAT) ledger
- `vat-accounts-and-duplications.md` - VAT accounting and the double counts it exposed
- `property-tax-and-solvency.md` - property tax and whether households and firms stay solvent under it
- `the-taxes-area.md` - the taxes area of the policy screen, 2026-09-14
- `whose-cost-is-it.md` - which party bears a cost in the books, 2026-09-15
- `national-accounts.md` - GDP and the national accounts as the game keeps them
- `gdp-cannot-go-negative.md` - a GDP that went negative, and why it must not
- `the-books-tell-the-truth.md` - the sector books made honest, 2026-09-09
- `model-fixes-fund-and-transit.md` - 0.7.46 to 0.7.49 (2026-10-05), Jerus's "go for the model fixes, manual up to date and also, the city fund" and "for transit, fix the leak": a triage of the open model bugs (eighteen built; items 16 and 22 dropped with proof), the load path and saved flows (0.7.46), government, labour and accounts with the wage floor in today's money, where B8 moved the default playtest a lot (0.7.47), the city fund's withdrawal dial from 0 to 10% a month (0.7.48), the treasury paying transit's bill and households choosing by their own commute's cost (0.7.49); the manual brought to 0.7.49 as version 12; the ensemble 22 to 20 of 25 (K2 and R3 new fails); deployed and verified as tag 1005b; not yet seen on the PC

## Sectors, firms and investment

The sector template, each sector's own note, private investment and the rebalance.

- `the-sector-template.md` - one class extending Sector per business; the registry; what the five handlers became
- `the-eleventh-sector.md` - Food Processing
- `business-services.md` - the eighth sector
- `manufacturing.md` - the ninth
- `farms.md` - Agriculture
- `food-market.md` - the food market before the thirteen-food shelf
- `food-industry-books.md` - the food industry's books
- `shops-paid-for-what-they-sell.md` - retail pays its suppliers
- `steel-and-heavy-industry.md` - ore to steel; heavy industry
- `the-unit-of-material.md` - the material unit and what a unit of it costs
- `a-firm-that-cannot-pay-sheds-plant.md` - distress: bankruptcy declared, overdraft forgiven, plant shed on a two-year fuse
- `private-investment.md` - how a sector decides to expand
- `investment-brake-and-forecasts.md` - the brake on investment and the forecasts it reads
- `real-estate-foresight.md` - real estate builds ahead of demand, within limits
- `the-crew-a-building-can-use.md` - 0.7.17 (2026-09-28/29), round 1 of Jerus's fixes from his 0.7.14 city: every building gets the crew it can use (Bromilow's exponent 0.70, water-filled, nothing parked), one wait an order would have for every planner and the build quote, the builders counting repairs and staffing, the landlords holding 12 months of work and stepping down to a smaller home, arrivals bounded by the placement's room, payroll by job type with idle crews laid off; four versions and why V3 shipped over Jerus's hybrid; what is open
- `why-the-builders-stall.md` - 2026-10-10, batch T1 (read-only, no code): why his 1008 city is construction-bound, about 420 points a month to 26 sites that owe 2.79M: repairs at 81% of the builders' capacity, the unburied dead and the sick rate's cap, what reaches the sites, why the builders do not grow ("already building" 119 of 120 months), the closed loop and the same trap in his history, who the points are owed to (his 14 Crude Units, 93.6%), cities that are not construction-bound, what he can do in his save today (death care first, buying depots), and the code options B and C for his call
- `the-exchange.md` - the stock exchange: listings, the company index
- `the-owners.md` - who owns the firms; dividends
- `every-building-pays-to-stand.md` - maintenance on every building
- `the-wind-farm.md` - a power building added
- `the-good-that-stopped-existing.md` - a good removed from the catalogue, and what referenced it, 2026-09-15
- `the-shelf-comes-apart.md` - groceries become thirteen foods, each its own invoice, 2026-09-15
- `a-meal-out-is-food.md` - Restaurants, the fifteenth sector: a meal replaces groceries, 0.6.7
- `the-car-goes-last.md` - households buy cars, and the car is the last thing bought, 2026-09-17
- `and-they-borrow-for-it.md` - households borrow for the car, 2026-09-17
- `the-statement-opens.md` - the sector statement's lines open into their detail, 2026-09-16
- `jobs-beyond-the-stalemate.md` - when the labour market stalls: jobs beyond it, 2026-09-12
- `the-rebalance-stage-one.md` - the household economy on real figures: wages, build costs, yields
- `the-rebalance-stage-two.md` - everything else on real figures: the buildings' capital costs, the iron band, the endowment
- `deploy-manifest-rebalance.md` - the files the rebalance shipped in
- `the-founding-endowment.md` - the cash a city is founded with, and why it is what it is (superseded for the figures by `founding-a-city.md`, 0.7.10)

## Transport

Roads, the freight band, the modes, the railway, the vehicles.

- `infrastructure-roads.md` - roads: capacity, load, throughput
- `three-roads.md` - three road kinds instead of one
- `transport-and-the-freight-band.md` - step 1: transport as a cost band on freight, 2026-09-16
- `the-freight-band-and-the-three-loads.md` - step 2: the three loads on the band
- `the-modes-and-the-fare.md` - step 3: the modes and what a fare is
- `the-railway.md` - step 4: the Rail sector
- `the-fourth-link.md` - vehicles, steps 5a and 5b
- `the-fifth-link.md` - step 5c: the cars
- `the-sixth-link.md` - step 5d: the vans
- `a-ride-is-not-a-month.md` - 0.6.6: a ride priced as a ride, not a month, 2026-09-18
- `spec-roads-and-ports.md` - Roads, islands and ships: a design study by another AI (2026-10-08, read-only on 0.7.79; Jerus adopted every recommendation on 2026-10-09): why the map looks wrong (five faults, all in the map code), streets by need and road by surface (cells with arterials, homes cells of long blocks, estate cells with a spine, the surface ladder, tracks), highways straight by preference with no building beside them, lots and streets in the model (RD4, built and dropped), islands linked by two ports and a Highway Bridge over fresh water only, ships on routes; its Python prototypes are in `roads-prototype/`; built as RD1 to RD3 and RD5 to RD7 (0.7.87 to 0.7.94; RD4, lots and streets in the model, was dropped), see `the-streets-by-need.md`; the islands, ships and the crossing wait for the Earth pack and the ports, see `todo.md`

## People: population, households, labour, education, health, crime

The pyramid, the households and their books, the labour market, the schools, the sick, the offenders.

- `population-revamp-phase-1.md` - the age pyramid replaces the headcount
- `population-revamp-phase-2.md` - births, deaths, ageing across the bands
- `population-goes-live.md` - the pyramid becomes the only source of population
- `workforce-and-the-people-screen.md` - who is in the workforce; the People screen
- `residents-per-job-and-the-tier-matrix.md` - residents per job and the tier matrix households are sorted by
- `household-books-per-tier.md` - household income statements per tier
- `household-balance-sheet.md` - assets and debts per household
- `every-household-keeps-its-own-books.md` - every household cell keeps its own books, 2026-09-10
- `household-cash-flow-redo.md` - the household cash-flow screen redone
- `household-screen-readable.md` - the household screen made readable
- `the-households-remember.md` - households carry memory month to month, 2026-09-11
- `the-people-the-books-left-out.md` - the retired, the students, the prisoners, the orphans, the out of work: households of their own
- `the-running-totals-of-the-dead.md` - cumulative death records by cause
- `the-long-sick.md` - long-term sickness and its rate
- `workforce-sickness.md` - sickness in the workforce
- `healthcare-buildings.md` - the healthcare buildings
- `healthcare-funded.md` - how healthcare is paid for
- `healthcare-mortality-and-births.md` - care coverage moves mortality and births
- `healthcare-panel-and-endowment.md` - the healthcare panel, and the endowment
- `pensions-and-cheaper-housing.md` - pensions, and housing made affordable to the retired
- `labour-market-design.md` - the labour market's design: bands, premiums, the floor
- `labour-market-built.md` - the labour market built
- `labour-mobility.md` - who moves between jobs and cities
- `the-chart-you-can-move.md` - 0.7.23 (2026-10-01), the charts: a decision log in the model, City History's chart on a canvas with pan, zoom, ranges, an overview strip, years, a crosshair, a legend, named recession bands, an episode lane, decision flags and full screen; ChartCheck; decisions taken while Jerus slept
- `the-player-takes-the-queue.md` - 0.7.22 (2026-10-01), the construction panel and the player's hand on the queue: priority in the city's own order, rush on paid overtime (Business Roundtable C-2, Canada Labour Code s. 174), cancel as termination for convenience with the shell kept (FAR 52.249-2), demolition at 5% of the points (SIGTARP, NAHB) with the 0.7.8 salvage, buy-outs by compulsory purchase (Ontario Expropriations Act); worked examples; decisions taken while Jerus slept
- `a-front-door-and-a-dashboard.md` - 0.7.21 (2026-09-30/10-01), the second interface batch: the palette and IBM Plex, colour only for meaning, the labelled rail, the header of six tiles with sparklines and the docked clock, the main menu over a skyline with Continue and YOUR CITIES, the (i) for text in three layers, the one-panel founding screen, the sector pages' money form, BuildMenuCheck to the taxed price; decisions taken while Jerus slept
- `the-page-stays-put.md` - 0.7.20 (2026-09-30), the interface's bugs and its layout, the first of four batches from the play-through of 0.7.19: History at the top, the keys and the tooltip that swallowed Esc, the price card's first rate (about month 50), what is on site on the build cards and in Needs you, tooltips, whole people, annualised GDP ratios, Quit asks, the top-aligned centre, toasts, wrapping, the receipt's last five, the simple founding screen, number formats; the model untouched
- `playing-0-7-19-ui-notes.md` - 2026-09-30, a play-through of 0.7.19 for the interface only (a new city for 13 months, then slot 10 at month 1792): likely bugs, layout, wording, ideas and what works well
- `the-price-keeps-up.md` - 0.7.19 (2026-09-29/30), round 3 of Jerus's fixes from his 0.7.14 city: the builders' labour at today's wages, an escalation clause, the sales tax in the quote with business credits and the rental rebates; the grant a real amount at the price index; the bank's branches by their customers with the charter exempt from the fee rule and its upkeep, the deposit cap gone, the one-month lag; Luxury's markup on the buyers at its price; three passes and why; his city and the ensembles; the held-25% city
- `workers-take-the-best-paid-job.md` - 0.7.18 (2026-09-29), round 2 of Jerus's fixes from his 0.7.14 city, labour: every planner that builds posts checks staffing (80% from spare workers, no band nobody can fill on his "Truly unfillable only"), workers take the best-paid job they qualify for (one market at one wage; Beaudry, Green and Sand 2016), some unskilled migrants for a dear wage (7.5% at the ceiling); the literal first pass and why it was replaced; his city and the ensembles; what is open
- `arrivals-have-diplomas.md` - migrants arrive with an education
- `education-built.md` - schools, tuition, who goes
- `the-price-of-a-place.md` - the student grant as a menu (a share of the wage, a fixed sum, a share of last month's surplus, a share of tuition; one rule), a rate on the student loan in the Canadian shape, and a price on a place (0-5x), 2026-09-21, 0.6.9; the default playtest that never built a school, the schools' books missing from the load path, the treasury overdraft with no floor
- `the-parent-who-went-to-school.md` - a parent in school orphans the household unless the same mechanism as a laid-off parent holds it, 2026-09-15
- `one-definition-of-unemployment.md` - the pool over the labour force less students and prisoners, one definition everywhere, 2026-09-15
- `the-band-that-was-two-bands.md` - a wage band that had split in two, 2026-09-15
- `the-pyramid-is-saved-by-name.md` - the band arrays are saved by name, not by index
- `everybody-gets-the-same-matrix.md` - the tier matrix is the same for every household, 2026-09-14
- `what-a-household-eats.md` - the consumption basket: Engel's and Bennett's laws, thirteen foods, 2026-09-15
- `why-the-households-were-rich.md` - why household wealth ran high, and the real cause, 2026-09-17
- `who-is-playing.md` - who the player is in the model's terms, 2026-09-17
- `crime-has-reasons.md` - crime from graded reasons per adult; police, prisons, the sick and the killed
- `the-cities-that-empty-out.md` - out-migration when a city fails its people, 2026-09-14
- `demolition-log-and-households.md` - the demolition log and the households it displaces

## Land, housing and water

Two prices for land, two markets for housing, the water supply.

- `land.md` - land as a system
- `land-two-prices.md` - land has a market price and a use price
- `land-parcels-and-iron.md` - parcels, and the iron under them
- `land-parcels-round-two.md` - parcels, second pass
- `rent-is-a-market.md` - rent set by the market, not a dial
- `rent-per-home.md` - rent per home by size
- `homes-have-sizes.md` - dwellings have sizes and households fit them or double up
- `housing-is-two-markets.md` - owning and renting are two markets
- `the-land-tab.md` - the land office screen
- `water-supply.md` - water: draw, supply, the ratio
- `the-world-the-water-and-the-map.md` - 0.7.55 to 0.7.64 (2026-10-06 to 07), Jerus's land plan built in twelve batches from the design study `spec-land.md` and deployed as tags 1007a and 1007d: a world the size of the Earth from one seed, with seven resources in finite fields sold whole with land; the land priced by crowding times the world's USD level, a centre and 40 offers (four sides of ten lanes, never rerolled) and why the block grid replaces the lanes; fresh water limited to 121,600 units a month per km² and the Desalination Plant; the painted map (districts, a sidecar file, Expand) that draws exactly what the city has; fuel from Oil Wells and an Oil Refinery; `SAVE_FORMAT` 31 and how older saves convert; what the block grid (`spec-grid.md`, 0.7.65 to 0.7.69) will change; the docs pass not yet deployed; not yet seen on the PC
- `the-land-as-a-block-grid.md` - 0.7.65 to 0.7.69 (2026-10-07), Jerus's "how you buy land, i think it should be squares or rectangles" built in five batches (M1 to M5) from the design study `spec-grid.md` and deployed as tags 1007e to 1007j: world-aligned square blocks of 120 m doubling up to 983 km, the city's block the biggest of which six fit across it; offers of whole blocks (one wide, two deep), six places a side, never rerolled, the next in a place the innermost free ground; owned ground as a quadtree rebuilt from rectangles and never saved; books exact at every size; `SAVE_FORMAT` 32 and how older saves snap to blocks (his live city +0.1304 km² dry, no money moved); areas in m² below 0.01 km² and ground prices per m²; the land office's places and the map's overlay; the test player's fixes after ensemble seed 14, and the ensemble at 22 of 25; not yet seen on the PC
- `after-the-grid.md` - Jerus's design list for the run after the block grid (2026-10-07): oil in depth first (land and offshore wells, a refinery of many buildings, a refinery pictogram), ports and boats drawn only where you look, the map's highways, roads and rail, gravel advice and a gravel-to-paved upgrade, childcare centres for daycares, the world as planet Earth, and automatic building with a slack setting and debt; the oil and ports research and mockups are briefed for another AI in `brief-oil-and-ports-design.md`
- `the-day-after-the-grid.md` - 0.7.70 to 0.7.84 (2026-10-08), Jerus's after-the-grid list built in fifteen batches (N1 to N6, S1, S2, O1 to O7) and deployed as tags 1008a to 1008e, with the Earth data file E0 (52,757,374 bytes): a road priced over its 20 years and a gravel road paved, childcare in three sizes (80, 220 and 360 places), the map's roads and rail as one network and gravel bridges, automatic building that buys its ground under a debt limit that is a share of GDP, the loose bank, the sector statements (paid-in capital, `SAVE_FORMAT` 33), and the oil chain so far (fuel split into nine goods, `SAVE_FORMAT` 34; wholesale prices; crude grades; the Crude Unit, 14 conversion units and the flow; the spread planner; vans' diesel, lubricants, bitumen and the Filling Station; wells that decline), with what comes next (oil O8 to O13, zoning, the materials chains to 0.8.0, Earth E1 to E5).
- `the-streets-by-need.md` - 0.7.87 to 0.7.92 (2026-10-09), Jerus's roads, the design study `spec-roads-and-ports.md` with every recommendation adopted, built in five map batches (RD1, RD2, RD3, RD5, RD6) and deployed as tags 1009a to 1009e, with the oil at sea (O10) shipped between them: why the map looked as it did (five faults in the drawing code), `DistrictPlan` and `PlanCheck`, the painter on the plan (verge and surface, tracks, packing, sidecar FORMAT 5), highways and the railway as runs on corridors (`CityRuns`), estate cells laid to fit what they hold and shared by industry and the outer kinds, RD4 (lots and streets in the model) built, held and dropped, the measurements (plan times, the old map failing the new checks, packed buildings and undrawn road on his save and the playtest), and what is left (islands, ships and the Highway Bridge with the Earth pack and the ports; O10b and RD7); not yet seen on the PC
- `the-oil-chain-finished.md` - 0.7.76 to 0.7.98 (2026-10-09), Jerus's oil and ports list built in fifteen batches (O1 to O14 with O10b) and deployed as tags 1008b to 1009k, RD7 (the map's plan made faster) in the middle: the whole chain in plain words from the well to the boat (grades and the sea's depth, land wells and platforms, two oil pools, the Crude Unit and 14 conversion units, the spread planner, wholesale prices and the Filling Station, the Tank Farm and the strategic reserve, four sea terminals and the boats), what the refinery, oil industry and map screens show, his 1008 save's pools and its refiners before and after the fix that ships what the city does not take, the measurements, what is open for him (a run rule, his 14 Crude Units, MapCheck's 5 ms bound, a construction-bound city) and what is left (W1, zoning, materials, Earth); not yet seen on the PC
- `fewer-and-bigger-deposits.md` - 0.7.99 (2026-10-10), Jerus's "the world has too many deposits, a city doesnt require a deposit" built as batch W1 and shipped as tag 0.7.99, the first version to go through GitHub: a tenth as many fields, ten times bigger and clustered, the world's totals the same to the tonne (fields drawn a pool at a time, ten to a cluster in a disc at the old density), no iron promised at a founding, old saves keeping the old world's fields on the ground they hold (`SAVE_FORMAT` 36), the foundings' iron 21.5% to 2.3%, the playtest's city that finds no iron on the new world (545,179 people against 630,290, re-baselined as `pt0799`), the ensemble at 22 of 25 (A2 newly red), the seven ★ calls, what it leaves for the materials plan's deposit types and Earth, and the two calls that are his; not yet seen on the PC
- `why-the-refinery-loses.md` - 2026-10-10, why a refinery loses money in play (his 1008 city's lose about $15M a month after 0.7.98) and what to do: Jerus took its recommendations at 01:09 (A2: (b), the run rule valued at the margin; R1 the planner's prices at the margin; R2 the Tank Farm trap; R3 `MAX_CONCURRENT_ORDERS` counting only the sector's own orders), built as batch P6, 0.7.105, after P4

## The interface

Every screen and strip, in the order they were redone.

- `javafx-commercial-port.md` - the first JavaFX port
- `javafx-info-panels.md` - the info panels
- `javafx-sector-screens.md` - the sector screens
- `the-palette.md` - the theme: colours picked to be read against dark
- `the-rail-and-the-inbox.md` - the navigation rail and the inbox
- `status-strips-and-calendar.md` - the two strips and the calendar
- `fullscreen-and-keys.md` - full screen and the keyboard
- `build-menu-info-and-receipt.md` - the build menu's info card and the receipt indicator
- `the-build-tab.md` - the build tab
- `the-city-panel.md` - the city panel
- `doors-and-defaults.md` - doors (what a screen opens onto) and defaults
- `reports-redo.md` - the reports screen redone
- `policy-redo.md` - the policy screen redone
- `trade-redo.md` - the trade screen redone
- `bank-redo.md` - the bank screen redone
- `finances-redo.md` - the finances screen redone
- `sector-economy-redo.md` - the sector economy screen redone
- `services-screen-redo.md` - the services screen redone
- `people-screen-redo.md` - the people screen redone
- `the-wheel-and-the-dial.md` - a wheel notch worth the same every time; the dial, 2026-09-14
- `seven-tries-at-a-scrollbar.md` - the scroll position across rebuilds, and what it took
- `the-clock.md` - the month arrives on a clock; speed, pause, the day inside the month; 0.5.0
- `the-summary-is-a-problem-list.md` - the summary screen as a list of problems, 2026-09-14
- `what-the-player-can-solve.md` - which problems the summary should name: the ones the player can act on
- `the-instrument-panel.md` - 0.6.5: the instrument panel, 2026-09-17
- `city-history-graphs.md` - the history screen's graphs
- `time-skip-report.md` - the report after a time skip
- `month-report-carried.md` - the month report carried in the save
- `play-test-and-ui-notes.md` - notes from playing, on the interface
- `the-advisor-was-the-model.md` - the advisor was the model explaining itself
- `the-build-screen-and-the-frame.md` - 0.7.24 (2026-10-01), the first interface batch done one screen at a time, from the walkthrough of 0.7.23: TREASURY as its own block by the clock, five tiles that never cut, frame B (the City overview a drawer behind a "Needs you" chip, construction a tab, NEXT DUE on Finances and FALLS DUE in NEEDS YOU, now measured in the model as `CityNeeds`), Build opening on an Overview with `BuildAdvice`'s suggestions and the rule behind them, the renames, the city's five on their needs; the check by eye on the PC, the fix round, Jerus's answers
- `one-card-for-every-building.md` - 0.7.25 (2026-10-01), one build card for all 73 buildings, from the design study `runs/card-spec-0725.md`: the card row by row and its figures in the model (`BuildCard`, held by `BuildCardCheck`), the market's nine in their sectors' groups, value added for producers and land as the market's second bar, the investors' line and its "this one:" gates, what the city cards got back, `setBank()` on the load path; decisions for Jerus; seen on the PC 2026-10-01 (Jerus's own play)
- `the-land-office-redrawn.md` - 0.7.26 (2026-10-01), the first of the rail's screens redrawn in Build's style, from the design study `runs/spec-land-0726.md`: THE GROUND (the free ground and the next N plots as numbered ghosts on one bar) and why it is not a ring of "used", the shelf as a 3 × 3 of wide cards with independent tags, the four worth cards, the funding page in the frame, the shared `Pieces`; "% used" without a verdict on the office, Build and the left panel (`CityNeeds.ground()`), the going rate a model read, the receipt in the screens' money; decisions for Jerus; seen on the PC 2026-10-01 (Jerus's own play)
- `people-at-a-glance.md` - 0.7.27 (2026-10-01), the People screen redrawn, from the design study `runs/spec-people-0727.md`: one page of pictures (the pyramid and its settled ghost, the month as a waterfall, the bridge to the draw, the care rings, the homes gauge, the household mosaic, the outside tiles, the skill ladder) and Household money as a page of its own; the study's nineteen bugs, the walkthrough's Household cash flow and Pensions contradictions among them; Migration's month, the dead by cause and the hunger's two halves saved (SAVE_FORMAT 30); built in a worktree and merged; decisions for Jerus; seen on the PC 2026-10-01 (Jerus's own play)
- `services-at-a-glance.md` - 0.7.28 (2026-10-01), the Services screen redrawn, from the design study `runs/spec-services-0728.md`: an Overview per system (the sick rate as a bar of its causes over four care cards, the schools as a pipeline with each school's gate, power, water and the road as capacity rows, the crime as a bar of its reasons over Police, Cells and What it did), the pages behind each led by a picture, the frame's dots, events and sparklines; power in kW, MW and GW on Services and Build; Build's "why ›" back; the Infrastructure tab moved to its own class; `getNewDiplomas()` (not saved) and the homes' draws; the study's bugs; built in a worktree and merged; decisions for Jerus; deployed and verified with 0.7.31 as tag 1001m; seen on the PC 2026-10-01 (Jerus's own play)
- `the-road-in-one-picture.md` - 0.7.29 (2026-10-01), the Infrastructure screen redrawn, from the design study `runs/spec-infra-0729.md`: why "108% full" and "83% flow" are one road, the flow curve with the city's dot beside the walk from trips to the road (`throughputAt()`, `roadBreakdown()`), Transit as a funnel through the three ceilings, the railway's lorry bill three ways (`Rail.getPaidAbroad()`, `getKept()`; allowed and abroad saved in its extras, not known from an older save), Freight as a bar a good; the road worded "162% full · 56% flow" in NEEDS YOU's one colour everywhere; the room before it slows on the effective load (B3); the after-load railway bill (B1) left for Jerus; built in a worktree and merged; decisions for Jerus; deployed and verified with 0.7.31 as tag 1001m; seen on the PC 2026-10-01 (Jerus's own play)
- `the-sectors-as-flows.md` - 0.7.30 (2026-10-01), the Sectors screen redrawn, from the design study `runs/spec-sectors-0730.md`: fifteen cards under four figures in Build's market order, each business as inputs → plant (a ring and the six throttles as a cascade) → outputs, a waterfall, two bars and an owners card shared with the Bank, a cash bridge, and its investors in one line with each building's first gate; `SectorFlow` and the new SectorFlowCheck, the investors' word in twelve kinds (`BuildCard.wordKind()`), `Sector.operations()` in two halves; the study's bugs, with B6, B12 and B13 left for Jerus; built in a worktree and merged; decisions for Jerus; deployed and verified with 0.7.31 as tag 1001m; seen on the PC 2026-10-01 (Jerus's own play)
- `earned-surplus-banked.md` - 0.7.31 (2026-10-01), the Government screen redrawn, from the design study `runs/spec-government-0731.md`: the city's money named three ways everywhere, EARNED (the header's figure, now "+$X earned a month", the drawer's "Earned"), the budget's SURPLUS and what the cash BANKED, and the bridge FROM EARNED TO BANKED with every step named (`Game.getEarnedToBudget()`, `getEarnedResidual()`, TreasuryCheck §8); the two rings kept with THE BALANCE between them; Revenue and Spending as ranked bars that open into who pays, each with a door to where it is decided; THE DEBT, THE SERVICES THAT CHARGE and PENSIONS as cards; Output led by the GDP layers; the GDP history seeded on load (`NationalAccounts.seedHistory()`) and `getIncome()` side-effect free (`getTaxIncomeNow()`); the study's bugs, with B10 (the transit bill nobody seems to pay) and B5's G for Jerus; built in a worktree and merged; deployed and verified with 0.7.28 to 0.7.30 as tag 1001m; decisions for Jerus, D2's wording first; seen on the PC 2026-10-01 (Jerus's own play)
- `the-debt-at-a-glance.md` - 0.7.32 (2026-10-01), the Finances screen redrawn, from the design study `runs/spec-finances-0732.md`: the hub as the debt's dashboard (TREASURY, OWED, THE RATE, COUPON, NEXT DUE), WHEN IT FALLS DUE by the calendar year each payment falls in with NEXT DUE beside it (`DebtManager.ladder()`, ForeignDebtCheck §9), the rollover and the bank's rescue said once, the six areas as cards, every page one picture first, Issued a receipt and the default page Finances' own; one verdict each, the 60%/120% thresholds gone; a dollar piece valued as a buyback pays, the net position, the scar's words; `Pieces.columns()` and `setting()`, PAPER, BANKNOTE and SAFE; built on the main tree; decisions for Jerus; deployed and verified with 0.7.33 as tag 1001n; seen on the PC in the orchestrator's one look of 2026-10-01
- `the-bank-at-a-glance.md` - 0.7.33 (2026-10-01), the Bank screen redrawn, from the design study `runs/spec-bank-0733.md`: an Overview that answers "is my bank healthy, and what does it charge?" (the stance as a banner, THE CAPITAL GAUGE on the ratio that binds, eight figures with HOW FULL, THE LADDER OF ITS RATES with every rung in its parts, `BusinessDebtManager.quoteParts()`) and six pages each one picture first, every old statement under "details"; the branch verdict the planner's; a sector's rate after a load fixed on the load path (B5, BankCheck §13b, the traces byte-identical); built in a worktree and merged; decisions for Jerus; deployed and verified with 0.7.32 as tag 1001n; seen on the PC in the orchestrator's one look of 2026-10-01
- `buttons-that-ask-to-be-pressed.md` - 0.7.34 (2026-10-01), Jerus's one request after playing 0.7.31 ("an actual button that is basically asking to be pressed"): `Pieces`' action button in four looks (GO, CHOOSE, CREDIT, HELD), saying the order from the model's quote, on every Build and Buy, and the door pill on every link to Build or the land office; Build at none sets the count to 1, a double-click one press; with the look's two other findings, Finances' "later" drawn broken and the Sectors list's one line after a load; `BuildAdvice.quoteTotal()`; built in a worktree and merged; decisions for Jerus; deploy pending (the final deploy of 2026-10-02); not yet seen on the PC
- `trade-at-a-glance.md` - 0.7.35 (2026-10-02), the Trade screen redrawn, from the design study `runs/spec-trade-0734.md`: five pages on one strip under five figures, what the city trades as bars a good off the businesses' own books (`Sectors.tradeByGood()`, footing to the balance of payments), the month as steps with the river a toggle away, the rate on City History's chart beside parity (`fxParity`, a new series), the forces as bars either side of a line, the vault with its claims and the exchange on the action button; one parity rule for the tab, the drawer and the header's rate line (D8); "not counted yet" after a load, D4 (saving the month) awaiting Jerus; built in a worktree and merged; decisions for Jerus; deploy pending (the final deploy of 2026-10-02); not yet seen on the PC
- `policy-at-a-glance.md` - 0.7.36 (2026-10-02), the Policy screen redrawn, from the design study `runs/spec-policy-0735.md`: a hub of four area cards over WHAT IS BITING and RECENT DECISIONS, every dial a dial card whose before → after rows follow the thumb, the staged tray with THE BUDGET, every "after" the model's own through `TaxPolicy.copy()` and the new `PolicyPreview` (PolicyPreviewCheck, the 70th harness); the floor in today's money; PROMISES without the waived tuition (D13); B8 (`isPinned` against the founding floor, D7) awaiting Jerus; built in a worktree and merged; decisions for Jerus; deploy pending (the final deploy of 2026-10-02); not yet seen on the PC
- `city-history-finished.md` - 0.7.37 (2026-10-02), City History, the last rail screen, redrawn, from the design study `runs/spec-history-0736.md`: a fixed frame (the year book's button, THE CITY, HARD TIMES, RUNNING NOW, YOUR DECISIONS) over a page at the stage's width, the pins as cards, a card a line with its move in neutral ink and a range bar, HARD TIMES AND YOUR DECISIONS in view, every series the history keeps (148 → 217 lines), PRICES THIS MONTH; the founding month's decisions on the lane (`ChartModel.onAxis()`); `YearBook.running()` and the chronic epidemic last; built in a worktree and merged; decisions for Jerus; deploy pending (the final deploy of 2026-10-02); not yet seen on the PC
- `the-loose-ends.md` - 0.7.38 (2026-10-02), the loose ends of the redraw, from the brief `runs/brief-ui19-0738.md` (no study): eleven display fixes the redraw of 0.7.24 to 0.7.37 left, none needing Jerus's word - small charts drawing the decisions they are handed (the Bank's ITS RATES, Finances' OWED AND THE RATE), the founding month's decisions on every lane (`ChartModel.onAxis()`), "under 0.1 months" of import cover through `Money.coverMonths()`, the floor in today's money on People and named founding money on History and in the year book, the fare on `Levers.dialCard` with every row the model's (`faresAt()`, `backOnTheRoadAt()`, `transitNetAt()`), a shut-out sector's name red on the Bank's ladder, Sectors' rate bar on `quoteParts()`, the drawer's "vs parity" on the one parity rule, no method name in the pension's (i), Build's total from `BuildAdvice.quoteTotal()`, nine members with no caller gone; the Bank chart's drag and the sector (i)s' drift left; built in a worktree and merged; decisions for Jerus; deploy pending (the final deploy of 2026-10-02); not yet seen on the PC
- `the-fund-as-a-brokerage.md` - 0.7.39 (2026-10-02), the city's fund as a brokerage, Jerus's note of the morning after 0.7.38 ("like wealthsimple trade ... the city fund should show pnl and acb"), from the design study `runs/spec-fund-0739.md`: Finances › The city's fund as four pages (Portfolio, Search, Activity, Rules & cash) and a page a security with YOUR POSITION beside THE ORDER TICKET (`ui/FundScreen`); `FundLedger`, each holding's adjusted cost base by the average-cost method with its realized P&L and its income apart, booked by hooks where the holdings already move and read through the pure `FundView`, an older save seeded at market value ("cost from") and the return since it began exact from the counters; three History series (`fundValue`, `fundPutIn`, `fundTakenOut`); the hand names its price (D2) and a waiting order can be cancelled (D3); a hand buy stops at the 10% cap (B1) and a queued buy's cash is held from the rule (B9); FundLedgerCheck the 71st harness; SAVE_FORMAT 30 and the eight traces byte-identical; B3, B6, B10 and B11 left for Jerus; built on the main tree; its docs pass run (two player strings), then three fixes in the same version (the 10% cap counting every order the fund has on a company, the rule's bid making way for the hand's; a seeded rescue lot asserted; Search's young-city words); decisions for Jerus, D2 and D7 first, and the hand first for the room; deployed and verified as tag 1002a (2026-10-02); not yet seen on the PC
- `fixes-from-playing-0-7-39.md` - 0.7.40 and 0.7.41 (2026-10-04), from Jerus's note after he played 0.7.39, two versions built side by side and shipped together: City History's charts and Build's order bar creeping right, clicks lost at 20x, building on credit and the borrow amount fixed (0.7.40); every service gauge on one rule, "served", under one verdict (0.7.41); merged three ways, then a docs pass on the merged tree; deployed and verified as tag 1004a; not yet seen on the PC
- `chart-crash-and-build-advice.md` - 0.7.50 and 0.7.51 (2026-10-06), Jerus's "hmm ok pretty good, but on one test run, the game got stuck" and, going to sleep, "the building ideas is flawed": the freeze traced to a chart that kept the history's live month list over layers fixed at handover, so a month landing made it throw inside the page's teardown and left nodes with no scene - now one snapshot a chart draws from, every chart handler guarded, a page torn down hearing nothing and the log keeping failures past its cap (0.7.50; the freeze tied to it with moderate confidence, not proven); Build's advice priced with its land at the land office's price, sized to the businesses' projection with 5% to spare, colleges and universities only for students the city would get and hire, the cash cap gone, and "Build all three" reading the run (0.7.51, after a design study); the manual brought to version 13; traces byte-identical to `pt0749`; deployed and verified as tag 1006a; not yet seen on the PC

## Saves, files, logging and packaging

Where the game keeps its files, how it loads them, and how it ships.

- `save-system.md` - slots, headers, atomic writes
- `save-load-flows.md` - the flows through save and load
- `save-load-stack-mismatch.md` - a stack that did not match after load
- `save-location-and-safety.md` - the platform data folder; backups
- `load-path-parity.md` - the loaded game must agree with the one saved: ReadPathCheck
- `load-path-workforce-bug.md` - a workforce that vanished on load
- `new-game-reset.md` - starting over resets everything
- `logging-and-crash-handling.md` - every println to the log; crashes caught
- `packaging-and-distribution.md` - jpackage, the app image, SmartScreen
- `buildings-data-file.md` - buildings.json as the balance file; ids permanent

## Playtests

Long runs and hand-played cities, and what each found.

- `playtest-2026-09-01.md` - the first playtest
- `playtest-2-long-run.md` - the second, long
- `playtest-4000-months.md` - 4,002 months audited every one: LongPlaytest
- `playtest-hand-played-200k.md` - a hand-played city to 200,000
- `playtest-hand-played-116k.md` - a hand-played city to 116,000
- `phase-5-complete.md` - phase 5 done: where the project stood
