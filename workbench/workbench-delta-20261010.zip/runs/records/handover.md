# CityBuilderSim — handover for a session working through GitHub (2026-10-10 15:45, at 0.7.104)

## State
- **GitHub `main` is e097c0f = 0.7.104**, pushed 15:19. The day's versions, each merged, gated and pushed by the orchestrator; the PC's auto pull (every 10 minutes) logged each one it saw:
  - fb20b5e: docs pass part 1 (0.7.70-0.7.79), no version (PC pulled 01:35);
  - e859997 = 0.7.100 P1, the checks (PC 02:55);
  - 9bb7be3 = 0.7.101 P2, automatic building and the advice (PC 08:45);
  - b327419 = 0.7.102 P3, the budget and the books (PC 11:35);
  - 0567afe: R1, CLAUDE.md and README - old saves need not load until the game is published;
  - bad33d2 = 0.7.103 P4, oil and roads (the PC was offline when checked);
  - e097c0f = 0.7.104 P2b, a smarter budget for automatic building.
- **Tags `0.7.100` to `0.7.104` exist only in the cloud clone.** This session's git proxy refuses tag pushes, ref deletes and GitHub API writes; pushing branches works. The push test's branch `test/push-check` (at 4074708) is still on GitHub. Jerus can delete it and push tags from the PC: `git push origin --delete test/push-check`, and `git tag -a 0.7.10x <commit> -m ... && git push origin 0.7.10x`.
- **Running at 15:45:** P6 (0.7.105, the refinery's run: `claude/why-the-refinery-loses.md` A2 (b) and R1-R3; worktree `git/wt-P6`, branch `batch/P6`, from bad33d2) and P5 (0.7.106, prices and rules: A18, A20, A23, A24, Insane's land bond; `git/wt-P5`, `batch/P5`, from e097c0f). Briefs `runs/brief-batchP6.md`, `brief-batchP5.md`; notes `runs/fixP6-notes.md`, `fixP5-notes.md`.
- **References:** the playtest's traces `scratch-ui1/orch-gate/pt07103/` (P4's; 0.7.104 left them byte-identical); the ensemble's baseline `runs/ensemble/out/07103b/summary.json` (22/26: A2, S1, HIGH T2, ZERO_HOT H2 red). `scratch-gate/gate.sh` points at pt07103 and takes the JVM lock for every run.
- **The records** (`claude/changelog.md`, `todo.md`, `index.md`) are current through 0.7.104, with the write-ups `claude/fewer-and-bigger-deposits.md`, `why-the-builders-stall.md` (T1) and `the-fixes-from-the-decisions.md`. Jerus's open calls are the todo's `CONFIRM (from 0.7.100 to 0.7.104)`.

## The workbench is newer than its zip
`Claude outputs\workbench-0799.zip.001`-`.004` on the PC is the base (restore it as in §1). Everything since lives only in the cloud workspace and is lost if it restarts: the batches' notes and changed lists (`runs/fixT1`, `fixP1`-`fixP6`, `fixP2b`, `docs-0779`), the briefs, `runs/records/`, the reference traces `pt07102`/`pt07103`, the gate's lock edits, and **the ensemble's rewritten S1 and H1 premises** (`runs/ensemble/score.py` and `src/.../Ensemble.java`, P1; the originals in `scratch-p1/ensemble-orig/`). The records reached the project; the rest has not been saved anywhere. A next session that restores 0799's zip must re-apply P1's ensemble change (`runs/fixP1-notes.md` §9 lists it) and re-baseline the playtest on `main` before its first gate.

## 1. Restore the workbench (the cloud workspace starts empty)
The zip is four parts on the PC in `C:\Users\Jerus\Documents\NetBeansProjects\CityBuilderSim\Claude outputs\`: `workbench-0799.zip.001` to `.003` (28,311,552 bytes each) and `.004` (4,584,190); whole 89,518,846 bytes, SHA-256 `8dfd34f068699fd8be1ee911f78bbd1fb051eadd7adb2a3428faffc17aa915f1`. Stage the four (one call), `cat` them in order into `/home/claude/workbench-0799.zip`, check the hash, `unzip -q` in `/home/claude`. Then attach the repo with push access (`add_repo`), clone, and keep the clone at `/home/claude/git/CityBuilderSim` (the gate's path; `register_repo_root` wants its own path, so link it). Fetch full history (`git fetch --deepen=1000 origin main`). In `scratch-gate/bmc.sh` set `FX=$(ls /home/claude/fx/*.jar | tr '\n' ':')`. Gson is `/opt/apache-maven-3.9.11/lib/gson-2.13.1.jar`. The zip's contents are listed in the earlier handover (`workbench-0799.zip`'s own `HANDOVER.md`).

## 2. How a batch runs now (`claude/git-workflow.md`, `claude/brief-shared-git.md`, both rewritten 2026-10-10)
- **Agents have no Projects tool.** Quote Jerus's decisions in each brief, and keep the shared rules on disk: `runs/brief-shared-git.md` is the project doc's copy (re-copy it when the project's changes).
- At most two implementers at once, on batches whose files don't overlap; a docs pass runs alone. Every `java` run, the orchestrator's gates included, under `flock /home/claude/jvm.lock`: with it the timing checks (PlanCheck 40 ms, MapCheck 5 ms) pass; without it they failed under load.
- Per batch: `git worktree add ../wt-<batch> -b batch/<batch> main` (or `origin/main`), the agent commits there and never pushes. Merge with `--no-ff`; if `main` moved meanwhile, merge `main` into the batch branch first (the orchestrator starts the merge; the agent may resolve conflicts and commit it), re-baseline and re-gate. Gate the merge on `main` only if its tree differs from the branch's gated tree. Tag locally, `git fetch origin main`, push `main`. Ten minutes later read `autopull\log.txt` on the PC (`device_bash` or staging).
- Agents probe before building, decide and keep going, and never wait on Jerus; a batch that cannot pass its guardrails stays on its branch.

## 3. Standing rules
- The orchestrator writes no code; implementers and docs passes on Opus, records on Sonnet (checked by the orchestrator).
- Save slots 1-9 are Jerus's. Old saves need not load until the game is published (bump `SAVE_FORMAT` where one would load wrongly; no conversion code).
- Agents never use `rm` and never touch `/dev` in any form; nearly every agent slipped once today (all read-only, `diff <(...)` or a grep naming /dev/null).
- Never end a turn with work pending; send updates with `SendUserMessage`.

## 4. What's next
1. Merge P6 and P5 as they finish (the second gets the full gate on the merged `main`, the playtest re-baselined and the ensemble run on the merge).
2. **The docs pass for 0.7.80 to the last fix**, alone (part 1, 0.7.70-0.7.79, merged as fb20b5e). Then **manual 16**.
3. Zoning Z1-Z2, the materials chains I1-I14 (0.8.0 at I14), Earth E1-E5 (`claude/todo.md` section 0).
4. Jerus's open calls (the todo's CONFIRM items), each a small follow-up batch when he answers.
