# Fewer and bigger deposits (0.7.99)

*2026-10-10. Your decision on the world's deposits ("the world has too many deposits, a city doesnt require a deposit, you can just make a deposit deeper or in very big clusters") was built in one batch, W1 (`runs/fixW1-notes.md`, from `runs/brief-batchW.md`), and shipped as 0.7.99, the first version to reach your PC through GitHub. This note is the batch in plain words, for you and for a session starting cold: what you asked and why, what the game does now, what it did to the playtest and the ensemble, the seven ★ calls, what it leaves for the next batches, what to look at on your PC and the two calls that are yours. The changelog's top block is the state of the tree; the todo's CONFIRM (from 0.7.99) and CHECK 0.7.99 ON THE PC hold what is open. Nothing here has been seen in the game's window yet.*

## 1. What you asked for, and why

You said the world had too many deposits and that a city does not need one: a deposit can be made deeper, or sit in very big clusters. Asked to choose, you picked two things. First, a tenth as many fields, each ten times bigger and clustered, with the world's total of every resource exactly as before. Second, no guaranteed iron at a founding: a city may start with no deposit at all, run, grow and import what it needs.

The brief held the work to some rules. The oil at sea had to keep working (O10's shallow and deep fields, whose platform slots come from a field's free sea sites, and O10b's two pools). An old save keeps the ground and deposits it owns as saved, with exact money. The words change wherever the game promised the iron. And the materials plan's deposit types (`spec-materials.md` 2.4) and real geology (`spec-earth.md` 4) must stay possible.

## 2. What was built

**The pools and the clusters.** Each cell's old count of fields and its total are drawn as before, so the world's totals are what they were to the tonne. What changed is how the fields are drawn from them: a pool at a time. A pool is a square of cells, a few cells a side for each resource (iron 2, oil 4, stone 6, coal 12, copper 24, uranium 37), the fewest whose land holds ten clusters. In a pool the old count is cut to a tenth of the fields (at least one where the old count was above nothing) and gathered ten fields to a cluster. Each cluster is centred in a cell picked by its share of the old count, off the sea (up to 8 redraws; oil may stand at sea), and takes that cell's richness. Each field of the cluster is picked uniformly inside a disc round the centre. The disc holds ten fields at the old density: radius 4.0 km for iron, 12.6 for oil, 17.8 for stone, 39.9 for coal, 79.8 for copper, 126 for uranium. A field's sites are ten old draws added together (10 to 5,120, mean 25.2). The pool's total is shared among its fields by sites times richness, in whole tonnes, the last field taking the remainder. A field is listed in the cell its centre is in and numbered from 65,536 up.

**What stayed.** The old generator is kept (`legacyFieldsInCell()`) for the ground an older save already holds. The pools' totals equal the old world's totals to the tonne, and WorldCheck 8 checks it.

**A founding without iron.** A founding no longer asks for an iron field within `SITE_IRON_KM` (the fourth of its tests); it keeps the first three. The conversion that moves an older save onto the block grid keeps its search for iron on the old world's fields, so old saves convert as before. No player-facing string had promised the founding's iron (Build's no-deposit page, the Ore card and the founding screen never did). The prose that described it was in `Deposit`'s header, now updated, and the manual's land chapter (`docs/manual.md` is generated, so the change goes in the manual's page).

**Old saves keep their ground.** `CityLand` reads two worlds. On every holding an older save brought, the held fields, the map and the hover read the old world's fields; on everything bought after, they read the new world's; an offer shows the new world's fields on its free plots. A save now carries those holdings (`landOldWorldHoldings`), the one new thing saved, so `SAVE_FORMAT` is 36. A load lets the save's own key decide which world the holdings are on, and falls back to the format number only when there is no key. The save's standing offers are measured again once (`LandMarket.remeasureStanding()`); the books and E are as saved, and the world's totals are unchanged every month.

**Old saves, tried.** City600, city2400, jerus-1007a and its slot 3, jerus-old and jerus-1008 were each run 24 months on copies, saved to slot 10 and loaded. The audits closed (the worst 5.2e-14), the world's totals held every month, and after the reload the land, offers, E, cash and people were the same, and the month after alike. Your 1008 keeps 455 holdings on the old world, its books equal the fields under them for all five resources, and its offers, measured again, hold iron in 4 where 19 held it before and oil in 1 where 10 did.

**The checks.** Harnesses that stood on the old world's fields were moved to a world that has what they need (premises changed are in the notes' §3): WorldCheck 3 no longer asks for iron at a founding and gains a section 8 for the pool rule; ConversionCheck reads the old world; LandCheck 19 founds a city on the nearest iron field on dry ground; MiningCheck, MapCheck 1 and PlanCheck 6 play on iron seed 35; the oil checks play on sea seed 518. AutoBuildCheck 3 weighed a paving's hold differently from the pass, a harness bug the new trajectory showed (44 DEBT holds of pavings from month 555), not a model one.

## 3. What it did to play

**The foundings.** Of the 659 sites a city could be founded on within 100 km of the default world's site, 21.5% found iron in their centre or first offers before W1, and 2.3% do now; coal (0.2%) and oil (1.7%) went to none. On the default world, within 50 km of a founding site, the fields fall: iron 357 to 36, oil 31 to 19, stone 15 to 0, copper 2 to 0, coal 0. The world holds a tenth as many fields within 1% (measured 0.3%), and a field's neighbours lie where they did: iron's mean distance to the nearest other field is 1.16 km (the old world's 1.18), where a tenth as many fields spread evenly would be 3.43 km apart. A field has 25.37 sites on average, against the expected 25.24 (3% allowed).

**The playtest.** All eight traces are identical to `pt0786` to month 359. At month 359 pt0786's player bought its first iron, West 2 (6 sites, 76.9 Mt, US$37.05M from the cash). On the new world no offer near its city ever holds iron: the player looked 202 times and found none listed; the nearest field is 12 km out, in a lake. So from month 360 the cash differs, people and labour from month 361, borrowing at its next issue (month 362). The run has no mine (pt0786 had up to 36 mines, and 243 sites at the end) and no oil well (pt0786's first at month 846, 512,706 t), and it buys its ground elsewhere (127.92 km² dry and 25.90 km² of lake and river). It is smaller all run: 11,559 people at month 611 (18,909), 29,890 at month 1,068 (56,045), 162,072 at month 2,019 (185,550), and 545,179 at the end against 630,290, which is 13.5% fewer, with GDP $1.9T a month ($2.5T). Every month was audited and every reload matched. It is re-baselined as `pt0799`.

**The ensemble.** Ensemble 0799 reads 22 of 25 against 0786's 23 of 25. S1 and H1 are red as before. A2 is newly red: seeds 8 and 13 spend 13 and 16 months above 10% yoy inflation after month 120, where fewer than 12 was asked (0786's worst was 11, seed 10). T2 AUTO2 reads 230,564 (224,676); 64 of 64 pairs are identical; there is no audit failure and no finding. It is reported, not tuned.

## 4. The ★ calls

- **W1-1, wider, not deeper** (the first implementer's, kept). A field is ten old draws' sites at the same tonnes a site, so a mine or a well lasts as it did and its ground costs what it did a site. Deeper would have made every site last ten times as long.
- **W1-2, the cluster.** Ten fields to a cluster, its disc holding them at the old density, so a tenth of the land holds the fields and a field's neighbours lie where they did; pools of ten clusters or more so the clusters fall where the draws put them. These are estimates.
- **W1-3, old saves.** Every holding a save brings keeps the old world's fields; what it buys after is the new world's; its standing offers are measured again once. Money is exact: the books and E are as saved.
- **W1-4, the key decides.** At a load the save's key says which world the holdings are on, the format number second, so a save always says which world its holdings are on.
- **W1-5, fixtures find their deposit by world.** Not by fiat, because a deposit placed by fiat has no place on the map: iron seed 35 (iron of 36 sites, 0.97 km out, dry, as the default world's was) and sea oil seed 518 (heavy, 12 sites, 58 m deep, 3.5 km out), both from a seed scan.
- **W1-6, MapCheck's copies** stay at the plain dry place; only his city's x 1 copy is built again where its square holds iron, because a copy moved there breaks PlanCheck's dense screen (the notes' §7).
- **W1-7, two bounds.** The clusters' nearest-neighbour bound is 1.25 times the old world's (an estimate; measured 0.98), and the count is held to a tenth within 1% (measured 0.3%).

## 5. What it leaves

**Zoning.** Nothing from W1 in the notes' §7. Z1 and Z2 go on as the todo lists them; Z1 is meant to be byte-identical, and what it is identical to is now `pt0799`.

**Materials.** The deposit types of `spec-materials.md` 2.4 stay possible: a field's type is drawn from its cell, index and kind as its grade is, on both worlds' fields. The batch that builds them (I1) now needs this. Its "types sum to the total" check has to run per pool (`World.poolFields()`). Its figures for ore near a founding site have to be measured again (the 50 km figures in §3). A city's ore will be of one type more often, because a 25-site field is all hematite or all magnetite, so `fits()` will refuse typed works more often and the chains will lean on imports. And I3's iron share was pinned to "the founding field's US$180M", which is gone, so it needs another reference.

**Earth.** `spec-earth.md` 4 holds: the geology weights act on the cells' counts and totals, which the pools gather, and the cluster centres follow the counts. These wait for it. Fields are drawn off the sea, not off lakes (as before), and the default world's nearest iron cluster lies in a lake. And the far views mark only the fields within the offers' reach, so a new default city sees no deposit at all (iron 12 km and 26 km out); mark the nearest field of each resource, or the clusters in view, and let Build's no-deposit page say how far the nearest is.

**The map's plan.** Over an iron cluster (MapCheck's dry place one cell south, the 10,000-times copy), district (1, -1) has 15,260 mined plots (23%) and its plan leaves a 50-plot street piece walled in by buildings and mines, which the ground does not part (`join()` never walks over a building), so PlanCheck's one network fails there. No fixture stands there now; W1's clusters make such districts possible in a dense city. The probe is `scratch-w1/probe2 W1Plan`.

## 6. For you to check on the PC

1. Load the 1008 city. The log says its 455 holdings keep the fields they held and its 24 offers were measured again (iron in 19 before, 4 now). Its map's deposits are under its ground as before. Save and load it again.
2. Found a city on the default world. No deposit in its offers or its map; the nearest iron lies 12 km out, in a lake.
3. Found a city on world 35. An iron field of 36 sites a kilometre out, listed whole after a few purchases toward it.

## 7. What is open for you

Two calls, asked of you on 2026-10-10 and not tuned: is each as intended?

1. **The playtest's city never finds iron.** On the new world no offer near it holds iron (202 looks, the nearest field 12 km out in a lake), so no mine and no oil well all run, and it ends 13.5% smaller (545,179 people against 630,290). Nothing was tuned.
2. **Ensemble check A2 went red.** Seeds 8 and 13 spend 13 and 16 months above 10% yoy inflation after month 120, against fewer than 12 asked (0786's worst was 11). The notes name no cause.

The seven ★ calls of §4 are also yours; the todo's CONFIRM (from 0.7.99) lists them with these two.

## 8. How it shipped

0.7.99 is the first version to go out through GitHub. `2048Israel/CityBuilderSim` `main` is the merge commit 4074708 of `batch/W1` (8 commits, ab9e8ea to 10cc2cf, on 0.7.98 = ea7ad19), tagged `0.7.99`. The session that built it had no push access, so Jerus pushed it from his PC with `Claude outputs\Apply 0.7.99.bat`, from a git bundle; the PC's auto pull (a scheduled task, every 10 minutes, `git pull --ff-only`) then read "Already up to date". From now on the cloud orchestrator merges, tags and pushes, and the PC pulls; nothing is written to the PC through the chat's file route any more (`claude/git-workflow.md`).

The batch was started by one implementer and finished by a second, from ab9e8ea in a worktree: WorldCheck did not build when the second began (`fewerAndBigger()` called but unwritten, and `b` twice), and section 8 was written then. The gate on `main` at 0.7.99 is W1's own: both builds silent; the suite 90 of 91 with HealthCheck the known red; BuildMenuCheck 101 of 101; Stale 0 firm (415 soft); the playtest re-baselined as `pt0799`; line endings clean (the six .bat files keep theirs).

## 9. What is left

A docs pass for 0.7.70 to 0.7.99 started on 2026-10-10 in three parts (branches `batch/docs-0779`, `docs-0792` and `docs-0799`) and is in progress; manual 16 follows it. Then zoning (Z1 and Z2), the materials chains (I1 to I14, the 0.8.0 release at their end) and the Earth pack (E1 to E5), renumbered when launched.
