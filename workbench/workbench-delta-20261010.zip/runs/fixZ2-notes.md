# Z2 notes - 0.7.109 zoning: the screens (worktree /home/claude/git/wt-Z2, branch batch/Z2)

## 0. Progress (a line per step)
- tree clean at 03eb4bd; scratch /home/claude/scratch-z2 with build/suite/pt/bmc/gate scripts pointed at wt-Z2; baseline builds silent
- 14fc972 model: DecisionLog.ZONING (Game's setZone/removeZone/setForestLaw), ZoningView (new, pure), BuildCard/quoteBuild/"Could not build" read freeFor(sector) + "is zoned for others", CityNeeds GROUND names what zones hold
- 82d0422 ZoningViewCheck (8 sections, 2.3 s); targeted LandCheck ZoningCheck InvestCheck BuildAdviceCheck BuildCardCheck PolicyPreviewCheck SectorStatementCheck ChartCheck all OK
- 43f00f0 ui: ZoningScreen (new), PolicyScreen's fifth area, Icons ZONING/TREES, TimeChart flag colour, BuildScreen LAND FREE + gate words, LandScreen THE CITY line; CLAUDE.md/README counts
- 6b54860 GameVersion 0.7.109; the unit switch keeps an unstaged size the city's. Words probe: 95 measured, 0 over
- city probe (scratch-z2/probe Z2Cities on copies, cities.txt): city600's bar overcounted -> 2653b78 ground() cuts built / the law's forest / free; all five cities add up; ZoningViewCheck 3 holds it. Stale 0 firm; BuildMenuCheck PASS 101
- gate 22:12-22:27 on 2653b78 (scratch-z2/gate.log): all green, see 5; tree clean, nothing to commit after it

## 1. What I built
- **Policy › Zoning, the fifth area** (`ui/ZoningScreen`, new; PolicyScreen dispatches to it as Finances does to FundScreen and keeps the frame, the staged set and the tray): its chip (Icons.ZONING, Lucide land-plot) beside Taxes/Wages/Money/Promises, and a fifth card on Policy's hub (ZONING: km² zoned, the dry ground as four slices, the zones' line, the law). Tabs: The ground, The forest law, then a tab per zone (and the open sector's, before it is applied).
  - **Board 1, The ground.** The frame's four figures on this area are zoning's: ZONED (km², share of the dry ground, zones), HELD FOR THEM, PRICE GIVEN UP (on what they hold; the tax relief a month), FOREST KEPT ("none" at 0/0; "the city owns no forest"); each a door. THE CITY'S GROUND: one bar (Pieces.causeBar) of the dry ground - built, each zone used solid / held hatched, bare ground free for anyone, open forest, working, protected - and a closer bar of the zones and the bare ground; parts click to their zone or the law. THE ZONES: a row each (sector icon and name, "holds less than it wants" when short, size and share, used against held as a bar and words, price share and a m², three rate chips with an offset marked in the accent, the month's relief, a door). THE FOREST LAW: its bar and one sentence, a door. "Zone ground for an industry" opens a picker of every unzoned sector.
  - **Board 2, Policy › Zoning › <sector>** (the breadcrumb three deep, "Zoning" a way back): HOW MUCH GROUND (unit chips "A share of the dry ground" | "km²" over the ladder; effects: <plot>s it carries, it holds for <sector>, free for anyone, what it holds at the going price), ITS PRICE (0-100%; effects: a <plot>'s ground with the going price in its (i), the price given up on what it holds, the property tax relief a month, THE BUDGET), ITS TAXES (one card, three ladders - the profit, sales and property offsets on Policy › Taxes' own keys - each "PROFIT · the city's 15.00% −2.00 pts = 13.00% → … · $X last month", and "The same dials as Policy › Taxes: a move here moves it for every <sector> building"; effects the sector's three taxes and THE BUDGET), "Take the zone off" (staged). The tray: chips, THE BUDGET (the taxes through the staged policy plus PolicyPreview.zoningTaxChange() of the staged zoning), "Apply it"/"Apply all N", "Leave it as it is".
  - **Board 3, The forest law:** the forest bar under the staged law (and as it stands, below, when staged), two ladders (protected; kept from building) on one card, WHAT IT WOULD DO: forest standing for ever, the most that may be cut, the forest a building may take, the ground free for anyone.
- **ZoningView** (new, model, pure): figures(), ground()/closer() (the parts add up to the dry ground), zones()/row(), with()/without()/withLaw() staged copies, plotOf(), page() and forest() before and after. Every figure a model read (LandManager, PolicyPreview.zoneAt()/forestAt()).
- **DecisionLog.ZONING** for setZone/removeZone/setForestLaw (Z1's TAX; a zone's tax rows stay TAX); Icons.ofDecision -> ZONING; TimeChart.flagColour -> Palette.ORE; Policy's RECENT DECISIONS counts it.
- **Elsewhere:** the land office's THE CITY line "· N zoned"; Build's LAND FREE note "free for anyone · X% …" and a door "zoned for <sector> Y ›" (one zone: its page; several: "zoned for N industries", the area); NEEDS YOU's GROUND, listed, adds "<Sector>'s zone holds X" / "N zones hold X" (CityNeeds.zonesHoldWords(); the homes' own zone left out); the build card's land gate (BuildCard.landGate()), the card's land free, Game.quoteBuild()'s landFree and both "Could not build" words read LandManager.freeFor(sector) - what buildFor() already asks - and add BusinessInvestment.zonedForOthersWords() ("…; X is zoned for others"), so the investors' word and "this one:" say it alike.

## 2. Departures, with reasons
- None from the brief's list. Where the study is open, or a widget was missing: the stars in 6.

## 3. Premises changed (before -> after) and new assertions
- No premise moved. New: ZoningViewCheck 1-8 (nothing set; the hub's figures the model's; the bar adds up and each part is the model's, and still adds up built past what the law keeps; a row is its zone, one dial two doors, short when the free ground is short; a sector's page staged moves nothing and applied reads as staged - new, re-sized and re-priced, taken off; the forest page the same, with the model's clamp; the ZONING kind, TAX for a tax row; NEEDS YOU's GROUND names the zones but the homes', the land gate and the quote count a zone, an unzoned shop's gate names what is zoned for others).

## 4. Trace movement
- None: the playtest's 8 traces are byte-identical to pt07106 (4,003 months, every month audited, every reload matched). With no zone freeFor(sector) is getAvailableSqFt() to the bit and every new word waits on a zone. Not re-baselined; no ensemble.
- City probe on copies (scratch-z2/cities.txt; Agriculture 5% at 50%, Real Estate 1 km², law 20/40, three months): the bar adds up to the dry ground and its free for anyone is the model's in all five (city600, city2400, jerus-1007a, jerus-1008 at 1,382 km² dry, jerus-old); three ZONING decisions each.

## 5. The gate, and the final commit
- Both builds silent. Suite (scratch-z2/suite.txt) 93 of 93 in 676 s, HealthCheck, MapCheck and PlanCheck among them. BuildMenuCheck PASS, 101 of 101. tools.Stale 0 firm, 425 soft. Playtest pt-main 8 of 8 traces identical to pt07106. No w/crlf outside .bat.
- Words probe (scratch-z2/probe Z2Words, words.txt): 95 measured at 1,389 x 868, 0 over.
- Final commit: 2653b78 (on 14fc972, 82d0422, 43f00f0, 6b54860). Tree clean.

## 6. Star calls
- ★1 The forest law's "bar with two thumbs" is the bar and two Ladders on one card: Ladder is the one dial class (Jerus, 0.7.6: "create an object or class of slider ... whenever you need it you just call that class"); a two-thumb slider would be a second. Flip: a two-thumb control in ui/.
- ★2 The tray says "Apply it" / "Apply all N" (the brief's "Apply N") and "Leave it as it is": the tray's own apply words as built, the apply bar's for the discard.
- ★3 PRICE GIVEN UP is Z1's preview figure (zoneAt().priceGivenUp(), its ★12: on the ground the zones hold), noted "on what they hold"; the price given up on ground already sold is a flow nothing records (a new saved field, while P7 owns the load path). Flip: record the discount at LandManager.recordSale(sqFt, price) and save it.
- ★4 Colours: a zone the business violet ramp, then the other categories (a zone is a sector's); built the rest's grey; free for anyone the land office's free-ground pink; the forest three greens off the map's (#527c45, protected). ZONING flags in Palette.ORE, the ground's sand, which no other decision kind takes.
- ★5 Dials: a share 0-100% in half-point steps (Zoning.MAX_SIZE_SHARE); km² 0 to the dry ground in 1/2/5 steps of about a two-hundredth of it; the price 0-100% in five points (TUITION_STEP's twentieth); the law 0-100% in points. A new zone is staged at the going price (100%), as an unzoned sector pays; a new zone of no size applies nothing.
- ★6 "What it carries" and "a plot" are the sector's building with the most ground standing and on site, else its first in buildings.json with ground (ZoningView.plotOf()).
- ★7 THE CITY line says "· 3.2 zoned" in its own style (km² once, at its head: "89.6 dry"), not "3.2 km² zoned".
- ★8 NEEDS YOU's GROUND names what the zones hold whenever the row is listed (free for anyone at a block or less), Real Estate's zone left out (the homes may build there).
- ★9 The land gate names what is zoned for others whenever another zone holds ground (landReason()'s own condition), not only when that alone kept the building out.
- ★10 The ground bar cuts the built ground first, then the law's forest as far as the dry ground goes past it, then the free ground: on an older save built past its bare ground (city600: C settles at its first month's end) or under a law set after building, the law keeps more than stands unbuilt, and the bar shows the built as built. FOREST KEPT is the law's (protected + working).
- ★11 THE BUDGET adds zoningTaxChange() of the staged zoning to PolicyPreview.budget() of the staged policy; the cross term (a staged property offset times a staged price share) is left out.

## 7. For the next batch
- The map's tint of a zone's districts is later (zones are amounts, not places).
- WHAT IS BITING has no zoning flag yet (a zone short of what it wants would be one).
- Docs pass: regenerate the maps (ZoningView.md, ZoningScreen.md; ZoningViewCheck in docs/harnesses.md).

## 8. For Jerus to check on the PC
1. Policy at 1,389 x 868: five chips, five hub cards; Zoning › The ground on a city with forest (jerus-1008): the bar, the hatched held ground, the closer bar.
2. Zone ground for an industry › Agriculture: move HOW MUCH GROUND, switch to km², move ITS PRICE and a tax row, Apply all: the zone's row, Build's LAND FREE "zoned for Agriculture …" and the land office's "· N zoned".
3. The forest law: drag each thumb (the effects follow), Apply; the area's FOREST KEPT and the law card.
4. City History: a zoning decision's flag in sand with the plot icon.

## 9. Outside my files
- BuildCard.java (landGate(); freeFor() in Figures.of(), gate(), appraise()), BusinessInvestment.java (zonedForOthersWords(); landReason() through it, the same words), Game.java (the three ZONING kinds; quoteBuild()'s landFree; the two "Could not build" words - none on P7's load path). Each waits on a zone: nothing moves with none.
