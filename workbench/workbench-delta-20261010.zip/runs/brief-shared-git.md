# Shared rules for every implementer, from 2026-10-10 (the git era)

GitHub (`2048Israel/CityBuilderSim`) is the one source of truth. The orchestrator clones it at `/home/claude/git/CityBuilderSim`, makes each batch a worktree and branch from `origin/main`, and alone merges, tags and pushes after the gate. Jerus's PC pulls `main` every ten minutes. Nothing is written to the PC by hand any more.

**Another implementer may be working beside you** (at most two at once, each on its own batch, branch and worktree; `git-workflow.md`, TWO IMPLEMENTERS AT ONCE). Keep to your files and take the shared JVM lock below.

## Git (from the project doc `claude/git-workflow.md`, verbatim)
**Git.** You work in your own worktree, `<path>`, on branch `batch/<id>`, which the orchestrator made for you. Never leave it, and never touch another worktree or `.git`. Commit there small and often, the version and batch first in the message ("0.7.99 O15: ..."), and commit your final state only after your gate is green. Never push, pull, fetch, tag, merge, rebase, switch branches or stash, and never run `git reset --hard`, `git clean`, `git checkout -- <file>`, `git restore`, `git push --force` or `git worktree remove`: like `rm`, they can throw work away, your own included. Your files are the ones this brief lists. If you must change one outside the list, keep the change as small as you can and list it under "Outside my files" in your notes; the orchestrator sorts it out at the merge.

**Your worktree and branch** are named in the prompt that launched you. Before your first edit, run `git -C <path> status` and `git -C <path> log --oneline -1`: the tree must be clean and at the commit the prompt names.

## Your tree
- Your worktree is the tree. Build it with copies of `/home/claude/bin/build.sh <path>` and `build-ui.sh <path>` in your scratch, without their `rm` line (or copies of `/home/claude/scratch-gate/{build,suite,pt,bmc}.sh`, which have none, every `/home/claude/scratch-gate` changed to your scratch and every `/home/claude/git/CityBuilderSim` to your worktree). Point every other script you copy (suite, playtest, BuildMenuCheck, harness runners) at your worktree, not at `/home/claude/cbs`.
- `/home/claude/cbs` and the `cbs-07xx` snapshots are the old deploy trees. Read them if useful; **never write them.**
- **Probe on copies of** `/home/claude/cities/city600`, `city2400`, `jerus-1007a`, `jerus-1008` and `jerus-old`, copied into your own scratch. A game run autosaves into any city it loads.
- Bump `GameVersion` to your version with an entry in the house shape. Update the counts in `CLAUDE.md` and `README.md` when you add a harness or a building.
- **The `MoneyAudit` must close every month.**
- **Old saves need not load until the game is published** (Jerus, 2026-10-10: "old saves do not matter, only once we publish to old saves matter"). Write no conversion code for them. If your change would make an older save load *wrongly*, bump `SAVE_FORMAT` and raise `GameVersion.OLDEST_LOADABLE_FORMAT` to it in the same batch, so the older save is refused cleanly instead (since 0.7.108 the loader refuses any save below the minimum), and say so in your notes. The probe cities above are old saves too: if your change stops one loading, note it and probe on a city founded and played on your own build instead. When the game is published this rule ends, and old saves must load again.

## Working fast, and never waiting on Jerus (Jerus, 2026-10-10)
Jerus is often away for many hours; a batch that stops to wait for him can sit idle for 20 hours. He wants findings reported, but the work never waits on his answer. Batch P2 (0.7.101) took about five hours, half of it a second round after its premises had already been moved; these three rules are what it showed.

1. **Probe before building.** If your batch changes behaviour, first try the change in rough form against the measurement the batch will be judged by (the auto-built seeds, the playtest, the ensemble, whichever your brief names), before you write the full version or move any harness premise. A rough switch and one measuring run is enough.
2. **When the probe fails or surprises, decide and keep going; don't stop.** Try the variants your brief and Jerus's words allow, and build the one that passes the guardrails while staying closest to what he asked (P2 did this: it kept the revenue budget because removing it stalled 3 of 8 seeds). Put the choice first in your notes' section 6, as one ★ line: what he asked, what you built instead and why, the measurement, and what flipping it would take. Only if no variant passes: commit what is safe on your branch, write the finding up in your notes, and finish. Your branch is not merged and the orchestrator moves on to the next batch. Never wait for an answer.
3. **Targeted checks while you iterate.** Run only the harnesses for the area you are changing (`AllChecks <name> <name>`; `docs/harnesses.md` says which harness mentions which class). Run the full suite once, at the gate. If a targeted run shows a premise must move, finish the behaviour first (rule 1) and move premises once.

## Standing rules
- No command that could raise a permission prompt. No network, except reading project docs through the Projects tool (if you have it; most agents don't, and their briefs quote what they need).
- **Don't use `rm` at all, and never touch `/dev` in any way:**
  - no `2>/dev/null` or `> /dev/null` (write `2> <scratch>/err.txt`);
  - no `/dev/stdout`, `/dev/stderr`, `/dev/stdin` or `/dev/fd`;
  - no reads, `ls`, `grep`, `find` or `diff` on `/dev`, and no `find /`;
  - no process substitution `<(...)`: diff two files you wrote.

  This applies inside heredocs and scripts you write or reuse too. Almost every agent has slipped on one of these; check each command.
- **Scratch:** `/home/claude/scratch-<batch>`. Your first command creates it. Keep it under about 2 GB; harness temp folders and profiler dumps count.
- **JVMs: one at a time on the whole machine, through the shared lock.** The machine has two cores and another implementer may be running. Run every `java` command, and every script that starts one (the builds' `javac` too, the suite, the playtest, a probe), under `flock /home/claude/jvm.lock`, e.g. `flock /home/claude/jvm.lock java -cp ... ham.citybuildersim.AllChecks -q` or `flock /home/claude/jvm.lock bash <scratch>/suite.sh`. It waits for the other's run to end, so the timing checks (PlanCheck's 40 ms, MapCheck's 5 ms) always measure a quiet machine. Hold it for one run at a time, never across a pause. Point `-Djava.io.tmpdir` at your scratch, and set `JDK_JAVA_OPTIONS` for the suite.
- **Write only to:**
  - your worktree;
  - your scratch;
  - your notes `/home/claude/runs/fix<batch>-notes.md` (at most 130 lines) and `/home/claude/runs/fix<batch>-changed.txt` (one path a line, relative to the tree).
- Save slots 1–9 are Jerus's; never write them. Don't grep across `/home/claude/runs` as a whole.
- **Line endings:** the repo stores LF (`.gitattributes`); `.bat` files are CRLF. Write LF, and never convert a file wholesale. Edit byte-safely.
- No invented numbers: every figure from the spec, its sources, or a named constant with its reason.
- **Restarts:** the workspace can restart without warning (it did on 2026-10-09). Commit as you go, and keep your notes current, a line per step done, so another agent can finish from your branch.

## The gate (once, at the end)
- Both builds silent.
- The full suite green except HealthCheck.
- BuildMenuCheck PASS, with the count your batch sets (101 today).
- `tools.Stale` 0 firm.
- The playtest as your brief says.
- **Line endings:** `git -C <path> ls-files --eol` shows no `w/crlf` except `.bat` files.
- **MapCheck's 5 ms month bound** (wall clock) fails about one run in ten on this two-core machine. If it fails, run MapCheck alone 10 times and report each run's worst month. Don't change it.

Leave `tools.Maps` to the docs pass.

**Then commit** your final state on your branch, with the version and batch first in the message.

## Notes: `/home/claude/runs/fix<batch>-notes.md`
1. What you built.
2. Departures, with reasons.
3. Premises changed (before → after) and the new assertions.
4. Trace movement, explained.
5. The gate, and your final commit's hash.
6. ★ calls. First, any choice you made in place of what Jerus asked (rule 2 above), one line each.
7. **For the next batch.**
8. **For Jerus to check on the PC:** at most 4 items.
9. **Outside my files** (if any).
