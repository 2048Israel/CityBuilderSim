# Brief: P4, oil and roads. 0.7.103. 2026-10-10

You are an implementer, on Opus with a fresh context. Decide, and mark judgement calls ★ with reasons.

## Jerus's decisions (2026-10-10, the project doc `claude/decisions-2026-10-10.md`, "all rec"; quoted here, as you cannot reach the project)
- **A7:** a fuel duty to the treasury on top of wholesale and sales tax -> **a Policy dial, default 0.**
- **A8:** a reserve release the refiners don't take -> **stays in the tanks** (not shipped abroad).
- **A9:** one lube plant makes 9.6% of a refinery's crude into lubricants (real about 1%) -> **cap the world's demand for them.**
- **A11:** gravel is cheaper to keep than paved (upkeep 1% of price a year for every road) -> **each road kind its own sourced upkeep.**
- **B:** "dry" on the Oil Well card's site count; "no feed" on a conversion unit's card with no crude unit.

## Where each was found (`/home/claude/runs/records/todo.md` line numbers as of 01:50)
- A7: line 1704 ("Oil's prices, the pump and the stations"); `runs/fixO2-notes.md` §8.1-8.2, `runs/fixO6-notes.md` §6 O6-1 to O6-6; `runs/spec-oil.md` 6 A ("the third way").
- A8: line 1743 ("A release the refineries don't take ships abroad..."); `runs/fixO8-notes.md`; `StrategicReserve`, `Game.releaseReserve()`.
- A9: line 1723 ("Lubricants and the refinery's units"); `runs/fixO5-notes.md` §7, `runs/fixO4-notes.md` §7. The world's demand for lubricants is what an export can sell: ★ the cap's form and its source (the real share is about 1% of crude; the research's risk line 2%).
- A11: line 1641 ("A road priced over its life, and gravel's upkeep"); `runs/fixN1-notes.md` §2 item 2 and §6; `RealEstate.MAINTENANCE_PER_YEAR`, `BuildAdvice`'s road over its life. Every road kind's upkeep from a named source (a published road-maintenance cost a km a year by surface), not an invented figure.
- B: lines 1720 and 1729; `BuildCard`.

## Do
1. **A7, the fuel duty:** a Policy dial (the Policy tab's tax rows; its `Ladder` entry; `PolicyPreview` shows it), default 0, levied a litre on petrol and diesel sold at the pump, paid to the treasury as its own budget line (inside the budget's totals since 0.7.102), the pump price rising by it. At 0 nothing moves.
2. **A8:** a release the refiners don't take stays in the reserve's tanks; the reserve's books and the treasury agree; OilCheck 16 asserts it.
3. **A9:** cap the world's demand for lubricants so a refinery cannot sell abroad more than the cap's share; the playtest and `jerus-1008` measured before and after.
4. **A11:** each road kind (gravel, paved, the highway and any other the tree has) its own upkeep, sourced; the advice's road over its life reads it.
5. **B:** the two card words; every string fits at 1,389 x 868.
6. **Harnesses:** each change asserted; a premise moves only where a decision changes the rule it asserts (list before -> after in §3).

## Batch
| batch | version | worktree / branch | scratch | traces |
|---|---|---|---|---|
| P4 | 0.7.103 | named in the launch prompt | `/home/claude/scratch-p4` | expected to move (A11's upkeep, and A9 if the playtest's refiners sell lubricants abroad): re-baseline as `pt07103` against the reference the launch prompt names, every move explained; then the ensemble (label `07103`, `BASELINE` the launch prompt names); report, don't tune. If they don't move, say so and skip the ensemble |

## Shared rules
**Follow `/home/claude/runs/brief-shared-git.md` in full.** Suite 90 of 91: HealthCheck stays the known red (by 0.4 points since 0.7.100, a call for Jerus); every other harness green. BuildMenuCheck 101. Old saves load and the audit closes: copies of the five research cities, 24 months each.

Reply with: a short summary; each road kind's upkeep and its source; the lubricants cap and its source; the trace movement explained; the ensemble; the gate and your final commit; your ★ calls.
