# fixP1 notes - 0.7.100 "the checks": HealthCheck O1, the ensemble's S1 and H1, MapCheck on thread CPU. Implementer (Opus), 2026-10-10
Worktree `/home/claude/git/wt-P1`, branch `batch/P1` from fb20b5e (clean at start). Brief `runs/brief-batchP1.md`; Jerus's A14, A27, A28.
No Projects tool here (the orchestrator confirmed): the trace was read as `runs/records/todo.md`'s "AFTER 0.7.17: HEALTHCHECK SHIPS RED",
the spec as `runs/spec-inflation.md`. Scratch `scratch-p1/`: build/bmc/suite/pt/gate/mc10 scripts (no rm, no /dev), `probe/` HcProbe.

## 0. Steps (a line per step)
- s1 tree clean at fb20b5e, scratch made.
- s2 HealthCheck O1: one depot stands. Gap 19.7 (0.7.99) -> 5.4 (money half +0.1, shelf half +5.3): still red by 0.4. Committed.
- s3 MapCheck A28: the month bound on the main thread's CPU, the wall clock beside it. Committed.
- s4 GameVersion 0.7.100. Committed. No count moves.
- s5 Ensemble: driver ZERO_SLACK from 1,800; score.py S1/H1 restated; baseline rebuilt from out/0741/score.md. Run as label 07100.
- s6 S1's runaway guard first written as the yoy gap to the twin's same month; it read the shelf cycle's phase; replaced before scoring.
- s7 Ensemble done: 24/26 (A2, S1 red). s8 gate (02:03-02:17): green but HealthCheck. s9 comment fix (classes identical). s10 MapCheck x10.
- s11 final commit 96a6c84 (section 5). Done.

## 1. What I built
- **HealthCheck 13 (A14, "O1"):** one Construction Depot stands with the poor-city fixture, `b.addStack(..., 1, true)` (the fixture's own
  call, as its clinics), under a banner in round 1's shape (ForeignCheck's THE BUILDERS' DEPOTS STAND FROM THE START). The twins' line
  prints the year's hunger in its two halves (`getHungerPricedOut()`, `getHungerShortOfStock()`, which add to the rate) and a line before
  the assertion prints the gap and its halves. No assertion, premise, direction or tolerance touched.
- **MapCheck 5 (A28):** a month's change at 5B and 10B timed by `monthClock()`: `ThreadMXBean.getCurrentThreadCpuTime()` when
  `isCurrentThreadCpuTimeSupported()` and enabled (enabled if it is off), else `System.nanoTime()`; `CPU_TIMED` says which in the output
  and the label. Bound still `RECONCILE_MS` 5, on the same months (the year of +0.01% and the -0.05%). Every month printed CPU/wall, the
  bounded months' worst (CPU), its wall and the wall's worst. The why in the header's item 5, the constant's sentence and a banner above
  `cost()`: RD7 4 and its star 4, RD7 7, O11 5.
- **GameVersion 0.7.100**, entry in the house shape; harnesses only, save format 36. CLAUDE.md/README counts unchanged.
- **The ensemble (outside the tree, section 9):** ZERO_SLACK holds 0% from `SLACK_START` 1,800; S1 and H1 restated in `score.py`
  (THE PREMISES RESTATED, each reason sourced to the spec); H2 now judged whenever H1 finds a burst.

## 2. Departures, with reasons
- **HealthCheck is not green.** O1 as decided leaves the gap at 5.4 against 5. The 0.7.23 trace's "40.0 -> 1.0" predates 0.7.43's baskets
  at a price: the residue is the grocers' shelf, not the clinic. I did not change the depot count or the measure (star 1).
- **Baseline:** neither `out/0799/summary.json` nor `out/0741/summary.json` exists (the out folders hold only score.md). I rebuilt
  0741's from its score.md's T1/T2/F1 rows (`scratch-p1/baseline-0741.json`), which are the figures 0799's score shows as its baseline.

## 3. Premises changed (before -> after) and the new assertions
- **HealthCheck:** none. Gap before (0.7.99): free 2.2%, dear 21.9% = 19.7 points (0.7.23: 40.0). After: free 10.6%, x1 7.1%, dear 16.0%
  = 5.4 points: priced out of a basket 6.6 / 7.0 / 6.7 (+0.1), short on the shelf 4.0 / 0.0 / 9.3 (+5.3). Ends 18,012 / 15,805 / 16,998
  people (were 7,653 / 6,773 / 6,340). Probe on 0.7.99's classes (`hcprobe-*.txt`): without the depot the dear twin's first depot stood
  on site 80 months after the fee; with it each twin had 3 depots by m48. Information only, not shipped: 2 depots read 1.5 points, 4
  read 3.5 (shelf half +1.1, +4.2; money half +0.4, -0.7). The shelf half is weather of several points either way.
- **S1** (before: hold from m600; the window's own inflation, median <= 3%, every seed <= 5%, no month's yoy > 10%; 0799: 5.35%
  [3.16 to 7.14], peak 20.75%, FAIL). **After:** hold from m1,800; the window minus its AUTO2 twin's, median <= +1 point (ANCHOR_TOL, the
  anchor's TOLERANCE, spec 2.1 and star 14), every seed <= +3, and no spell of yoy > 10% for 12 months (A2's runaway). **Reads +1.41%
  [0.93 to 2.27]; longest spell 13 months (seed 0 from m1881, peak 17.6%; seed 3 12 from m1988): FAIL** on the median and the spell.
  Beside it: the window's own 3.48% [3.02 to 4.42]; peak yoy 11.95% [8.32 to 17.65] against the twin's 4.78% [2.65 to 9.76];
  unemployment 12.8% [4.9 to 16.6] against the twin's 12.9% (a slack city, which m600 was not); at m2040 fx +38.7% weaker, rent +24.5%.
- **H1** (before "builds": 2nd half >= 5%, minus the 1st >= +1, minus the twin >= +3; 0799 4.17%; -1.32; +2.12, FAIL). **After
  "persists":** 1st half minus twin >= +1, 2nd half minus twin >= +1 (medians; the anchor's tolerance: past it credibility keeps falling),
  2nd minus 1st < +1 (no acceleration: spec star 1 rules it out, and the old acceleration threshold now caps it). **Reads +2.55% [0.54 to
  6.21]; +2.12% [0.83 to 4.08]; -1.32% [-4.11 to 0.64]: PASS.** Every seed's 2nd half above its twin's; 13 of 16 slower than the 1st.
- **H2** thresholds as written, no longer vacuous: **2.65% [1.06 to 3.64], 12/16 below the 2nd half: PASS**; minus the twin -1.96%.
- **Score 24/26** against 0799's 22/25 (H2 now counted). Red: A2 and S1. Every other row is 0799's to the figure (model unchanged).

## 4. Trace movement
- Playtest: the 8 traces byte-identical to `scratch-ui1/orch-gate/pt0799`. HealthCheck's twins move with the fixture (section 3).

## 5. The gate
Run alone by `scratch-p1/gate.sh` on the tree at 6123d80 (02:03-02:17; `gate.log`).
- Builds silent: model and UI (`b-model.txt`, `b-ui.txt` 0 bytes).
- Suite (`suite.txt`, 700 s): 91 run, 90 passed. **HealthCheck red** on its one known label at 5.4 points (section 2). MapCheck OK (months
  CPU 0.58 at 5B, 1.24 at 10B; walls 0.59, 1.25); PlanCheck OK.
- BuildMenuCheck PASS, 101 of 101. `tools.Stale`: 0 firm; soft 97 unresolved, 304 map older, 13 fuzzy (none from this batch).
- Playtest: exit 0, 8 of 8 traces identical to pt0799; "Nothing. Every month passed the audit and every reload matched."
- Line endings: `git ls-files --eol`: no w/crlf outside .bat. All three edited files LF, as their base.
- After the gate one comment in HealthCheck named a getter in full; rebuilt, `diff -rq` against the gate's classes: identical.
- **MapCheck alone 10 times** (`mc10.sh`, `mc10.out`, `mc-run1..10.txt`; gate classes, load 1.4-2.1): **10 of 10 OK**, every
  assertion. Bounded months' worst, ms of CPU / its wall clock; the wall clock's worst:

  | run | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
  |---|---|---|---|---|---|---|---|---|---|---|
  | 5B CPU/wall | .53/.53 | .55/.56 | .52/.52 | .50/.51 | .63/.63 | .62/.90 | .56/.56 | .57/1.20 | .52/.53 | .59/.59 |
  | 5B wall worst | 0.53 | 2.26 | 0.52 | 1.83 | 2.79 | 4.94 | 2.48 | 2.38 | 3.81 | 0.59 |
  | 10B CPU/wall | .98/1.55 | .96/.96 | 1.03/1.03 | .89/.90 | 1.03/1.04 | 1.07/1.07 | .92/.92 | 1.44/1.44 | .86/.87 | 1.06/1.08 |
  | 10B wall worst | 1.55 | 1.51 | 1.03 | 1.43 | 1.47 | 1.07 | 0.92 | 1.51 | 1.46 | 1.08 |

  The first loaded run (s3, load 5.5): CPU 0.58 and 1.10, walls up to 8.40 (a 0.39 ms CPU month) and 5.03; its screen ratio failed
  on the wall clock (x 1 at 1.82 of the 5B copy's, bound 1.5; not mine, not seen again in 11 runs).
- Slips: none. No rm, nothing on /dev, one JVM at a time. Saves: none touched.
- Final commit: **96a6c84** on `batch/P1` (4 commits over fb20b5e); `git status` clean.

## 6. Star calls
1. **HealthCheck keeps ONE depot, red by 0.4.** A14 said one; 2 and 4 pass (measured for information), but choosing the count by the
   result is tuning the fixture to the line. Reading only the money half (+0.1) would move the premise. The halves are printed instead.
2. **S1 against its twin.** At m1,800 the autopilot's own weather is in the window (A2), so the policy's effect is the run minus its twin;
   the old thresholds become their excess over the 2% target (3% -> +1, 5% -> +3), the +1 being the anchor's tolerance. The month-by-month
   guard became A2's 12-month runaway: the first form (yoy gap to the twin's same month <= +8) measured the shelf cycle's phase (seed 0
   m1890: 16.3% against -4.1%, a +20.4 gap) and was replaced before the score was taken. Both are disclosed in score.py and printed.
3. **H1 "persists"** as the spec's star 1 and star 14 put it: both halves beyond the anchor's tolerance over the twin, and the old
   acceleration threshold kept as a ceiling, which a spiral (the spec's 5, failure 4: hyperinflation at 0%) would break.
4. **H2 as written**: it now asks whether the autopilot stops a burst H1 found.
5. **SLACK_START 1,800**, the spec's section 8 month; a `-Densemble.slackStart` like hotStart; MATURE stays 600 for SHOCK and HIGH.
6. **MapCheck's clock** enables thread CPU timing if supported but off, and falls back to the wall clock, saying so in the label.

## 7. For the next batch
- **HealthCheck** stays red until Jerus picks (section 8). The probe is `scratch-p1/probe/ham/citybuildersim/HcProbe.java` (arg: depots).
- **S1 reads red in a slack mature city:** a held 0% runs +1.4 points a year over its twin for 20 years and the currency keeps
  weakening (seed 0: fx over its twin's 1.06 a year in, 1.19 at five, 1.37 at ten, 1.51 at twenty). The spec's star 16 says UIP reversion stops a held 0%
  compounding; here the gap grows all window, slowing. Model or premise: Jerus's.
- **A2 watched:** seed 8, 13 months from m628 (peak 15.6%); seed 13, 16 from m394 (21.2%); 0799's figures exactly. Seeds 2, 10, 12 at 11.
- **score.py, not touched:** A3's verdict prints "True" and is not counted (numpy bool fails `ok is True`; 0799 too). ZERO_SLACK's T2 now
  compares m2040 with 0741's m840 baseline (156,451 against 18,209): vacuous; `out/07100/summary.json` is the next baseline.
- **out/07100** holds 80 CSVs (46 MB).
- **Docs pass:** harnesses.md (MapCheck's two labels now name the clock), dials.md (MapCheck.THREADS, CPU_TIMED; RECONCILE_MS's
  sentence), maps for HealthCheck, MapCheck and GameVersion. Leave `tools.Maps` to it.

## 8. For Jerus to check on the PC
1. HealthCheck: O1 applied and still red by 0.4 (money +0.1, shelf +5.3). Choose: read the money half (a premise change), accept red,
   or have a fixture keep the shelves (another fixture change).
2. S1 under the new premise reads red (+1.41 a year, the currency 39% weaker, two seeds a year-plus over 10%). The city you want?
3. H1 now asks for "a burst that persists, not a spiral" and passes; H2 passes. Confirm that is the claim.
4. MapCheck's output line on the PC should say "the main thread's CPU". If it says the wall clock, the JVM there cannot time threads.

## 9. Outside my files
Workbench `/home/claude/runs/ensemble/` (originals in `scratch-p1/ensemble-orig/`; `diff` them for the full change):
- `src/ham/citybuildersim/Ensemble.java`: before, ZERO_SLACK held from `MATURE` (600) in `end()`, `heldRate()` and `phase()`. After,
  `SLACK_START` = `-Densemble.slackStart`, default 1800, with its reason; MATURE's javadoc names SHOCK and HIGH only; the usage line.
- `score.py`: docstring's ZERO_SLACK/S1 and ZERO_HOT/H1/H2 lines (before as quoted in section 3); THE PREMISES RESTATED (ANCHOR_TOL,
  SLACK_EXCESS_MEDIAN, SLACK_EXCESS_SEED, HOT_PERSIST_MIN, the reasons); S1's block (paired, A2's spell, new info rows: peaks, the gap
  to the twin's month, unemployment); H1's block (`burst`; info rows for both halves and the tail against the twin); H2's vacuity on
  `burst` ("no burst to stop"); EXPECTED_END ZERO_SLACK 840 -> 2040, and set from its phase. A2 and every other criterion unchanged.
- Written by run.sh: `out/07100/` (CSVs, times.txt, score.md, summary.json), `classes/07100/`, `tmp/`.
