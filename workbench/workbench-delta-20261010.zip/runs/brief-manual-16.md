# Brief: manual 16, from 0.7.77 to 0.7.106, in two parts. 2026-10-10 evening

You are a manual writer, on Opus with a fresh context. The manual is a published page that writes the model out in full. Its source is **`/home/claude/runs/manual/index.html`**, current to 0.7.77 (its own record `runs/manual-0777.md`); the live page is version 15 (0.7.69). Version 16 brings it to 0.7.106. Jerus is away; decide, and note judgement calls in your record.

## Two writers, one after the other (they edit one file)
| part | versions | the notes in `/home/claude/runs/` (read §1, §2, §6 and §8 of each; §7 for what changed later) |
|---|---|---|
| 1 | 0.7.78-0.7.92 | `fixO2` (wholesale fuel prices), `fixO3` (grades, depth), `fixO4` (refinery units, the flow), `fixN6` (auto-build's limit), `fixO5` (the spread planner), `fixO6` (the forecourts, vans' diesel, bitumen), `fixO7` (oil wells, land wells on dry sites), `fixO8` (the Tank Farm, the strategic reserve), `fixO9` (ports, sea freight, boats), `fixRD1`, `fixRD2`, `fixRD3` (streets by need, the painter, highways and rail), `fixRD5`, `fixRD6` (estate cells), `fixO10` (oil at sea) |
| 2 | 0.7.93-0.7.106 | `fixO10b` (two oil pools), `fixRD7` (speed), `fixO11`, `fixO12`, `fixO13`, `fixO14` (the refinery picture, the oil page, the map at sea, the slate shipped), `fixW1` (fewer and bigger deposits), `fixP1` (the checks), `fixP2` and `fixP2b` (automatic building and the advice; the payback), `fixP3` (the budget and the books), `fixP4` (fuel duty, the reserve, lubricants, road repairs), `fixP6` (the refinery's run), `fixP5` (prices and rules); then the masthead, the "what moved" paragraph, the publish file and the tree's copies |

**The code wins:** check every figure against the tree, read-only at `/home/claude/git/CityBuilderSim` (`main`, 0.7.106: navigate by `docs/map/`, `docs/dials.md`, `docs/harnesses.md`). Where a later version changed what an earlier one built, write today's rule (part 1 writes 0.7.78-0.7.92's mechanisms as they stand at 0.7.106). The project's write-ups for these versions (in `/home/claude/runs/records/`: `the-day-after-the-grid.md`, `the-streets-by-need.md`, `the-oil-chain-finished.md`, `fewer-and-bigger-deposits.md`, `the-fixes-from-the-decisions.md`) are the plain-words summaries.

## Standing rules
- No command that could raise a permission prompt. No network. You have no Projects tool.
- **Don't use `rm` at all, and never touch `/dev` in any way.** No `2>/dev/null` (write `2> <scratch>/err.txt`), no `/dev/stdout`, `/dev/stdin` or `/dev/stderr`, no `find /`, no `<(...)` (not even a throwaway `diff <(echo) <(echo)`), no `grep ... /dev/null`.
- **Before your first edit,** copy `index.html` to `/home/claude/runs/manual/index.before-07<part>.html` (part 1: `index.before-0778.html`; part 2: `index.before-0793.html`). Edit byte-safely, with Python on bytes, replacing exact spans. Keep the file's line endings and its HTML conventions. **Keep `&mp;` as it is (it is ∓).**
- **Don't read the big file whole** (about 800 KB). Find each `<h2>` with `grep -n`, then read sections with `sed -n`. Don't grep across `/home/claude/runs` as a whole.
- Every `java` run (part 2's ManualToMarkdown) under `flock /home/claude/jvm.lock`.
- **Write only to:**
  - `runs/manual/index.html` (both parts) and `runs/manual/manual-publish.html` (part 2);
  - part 2 only: `docs/manual.html` and `docs/manual.md` in its own worktree (named in its launch prompt), committed there;
  - your scratch (named in your launch prompt);
  - your record `/home/claude/runs/manual-16-part<N>.md`.

## Write
Bring the manual to your versions in its own voice: each mechanism as the player meets it, its rule and its numbers (from the code's constants), the screens that show it, and the harnesses that hold it (the harness table and counts). Part 1 covers the oil chain's first half (wholesale fuel, grades and depth, the refinery's units and their flow, the spread planner, the forecourts, wells, storage and the reserve, ports and boats, oil at sea), auto-build's debt limit as it now reads, and the streets by need (the plan, the painter, highways and rail, estate cells). Part 2 covers the rest of your table, then:
- the masthead's edition line: "Build 0.7.106 · Save format 36 · 10 October 2026";
- the "what moved since the last edition" paragraph (0.7.69 to 0.7.106: the version 15 reader's view);
- **`manual-publish.html`** with `runs/manual/tools/publish.py`: first check that it rebuilds the current `manual-publish.html` from `index.before-0778.html` (0.7.77's source) byte for byte, then that the new one differs only in the manual's new passages;
- **the tree's copies** with `tools.ManualToMarkdown` (`--wrap` into `docs/manual.html`, then `docs/manual.md`), using classes built from your worktree; commit them on your branch ("0.7.106 manual-16: ...").
- **Don't publish.** The orchestrator publishes when Jerus says so.

## Record: `/home/claude/runs/manual-16-part<N>.md`, at most 90 lines
Each section you changed and what it says now; the figures you checked and any record/code disagreements; anything unsettled; for part 1, what part 2 needs to know.

Reply with a short summary.
