#!/bin/bash
# pt.sh <name> [refdir] - the default playtest on a copy of scratch-w1/classes; traces to scratch-w1/<name>/t-*.csv, compared with the reference
N=${1:?name}; S=/home/claude/scratch-gate
REF=${2:-/home/claude/scratch-ui1/orch-gate/pt0786}
GSON=/opt/apache-maven-3.9.11/lib/gson-2.13.1.jar
mkdir -p $S/$N/classes $S/tmp
cp -a $S/classes/. $S/$N/classes/
cd $S/$N && java ${JOPTS:-} -Djava.io.tmpdir=$S/tmp -Dplaytest.trace=$S/$N/t -cp "$S/$N/classes:$GSON" ham.citybuildersim.LongPlaytest > $S/$N/report.txt 2>&1
echo "exit $?"
for f in $REF/t-*.csv; do b=$(basename $f); cmp -s $f $S/$N/$b && echo "$b identical" || echo "$b DIFFERS"; done
grep -n "FINDING\|Findings\|finding" $S/$N/report.txt | head -5
